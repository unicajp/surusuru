
import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../game/game_controller.dart';
import '../sfx_manager.dart';
import '../widgets/game_bottom_nav.dart';
import 'rpg_home_screen.dart';
import 'shop_screen.dart';
import 'stage_map_screen.dart';
import 'training_screen.dart';

/// V16.37.5.59 CHANCE_MODE_MINIGAME
///
/// New visual/physics prototype:
/// - 3000 Surusuru for test play.
/// - Manual connect from the upper hub.
/// - Auto connect up to 30 in one hold.
/// - Smaller, staggered pachinko-style pin field.
/// - Three small branch bumpers near the top.
/// - Central special star bumper.
/// - Five bottom pockets with real separator collisions.
/// - Strong pocket/branch/star flashes and trails.
class SurusuruPlayScreen extends StatefulWidget {
  final GameController controller;

  const SurusuruPlayScreen({
    super.key,
    required this.controller,
  });

  @override
  State<SurusuruPlayScreen> createState() => _SurusuruPlayScreenState();
}

class _DropPiece {
  _DropPiece({
    required this.id,
    required this.type,
    required this.x,
    required this.y,
    required this.vx,
    required this.vy,
  });

  final int id;
  final int type;
  double x;
  double y;
  double vx;
  double vy;
  double angle = 0;
  double spin = 0;
  bool scored = false;
  bool branchTriggered = false;
  int branchCooldown = 0;
  bool starTriggered = false;
  int slowCenterFrames = 0;
  final Set<int> hitUPockets = <int>{};
  final List<Offset> trail = <Offset>[];
}

class _RewardToken {
  _RewardToken({
    required this.amount,
    required this.origin,
    required this.startedAt,
  });

  final int amount;
  final Offset origin;
  final DateTime startedAt;
  bool arrived = false;
}

class _ConnectionFlash {
  _ConnectionFlash(this.port, this.startedAt);
  final int port;
  final DateTime startedAt;
}

class _PocketBurst {
  _PocketBurst({
    required this.center,
    required this.text,
    required this.startedAt,
    required this.kind,
  });

  final Offset center;
  final String text;
  final DateTime startedAt;
  final int kind;
}

class _SurusuruPlayScreenState extends State<SurusuruPlayScreen> {
  final math.Random _random = math.Random();

  final List<_DropPiece> _pieces = <_DropPiece>[];
  final List<_ConnectionFlash> _flashes = <_ConnectionFlash>[];
  final List<_PocketBurst> _bursts = <_PocketBurst>[];
  final List<_RewardToken> _rewardTokens = <_RewardToken>[];

  int _rewardCounter = 0;
  DateTime? _lastCounterAddAt;
  DateTime? _expBeamStartedAt;
  DateTime? _expCountStartedAt;
  static const int _expBeamTravelDurationMs = 720;
  int _expBeamAmount = 0;
  int _expTransferApplied = 0;
  int _expTransferDurationMs = 0;
  DateTime? _lastExpTickSfxAt;

  Timer? _physicsTimer;
  Timer? _autoTimer;

  Size _boardSize = Size.zero;
  int _nextPieceId = 1;

  int get _surusuru => widget.controller.surusuruBalance;
  int _monsterExp = 0;
  int _monsterLevel = 1;

  int _autoUsed = 0;
  bool _autoRunning = false;

  bool _manualDragging = false;
  Offset? _manualFinger;
  int? _manualHoverPort;

  bool _miniGameOpen = false;
  bool _batchActive = false;
  bool _batchSettlementStarted = false;
  bool _holdCounterForBatch = false;
  int _centerPocketHits = 0;

  DateTime? _lastPegSfxAt;
  DateTime? _lastWallSfxAt;
  DateTime? _lastPieceSfxAt;

  bool get _dropBusy =>
      _autoRunning ||
      _pieces.isNotEmpty ||
      _miniGameOpen ||
      _batchSettlementStarted ||
      _rewardTokens.isNotEmpty ||
      _rewardCounter > 0 ||
      _expBeamStartedAt != null;

  static const int _portCount = 5;
  static const int _autoMax = 30;

  @override
  void initState() {
    super.initState();
    _physicsTimer = Timer.periodic(
      const Duration(milliseconds: 16),
      (_) => _tick(),
    );
  }

  @override
  void dispose() {
    _physicsTimer?.cancel();
    _autoTimer?.cancel();
    super.dispose();
  }

  double _pieceRadius(Size size) =>
      (size.width / 68).clamp(4.5, 6.0).toDouble();

  double _pegRadius(Size size) =>
      (size.width / 104).clamp(3.0, 4.2).toDouble();

  Rect _playRect(Size size) {
    // Restore the original vertical height, while narrowing the board width.
    final top = math.max(112.0, size.height * .205);
    final bottom = size.height - 122.0;
    final side = math.max(42.0, size.width * .16);
    return Rect.fromLTRB(side, top, size.width - side, bottom);
  }

  Offset _hub(Size size) =>
      Offset(size.width / 2, math.max(52.0, size.height * .085));

  List<Offset> _ports(Size size) {
    final y = math.max(88.0, size.height * .145);
    final side = math.max(48.0, size.width * .18);
    final left = side;
    final right = size.width - side;
    return List<Offset>.generate(
      _portCount,
      (i) => Offset(
        left + (right - left) * i / (_portCount - 1),
        y,
      ),
    );
  }

  List<({String label, Offset center})> _letterBumpers(Size size) {
    final r = _playRect(size);
    final topY = r.top + r.height * .31;
    final bottomY = r.top + r.height * .62;

    // Upper row:  S   U   R   U
    // Lower row:  S   U   ★   R   U
    return <({String label, Offset center})>[
      (label: 'S', center: Offset(r.left + r.width * .14, topY + 6)),
      (label: 'U', center: Offset(r.left + r.width * .38, topY - 8)),
      (label: 'R', center: Offset(r.left + r.width * .62, topY + 5)),
      (label: 'U', center: Offset(r.left + r.width * .86, topY - 4)),

      (label: 'S', center: Offset(r.left + r.width * .10, bottomY - 6)),
      (label: 'U', center: Offset(r.left + r.width * .27, bottomY + 10)),
      (label: 'R', center: Offset(r.left + r.width * .74, bottomY + 10)),
      (label: 'U', center: Offset(r.left + r.width * .90, bottomY - 6)),
    ];
  }

  Offset _starBumper(Size size) {
    final r = _playRect(size);
    // Move the ★ slightly upward so it is visually distinct from the
    // mini-game entrance mechanism below.
    return Offset(r.center.dx, r.top + r.height * .615);
  }

  List<Offset> _pegs(Size size) {
    final r = _playRect(size);
    if (r.height < 250) return const <Offset>[];
    return <Offset>[
      Offset(r.left + r.width * .23, r.top + r.height * .47),
      Offset(r.left + r.width * .50, r.top + r.height * .43),
      Offset(r.left + r.width * .77, r.top + r.height * .47),
      Offset(r.left + r.width * .20, r.top + r.height * .78),
      Offset(r.left + r.width * .80, r.top + r.height * .78),
    ];
  }

  List<Offset> _bottomPockets(Size size) {
    final r = _playRect(size);
    final y = r.bottom - 25;
    return List<Offset>.generate(
      5,
      (i) => Offset(r.left + r.width * (i + .5) / 5, y),
    );
  }

  List<double> _separatorXs(Size size) {
    final r = _playRect(size);
    return List<double>.generate(
      4,
      (i) => r.left + r.width * (i + 1) / 5,
    );
  }

  List<({Offset a, Offset b})> _miniGameGuards(Size size) {
    final r = _playRect(size);
    final cx = r.center.dx;

    // Final stage is deliberately simple and readable:
    // one straight-drop blocker and two side rails. The visible purple hole
    // itself is the only scoring trigger; there are no hidden qualifications.
    return <({Offset a, Offset b})>[
      (
        a: Offset(cx - 58, r.bottom - 108),
        b: Offset(cx - 27, r.bottom - 88),
      ),
      (
        a: Offset(cx + 58, r.bottom - 108),
        b: Offset(cx + 27, r.bottom - 88),
      ),
    ];
  }

  Offset _miniGameBlocker(Size size) {
    final r = _playRect(size);
    return Offset(r.center.dx, r.bottom - 112);
  }

  bool _allowSfx(DateTime? last, int milliseconds) {
    if (last == null) return true;
    return DateTime.now().difference(last).inMilliseconds >= milliseconds;
  }

  void _pegSfx() {
    if (!_allowSfx(_lastPegSfxAt, 55)) return;
    _lastPegSfxAt = DateTime.now();
    SfxManager.instance.traceStep(1 + _random.nextInt(3));
  }

  void _wallSfx() {
    if (!_allowSfx(_lastWallSfxAt, 90)) return;
    _lastWallSfxAt = DateTime.now();
    SfxManager.instance.tap();
  }

  void _pieceSfx() {
    if (!_allowSfx(_lastPieceSfxAt, 70)) return;
    _lastPieceSfxAt = DateTime.now();
    SfxManager.instance.spawn();
  }

  void _tick() {
    if (!mounted || _boardSize == Size.zero) return;

    _tickRewardFlow();
    if (_miniGameOpen) {
      if (_rewardTokens.isNotEmpty ||
          _rewardCounter > 0 ||
          _expBeamStartedAt != null) {
        setState(() {});
      }
      return;
    }

    final size = _boardSize;
    final rect = _playRect(size);
    final radius = _pieceRadius(size);
    final pegR = _pegRadius(size);
    final pegs = _pegs(size);
    final letterBumpers = _letterBumpers(size);
    final star = _starBumper(size);
    final pockets = _bottomPockets(size);
    final separators = _separatorXs(size);

    for (var index = 0; index < _pieces.length; index++) {
      final p = _pieces[index];
      if (p.scored) continue;
      if (p.branchCooldown > 0) p.branchCooldown--;

      final previousPosition = Offset(p.x, p.y);

      p.vy = math.min(p.vy + .17, 7.8);
      p.vx += (_random.nextDouble() - .5) * .025;
      p.vx *= .998;
      p.x += p.vx;
      p.y += p.vy;
      p.angle += p.spin;

      p.trail.add(Offset(p.x, p.y));
      if (p.trail.length > 8) p.trail.removeAt(0);

      // Swept side walls: even if a fast piece crosses beyond the wall
      // between frames, force it back inside and reflect the velocity.
      final leftLimit = rect.left + radius;
      final rightLimit = rect.right - radius;
      if (p.x < leftLimit ||
          (previousPosition.dx >= leftLimit && p.x < leftLimit)) {
        p.x = leftLimit + .35;
        p.vx = math.max(.9, p.vx.abs() * (.86 + _random.nextDouble() * .10));
        p.spin += .025;
        _wallSfx();
      } else if (p.x > rightLimit ||
          (previousPosition.dx <= rightLimit && p.x > rightLimit)) {
        p.x = rightLimit - .35;
        p.vx = -math.max(.9, p.vx.abs() * (.86 + _random.nextDouble() * .10));
        p.spin -= .025;
        _wallSfx();
      }

      // Small metallic pins.
      for (final peg in pegs) {
        final pegHit = _bounceCircle(
          p,
          peg,
          pegR,
          radius,
          restitution: .82 + _random.nextDouble() * .13,
          randomKick: .7,
        );
        if (pegHit) _pegSfx();
      }

      // Round SURUSURU letter bumpers.
      // Swept collision prevents tunnelling. Every valid hit gives EXP.
      for (var bumperIndex = 0;
          bumperIndex < letterBumpers.length;
          bumperIndex++) {
        final bumper = letterBumpers[bumperIndex];
        final hit = _bounceCircleSwept(
          p,
          previousPosition,
          bumper.center,
          13,
          radius,
          restitution: .88,
          randomKick: .72,
        );

        if (hit) {
          final gain = bumper.label == 'U' ? 1 : 2;
          if (bumper.label == 'U') {
            SfxManager.instance.traceStep(4);
          } else {
            SfxManager.instance.reaction();
          }
          _queueReward(gain, bumper.center);
          _bursts.add(
            _PocketBurst(
              center: bumper.center,
              text: '$gain',
              startedAt: DateTime.now(),
              kind: bumper.label == 'U' ? 0 : 1,
            ),
          );
        }
      }

      // Central star. Physical collision and EXP reward are active every hit.


      final starHit = _bounceCircleSwept(
        p,
        previousPosition,
        star,
        24,
        radius,
        restitution: .96,
        randomKick: 1.15,
      );
      if (starHit) {
        SfxManager.instance.lightning();
        _queueReward(5, star);
        _bursts.add(
          _PocketBurst(
            center: star,
            text: '5',
            startedAt: DateTime.now(),
            kind: 2,
          ),
        );
      }

      // Tiny character-to-character bounce.
      for (final q in _pieces) {
        if (identical(p, q) || q.id <= p.id || q.scored) continue;
        var dx = q.x - p.x;
        var dy = q.y - p.y;
        final minD = radius * 2;
        final d2 = dx * dx + dy * dy;
        if (d2 <= .0001 || d2 >= minD * minD) continue;
        final d = math.sqrt(d2);
        final nx = dx / d;
        final ny = dy / d;
        final overlap = minD - d;
        p.x -= nx * overlap * .5;
        p.y -= ny * overlap * .5;
        q.x += nx * overlap * .5;
        q.y += ny * overlap * .5;

        final rv = (q.vx - p.vx) * nx + (q.vy - p.vy) * ny;
        if (rv < 0) {
          _pieceSfx();
          final impulse = -rv * .60;
          p.vx -= nx * impulse;
          p.vy -= ny * impulse;
          q.vx += nx * impulse;
          q.vy += ny * impulse;
        }
      }

      // Real collision on the four vertical pocket separators.
      final separatorTop = rect.bottom - 86;
      final separatorBottom = rect.bottom + 6;
      if (p.y + radius >= separatorTop &&
          p.y - radius <= separatorBottom) {
        for (final sx in separators) {
          final dx = p.x - sx;
          final halfThickness = 4.5;
          if (dx.abs() <= radius + halfThickness) {
            p.x = sx +
                (dx >= 0 ? 1 : -1) * (radius + halfThickness + .2);
            p.vx = (dx >= 0 ? 1 : -1) *
                math.max(.85, p.vx.abs() * .78);
            p.spin += (dx >= 0 ? 1 : -1) * .03;
            _wallSfx();
          }
        }
      }

      // Pocket entry. The ball must actually descend below the lip.
      if (!p.scored && p.y >= rect.bottom - 40) {
        final pocketWidth = rect.width / 5;
        var pocketIndex =
            ((p.x - rect.left) / pocketWidth).floor().clamp(0, 4).toInt();

        final left = rect.left + pocketWidth * pocketIndex;
        final right = left + pocketWidth;
        if (p.x > left + radius + 4 &&
            p.x < right - radius - 4 &&
            p.y >= rect.bottom - 20) {
          p.scored = true;

          {
            const rewards = <int>[100, 200, 0, 200, 100];
            const labels = <String>[
              '100',
              '200',
              '',
              '200',
              '100',
            ];
            if (pocketIndex == 2) {
              // The center RED pocket is the mini-game pocket. It only counts
              // hits now; the mini-game opens later, after the whole batch has
              // finished, exactly like the existing settlement flow.
              _centerPocketHits++;
              SfxManager.instance.reward();
              _bursts.add(
                _PocketBurst(
                  center: pockets[pocketIndex] - const Offset(0, 18),
                  text: '×$_centerPocketHits',
                  startedAt: DateTime.now(),
                  kind: 5,
                ),
              );
            } else {
              SfxManager.instance.clear();
              _queueReward(rewards[pocketIndex], pockets[pocketIndex]);
              _bursts.add(
                _PocketBurst(
                  center: pockets[pocketIndex] - const Offset(0, 18),
                  text: labels[pocketIndex],
                  startedAt: DateTime.now(),
                  kind: 0,
                ),
              );
            }

            p.y = rect.bottom + 100;
            p.vx = 0;
            p.vy = 0;
          }
        }
      }
    }

    final hadPieces = _pieces.isNotEmpty;
    _pieces.removeWhere(
      (p) =>
          p.scored ||
          p.y > rect.bottom + 90 ||
          p.x < -100 ||
          p.x > size.width + 100,
    );
    if (hadPieces && _pieces.isEmpty && !_autoRunning) {
      SfxManager.instance.unlock();
      if (_batchActive && !_batchSettlementStarted) {
        _batchSettlementStarted = true;
        Future<void>.delayed(
          const Duration(milliseconds: 700),
          _settleBatch,
        );
      }
    }

    final now = DateTime.now();
    _flashes.removeWhere(
      (f) => now.difference(f.startedAt).inMilliseconds > 450,
    );
    _bursts.removeWhere(
      (b) =>
          now.difference(b.startedAt).inMilliseconds >
          (b.kind == 4 ? 1400 : b.kind == 5 ? 950 : 720),
    );

    if (mounted &&
        (_pieces.isNotEmpty ||
            _flashes.isNotEmpty ||
            _bursts.isNotEmpty ||
            _rewardTokens.isNotEmpty ||
            _rewardCounter > 0 ||
            _expBeamStartedAt != null)) {
      setState(() {});
    }
  }

  bool _bounceSegment(
    _DropPiece p,
    Offset a,
    Offset b,
    double obstacleRadius,
    double pieceRadius, {
    required double restitution,
    required double randomKick,
  }) {
    final ab = b - a;
    final len2 = ab.dx * ab.dx + ab.dy * ab.dy;
    if (len2 <= .0001) return false;

    final ap = Offset(p.x, p.y) - a;
    final t = ((ap.dx * ab.dx + ap.dy * ab.dy) / len2)
        .clamp(0.0, 1.0)
        .toDouble();
    final closest = a + ab * t;

    var dx = p.x - closest.dx;
    var dy = p.y - closest.dy;
    final minD = obstacleRadius + pieceRadius;
    final d2 = dx * dx + dy * dy;
    if (d2 >= minD * minD) return false;

    var d = math.sqrt(math.max(.0001, d2));
    if (d < .01) {
      dx = -ab.dy;
      dy = ab.dx;
      d = math.sqrt(dx * dx + dy * dy);
    }

    final nx = dx / d;
    final ny = dy / d;
    final overlap = minD - d;
    p.x += nx * (overlap + .25);
    p.y += ny * (overlap + .25);

    final dot = p.vx * nx + p.vy * ny;
    if (dot < 0) {
      p.vx -= (1 + restitution) * dot * nx;
      p.vy -= (1 + restitution) * dot * ny;
    }

    final kick = (_random.nextDouble() - .5) * randomKick;
    p.vx += -ny * kick;
    p.vy += nx * kick * .25;
    p.spin += kick * .018;
    return true;
  }

  Future<void> _settleBatch() async {
    if (!mounted) return;

    // Wait until all normal reward stars from this 30-ball batch have reached
    // the big counter. The counter is intentionally held and cannot beam yet.
    while (mounted && _rewardTokens.any((t) => !t.arrived)) {
      await Future<void>.delayed(const Duration(milliseconds: 80));
    }
    if (!mounted) return;

    final hits = _centerPocketHits;
    if (hits > 0) {
      setState(() {
        _miniGameOpen = true;
      });

      final miniReward = await Navigator.of(context).push<int>(
        MaterialPageRoute<int>(
          builder: (_) => _ConnectMiniGameScreen(multiplier: hits),
          fullscreenDialog: true,
        ),
      );

      if (!mounted) return;

      if (miniReward != null && miniReward > 0) {
        final bonus = miniReward * hits;
        setState(() {
          _miniGameOpen = false;
          _queueReward(
            bonus,
            _bottomPockets(_boardSize)[2],
          );
          _bursts.add(
            _PocketBurst(
              center: _playRect(_boardSize).center,
              text: hits > 1 ? '$miniReward ×$hits = $bonus' : '$bonus',
              startedAt: DateTime.now(),
              kind: 4,
            ),
          );
        });
        SfxManager.instance.unlock();
        SfxManager.instance.reward();

        // Wait for the mini-game bonus star to enter the big counter too.
        while (mounted && _rewardTokens.any((t) => !t.arrived)) {
          await Future<void>.delayed(const Duration(milliseconds: 80));
        }
      } else {
        setState(() {
          _miniGameOpen = false;
        });
      }
    }

    if (!mounted) return;
    setState(() {
      _centerPocketHits = 0;
      _batchActive = false;
      _batchSettlementStarted = false;
      _holdCounterForBatch = false;
      _lastCounterAddAt = DateTime.now();
    });
  }


  bool _bounceCircleSwept(
    _DropPiece p,
    Offset previous,
    Offset center,
    double obstacleRadius,
    double pieceRadius, {
    required double restitution,
    required double randomKick,
  }) {
    final current = Offset(p.x, p.y);
    final segment = current - previous;
    final segmentLen2 =
        segment.dx * segment.dx + segment.dy * segment.dy;
    final minD = obstacleRadius + pieceRadius;

    double t = 0.0;
    if (segmentLen2 > .000001) {
      final toCenter = center - previous;
      t = ((toCenter.dx * segment.dx + toCenter.dy * segment.dy) /
              segmentLen2)
          .clamp(0.0, 1.0)
          .toDouble();
    }

    final closest = previous + segment * t;
    var delta = closest - center;
    var distance = delta.distance;

    // Also catch ordinary overlap at the current position.
    final currentDelta = current - center;
    final currentDistance = currentDelta.distance;
    if (distance > minD && currentDistance > minD) return false;

    if (currentDistance <= minD) {
      delta = currentDelta;
      distance = currentDistance;
    }

    if (distance < .001) {
      final speed = Offset(p.vx, p.vy);
      if (speed.distance > .001) {
        delta = -speed / speed.distance;
      } else {
        delta = const Offset(0, -1);
      }
      distance = 1;
    }

    final normal = delta / distance;

    // Force the character back to the outside edge. This is the key part
    // that prevents tunnelling straight through on later contacts.
    p.x = center.dx + normal.dx * (minD + .35);
    p.y = center.dy + normal.dy * (minD + .35);

    final dot = p.vx * normal.dx + p.vy * normal.dy;
    if (dot < 0) {
      p.vx -= (1 + restitution) * dot * normal.dx;
      p.vy -= (1 + restitution) * dot * normal.dy;
    } else {
      // A swept crossing can finish on the far side with dot >= 0.
      // Give it a guaranteed outward push instead of allowing a pass-through.
      final outward = math.max(1.1, math.sqrt(p.vx * p.vx + p.vy * p.vy) * .72);
      p.vx = normal.dx * outward;
      p.vy = normal.dy * outward;
    }

    final tangentKick =
        (_random.nextDouble() - .5) * randomKick;
    p.vx += -normal.dy * tangentKick;
    p.vy += normal.dx * tangentKick * .22;
    p.spin += tangentKick * .02;
    return true;
  }

  bool _bounceCircle(
    _DropPiece p,
    Offset center,
    double obstacleRadius,
    double pieceRadius, {
    required double restitution,
    required double randomKick,
  }) {
    var dx = p.x - center.dx;
    var dy = p.y - center.dy;
    final minD = obstacleRadius + pieceRadius;
    var d2 = dx * dx + dy * dy;
    if (d2 >= minD * minD) return false;

    var d = math.sqrt(math.max(.0001, d2));
    if (d < .01) {
      dx = (_random.nextDouble() - .5) * .2;
      dy = -1;
      d = math.sqrt(dx * dx + dy * dy);
    }

    final nx = dx / d;
    final ny = dy / d;
    final overlap = minD - d;
    p.x += nx * overlap;
    p.y += ny * overlap;

    final dot = p.vx * nx + p.vy * ny;
    if (dot < 0) {
      p.vx -= (1 + restitution) * dot * nx;
      p.vy -= (1 + restitution) * dot * ny;
    }

    final tangentKick = (_random.nextDouble() - .5) * randomKick;
    p.vx += -ny * tangentKick;
    p.vy += nx * tangentKick * .22;
    p.spin += tangentKick * .02;
    return true;
  }

  Offset _rewardCounterCenter(Size size) {
    final r = _playRect(size);
    return Offset(r.center.dx, r.top + 34);
  }

  void _queueReward(int amount, Offset origin) {
    if (amount <= 0 || _boardSize == Size.zero) return;
    _rewardTokens.add(
      _RewardToken(
        amount: amount,
        origin: origin,
        startedAt: DateTime.now(),
      ),
    );
  }

  void _applyExp(int amount) {
    _monsterExp += amount;
    var leveledUp = false;
    while (true) {
      final need = _expNeed(_monsterLevel);
      if (_monsterExp < need) break;
      _monsterExp -= need;
      _monsterLevel++;
      leveledUp = true;
    }
    if (leveledUp) SfxManager.instance.unlock();
  }

  void _tickRewardFlow() {
    if (_boardSize == Size.zero) return;
    final now = DateTime.now();
    var addedToCounter = false;

    for (final token in _rewardTokens) {
      if (token.arrived) continue;
      if (now.difference(token.startedAt).inMilliseconds >= 430) {
        token.arrived = true;
        _rewardCounter += token.amount;
        _lastCounterAddAt = now;
        addedToCounter = true;
      }
    }

    _rewardTokens.removeWhere(
      (t) =>
          t.arrived &&
          now.difference(t.startedAt).inMilliseconds > 560,
    );

    if (addedToCounter) {
      SfxManager.instance.traceStep(
        (_rewardCounter ~/ 100 + 3).clamp(3, 8).toInt(),
      );
    }

    final waitingToken = _rewardTokens.any((t) => !t.arrived);

    // Start the counter -> EXP transfer automatically when settlement ends.
    if (!_holdCounterForBatch &&
        _expBeamStartedAt == null &&
        _rewardCounter > 0 &&
        !waitingToken &&
        _lastCounterAddAt != null &&
        now.difference(_lastCounterAddAt!).inMilliseconds >= 320) {
      _expBeamAmount = _rewardCounter;
      _rewardCounter = 0;
      _expTransferApplied = 0;

      // Bigger totals deliberately take longer to count up.
      // 100 ~= 0.9s, 1000 ~= 1.5s, 8000 ~= 3.0s.
      _expTransferDurationMs =
          (700 + math.sqrt(_expBeamAmount.toDouble()) * 25)
              .round()
              .clamp(850, 3600)
              .toInt();
      _expBeamStartedAt = now;
      _expCountStartedAt = null;
      _lastExpTickSfxAt = null;
      SfxManager.instance.core();

      // The counter becomes 0 immediately. First, the total itself flies
      // to the EXP gauge as light. EXP must not increase until it arrives.
      if (mounted) setState(() {});
    }

    if (_expBeamStartedAt != null && _expBeamAmount > 0) {
      if (_expCountStartedAt == null) {
        final beamElapsed =
            now.difference(_expBeamStartedAt!).inMilliseconds;
        if (beamElapsed >= _expBeamTravelDurationMs) {
          _expCountStartedAt = now;
          _lastExpTickSfxAt = null;
          SfxManager.instance.traceStep(1);
          if (mounted) setState(() {});
        }
      } else {
        final elapsed =
            now.difference(_expCountStartedAt!).inMilliseconds;
        final duration = math.max(1, _expTransferDurationMs);
        final progress =
            (elapsed / duration).clamp(0.0, 1.0).toDouble();

        // Only after the light reaches the gauge: "turururururun" EXP count-up.
        final eased = Curves.easeOutCubic.transform(progress);
        final targetApplied =
            (_expBeamAmount * eased).round().clamp(0, _expBeamAmount);
        final delta = targetApplied - _expTransferApplied;

        if (delta > 0) {
          _applyExp(delta);
          _expTransferApplied += delta;

          if (_lastExpTickSfxAt == null ||
              now.difference(_lastExpTickSfxAt!).inMilliseconds >= 55) {
            _lastExpTickSfxAt = now;
            final step =
                1 + (progress * 7).floor().clamp(0, 7).toInt();
            SfxManager.instance.traceStep(step);
          }

          if (mounted) setState(() {});
        }

        if (progress >= 1.0) {
          final remaining = _expBeamAmount - _expTransferApplied;
          if (remaining > 0) {
            _applyExp(remaining);
            _expTransferApplied += remaining;
          }

          _expBeamAmount = 0;
          _expTransferApplied = 0;
          _expTransferDurationMs = 0;
          _expBeamStartedAt = null;
          _expCountStartedAt = null;
          _lastExpTickSfxAt = null;
          SfxManager.instance.reward();

          if (mounted) setState(() {});
        }
      }
    }
  }

  int _expNeed(int level) {
    final n = level - 1;
    // Numeric rewards from the five bottom pockets are now large, so leveling needs
    // a much larger curve. Lv1=8,000, Lv2=13,000, Lv3=20,000, Lv4=29,000...
    return 8000 + n * 4000 + n * n * 1000;
  }

  bool _consumeOneAndConnect(int port, {bool automatic = false}) {
    if (_surusuru <= 0 || _boardSize == Size.zero) return false;

    final ports = _ports(_boardSize);
    if (port < 0 || port >= ports.length) return false;

    setState(() {
      widget.controller.consumeSurusuru();
      SfxManager.instance.spawn();
      _flashes.add(_ConnectionFlash(port, DateTime.now()));

      final start = ports[port];
      final r = _pieceRadius(_boardSize);
      _pieces.add(
        _DropPiece(
          id: _nextPieceId++,
          type: _random.nextInt(5),
          x: start.dx + (_random.nextDouble() - .5) * r * 1.2,
          y: math.min(start.dy + r * 1.25, _playRect(_boardSize).top - r - 2),
          vx: (_random.nextDouble() - .5) * (automatic ? 2.0 : 1.2),
          vy: .45 + _random.nextDouble() * .75,
        ),
      );
    });
    return true;
  }

  void _startAuto() {
    if (_dropBusy || _surusuru <= 0) {
      SfxManager.instance.error();
      return;
    }
    _autoUsed = 0;
    _autoRunning = true;
    _batchActive = true;
    _batchSettlementStarted = false;
    _holdCounterForBatch = true;
    _centerPocketHits = 0;
    SfxManager.instance.surusuru();

    void fire() {
      if (!_autoRunning ||
          _autoUsed >= _autoMax ||
          _surusuru <= 0 ||
          !mounted) {
        _stopAuto();
        return;
      }

      if (_consumeOneAndConnect(
        _random.nextInt(_portCount),
        automatic: true,
      )) {
        _autoUsed++;
      }
    }

    fire();
    _autoTimer?.cancel();
    _autoTimer = Timer.periodic(
      const Duration(milliseconds: 118),
      (_) => fire(),
    );
    setState(() {});
  }

  void _stopAuto() {
    _autoTimer?.cancel();
    _autoTimer = null;
    if (!_autoRunning) return;
    _autoRunning = false;
    if (mounted) setState(() {});
  }

  void _manualStart(DragStartDetails details) {
    if (_autoRunning || _surusuru <= 0) return;
    final hub = _hub(_boardSize);
    if ((details.localPosition - hub).distance > 42) return;

    SfxManager.instance.tap();
    setState(() {
      _manualDragging = true;
      _manualFinger = details.localPosition;
      _manualHoverPort = null;
    });
  }

  void _manualUpdate(DragUpdateDetails details) {
    if (!_manualDragging) return;
    final finger = details.localPosition;
    final ports = _ports(_boardSize);

    int? hover;
    var best = 38.0;
    for (var i = 0; i < ports.length; i++) {
      final d = (finger - ports[i]).distance;
      if (d < best) {
        best = d;
        hover = i;
      }
    }

    setState(() {
      _manualFinger = finger;
      _manualHoverPort = hover;
    });
  }

  void _manualEnd(DragEndDetails details) {
    if (!_manualDragging) return;
    final port = _manualHoverPort;

    setState(() {
      _manualDragging = false;
      _manualFinger = null;
      _manualHoverPort = null;
    });

    if (port != null) {
      if (!_batchActive) {
        _batchActive = true;
        _batchSettlementStarted = false;
        _holdCounterForBatch = true;
        _centerPocketHits = 0;
      }
      _consumeOneAndConnect(port);
    }
  }

  void _manualCancel() {
    if (!_manualDragging) return;
    setState(() {
      _manualDragging = false;
      _manualFinger = null;
      _manualHoverPort = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final expNeed = _expNeed(_monsterLevel);

    // V57: The SURUSURU machine now lives on a fixed logical canvas.
    // Its internal coordinates never depend on the phone height or on the
    // bottom navigation bar.  Different devices only scale this canvas as a
    // whole, so bumper/pin/pocket positions and physics stay identical.
    const logicalBoardSize = Size(390, 525);
    const topBarHeight = 74.0;

    return Scaffold(
      backgroundColor: const Color(0xFF0B1025),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, outer) {
            final scale = outer.maxWidth / logicalBoardSize.width;
            final renderedBoardHeight = logicalBoardSize.height * scale;

            return Stack(
              clipBehavior: Clip.hardEdge,
              children: [
                Positioned.fill(
                  child: Container(color: const Color(0xFF0B1025)),
                ),
                Positioned(
                  top: 0,
                  left: 0,
                  right: 0,
                  height: topBarHeight,
                  child: _TopBar(
                    level: _monsterLevel,
                    exp: _monsterExp,
                    expNeed: expNeed,
                    onBack: () => Navigator.pop(context),
                  ),
                ),
                Positioned(
                  top: topBarHeight,
                  left: 0,
                  right: 0,
                  height: renderedBoardHeight,
                  child: FittedBox(
                    fit: BoxFit.fill,
                    alignment: Alignment.topCenter,
                    child: SizedBox(
                      width: logicalBoardSize.width,
                      height: logicalBoardSize.height,
                      child: Builder(
                        builder: (context) {
                          _boardSize = logicalBoardSize;
                          return GestureDetector(
                            behavior: HitTestBehavior.opaque,
                            onPanStart: _manualStart,
                            onPanUpdate: _manualUpdate,
                            onPanEnd: _manualEnd,
                            onPanCancel: _manualCancel,
                            child: Stack(
                              children: [
                                Positioned.fill(
                                  child: CustomPaint(
                                    painter: _SuruBoardPainter(
                                      pieces: _pieces,
                                      flashes: _flashes,
                                      bursts: _bursts,
                                      hub: _hub(_boardSize),
                                      ports: _ports(_boardSize),
                                      pegs: _pegs(_boardSize),
                                      letterBumpers: _letterBumpers(_boardSize),
                                      starBumper: _starBumper(_boardSize),
                                      pockets: _bottomPockets(_boardSize),
                                      separators: _separatorXs(_boardSize),
                                      playRect: _playRect(_boardSize),
                                      pieceRadius: _pieceRadius(_boardSize),
                                      pegRadius: _pegRadius(_boardSize),
                                      manualFinger: _manualFinger,
                                      manualHoverPort: _manualHoverPort,
                                      rewardTokens: _rewardTokens,
                                      rewardCounter: _rewardCounter,
                                      expBeamStartedAt: _expBeamStartedAt,
                                      expCountStartedAt: _expCountStartedAt,
                                      expBeamAmount: _expBeamAmount,
                                      expTransferApplied: _expTransferApplied,
                                      expTransferDurationMs: _expTransferDurationMs,
                                      centerPocketHits: _centerPocketHits,
                                    ),
                                  ),
                                ),
                                Positioned(
                                  top: 6,
                                  left: 0,
                                  right: 0,
                                  child: IgnorePointer(
                                    child: Center(
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 12,
                                          vertical: 4,
                                        ),
                                        decoration: BoxDecoration(
                                          color: const Color(0xCC11182D),
                                          borderRadius: BorderRadius.circular(15),
                                          border: Border.all(
                                            color: const Color(0x99A9C7FF),
                                          ),
                                        ),
                                        child: Text(
                                          _manualDragging
                                              ? '好きな入口へつないで離す'
                                              : '手動つなぎ  •  1スルスル',
                                          style: const TextStyle(
                                            color: Colors.white,
                                            fontSize: 10,
                                            fontWeight: FontWeight.w900,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  left: 0,
                                  right: 0,
                                  bottom: 2,
                                  child: Center(
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        GestureDetector(
                                          onTap: () {
                                            if (_dropBusy || _surusuru <= 0) {
                                              SfxManager.instance.error();
                                              return;
                                            }
                                            SfxManager.instance.tap();
                                            _consumeOneAndConnect(
                                              _random.nextInt(_portCount),
                                              automatic: true,
                                            );
                                          },
                                          onLongPressStart: (_) => _startAuto(),
                                          onLongPressEnd: (_) {},
                                          child: AnimatedScale(
                                            duration: const Duration(milliseconds: 90),
                                            scale: _autoRunning ? .93 : 1,
                                            child: Container(
                                              width: 116,
                                              height: 116,
                                              decoration: BoxDecoration(
                                                shape: BoxShape.circle,
                                                gradient: const RadialGradient(
                                                  colors: [
                                                    Color(0xFFFFF39B),
                                                    Color(0xFFFFB62F),
                                                    Color(0xFFE36B16),
                                                  ],
                                                ),
                                                border: Border.all(
                                                  color: Colors.white,
                                                  width: 4,
                                                ),
                                                boxShadow: const [
                                                  BoxShadow(
                                                    color: Color(0x99FF8A28),
                                                    blurRadius: 26,
                                                    spreadRadius: 3,
                                                  ),
                                                  BoxShadow(
                                                    color: Color(0x77000000),
                                                    blurRadius: 10,
                                                    offset: Offset(0, 6),
                                                  ),
                                                ],
                                              ),
                                              child: Column(
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                children: [
                                                  const Text(
                                                    'スルスル',
                                                    style: TextStyle(
                                                      color: Color(0xFF432416),
                                                      fontSize: 18,
                                                      fontWeight: FontWeight.w900,
                                                    ),
                                                  ),
                                                  Text(
                                                    _autoRunning
                                                        ? '$_autoUsed / $_autoMax'
                                                        : _pieces.isNotEmpty
                                                            ? '落下中 ${_pieces.length}'
                                                            : 'MAX $_autoMax',
                                                    style: const TextStyle(
                                                      color: Color(0xFF432416),
                                                      fontSize: 15,
                                                      fontWeight: FontWeight.w900,
                                                    ),
                                                  ),
                                                  const Text(
                                                    '長押し',
                                                    style: TextStyle(
                                                      color: Color(0xAA432416),
                                                      fontSize: 9,
                                                      fontWeight: FontWeight.w900,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(height: 5),
                                        Container(
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 13,
                                            vertical: 4,
                                          ),
                                          decoration: BoxDecoration(
                                            color: const Color(0xDD0E1120),
                                            borderRadius: BorderRadius.circular(13),
                                            border: Border.all(
                                              color: const Color(0x99FFD76A),
                                            ),
                                          ),
                                          child: Text(
                                            '所持スルスル  $_surusuru',
                                            style: const TextStyle(
                                              color: Colors.white,
                                              fontSize: 11,
                                              fontWeight: FontWeight.w900,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ),
                // Navigation is an overlay sibling, not part of the machine's
                // layout. Adding/removing/changing this bar can no longer move
                // any pin, bumper, pocket or physics coordinate.
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: GameBottomNav(
                    active: 'surusuru',
                    onAdventure: () {
                      SfxManager.instance.tap();
                      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => StageMapScreen(controller: widget.controller)));
                    },
                    onShop: () {
                      SfxManager.instance.tap();
                      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => ShopScreen(controller: widget.controller)));
                    },
                    onSurusuru: () {},
                    onTraining: () {
                      SfxManager.instance.tap();
                      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => TrainingScreen(controller: widget.controller)));
                    },
                    onMap: () {
                      SfxManager.instance.tap();
                      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => RpgHomeScreen(controller: widget.controller)));
                    },
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _TopBar extends StatelessWidget {
  const _TopBar({
    required this.level,
    required this.exp,
    required this.expNeed,
    required this.onBack,
  });

  final int level;
  final int exp;
  final int expNeed;
  final VoidCallback onBack;

  @override
  Widget build(BuildContext context) {
    final ratio =
        expNeed <= 0 ? 0.0 : (exp / expNeed).clamp(0.0, 1.0);

    return Container(
      height: 74,
      padding: const EdgeInsets.fromLTRB(7, 6, 9, 7),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Color(0xFF15182D),
            Color(0xFF242047),
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: Color(0x66000000),
            blurRadius: 8,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          IconButton(
            onPressed: onBack,
            icon: const Icon(Icons.arrow_back, color: Colors.white),
          ),
          Expanded(
            child: Container(
              padding: const EdgeInsets.fromLTRB(10, 6, 10, 7),
              decoration: BoxDecoration(
                color: const Color(0xFF101526),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFF675A98)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      const Text(
                        '育成モンスター',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                          fontSize: 12,
                        ),
                      ),
                      const Spacer(),
                      Text(
                        'Lv.$level',
                        style: const TextStyle(
                          color: Color(0xFFFFE386),
                          fontWeight: FontWeight.w900,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 5),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(7),
                    child: Stack(
                      children: [
                        Container(
                          height: 14,
                          color: const Color(0xFF080B12),
                        ),
                        FractionallySizedBox(
                          widthFactor: ratio,
                          child: Container(
                            height: 14,
                            decoration: const BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Color(0xFF54E273),
                                  Color(0xFFA7F06F),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Positioned.fill(
                          child: Center(
                            child: Text(
                              '$exp / $expNeed',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 9,
                                fontWeight: FontWeight.w900,
                                shadows: [
                                  Shadow(
                                    color: Colors.black,
                                    blurRadius: 2,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}


enum _ChanceMode { instant, stepUp, battle }

class _ConnectMiniGameScreen extends StatefulWidget {
  const _ConnectMiniGameScreen({required this.multiplier});
  final int multiplier;

  @override
  State<_ConnectMiniGameScreen> createState() => _ConnectMiniGameScreenState();
}

class _ConnectMiniGameScreenState extends State<_ConnectMiniGameScreen> {
  final math.Random _rng = math.Random();
  late final int _result;
  _ChanceMode? _mode;
  int _step = 0;
  bool _revealed = false;
  bool _holding = false;
  int _battleHits = 0;
  int _defeated = 0;
  int _battleTarget = 0;
  String _message = '演出モードを選んでください';
  Timer? _holdTimer;

  @override
  void initState() {
    super.initState();
    final r = _rng.nextInt(100);
    _result = r < 15 ? 4000 : r < 40 ? 3000 : r < 85 ? 2000 : 1000;
  }

  @override
  void dispose() { _holdTimer?.cancel(); super.dispose(); }

  int get _resultLevel => (_result ~/ 1000).clamp(1, 4);
  Color get _heatColor => _result >= 4000 ? const Color(0xFFFFD54F) : _result >= 3000 ? const Color(0xFFFF405F) : _result >= 2000 ? const Color(0xFFFFA726) : const Color(0xFF42A5F5);
  String get _heatText => _result >= 4000 ? '激アツ' : _result >= 3000 ? '大チャンス' : _result >= 2000 ? 'チャンス' : 'ノーマル';

  void _fxTap() { SfxManager.instance.tap(); }
  void _fxRise(int n) { SfxManager.instance.traceStep(n.clamp(1, 8)); if (n >= 4) SfxManager.instance.reaction(); }
  void _fxImpact() { SfxManager.instance.bomb(); SfxManager.instance.lightning(); }
  void _fxKyuiin() {
    SfxManager.instance.unlock();
    SfxManager.instance.lightning();
    Future<void>.delayed(const Duration(milliseconds: 130), () { SfxManager.instance.unlock(); SfxManager.instance.reaction(); });
    Future<void>.delayed(const Duration(milliseconds: 270), () { SfxManager.instance.unlock(); SfxManager.instance.reward(); });
  }

  void _choose(_ChanceMode mode) {
    _fxImpact();
    setState(() {
      _mode = mode; _step = 0; _battleHits = 0; _defeated = 0; _battleTarget = 0;
      _message = switch (mode) {
        _ChanceMode.instant => '長押しして、あの音を待て…',
        _ChanceMode.stepUp => '4つの封印を解除して宝箱を開けろ！',
        _ChanceMode.battle => '4体の敵を撃破せよ！',
      };
    });
  }

  void _instantStart() {
    if (_revealed) return;
    _holding = true; _fxTap(); _holdTimer?.cancel();
    setState(() { _step = 1; _message = '・・・・・・'; });
    _holdTimer = Timer(Duration(milliseconds: 850 + _rng.nextInt(900)), () {
      if (!mounted || !_holding) return;
      if (_resultLevel >= 3) {
        _fxKyuiin();
        setState(() { _step = 6; _message = _result == 4000 ? 'キュイン！キュイン！キュイーーーン！！' : 'キュイン！ キュイン！！'; });
      } else {
        SfxManager.instance.reaction();
        setState(() { _step = 3; _message = _result == 2000 ? 'ピキーン！ CHANCE！' : 'ポンッ！'; });
      }
      Future<void>.delayed(const Duration(milliseconds: 900), _reveal);
    });
  }
  void _instantEnd() { _holding = false; if (!_revealed && _step < 3) setState(() { _step = 0; _message = 'もう一度、長押し！'; }); }

  static const _missions = ['鍵を発見！', '封印を解除！', '宝石を点灯！', '宝箱を開放！'];
  void _stepTap() {
    if (_revealed) return;
    _fxRise(_step + 2);
    setState(() {
      _step++;
      final idx = (_step - 1).clamp(0, 3);
      _message = '${_missions[idx]}  STEP $_step/4';
      if (_step >= 4) _message = _result == 4000 ? '全封印解除！ 虹の宝箱！！' : '最終ジャッジ！ 宝箱OPEN！';
    });
    if (_step >= 4) { _fxImpact(); Future<void>.delayed(const Duration(milliseconds: 750), _reveal); }
  }

  void _battleTap() {
    if (_revealed || _battleTarget >= 4) return;
    _battleHits++; _fxTap();
    final hitsNeeded = 2 + _battleTarget;
    setState(() {
      _step++;
      _message = _battleHits >= hitsNeeded ? '必殺！' : 'HIT！ 連打！';
    });
    if (_battleHits >= hitsNeeded) {
      _battleHits = 0;
      final canDefeat = _defeated < _resultLevel;
      if (canDefeat) {
        _fxImpact();
        setState(() { _defeated++; _battleTarget++; _message = '撃破！！  $_defeated / 4'; });
        if (_defeated >= _resultLevel) {
          if (_defeated == 4) { _fxKyuiin(); setState(() => _message = '全滅！！ PERFECT！！'); }
          Future<void>.delayed(const Duration(milliseconds: 900), _reveal);
        }
      } else {
        SfxManager.instance.error();
        Future<void>.delayed(const Duration(milliseconds: 650), _reveal);
      }
    }
  }

  void _reveal() {
    if (!mounted || _revealed) return;
    setState(() { _revealed = true; _message = _result == 4000 ? 'PERFECT BONUS！！' : '報酬 GET！'; });
    if (_result == 4000) _fxKyuiin(); else { SfxManager.instance.unlock(); SfxManager.instance.reward(); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(backgroundColor: const Color(0xFF090516), body: SafeArea(child: Padding(padding: const EdgeInsets.all(16), child: _mode == null ? _modeSelect() : _modePlay())));

  Widget _modeSelect() => Column(children: [
    const SizedBox(height: 10),
    const Text('CHANCE MODE', style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w900, letterSpacing: 2.5)),
    const SizedBox(height: 5),
    Text('好きな演出で運命を見届けよう！', style: TextStyle(color: Colors.white.withOpacity(.68))),
    const SizedBox(height: 20),
    Expanded(child: Column(children: [
      _modeCard(_ChanceMode.instant, Icons.notifications_active_rounded, '一発告知', '静寂から突然の「キュイン！」を狙え', const Color(0xFFFFD54F)),
      const SizedBox(height: 11),
      _modeCard(_ChanceMode.stepUp, Icons.auto_awesome_rounded, 'ステップアップ', '4つの封印を順番に解除して宝箱OPEN', const Color(0xFFFF7043)),
      const SizedBox(height: 11),
      _modeCard(_ChanceMode.battle, Icons.sports_mma_rounded, '4 ENEMY BATTLE', '倒した敵の数がそのまま報酬ランク！', const Color(0xFFE040FB)),
    ])),
    Text('中央ポケット ×${widget.multiplier}', style: const TextStyle(color: Color(0xFFFFD54F), fontWeight: FontWeight.w900)),
  ]);

  Widget _modeCard(_ChanceMode mode, IconData icon, String title, String sub, Color accent) => Expanded(child: InkWell(onTap: () => _choose(mode), borderRadius: BorderRadius.circular(24), child: Ink(decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), gradient: LinearGradient(colors: [accent.withOpacity(.30), const Color(0xFF21113F)]), border: Border.all(color: accent.withOpacity(.75), width: 2), boxShadow: [BoxShadow(color: accent.withOpacity(.16), blurRadius: 18)]), child: Padding(padding: const EdgeInsets.symmetric(horizontal: 17), child: Row(children: [Container(width: 62, height: 62, decoration: BoxDecoration(shape: BoxShape.circle, color: accent.withOpacity(.18), border: Border.all(color: accent, width: 2)), child: Icon(icon, color: accent, size: 36)), const SizedBox(width: 15), Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)), const SizedBox(height: 5), Text(sub, style: TextStyle(color: Colors.white.withOpacity(.72), fontSize: 12.5))])), const Icon(Icons.chevron_right_rounded, color: Colors.white70)])))));

  Widget _modePlay() {
    final title = switch (_mode!) { _ChanceMode.instant => '⚡ 一発告知', _ChanceMode.stepUp => '🔥 ステップアップ', _ChanceMode.battle => '⚔️ 4 ENEMY BATTLE' };
    final accent = _mode == _ChanceMode.instant ? const Color(0xFFFFD740) : _mode == _ChanceMode.stepUp ? const Color(0xFFFF7043) : const Color(0xFFE040FB);
    return Column(children: [
      Row(children: [IconButton(onPressed: _revealed ? null : () => setState(() => _mode = null), icon: const Icon(Icons.arrow_back_rounded, color: Colors.white)), Expanded(child: Text(title, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w900))), const SizedBox(width: 48)]),
      const SizedBox(height: 8),
      Expanded(child: AnimatedContainer(duration: const Duration(milliseconds: 180), width: double.infinity, decoration: BoxDecoration(borderRadius: BorderRadius.circular(28), gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [accent.withOpacity(.18), const Color(0xFF170C31), const Color(0xFF080412)]), border: Border.all(color: (_step >= 3 ? _heatColor : accent).withOpacity(.85), width: 2.5), boxShadow: [BoxShadow(color: (_step >= 3 ? _heatColor : accent).withOpacity(.22), blurRadius: 30, spreadRadius: 2)]), child: _revealed ? _resultView() : _playBody())),
    ]);
  }

  Widget _playBody() {
    if (_mode == _ChanceMode.battle) return _battleBody();
    if (_mode == _ChanceMode.stepUp) return _stepBody();
    return _instantBody();
  }

  Widget _instantBody() => Column(mainAxisAlignment: MainAxisAlignment.center, children: [
    AnimatedContainer(duration: const Duration(milliseconds: 160), width: 210, height: 210, decoration: BoxDecoration(shape: BoxShape.circle, color: _step >= 6 ? Colors.white : const Color(0xFF160E2A), border: Border.all(color: _step >= 6 ? const Color(0xFFFFD740) : Colors.white24, width: _step >= 6 ? 8 : 2), boxShadow: _step >= 6 ? const [BoxShadow(color: Color(0xFFFFD740), blurRadius: 55, spreadRadius: 15)] : null), child: Icon(Icons.notifications_active_rounded, size: 105, color: _step >= 6 ? const Color(0xFFFF1744) : Colors.white24)),
    const SizedBox(height: 24),
    Text(_message, textAlign: TextAlign.center, style: TextStyle(color: _step >= 6 ? const Color(0xFFFFD740) : Colors.white, fontSize: _step >= 6 ? 25 : 21, fontWeight: FontWeight.w900)),
    const SizedBox(height: 28),
    GestureDetector(onLongPressStart: (_) => _instantStart(), onLongPressEnd: (_) => _instantEnd(), child: _pushButton(_holding ? 'HOLD!!' : '長押し', const Color(0xFFD50000))),
  ]);

  Widget _stepBody() => Column(mainAxisAlignment: MainAxisAlignment.center, children: [
    const Text('TREASURE SEAL', style: TextStyle(color: Colors.white60, fontWeight: FontWeight.w900, letterSpacing: 2)),
    const SizedBox(height: 18),
    Stack(alignment: Alignment.center, children: [
      Icon(Icons.inventory_2_rounded, size: 120, color: _step >= 4 ? _heatColor : const Color(0xFF8D6E63)),
      if (_step >= 4) const Icon(Icons.auto_awesome, size: 54, color: Colors.white),
    ]),
    const SizedBox(height: 16),
    Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(4, (i) { final done = i < _step; return Container(margin: const EdgeInsets.symmetric(horizontal: 5), width: 54, height: 54, decoration: BoxDecoration(shape: BoxShape.circle, color: done ? _heatColor : Colors.white10, border: Border.all(color: done ? Colors.white : Colors.white24, width: 2)), alignment: Alignment.center, child: Icon([Icons.key_rounded, Icons.lock_open_rounded, Icons.diamond_rounded, Icons.inventory_2_rounded][i], color: done ? Colors.white : Colors.white38)); })),
    const SizedBox(height: 20),
    Text(_message, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)),
    const SizedBox(height: 22),
    GestureDetector(onTap: _stepTap, child: _pushButton('PUSH!', const Color(0xFFFF3D00))),
  ]);

  Widget _battleBody() => Column(mainAxisAlignment: MainAxisAlignment.center, children: [
    const Text('DEFEAT 4 ENEMIES', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w900, letterSpacing: 2)),
    const SizedBox(height: 16),
    Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(4, (i) { final dead = i < _defeated; final active = i == _battleTarget; return AnimatedContainer(duration: const Duration(milliseconds: 180), margin: const EdgeInsets.symmetric(horizontal: 5), width: 65, height: 91, decoration: BoxDecoration(borderRadius: BorderRadius.circular(15), color: dead ? Colors.black38 : active ? const Color(0xFF5A174E) : Colors.white10, border: Border.all(color: dead ? Colors.white12 : active ? const Color(0xFFFF4081) : Colors.white24, width: active ? 3 : 1.5), boxShadow: active ? const [BoxShadow(color: Color(0x88FF4081), blurRadius: 16)] : null), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text(dead ? '💥' : ['👾','👹','🤖','🐲'][i], style: const TextStyle(fontSize: 34)), const SizedBox(height: 4), Text(dead ? '撃破' : 'ENEMY ${i + 1}', style: TextStyle(color: dead ? Colors.white38 : Colors.white, fontSize: 10, fontWeight: FontWeight.w900))])); })),
    const SizedBox(height: 18),
    Text('撃破  $_defeated / 4', style: TextStyle(color: _defeated >= 3 ? const Color(0xFFFFD740) : Colors.white, fontSize: 27, fontWeight: FontWeight.w900)),
    const SizedBox(height: 10),
    Text(_message, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w900)),
    const SizedBox(height: 22),
    GestureDetector(onTap: _battleTap, child: _pushButton('ATTACK!', const Color(0xFFD500F9), wide: true)),
  ]);

  Widget _pushButton(String text, Color color, {bool wide = false}) => Container(width: wide ? 190 : 150, height: wide ? 82 : 105, decoration: BoxDecoration(borderRadius: BorderRadius.circular(wide ? 42 : 55), gradient: RadialGradient(colors: [color.withOpacity(.65), color]), border: Border.all(color: Colors.white, width: 4), boxShadow: [BoxShadow(color: color.withOpacity(.55), blurRadius: 24, spreadRadius: 2), const BoxShadow(color: Colors.black54, blurRadius: 12, offset: Offset(0, 7))]), alignment: Alignment.center, child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900)));

  Widget _resultView() => Column(mainAxisAlignment: MainAxisAlignment.center, children: [
    if (_mode == _ChanceMode.battle) Text('$_defeated / 4 ENEMIES', style: TextStyle(color: _heatColor, fontSize: 24, fontWeight: FontWeight.w900)),
    Text(_result == 4000 ? '✨ PERFECT!! ✨' : _heatText, style: TextStyle(color: _heatColor, fontSize: 30, fontWeight: FontWeight.w900)),
    const SizedBox(height: 16),
    Text('$_result', style: const TextStyle(color: Colors.white, fontSize: 76, fontWeight: FontWeight.w900, shadows: [Shadow(color: Colors.white54, blurRadius: 18)])),
    const Text('EXP', style: TextStyle(color: Colors.white70, fontSize: 20, fontWeight: FontWeight.w900)),
    if (widget.multiplier > 1) Padding(padding: const EdgeInsets.only(top: 10), child: Text('× ${widget.multiplier}  →  ${_result * widget.multiplier}', style: const TextStyle(color: Color(0xFFFFD54F), fontSize: 22, fontWeight: FontWeight.w900))),
    const SizedBox(height: 30),
    FilledButton(onPressed: () => Navigator.of(context).pop(_result), style: FilledButton.styleFrom(backgroundColor: const Color(0xFFFFC107), foregroundColor: const Color(0xFF251100), padding: const EdgeInsets.symmetric(horizontal: 44, vertical: 16)), child: const Text('GET!', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900))),
  ]);
}


class _SuruBoardPainter extends CustomPainter {
  const _SuruBoardPainter({
    required this.pieces,
    required this.flashes,
    required this.bursts,
    required this.hub,
    required this.ports,
    required this.pegs,
    required this.letterBumpers,
    required this.starBumper,
    required this.pockets,
    required this.separators,
    required this.playRect,
    required this.pieceRadius,
    required this.pegRadius,
    required this.manualFinger,
    required this.manualHoverPort,
    required this.rewardTokens,
    required this.rewardCounter,
    required this.expBeamStartedAt,
    required this.expCountStartedAt,
    required this.expBeamAmount,
    required this.expTransferApplied,
    required this.expTransferDurationMs,
    required this.centerPocketHits,
  });

  final List<_DropPiece> pieces;
  final List<_ConnectionFlash> flashes;
  final List<_PocketBurst> bursts;
  final Offset hub;
  final List<Offset> ports;
  final List<Offset> pegs;
  final List<({String label, Offset center})> letterBumpers;
  final Offset starBumper;
  final List<Offset> pockets;
  final List<double> separators;
  final Rect playRect;
  final double pieceRadius;
  final double pegRadius;
  final Offset? manualFinger;
  final int? manualHoverPort;
  final List<_RewardToken> rewardTokens;
  final int rewardCounter;
  final DateTime? expBeamStartedAt;
  final DateTime? expCountStartedAt;
  final int expBeamAmount;
  final int expTransferApplied;
  final int expTransferDurationMs;
  final int centerPocketHits;

  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          Color(0xFF172145),
          Color(0xFF25164B),
          Color(0xFF371654),
          Color(0xFF14152D),
        ],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, bg);

    // Decorative stars / light speckles.
    final sparkle = Paint()..color = const Color(0x447EC8FF);
    for (var i = 0; i < 34; i++) {
      final x = (i * 71.0) % size.width;
      final y =
          (28 + ((i * 137.0) % math.max(50.0, size.height - 80))).toDouble();
      canvas.drawCircle(Offset(x, y), i % 5 == 0 ? 1.8 : .8, sparkle);
    }

    final machineRect = Rect.fromLTRB(
      playRect.left,
      math.max(8.0, hub.dy - 34),
      playRect.right,
      math.min(size.height - 4, playRect.bottom + 155),
    );
    final arena = RRect.fromRectAndRadius(
      machineRect,
      const Radius.circular(28),
    );
    canvas.drawRRect(
      arena,
      Paint()..color = const Color(0x99200F4A),
    );
    canvas.drawRRect(
      arena,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 5
        ..color = const Color(0xFFFFA52D),
    );
    canvas.drawRRect(
      arena.deflate(6),
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = const Color(0xFFFFE072),
    );

    _drawRewardCounter(canvas);
    _drawConnectionArea(canvas);
    _drawPegs(canvas);
    _drawLetterBumpers(canvas);
    _drawStar(canvas);
    _drawPocketArea(canvas);
    _drawCenterPocketCount(canvas);
    _drawTrails(canvas);
    _drawPieces(canvas);
    _drawBursts(canvas);
    _drawRewardTransfers(canvas, size);
  }

  Offset get _counterCenter =>
      Offset(playRect.center.dx, playRect.top + 34);

  void _drawRewardCounter(Canvas canvas) {
    final center = _counterCenter;
    final rect = RRect.fromRectAndRadius(
      Rect.fromCenter(
        center: center,
        width: math.min(220.0, playRect.width * .72),
        height: 54,
      ),
      const Radius.circular(16),
    );

    canvas.drawRRect(
      rect.inflate(7),
      Paint()
        ..color = const Color(0x44FFBF32)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12),
    );
    canvas.drawRRect(
      rect,
      Paint()
        ..shader = const LinearGradient(
          colors: [
            Color(0xFF5B210B),
            Color(0xFF1B101C),
            Color(0xFF5B210B),
          ],
        ).createShader(rect.outerRect),
    );
    canvas.drawRRect(
      rect,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 4
        ..color = const Color(0xFFFFB733),
    );

    // LED dots.
    final dotPaint = Paint()..color = const Color(0x44FFB432);
    for (var row = 0; row < 4; row++) {
      for (var col = 0; col < 21; col++) {
        canvas.drawCircle(
          Offset(
            rect.left + 10 + col * (rect.width - 20) / 20,
            rect.top + 9 + row * 12,
          ),
          1.1,
          dotPaint,
        );
      }
    }

    // As soon as transfer begins the big counter visually becomes 0.
    final shown = rewardCounter;
    final tp = TextPainter(
      text: TextSpan(
        text: '$shown',
        style: const TextStyle(
          color: Color(0xFFFFF4BA),
          fontSize: 29,
          fontWeight: FontWeight.w900,
          shadows: [
            Shadow(color: Color(0xFFFF8B1F), blurRadius: 9),
            Shadow(color: Colors.black, blurRadius: 3),
          ],
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(
      canvas,
      center - Offset(tp.width / 2, tp.height / 2),
    );
  }

  void _drawRewardTransfers(Canvas canvas, Size size) {
    final now = DateTime.now();
    final counter = _counterCenter;

    // Reward stars fly from the hit/pocket location into the counter.
    for (final token in rewardTokens) {
      if (token.arrived) continue;
      final elapsed = now.difference(token.startedAt).inMilliseconds;
      final t = (elapsed / 430).clamp(0.0, 1.0);
      final eased = Curves.easeOutCubic.transform(t);
      final control = Offset(
        (token.origin.dx + counter.dx) / 2,
        math.min(token.origin.dy, counter.dy) - 55,
      );
      final oneMinus = 1 - eased;
      final pos =
          token.origin * (oneMinus * oneMinus) +
          control * (2 * oneMinus * eased) +
          counter * (eased * eased);

      canvas.drawCircle(
        pos,
        18,
        Paint()
          ..color = const Color(0x55FFE15A)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10),
      );

      final star = TextPainter(
        text: const TextSpan(
          text: '★',
          style: TextStyle(
            color: Color(0xFFFFE55C),
            fontSize: 19,
            fontWeight: FontWeight.w900,
            shadows: [
              Shadow(color: Color(0xFFFF8E1A), blurRadius: 6),
            ],
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      star.paint(canvas, pos - Offset(star.width / 2, star.height / 2));

      final number = TextPainter(
        text: TextSpan(
          text: '${token.amount}',
          style: const TextStyle(
            color: Colors.white,
            fontSize: 9,
            fontWeight: FontWeight.w900,
            shadows: [
              Shadow(color: Colors.black, blurRadius: 3),
            ],
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      number.paint(
        canvas,
        pos + Offset(10, -number.height / 2),
      );
    }

    // The counter total itself becomes light and flies to the EXP gauge.
    // During this travel phase the EXP value is still unchanged.
    if (expBeamStartedAt != null &&
        expBeamAmount > 0 &&
        expCountStartedAt == null) {
      final elapsed = now.difference(expBeamStartedAt!).inMilliseconds;
      const duration = 720;
      final t = (elapsed / duration).clamp(0.0, 1.0);
      final eased = Curves.easeInOutCubic.transform(t);
      final target = Offset(size.width * .58, -18);
      final pos = Offset.lerp(counter, target, eased)!;

      canvas.drawLine(
        counter,
        pos,
        Paint()
          ..color = const Color(0x66FFF29A)
          ..strokeWidth = 15 * (1 - t) + 4
          ..strokeCap = StrokeCap.round
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12),
      );
      canvas.drawLine(
        counter,
        pos,
        Paint()
          ..color = const Color(0xFFFFF8CB)
          ..strokeWidth = 3.5
          ..strokeCap = StrokeCap.round,
      );
      canvas.drawCircle(
        pos,
        16,
        Paint()
          ..color = const Color(0x99FFF1A8)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8),
      );

      final flyingNumber = TextPainter(
        text: TextSpan(
          text: '$expBeamAmount',
          style: const TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.w900,
            shadows: [
              Shadow(color: Color(0xFFFFB52E), blurRadius: 10),
              Shadow(color: Colors.black, blurRadius: 3),
            ],
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      flyingNumber.paint(
        canvas,
        pos - Offset(flyingNumber.width / 2, flyingNumber.height / 2),
      );
    }
  }

  void _drawConnectionArea(Canvas canvas) {
    canvas.drawCircle(
      hub,
      22,
      Paint()
        ..color = const Color(0x5546B5FF)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 14),
    );
    canvas.drawCircle(
      hub,
      17,
      Paint()..color = const Color(0xFF2C1C65),
    );
    canvas.drawCircle(
      hub,
      17,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.4
        ..color = const Color(0xFFA3E7FF),
    );

    final hubText = TextPainter(
      text: const TextSpan(
        text: '手動',
        style: TextStyle(
          color: Colors.white,
          fontSize: 7,
          fontWeight: FontWeight.w900,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    hubText.paint(
      canvas,
      hub - Offset(hubText.width / 2, hubText.height / 2),
    );

    final guide = Paint()
      ..color = const Color(0x3358BFFF)
      ..strokeWidth = 1.2;
    for (final port in ports) {
      canvas.drawLine(hub, port, guide);
    }

    final now = DateTime.now();
    for (final flash in flashes) {
      if (flash.port < 0 || flash.port >= ports.length) continue;
      final elapsed = now.difference(flash.startedAt).inMilliseconds;
      final t = (elapsed / 450).clamp(0.0, 1.0);
      final a = ((1 - t) * 255).round().clamp(0, 255);

      canvas.drawLine(
        hub,
        ports[flash.port],
        Paint()
          ..color = Color.fromARGB(a ~/ 2, 81, 206, 255)
          ..strokeWidth = 12
          ..strokeCap = StrokeCap.round
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8),
      );
      canvas.drawLine(
        hub,
        ports[flash.port],
        Paint()
          ..color = Color.fromARGB(a, 214, 250, 255)
          ..strokeWidth = 3.2
          ..strokeCap = StrokeCap.round,
      );
    }

    if (manualFinger != null) {
      final to = manualHoverPort == null
          ? manualFinger!
          : ports[manualHoverPort!];
      canvas.drawLine(
        hub,
        to,
        Paint()
          ..color = const Color(0xFFFFE25C)
          ..strokeWidth = 5
          ..strokeCap = StrokeCap.round,
      );
    }

    for (var i = 0; i < ports.length; i++) {
      final selected = i == manualHoverPort;
      final p = ports[i];

      canvas.drawCircle(
        p,
        selected ? 5.5 : 3.2,
        Paint()
          ..color = const Color(0x5526AFFF)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
      );
      canvas.drawCircle(
        p,
        selected ? 4.5 : 2.5,
        Paint()..color = const Color(0xFF0E1021),
      );
      canvas.drawCircle(
        p,
        selected ? 4.5 : 2.5,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = selected ? 2.0 : 1.2
          ..color = selected
              ? const Color(0xFFFFE86A)
              : const Color(0xFF8FDAFF),
      );
    }
  }

  void _drawPegs(Canvas canvas) {
    for (final p in pegs) {
      canvas.drawCircle(
        p + const Offset(0, 1.2),
        pegRadius + 1.2,
        Paint()..color = const Color(0x55000000),
      );
      canvas.drawCircle(
        p,
        pegRadius + 1.4,
        Paint()
          ..shader = const RadialGradient(
            center: Alignment(-.35, -.35),
            colors: [
              Color(0xFFFFF2C2),
              Color(0xFFFFC247),
              Color(0xFF9A5A12),
            ],
          ).createShader(
            Rect.fromCircle(center: p, radius: pegRadius + 1.4),
          ),
      );
      canvas.drawCircle(
        p,
        pegRadius + 1.4,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = .8
          ..color = const Color(0xFFFFE89A),
      );
    }
  }

  void _drawLetterBumpers(Canvas canvas) {
    for (final bumper in letterBumpers) {
      final p = bumper.center;
      final isU = bumper.label == 'U';
      final ringColor =
          isU ? const Color(0xFF64DFFF) : const Color(0xFFFF63C8);

      canvas.drawCircle(
        p,
        16,
        Paint()
          ..color = ringColor.withOpacity(.18)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5),
      );
      canvas.drawCircle(
        p,
        13,
        Paint()
          ..shader = const RadialGradient(
            colors: [
              Color(0xFF432A79),
              Color(0xFF171226),
            ],
          ).createShader(
            Rect.fromCircle(center: p, radius: 13),
          ),
      );
      canvas.drawCircle(
        p,
        13,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.6
          ..color = ringColor,
      );

      final tp = TextPainter(
        text: TextSpan(
          text: bumper.label,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 14,
            fontWeight: FontWeight.w900,
            shadows: [
              Shadow(color: Colors.black, blurRadius: 3),
            ],
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();

      tp.paint(
        canvas,
        p - Offset(tp.width / 2, tp.height / 2),
      );
    }
  }

  void _drawStar(Canvas canvas) {
    canvas.drawCircle(
      starBumper,
      35,
      Paint()
        ..color = const Color(0x55FF4CE3)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12),
    );
    canvas.drawCircle(
      starBumper,
      25,
      Paint()
        ..shader = const RadialGradient(
          colors: [
            Color(0xFFFF89ED),
            Color(0xFF8F42D9),
            Color(0xFF46247C),
          ],
        ).createShader(
          Rect.fromCircle(center: starBumper, radius: 25),
        ),
    );
    canvas.drawCircle(
      starBumper,
      25,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 4
        ..color = const Color(0xFFFFDF63),
    );

    final tp = TextPainter(
      text: const TextSpan(
        text: '★',
        style: TextStyle(
          color: Colors.white,
          fontSize: 27,
          fontWeight: FontWeight.w900,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(
      canvas,
      starBumper - Offset(tp.width / 2, tp.height / 2),
    );
  }

  void _drawMiniGameGuards(Canvas canvas) {
    final cx = playRect.center.dx;
    final hole = Offset(cx, playRect.bottom - 82);

    // Exact scoring marker: the BRIGHT INNER OVAL is the suction hit area.
    // Outside glow is intentionally faint so the player reads the inner ring
    // as the only target.
    final hitRect = Rect.fromCenter(center: hole, width: 22, height: 12);
    canvas.drawOval(
      Rect.fromCenter(center: hole, width: 27, height: 17),
      Paint()
        ..color = const Color(0x335C27D9)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 7),
    );
    canvas.drawOval(
      hitRect,
      Paint()
        ..shader = const RadialGradient(
          colors: [
            Color(0xFF47107E),
            Color(0xFF160329),
            Color(0xFF020106),
          ],
        ).createShader(hitRect),
    );
    canvas.drawOval(
      hitRect,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.6
        ..color = const Color(0xFFF0D6FF),
    );

    // Straight-drop blocker. Clearly separate from the hole.
    final blockerY = playRect.bottom - 112;
    final blockerA = Offset(cx - 20, blockerY);
    final blockerB = Offset(cx + 20, blockerY);
    canvas.drawLine(
      blockerA,
      blockerB,
      Paint()
        ..color = const Color(0x5546C8FF)
        ..strokeWidth = 11
        ..strokeCap = StrokeCap.round
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5),
    );
    canvas.drawLine(
      blockerA,
      blockerB,
      Paint()
        ..color = const Color(0xFFFFE7B0)
        ..strokeWidth = 6
        ..strokeCap = StrokeCap.round,
    );
    canvas.drawLine(
      blockerA,
      blockerB,
      Paint()
        ..color = const Color(0xFF7A5260)
        ..strokeWidth = 3
        ..strokeCap = StrokeCap.round,
    );

    // Only two side rails. No lower rails overlapping the hole.
    final guards = <({Offset a, Offset b})>[
      (
        a: Offset(cx - 58, playRect.bottom - 108),
        b: Offset(cx - 27, playRect.bottom - 88),
      ),
      (
        a: Offset(cx + 58, playRect.bottom - 108),
        b: Offset(cx + 27, playRect.bottom - 88),
      ),
    ];
    for (final g in guards) {
      canvas.drawLine(
        g.a,
        g.b,
        Paint()
          ..color = const Color(0x5546C8FF)
          ..strokeWidth = 11
          ..strokeCap = StrokeCap.round
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5),
      );
      canvas.drawLine(
        g.a,
        g.b,
        Paint()
          ..color = const Color(0xFFFFE7B0)
          ..strokeWidth = 6
          ..strokeCap = StrokeCap.round,
      );
      canvas.drawLine(
        g.a,
        g.b,
        Paint()
          ..color = const Color(0xFF7A5260)
          ..strokeWidth = 3
          ..strokeCap = StrokeCap.round,
      );
    }

  }

  void _drawPocketArea(Canvas canvas) {
    final pocketWidth = playRect.width / 5;
    final top = playRect.bottom - 76;
    final bottom = playRect.bottom + 2;

    // Separator walls.
    for (final x in separators) {
      final wall = RRect.fromRectAndRadius(
        Rect.fromLTWH(x - 4, top, 8, bottom - top),
        const Radius.circular(4),
      );
      canvas.drawRRect(
        wall,
        Paint()..color = const Color(0xFFFFC14D),
      );
      canvas.drawRRect(
        wall,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5
          ..color = Colors.white,
      );
    }

    const labels = <String>[
      '100',
      '200',
      '',
      '200',
      '100',
    ];
    const baseColors = <Color>[
      Color(0xFF1D7DDF),
      Color(0xFF3AAA57),
      Color(0xFFD63C72),
      Color(0xFF3AAA57),
      Color(0xFF1D7DDF),
    ];

    for (var i = 0; i < 5; i++) {
      final left = playRect.left + i * pocketWidth + 4;
      final rect = RRect.fromRectAndRadius(
        Rect.fromLTWH(
          left,
          playRect.bottom - 64,
          pocketWidth - 8,
          58,
        ),
        const Radius.circular(10),
      );

      canvas.drawRRect(rect, Paint()..color = baseColors[i]);
      canvas.drawRRect(
        rect,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.5
          ..color = const Color(0xFFFFE06E),
      );

      final tp = TextPainter(
        text: TextSpan(
          text: labels[i],
          style: const TextStyle(
            color: Colors.white,
            fontSize: 10,
            height: 1.0,
            fontWeight: FontWeight.w900,
            shadows: [
              Shadow(
                color: Colors.black,
                blurRadius: 3,
              ),
            ],
          ),
        ),
        textAlign: TextAlign.center,
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(
        canvas,
        Offset(
          left + (pocketWidth - 8 - tp.width) / 2,
          playRect.bottom - 52,
        ),
      );
    }
  }

  void _drawCenterPocketCount(Canvas canvas) {
    final pocketWidth = playRect.width / 5;
    final center = Offset(
      playRect.left + pocketWidth * 2.5,
      playRect.bottom - 35,
    );

    final tp = TextPainter(
      text: TextSpan(
        text: centerPocketHits > 0 ? '×$centerPocketHits' : '×0',
        style: TextStyle(
          color: centerPocketHits > 0
              ? const Color(0xFFFFF06B)
              : const Color(0x99FFFFFF),
          fontSize: centerPocketHits > 0 ? 18 : 16,
          fontWeight: FontWeight.w900,
          shadows: const [
            Shadow(color: Colors.black, blurRadius: 5),
          ],
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();

    tp.paint(
      canvas,
      center - Offset(tp.width / 2, tp.height / 2),
    );
  }

  void _drawTrails(Canvas canvas) {
    for (final p in pieces) {
      if (p.trail.length < 2) continue;

      for (var i = 1; i < p.trail.length; i++) {
        final t = i / p.trail.length;
        canvas.drawLine(
          p.trail[i - 1],
          p.trail[i],
          Paint()
            ..color = Color.fromARGB(
              (38 + 90 * t).round(),
              103,
              214,
              255,
            )
            ..strokeWidth = 1.2 + t * 2
            ..strokeCap = StrokeCap.round,
        );
      }
    }
  }

  void _drawPieces(Canvas canvas) {
    for (final p in pieces) {
      canvas.save();
      canvas.translate(p.x, p.y);
      canvas.rotate(p.angle);

      canvas.drawCircle(
        Offset.zero,
        pieceRadius * 1.75,
        Paint()
          ..color = const Color(0x4468D8FF)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5),
      );

      final s = pieceRadius * 2;
      canvas.translate(-pieceRadius, -pieceRadius);
      _MiniCharacterPainter(type: p.type).paint(
        canvas,
        Size(s, s),
      );
      canvas.restore();
    }
  }

  void _drawBursts(Canvas canvas) {
    final now = DateTime.now();

    for (final b in bursts) {
      final elapsed = now.difference(b.startedAt).inMilliseconds;
      final duration = b.kind == 4 ? 1400.0 : b.kind == 5 ? 950.0 : 720.0;
      final t = (elapsed / duration).clamp(0.0, 1.0);
      final alpha = ((1 - t) * 255).round().clamp(0, 255);
      final radius = b.kind == 4 ? 24 + 72 * t : b.kind == 5 ? 18 + 50 * t : 12 + 34 * t;

      canvas.drawCircle(
        b.center,
        radius,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 4 * (1 - t) + 1
          ..color = Color.fromARGB(
            alpha,
            b.kind == 5 ? 255 : b.kind == 3 ? 255 : 118,
            b.kind == 5 ? 225 : b.kind == 3 ? 108 : 221,
            b.kind == 5 ? 75 : 255,
          ),
      );

      for (var i = 0; i < 8; i++) {
        final a = i * math.pi / 4 + t * .8;
        final p = b.center +
            Offset(math.cos(a), math.sin(a)) * (10 + 38 * t);
        canvas.drawCircle(
          p,
          2.5 * (1 - t) + .8,
          Paint()
            ..color = Color.fromARGB(
              alpha,
              255,
              b.kind == 2 ? 226 : 185,
              82,
            ),
        );
      }

      final tp = TextPainter(
        text: TextSpan(
          text: b.text,
          style: TextStyle(
            color: Color.fromARGB(alpha, 255, 255, 255),
            fontSize: b.kind == 4
                ? 18 + 7 * (1 - t)
                : b.kind == 5
                    ? 20 + 8 * (1 - t)
                    : 11 + 5 * (1 - t),
            fontWeight: FontWeight.w900,
            shadows: [
              Shadow(
                color: Color.fromARGB(
                  (alpha * .78).round().clamp(0, 255),
                  0,
                  0,
                  0,
                ),
                blurRadius: 4,
              ),
            ],
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();

      tp.paint(
        canvas,
        b.center +
            Offset(
              -tp.width / 2,
              b.kind == 4 ? -48 - t * 30 : -34 - t * 24,
            ),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _SuruBoardPainter oldDelegate) => true;
}

class _MiniCharacterPainter extends CustomPainter {
  const _MiniCharacterPainter({required this.type});

  final int type;

  Paint _gloss(
    Color light,
    Color base,
    Color dark,
    Offset c,
    double r,
  ) {
    return Paint()
      ..shader = RadialGradient(
        center: const Alignment(-.34, -.42),
        radius: 1.05,
        colors: [light, base, dark],
        stops: const [0, .55, 1],
      ).createShader(Rect.fromCircle(center: c, radius: r));
  }

  void _eyes(Canvas canvas, Offset c, double r) {
    final p = Paint()..color = const Color(0xFF202020);
    canvas.drawCircle(c + Offset(-r * .25, -r * .08), r * .085, p);
    canvas.drawCircle(c + Offset(r * .25, -r * .08), r * .085, p);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = math.min(size.width, size.height) / 2;

    switch (type % 5) {
      case 0:
        canvas.drawCircle(
          c,
          r * .82,
          _gloss(
            const Color(0xFFFFF08A),
            const Color(0xFFFFC928),
            const Color(0xFFE79A00),
            c,
            r,
          ),
        );
        _eyes(canvas, c, r);
        break;
      case 1:
        final body = _gloss(
          const Color(0xFFA6F3A9),
          const Color(0xFF63D46B),
          const Color(0xFF2C9A42),
          c,
          r,
        );
        canvas.drawCircle(c, r * .82, body);
        canvas.drawCircle(
          c + Offset(-r * .42, -r * .54),
          r * .22,
          body,
        );
        canvas.drawCircle(
          c + Offset(r * .42, -r * .54),
          r * .22,
          body,
        );
        _eyes(canvas, c, r);
        break;
      case 2:
        canvas.drawCircle(
          c,
          r * .82,
          _gloss(
            const Color(0xFF9DE1FF),
            const Color(0xFF4F9ED8),
            const Color(0xFF2464A8),
            c,
            r,
          ),
        );
        canvas.drawOval(
          Rect.fromCenter(
            center: c + Offset(0, r * .18),
            width: r * .98,
            height: r * 1.05,
          ),
          Paint()..color = const Color(0xFFEAF6FF),
        );
        _eyes(canvas, c, r);
        break;
      case 3:
        final ear = Paint()..color = const Color(0xFF7453B7);
        canvas.drawOval(
          Rect.fromCenter(
            center: c + Offset(-r * .63, -r * .12),
            width: r * .36,
            height: r * .65,
          ),
          ear,
        );
        canvas.drawOval(
          Rect.fromCenter(
            center: c + Offset(r * .63, -r * .12),
            width: r * .36,
            height: r * .65,
          ),
          ear,
        );
        canvas.drawCircle(
          c,
          r * .82,
          _gloss(
            const Color(0xFFE4D7FF),
            const Color(0xFFBFA8F2),
            const Color(0xFF8060C7),
            c,
            r,
          ),
        );
        _eyes(canvas, c, r);
        break;
      default:
        final body = _gloss(
          const Color(0xFFFFE2EE),
          const Color(0xFFFFA7C7),
          const Color(0xFFE66B9B),
          c,
          r,
        );
        canvas.drawOval(
          Rect.fromCenter(
            center: c + Offset(-r * .27, -r * .72),
            width: r * .28,
            height: r * .72,
          ),
          body,
        );
        canvas.drawOval(
          Rect.fromCenter(
            center: c + Offset(r * .27, -r * .72),
            width: r * .28,
            height: r * .72,
          ),
          body,
        );
        canvas.drawCircle(
          c + Offset(0, r * .06),
          r * .76,
          body,
        );
        _eyes(canvas, c + Offset(0, r * .04), r);
        break;
    }
  }

  @override
  bool shouldRepaint(covariant _MiniCharacterPainter oldDelegate) =>
      oldDelegate.type != type;
}
