import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../game/game_controller.dart';

enum _Role { attacker, tank, support }

class _Unit {
  _Unit(
    this.pos,
    this.type,
    this.role, {
    required this.ally,
  });

  Offset pos;
  Offset vel = Offset.zero;
  final int type;
  final _Role role;
  final bool ally;
  int hp = 100;
  int? target;
  double cooldown = 0;
  double flash = 0;
}

class ConnectBattleScreen extends StatefulWidget {
  final GameController controller;
  final int stageId;

  const ConnectBattleScreen({
    super.key,
    required this.controller,
    required this.stageId,
  });

  @override
  State<ConnectBattleScreen> createState() => _ConnectBattleScreenState();
}

class _ConnectBattleScreenState extends State<ConnectBattleScreen> {
  final math.Random _random = math.Random();
  final List<_Unit> _allies = <_Unit>[];
  final List<_Unit> _enemies = <_Unit>[];

  Timer? _timer;
  DateTime _last = DateTime.now();
  int? _dragAlly;
  Offset? _finger;
  bool _auto = false;
  bool _finished = false;
  bool _battleStarted = false;
  int _speed = 1;
  Size _field = Size.zero;

  static const double _unitRadius = 27;
  static const double _sameTeamMinDistance = 62;
  static const double _enemyMinDistance = 55;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(
      const Duration(milliseconds: 33),
      (_) => _tick(),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _seed(Size size) {
    if (_allies.isNotEmpty) return;
    _field = size;

    _allies.addAll(<_Unit>[
      _Unit(Offset(size.width * .18, size.height * .28), 0, _Role.attacker, ally: true),
      _Unit(Offset(size.width * .16, size.height * .55), 2, _Role.tank, ally: true),
      _Unit(Offset(size.width * .20, size.height * .79), 4, _Role.support, ally: true),
    ]);

    _enemies.addAll(<_Unit>[
      _Unit(Offset(size.width * .78, size.height * .25), 1, _Role.attacker, ally: false),
      _Unit(Offset(size.width * .82, size.height * .52), 3, _Role.attacker, ally: false),
      _Unit(Offset(size.width * .76, size.height * .79), 2, _Role.attacker, ally: false),
    ]);
  }

  void _tick() {
    if (!mounted || _finished || _field == Size.zero) return;

    final DateTime now = DateTime.now();
    var dt = now.difference(_last).inMilliseconds / 1000;
    _last = now;

    if (!_battleStarted) {
      if (mounted) setState(() {});
      return;
    }

    dt = math.min(.08, dt) * _speed;
    final int subSteps = _speed >= 4 ? 2 : 1;
    for (var i = 0; i < subSteps; i++) {
      _step(dt / subSteps);
    }
    if (mounted) setState(() {});
  }

  void _step(double dt) {
    if (_auto) _autoTargets();

    for (var i = 0; i < _allies.length; i++) {
      _moveAlly(i, dt);
    }
    for (var i = 0; i < _enemies.length; i++) {
      _moveEnemy(i, dt);
    }

    _resolveAllCollisions();

    if (_enemies.every((u) => u.hp <= 0)) {
      _win();
    } else if (_allies.every((u) => u.hp <= 0)) {
      _finished = true;
    }
  }

  Offset _wander(_Unit unit, double dt, bool leftSide) {
    final double cx = leftSide ? _field.width * .30 : _field.width * .70;
    final double cy = _field.height * .52;
    final Offset toCenter = Offset(cx, cy) - unit.pos;
    final Offset jitter = Offset(
      (_random.nextDouble() - .5) * 13,
      (_random.nextDouble() - .5) * 13,
    );
    unit.vel = unit.vel * .95 + toCenter * .0025 + jitter * dt;
    return unit.vel;
  }

  void _moveAlly(int index, double dt) {
    final _Unit unit = _allies[index];
    if (unit.hp <= 0) return;

    unit.cooldown = math.max(0, unit.cooldown - dt);
    unit.flash = math.max(0, unit.flash - dt);

    final bool support = unit.role == _Role.support;
    Offset? goal;

    if (unit.target != null) {
      if (support) {
        if (unit.target! < _allies.length && _allies[unit.target!].hp > 0) {
          goal = _allies[unit.target!].pos;
        } else {
          unit.target = null;
        }
      } else {
        if (unit.target! < _enemies.length && _enemies[unit.target!].hp > 0) {
          goal = _enemies[unit.target!].pos;
        } else {
          unit.target = null;
        }
      }
    }

    if (goal == null) {
      unit.pos += _wander(unit, dt, true) * dt;
      _clamp(unit);
      return;
    }

    final double distance = (goal - unit.pos).distance;
    final double range = support ? 68 : 61;

    if (distance > range) {
      final Offset dir = (goal - unit.pos) / math.max(distance, .001);
      unit.pos += dir * (unit.role == _Role.attacker ? 60 : 52) * dt;
    } else if (unit.cooldown <= 0) {
      unit.cooldown = support ? 1.25 : .85;
      if (support) {
        final _Unit target = _allies[unit.target!];
        target.hp = math.min(100, target.hp + 18);
        target.flash = .25;
      } else {
        final _Unit target = _enemies[unit.target!];
        target.hp = math.max(0, target.hp - (unit.role == _Role.tank ? 12 : 22));
        target.flash = .18;
      }
    }

    _clamp(unit);
  }

  void _moveEnemy(int index, double dt) {
    final _Unit unit = _enemies[index];
    if (unit.hp <= 0) return;

    unit.cooldown = math.max(0, unit.cooldown - dt);
    unit.flash = math.max(0, unit.flash - dt);

    int best = -1;
    double bestDistance = double.infinity;
    for (var i = 0; i < _allies.length; i++) {
      if (_allies[i].hp <= 0) continue;
      final double d = (_allies[i].pos - unit.pos).distance;
      if (d < bestDistance) {
        bestDistance = d;
        best = i;
      }
    }

    if (best < 0) return;
    final Offset goal = _allies[best].pos;

    if (bestDistance > 61) {
      unit.pos += (goal - unit.pos) / math.max(bestDistance, .001) * 43 * dt;
    } else if (unit.cooldown <= 0) {
      unit.cooldown = 1.15;
      _allies[best].hp = math.max(0, _allies[best].hp - 9);
      _allies[best].flash = .18;
    }

    _clamp(unit);
  }

  void _resolveAllCollisions() {
    _resolveTeamCollisions(_allies);
    _resolveTeamCollisions(_enemies);

    for (final _Unit ally in _allies) {
      if (ally.hp <= 0) continue;
      for (final _Unit enemy in _enemies) {
        if (enemy.hp <= 0) continue;
        _separatePair(ally, enemy, _enemyMinDistance);
      }
    }
  }

  void _resolveTeamCollisions(List<_Unit> team) {
    for (var i = 0; i < team.length; i++) {
      if (team[i].hp <= 0) continue;
      for (var j = i + 1; j < team.length; j++) {
        if (team[j].hp <= 0) continue;
        _separatePair(team[i], team[j], _sameTeamMinDistance);
      }
    }
  }

  void _separatePair(_Unit a, _Unit b, double minimumDistance) {
    Offset delta = b.pos - a.pos;
    double distance = delta.distance;

    if (distance >= minimumDistance) return;
    if (distance < .001) {
      delta = const Offset(1, 0);
      distance = 1;
    }

    final Offset dir = delta / distance;
    final double push = (minimumDistance - distance) / 2;
    a.pos -= dir * push;
    b.pos += dir * push;
    _clamp(a);
    _clamp(b);
  }

  void _clamp(_Unit unit) {
    unit.pos = Offset(
      unit.pos.dx.clamp(_unitRadius + 4, _field.width - _unitRadius - 4),
      unit.pos.dy.clamp(_unitRadius + 12, _field.height - _unitRadius - 8),
    );
  }

  void _autoTargets() {
    for (var i = 0; i < _allies.length; i++) {
      final _Unit unit = _allies[i];
      if (unit.hp <= 0) continue;

      if (unit.role == _Role.support) {
        int best = -1;
        int lowestHp = 101;
        for (var j = 0; j < _allies.length; j++) {
          if (i == j || _allies[j].hp <= 0) continue;
          if (_allies[j].hp < lowestHp) {
            lowestHp = _allies[j].hp;
            best = j;
          }
        }
        if (best < 0) {
          for (var j = 0; j < _allies.length; j++) {
            if (i != j && _allies[j].hp > 0) {
              best = j;
              break;
            }
          }
        }
        unit.target = best < 0 ? null : best;
      } else if (unit.target == null ||
          unit.target! >= _enemies.length ||
          _enemies[unit.target!].hp <= 0) {
        int best = -1;
        double bestDistance = double.infinity;
        for (var j = 0; j < _enemies.length; j++) {
          if (_enemies[j].hp <= 0) continue;
          final double d = (_enemies[j].pos - unit.pos).distance;
          if (d < bestDistance) {
            bestDistance = d;
            best = j;
          }
        }
        unit.target = best < 0 ? null : best;
      }
    }
  }

  Future<void> _win() async {
    if (_finished) return;
    _finished = true;
    _timer?.cancel();
    await widget.controller.completeRpgStage(widget.stageId);
    if (!mounted) return;

    await showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('勝利！ 🎉'),
        content: const Text('敵をすべて倒しました！'),
        actions: <Widget>[
          FilledButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
    if (mounted) Navigator.pop(context);
  }

  void _startBattle() {
    if (_battleStarted || _finished) return;
    if (_auto) _autoTargets();
    _last = DateTime.now();
    setState(() => _battleStarted = true);
  }

  void _resultMode() {
    if (_finished) return;
    if (!_battleStarted) {
      _autoTargets();
      _battleStarted = true;
    }
    setState(() {
      _speed = 4;
      _auto = true;
      _last = DateTime.now();
    });
  }

  void _startDrag(DragStartDetails details) {
    int best = -1;
    double bestDistance = 45;
    for (var i = 0; i < _allies.length; i++) {
      if (_allies[i].hp <= 0) continue;
      final double d = (_allies[i].pos - details.localPosition).distance;
      if (d < bestDistance) {
        bestDistance = d;
        best = i;
      }
    }

    if (best >= 0) {
      _dragAlly = best;
      _finger = details.localPosition;
      setState(() {});
    }
  }

  void _moveDrag(DragUpdateDetails details) {
    if (_dragAlly == null) return;
    _finger = details.localPosition;
    setState(() {});
  }

  void _endDrag(DragEndDetails details) {
    if (_dragAlly == null) return;

    final _Unit source = _allies[_dragAlly!];
    int best = -1;
    double bestDistance = 56;
    final Offset pointer = _finger ?? Offset.zero;

    if (source.role == _Role.support) {
      for (var i = 0; i < _allies.length; i++) {
        if (i == _dragAlly || _allies[i].hp <= 0) continue;
        final double d = (_allies[i].pos - pointer).distance;
        if (d < bestDistance) {
          bestDistance = d;
          best = i;
        }
      }
    } else {
      for (var i = 0; i < _enemies.length; i++) {
        if (_enemies[i].hp <= 0) continue;
        final double d = (_enemies[i].pos - pointer).distance;
        if (d < bestDistance) {
          bestDistance = d;
          best = i;
        }
      }
    }

    if (best >= 0) source.target = best;
    _dragAlly = null;
    _finger = null;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF182638),
      body: SafeArea(
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.fromLTRB(6, 4, 10, 4),
              child: Row(
                children: <Widget>[
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                  ),
                  Text(
                    '冒険  STAGE ${widget.stageId}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      fontSize: 18,
                    ),
                  ),
                  const Spacer(),
                  _modeButton('AUTO', _auto, () {
                    setState(() {
                      _auto = !_auto;
                      if (_auto) _autoTargets();
                    });
                  }),
                  const SizedBox(width: 5),
                  _modeButton(_speed == 2 ? '×2' : '倍速', _speed == 2, () {
                    setState(() => _speed = _speed == 2 ? 1 : 2);
                  }),
                  const SizedBox(width: 5),
                  _modeButton('結果', _speed == 4, _resultMode),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 6),
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: Text(
                      _battleStarted
                          ? '戦闘中：味方からドラッグでつなぎ直せます'
                          : '作戦タイム：敵はまだ動きません。先につなぐ相手を決めよう',
                      style: TextStyle(
                        color: _battleStarted
                            ? const Color(0xFFFFE18A)
                            : const Color(0xFF9BE8FF),
                        fontWeight: FontWeight.w800,
                        fontSize: 12,
                      ),
                    ),
                  ),
                  if (!_battleStarted)
                    FilledButton.icon(
                      onPressed: _startBattle,
                      icon: const Icon(Icons.play_arrow),
                      label: const Text('戦闘開始'),
                      style: FilledButton.styleFrom(
                        backgroundColor: const Color(0xFFFFD85A),
                        foregroundColor: Colors.black,
                      ),
                    ),
                ],
              ),
            ),
            Expanded(
              child: LayoutBuilder(
                builder: (context, box) {
                  final Size size = Size(box.maxWidth, box.maxHeight);
                  _field = size;
                  _seed(size);
                  return GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onPanStart: _startDrag,
                    onPanUpdate: _moveDrag,
                    onPanEnd: _endDrag,
                    child: CustomPaint(
                      size: size,
                      painter: _FieldPainter(
                        _allies,
                        _enemies,
                        _dragAlly,
                        _finger,
                        _battleStarted,
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _modeButton(String text, bool on, VoidCallback tap) {
    return SizedBox(
      height: 34,
      child: FilledButton.tonal(
        onPressed: tap,
        style: FilledButton.styleFrom(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          backgroundColor: on ? const Color(0xFFFFD85A) : Colors.white12,
          foregroundColor: on ? Colors.black : Colors.white,
        ),
        child: Text(
          text,
          style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12),
        ),
      ),
    );
  }
}

class _FieldPainter extends CustomPainter {
  final List<_Unit> allies;
  final List<_Unit> enemies;
  final int? drag;
  final Offset? finger;
  final bool battleStarted;

  _FieldPainter(
    this.allies,
    this.enemies,
    this.drag,
    this.finger,
    this.battleStarted,
  );

  @override
  void paint(Canvas canvas, Size size) {
    final Paint bg = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: <Color>[Color(0xFF27415B), Color(0xFF172C35)],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, bg);

    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(size.width * .5, size.height * .55),
        width: size.width * .92,
        height: size.height * .75,
      ),
      Paint()..color = const Color(0x2237C78B),
    );

    if (!battleStarted) {
      final Paint divider = Paint()
        ..color = const Color(0x447EDBFF)
        ..strokeWidth = 1.5;
      for (double y = 45; y < size.height; y += 16) {
        canvas.drawLine(
          Offset(size.width * .5, y),
          Offset(size.width * .5, math.min(y + 8, size.height)),
          divider,
        );
      }
    }

    final Paint line = Paint()
      ..strokeWidth = 2.5
      ..strokeCap = StrokeCap.round;

    for (var i = 0; i < allies.length; i++) {
      final _Unit unit = allies[i];
      if (unit.hp <= 0 || unit.target == null) continue;
      Offset? target;
      if (unit.role == _Role.support) {
        if (unit.target! < allies.length) target = allies[unit.target!].pos;
        line.color = const Color(0xCC70F0A5);
      } else {
        if (unit.target! < enemies.length) target = enemies[unit.target!].pos;
        line.color = const Color(0xBBFFD86B);
      }
      if (target != null) canvas.drawLine(unit.pos, target, line);
    }

    if (drag != null && finger != null) {
      line.color = allies[drag!].role == _Role.support
          ? const Color(0xFF79F5A9)
          : const Color(0xFFFFE06A);
      line.strokeWidth = 5;
      canvas.drawLine(allies[drag!].pos, finger!, line);
    }

    for (final _Unit unit in enemies) {
      _drawUnit(canvas, unit, false);
    }
    for (final _Unit unit in allies) {
      _drawUnit(canvas, unit, true);
    }

    _label(canvas, '味方', const Offset(18, 12), const Color(0xFF8DE7FF));
    _label(canvas, '敵', Offset(size.width - 48, 12), const Color(0xFFFF8D9E));
  }

  void _drawUnit(Canvas canvas, _Unit unit, bool ally) {
    if (unit.hp <= 0) return;

    canvas.drawOval(
      Rect.fromCenter(
        center: unit.pos + const Offset(0, 23),
        width: 46,
        height: 14,
      ),
      Paint()..color = Colors.black26,
    );

    if (unit.flash > 0) {
      canvas.drawCircle(
        unit.pos,
        34,
        Paint()..color = Colors.white.withValues(alpha: .52),
      );
    }

    canvas.drawCircle(
      unit.pos,
      31,
      Paint()
        ..color = ally ? const Color(0x885EDCF4) : const Color(0x88FF6B7E)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3,
    );

    canvas.save();
    canvas.translate(unit.pos.dx - 29, unit.pos.dy - 29);
    const Size characterSize = Size(58, 58);
    _BattleRoundCharacterPainter(type: unit.type).paint(canvas, characterSize);
    canvas.restore();

    final Rect hpRect = Rect.fromLTWH(unit.pos.dx - 25, unit.pos.dy - 37, 50, 6);
    canvas.drawRRect(
      RRect.fromRectAndRadius(hpRect, const Radius.circular(4)),
      Paint()..color = Colors.black45,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(hpRect.left, hpRect.top, 50 * unit.hp / 100, 6),
        const Radius.circular(4),
      ),
      Paint()..color = ally ? const Color(0xFF62E58C) : const Color(0xFFFF6678),
    );

    if (ally) {
      final String mark = unit.role == _Role.support
          ? 'SUP'
          : unit.role == _Role.tank
              ? 'DEF'
              : 'ATK';
      _label(
        canvas,
        mark,
        unit.pos + const Offset(-14, 30),
        unit.role == _Role.support ? const Color(0xFF86F0AD) : Colors.white70,
        9,
      );
    }
  }

  void _label(Canvas canvas, String text, Offset pos, Color color, [double fontSize = 12]) {
    final TextPainter painter = TextPainter(
      text: TextSpan(
        text: text,
        style: TextStyle(
          color: color,
          fontSize: fontSize,
          fontWeight: FontWeight.w900,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    painter.paint(canvas, pos);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

// V50: Uses the same round character designs as the old Tsum-Tsum style puzzle.
class _BattleRoundCharacterPainter {
  final int type;

  const _BattleRoundCharacterPainter({required this.type});

  Paint _gloss(Color light, Color base, Color dark, Offset c, double r) {
    return Paint()
      ..shader = RadialGradient(
        center: const Alignment(-.34, -.42),
        radius: 1.05,
        colors: <Color>[light, base, dark],
        stops: const <double>[0, .55, 1],
      ).createShader(Rect.fromCircle(center: c, radius: r));
  }

  void _bodyShine(Canvas canvas, Offset c, double r) {
    canvas.drawOval(
      Rect.fromCenter(
        center: c + Offset(-r * .28, -r * .38),
        width: r * .48,
        height: r * .25,
      ),
      Paint()..color = Colors.white.withValues(alpha: .34),
    );
  }

  void paint(Canvas canvas, Size size) {
    final Offset c = Offset(size.width / 2, size.height / 2);
    final double r = math.min(size.width, size.height) / 2;
    final Paint shadow = Paint()
      ..color = const Color(0x33000000)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3);
    canvas.drawOval(
      Rect.fromCenter(
        center: c + Offset(0, r * .12),
        width: r * 1.62,
        height: r * 1.58,
      ),
      shadow,
    );

    switch (type) {
      case 0:
        _drawChick(canvas, c, r);
        break;
      case 1:
        _drawFrog(canvas, c, r);
        break;
      case 2:
        _drawPenguin(canvas, c, r);
        break;
      case 3:
        _drawDog(canvas, c, r);
        break;
      default:
        _drawBunny(canvas, c, r);
    }
  }

  void _eyes(Canvas canvas, Offset c, double r, {double y = -.10}) {
    final Paint eye = Paint()..color = const Color(0xFF252525);
    canvas.drawCircle(c + Offset(-r * .25, r * y), r * .075, eye);
    canvas.drawCircle(c + Offset(r * .25, r * y), r * .075, eye);
    final Paint hi = Paint()..color = Colors.white.withValues(alpha: .9);
    canvas.drawCircle(c + Offset(-r * .225, r * (y - .025)), r * .018, hi);
    canvas.drawCircle(c + Offset(r * .275, r * (y - .025)), r * .018, hi);
  }

  void _blush(Canvas canvas, Offset c, double r) {
    final Paint paint = Paint()..color = const Color(0x55F38E9E);
    canvas.drawCircle(c + Offset(-r * .48, r * .13), r * .11, paint);
    canvas.drawCircle(c + Offset(r * .48, r * .13), r * .11, paint);
  }

  void _drawChick(Canvas canvas, Offset c, double r) {
    final Paint body = _gloss(
      const Color(0xFFFFF08A),
      const Color(0xFFFFC928),
      const Color(0xFFE79A00),
      c,
      r,
    );
    canvas.drawCircle(c, r * .82, body);
    _bodyShine(canvas, c, r);
    final Paint wing = Paint()..color = const Color(0xFFFFB51E);
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(-r * .66, r * .12), width: r * .28, height: r * .48),
      wing,
    );
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(r * .66, r * .12), width: r * .28, height: r * .48),
      wing,
    );
    _eyes(canvas, c, r);
    _blush(canvas, c, r);
    final Path beak = Path()
      ..moveTo(c.dx - r * .10, c.dy + r * .08)
      ..lineTo(c.dx + r * .12, c.dy + r * .08)
      ..lineTo(c.dx, c.dy + r * .20)
      ..close();
    canvas.drawPath(beak, Paint()..color = const Color(0xFFF18A18));
  }

  void _drawFrog(Canvas canvas, Offset c, double r) {
    final Paint body = _gloss(
      const Color(0xFFA6F3A9),
      const Color(0xFF63D46B),
      const Color(0xFF2C9A42),
      c,
      r,
    );
    final Paint deep = Paint()..color = const Color(0xFF25873A);
    canvas.drawCircle(c, r * .82, body);
    _bodyShine(canvas, c, r);
    canvas.drawCircle(c + Offset(-r * .42, -r * .55), r * .25, body);
    canvas.drawCircle(c + Offset(r * .42, -r * .55), r * .25, body);
    canvas.drawCircle(c + Offset(-r * .42, -r * .55), r * .11, Paint()..color = Colors.white);
    canvas.drawCircle(c + Offset(r * .42, -r * .55), r * .11, Paint()..color = Colors.white);
    canvas.drawCircle(c + Offset(-r * .42, -r * .55), r * .055, Paint()..color = const Color(0xFF1E2A25));
    canvas.drawCircle(c + Offset(r * .42, -r * .55), r * .055, Paint()..color = const Color(0xFF1E2A25));
    _blush(canvas, c, r);
    final Paint smile = Paint()
      ..color = deep.color
      ..style = PaintingStyle.stroke
      ..strokeWidth = math.max(1.8, r * .07)
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(
      Rect.fromCenter(center: c + Offset(0, r * .12), width: r * .60, height: r * .36),
      .15,
      math.pi - .30,
      false,
      smile,
    );
  }

  void _drawPenguin(Canvas canvas, Offset c, double r) {
    final Paint blue = _gloss(
      const Color(0xFF9DE1FF),
      const Color(0xFF4F9ED8),
      const Color(0xFF2464A8),
      c,
      r,
    );
    final Paint deepBlue = Paint()..color = const Color(0xFF2E6F9F);
    final Paint belly = Paint()..color = const Color(0xFFEAF6FF);
    canvas.drawCircle(c, r * .82, blue);
    _bodyShine(canvas, c, r);
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(0, r * .19), width: r * 1.00, height: r * 1.10),
      belly,
    );
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(-r * .62, r * .08), width: r * .22, height: r * .56),
      deepBlue,
    );
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(r * .62, r * .08), width: r * .22, height: r * .56),
      deepBlue,
    );
    _eyes(canvas, c + Offset(0, -r * .10), r, y: 0);
    final Path beak = Path()
      ..moveTo(c.dx - r * .10, c.dy + r * .01)
      ..lineTo(c.dx + r * .10, c.dy + r * .01)
      ..lineTo(c.dx, c.dy + r * .15)
      ..close();
    canvas.drawPath(beak, Paint()..color = const Color(0xFFFF9B2F));
  }

  void _drawDog(Canvas canvas, Offset c, double r) {
    final Paint ear = Paint()..color = const Color(0xFF7453B7);
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(-r * .62, -r * .18), width: r * .42, height: r * .72),
      ear,
    );
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(r * .62, -r * .18), width: r * .42, height: r * .72),
      ear,
    );
    canvas.drawCircle(
      c,
      r * .82,
      _gloss(
        const Color(0xFFE4D7FF),
        const Color(0xFFBFA8F2),
        const Color(0xFF8060C7),
        c,
        r,
      ),
    );
    _bodyShine(canvas, c, r);
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(r * .26, -r * .18), width: r * .36, height: r * .46),
      ear,
    );
    _eyes(canvas, c, r);
    _blush(canvas, c, r);
    canvas.drawCircle(c + Offset(0, r * .16), r * .09, Paint()..color = const Color(0xFF3E315A));
  }

  void _drawBunny(Canvas canvas, Offset c, double r) {
    final Paint body = _gloss(
      const Color(0xFFFFE2EE),
      const Color(0xFFFFA7C7),
      const Color(0xFFE66B9B),
      c,
      r,
    );
    final Paint inner = Paint()..color = const Color(0xFFFF6F9F);
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(-r * .28, -r * .86), width: r * .32, height: r * .88),
      body,
    );
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(r * .28, -r * .86), width: r * .32, height: r * .88),
      body,
    );
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(-r * .28, -r * .86), width: r * .11, height: r * .55),
      inner,
    );
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(r * .28, -r * .86), width: r * .11, height: r * .55),
      inner,
    );
    canvas.drawCircle(c + Offset(0, r * .04), r * .76, body);
    _bodyShine(canvas, c + Offset(0, r * .04), r * .92);
    _eyes(canvas, c + Offset(0, r * .02), r);
    _blush(canvas, c, r);
    canvas.drawCircle(c + Offset(0, r * .16), r * .06, Paint()..color = const Color(0xFF8C3F61));
  }
}
