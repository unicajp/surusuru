import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../game/game_controller.dart';

class ConnectBattleScreen extends StatefulWidget {
  final GameController controller;
  final int stageId;

  const ConnectBattleScreen({
    super.key,
    required this.controller,
    required this.stageId,
  });

  @override
  State<ConnectBattleScreen> createState() => _ConnectBattleScreenState();
}

class _DummyEnemy {
  _DummyEnemy(this.pos, this.phase);
  Offset pos;
  final double phase;
}

class _ConnectBattleScreenState extends State<ConnectBattleScreen> {
  Timer? _timer;
  DateTime _last = DateTime.now();
  Size _field = Size.zero;

  Offset _hero = const Offset(190, 360);
  Offset _velocity = Offset.zero;
  Offset _target = const Offset(190, 360);
  bool _holding = false;
  double _time = 0;
  double _tilt = 0;
  final List<_DummyEnemy> _enemies = <_DummyEnemy>[];

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(milliseconds: 16), (_) => _tick());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _seed(Size size) {
    if (_field != Size.zero) return;
    _field = size;
    _hero = Offset(size.width * .50, size.height * .74);
    _target = _hero;
    _enemies.addAll(<_DummyEnemy>[
      _DummyEnemy(Offset(size.width * .22, size.height * .29), .2),
      _DummyEnemy(Offset(size.width * .50, size.height * .20), 1.5),
      _DummyEnemy(Offset(size.width * .78, size.height * .31), 2.8),
    ]);
  }

  void _tick() {
    if (!mounted || _field == Size.zero) return;
    final now = DateTime.now();
    double dt = now.difference(_last).inMicroseconds / 1000000;
    _last = now;
    dt = dt.clamp(0.0, .035);
    _time += dt;

    final delta = _target - _hero;
    final spring = _holding ? 28.0 : 12.0;
    final damping = _holding ? 8.2 : 6.8;
    _velocity += delta * spring * dt;
    _velocity *= math.exp(-damping * dt);

    final speed = _velocity.distance;
    if (speed > 1050) _velocity = _velocity / speed * 1050;
    _hero += _velocity * dt;
    _hero = Offset(
      _hero.dx.clamp(44.0, _field.width - 44.0),
      _hero.dy.clamp(58.0, _field.height - 52.0),
    );

    final wantedTilt = (_velocity.dx / 650).clamp(-.15, .15);
    _tilt += (wantedTilt - _tilt) * math.min(1, dt * 10);
    setState(() {});
  }

  void _down(Offset p) {
    setState(() {
      _holding = true;
      _target = p;
    });
  }

  void _move(Offset p) {
    _holding = true;
    _target = p;
  }

  void _up() {
    _holding = false;
    _target = _hero;
  }

  String get _heroFacing {
    final speed = _velocity.distance;
    if (speed < 65) return 'back';

    final ax = _velocity.dx.abs();
    final ay = _velocity.dy.abs();
    if (ax > ay * .82) {
      return _velocity.dx >= 0 ? 'right' : 'left';
    }

    // Screen Y grows downward: moving toward the player shows her face,
    // moving toward the enemies keeps the rear view.
    return _velocity.dy > 0 ? 'front' : 'back';
  }

  int get _walkFrame {
    if (_velocity.distance < 65) return 0;
    return ((_time * 7).floor() & 1);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF142536),
      body: SafeArea(
        child: Column(
          children: <Widget>[
            SizedBox(
              height: 64,
              child: Row(
                children: <Widget>[
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    '冒険  STAGE ${widget.stageId}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const Spacer(),
                  const Padding(
                    padding: EdgeInsets.only(right: 18),
                    child: Text(
                      '操作テスト',
                      style: TextStyle(
                        color: Color(0xFFFFD978),
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: LayoutBuilder(
                builder: (context, c) {
                  final size = Size(c.maxWidth, c.maxHeight);
                  _seed(size);
                  return Listener(
                    behavior: HitTestBehavior.opaque,
                    onPointerDown: (e) => _down(e.localPosition),
                    onPointerMove: (e) => _move(e.localPosition),
                    onPointerUp: (_) => _up(),
                    onPointerCancel: (_) => _up(),
                    child: Stack(
                      fit: StackFit.expand,
                      children: <Widget>[
                        const CustomPaint(painter: _BrightFieldPainter()),
                        ..._buildEnemies(),
                        if (_holding)
                          Positioned(
                            left: _target.dx - 14,
                            top: _target.dy - 14,
                            child: IgnorePointer(
                              child: Container(
                                width: 28,
                                height: 28,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: Colors.white.withValues(alpha: .28),
                                    width: 2,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        _buildHero(),
                      ],
                    ),
                  );
                },
              ),
            ),
            Container(
              height: 58,
              alignment: Alignment.center,
              color: const Color(0xFF0D1C28),
              child: const Text(
                '指で動かして、ちびキャラの追従感を確認',
                style: TextStyle(
                  color: Colors.white70,
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildEnemies() {
    return _enemies.map((e) {
      final bounce = math.sin(_time * 2.4 + e.phase) * 3;
      final frame = (((_time * 3 + e.phase).floor()) & 1);
      const w = 64.0;
      const h = 64.0;
      return Positioned(
        left: e.pos.dx - w / 2,
        top: e.pos.dy - h / 2 + bounce,
        child: IgnorePointer(
          child: Image.asset(
            'assets/sprites/enemy_forest_$frame.png',
            width: w,
            height: h,
            fit: BoxFit.contain,
            filterQuality: FilterQuality.none,
          ),
        ),
      );
    }).toList();
  }

  Widget _buildHero() {
    const w = 112.0;
    const h = 128.0;
    final speedRatio = (_velocity.distance / 430).clamp(0.0, 1.0);
    final moving = _velocity.distance >= 65;
    final step = moving ? math.sin(_time * 13.0) : math.sin(_time * 2.4) * .18;
    final bob = moving
        ? math.sin(_time * 13.0) * 2.2 * speedRatio
        : math.sin(_time * 2.4) * .8;
    final squash = moving ? 1.0 + math.sin(_time * 13.0) * .022 : 1.0;

    return Positioned(
      left: _hero.dx - w / 2,
      top: _hero.dy - h * .70 + bob,
      child: IgnorePointer(
        child: Transform.rotate(
          angle: _tilt,
          alignment: Alignment.bottomCenter,
          child: Transform(
            alignment: Alignment.bottomCenter,
            transform: Matrix4.diagonal3Values(1 / squash, squash, 1),
            child: SizedBox(
              width: w,
              height: h,
              child: CustomPaint(
                painter: _ChickHeroPainter(
                  facing: _heroFacing,
                  step: step,
                  speedRatio: speedRatio,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _ChickHeroPainter extends CustomPainter {
  const _ChickHeroPainter({
    required this.facing,
    required this.step,
    required this.speedRatio,
  });

  final String facing;
  final double step;
  final double speedRatio;

  static const _outline = Color(0xFF2A160B);
  static const _white = Color(0xFFFFFEFA);
  static const _pink = Color(0xFFFF8E96);
  static const _footPink = Color(0xFFFF9CA2);
  static const _cheek = Color(0xFFFFB7BD);
  static const _gold = Color(0xFFF6B92C);
  static const _dark = Color(0xFF281307);

  Paint _fill(Color color) => Paint()
    ..color = color
    ..style = PaintingStyle.fill
    ..isAntiAlias = true;

  Paint _stroke([double width = 4.4]) => Paint()
    ..color = _outline
    ..style = PaintingStyle.stroke
    ..strokeWidth = width
    ..strokeCap = StrokeCap.round
    ..strokeJoin = StrokeJoin.round
    ..isAntiAlias = true;

  @override
  void paint(Canvas canvas, Size size) {
    final shadow = Paint()
      ..color = const Color(0xFF55704B).withValues(alpha: .18)
      ..isAntiAlias = true;
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(size.width * .50, size.height * .925),
        width: size.width * .60,
        height: size.height * .075,
      ),
      shadow,
    );

    if (facing == 'left') {
      canvas.save();
      canvas.translate(size.width, 0);
      canvas.scale(-1, 1);
      _paintRightSide(canvas, size);
      canvas.restore();
    } else if (facing == 'right') {
      _paintRightSide(canvas, size);
    } else if (facing == 'front') {
      _paintFront(canvas, size);
    } else {
      _paintBack(canvas, size);
    }
  }

  // Front, back and side deliberately use different silhouettes.
  // This avoids the old "same body with the face removed" look.
  void _paintFront(Canvas canvas, Size size) {
    final cx = size.width * .50;
    final wingSwing = step * 2.2 * speedRatio;

    // Feet are tucked under the body, like the reference character.
    final leftLift = math.max(0.0, step) * 2.3 * speedRatio;
    final rightLift = math.max(0.0, -step) * 2.3 * speedRatio;
    _frontFoot(canvas, Offset(cx - 18, 103 - leftLift));
    _frontFoot(canvas, Offset(cx + 18, 103 - rightLift));

    final body = Path()
      ..moveTo(cx, 25)
      ..cubicTo(30, 22, 20, 35, 17, 52)
      ..cubicTo(13, 72, 18, 89, 31, 98)
      ..cubicTo(38, 103, 45, 105, cx, 105)
      ..cubicTo(59, 105, 66, 103, 73, 98)
      ..cubicTo(86, 89, 91, 72, 87, 52)
      ..cubicTo(84, 35, 74, 22, cx, 25)
      ..close();
    canvas.drawPath(body, _fill(_white));
    canvas.drawPath(body, _stroke());

    _frontWing(canvas, Offset(20, 65), -1, -wingSwing);
    _frontWing(canvas, Offset(84, 65), 1, wingSwing);

    // Large soft eyes.
    for (final x in <double>[36, 68]) {
      canvas.drawOval(
        Rect.fromCenter(center: Offset(x, 57), width: 15.5, height: 21),
        _fill(_dark),
      );
      canvas.drawCircle(Offset(x - 2.5, 52.3), 3.4, _fill(Colors.white));
      canvas.drawCircle(Offset(x + 2.2, 62.2), 1.2, _fill(const Color(0xFF6B4730)));
    }

    canvas.drawOval(
      Rect.fromCenter(center: const Offset(26.5, 69), width: 12, height: 7.5),
      _fill(_cheek.withValues(alpha: .62)),
    );
    canvas.drawOval(
      Rect.fromCenter(center: const Offset(77.5, 69), width: 12, height: 7.5),
      _fill(_cheek.withValues(alpha: .62)),
    );

    final beak = Path()
      ..moveTo(cx - 8.5, 67)
      ..quadraticBezierTo(cx, 61.5, cx + 8.5, 67)
      ..quadraticBezierTo(cx, 75.5, cx - 8.5, 67)
      ..close();
    canvas.drawPath(beak, _fill(_pink));
    canvas.drawPath(beak, _stroke(3.1));
    canvas.drawLine(Offset(cx - 6.5, 67), Offset(cx + 6.5, 67), _stroke(2.0));

    _heart(canvas, const Offset(32.5, 39.5), 5.0, const Color(0xFFFF8C95));
    _heart(canvas, const Offset(71.5, 39.5), 5.0, const Color(0xFFFF8C95));
    _frontHat(canvas, back: false);
  }

  void _paintBack(Canvas canvas, Size size) {
    final cx = size.width * .50;
    final wingSwing = step * 2.0 * speedRatio;

    final leftLift = math.max(0.0, step) * 2.3 * speedRatio;
    final rightLift = math.max(0.0, -step) * 2.3 * speedRatio;
    _frontFoot(canvas, Offset(cx - 18, 103 - leftLift));
    _frontFoot(canvas, Offset(cx + 18, 103 - rightLift));

    // Rear silhouette is wider through the shoulders and fuller at the rump.
    final body = Path()
      ..moveTo(cx, 25)
      ..cubicTo(29, 23, 18, 37, 17, 55)
      ..cubicTo(15, 74, 20, 91, 33, 99)
      ..cubicTo(40, 103, 46, 105, cx, 105)
      ..cubicTo(58, 105, 64, 103, 71, 99)
      ..cubicTo(84, 91, 89, 74, 87, 55)
      ..cubicTo(86, 37, 75, 23, cx, 25)
      ..close();
    canvas.drawPath(body, _fill(_white));
    canvas.drawPath(body, _stroke());

    _backWing(canvas, Offset(20.5, 66), -1, -wingSwing);
    _backWing(canvas, Offset(83.5, 66), 1, wingSwing);

    _heart(canvas, const Offset(52, 90), 4.2, _outline);
    _frontHat(canvas, back: true);
  }

  void _paintRightSide(Canvas canvas, Size size) {
    final swing = step * 2.1 * speedRatio;

    // Side feet are short flat ovals, one slightly ahead of the other.
    final rearLift = math.max(0.0, step) * 2.5 * speedRatio;
    final frontLift = math.max(0.0, -step) * 2.5 * speedRatio;
    _sideFoot(canvas, Offset(45 - swing * .55, 102 - rearLift), 20);
    _sideFoot(canvas, Offset(66 + swing * .65, 101 - frontLift), 21);

    // Dedicated side silhouette: flatter back, round chest and a small rump.
    final body = Path()
      ..moveTo(43, 27)
      ..cubicTo(27, 29, 21, 43, 21, 59)
      ..cubicTo(21, 77, 29, 92, 44, 99)
      ..cubicTo(56, 105, 72, 102, 81, 92)
      ..cubicTo(88, 83, 90, 69, 87, 54)
      ..cubicTo(84, 39, 68, 25, 43, 27)
      ..close();
    canvas.drawPath(body, _fill(_white));
    canvas.drawPath(body, _stroke());

    final tail = Path()
      ..moveTo(24, 78)
      ..cubicTo(16, 75, 13, 80, 18, 85)
      ..cubicTo(23, 87, 27, 84, 29, 81)
      ..close();
    canvas.drawPath(tail, _fill(_white));
    canvas.drawPath(tail, _stroke(3.5));

    // One large side wing, placed lower like the reference.
    canvas.save();
    canvas.translate(49, 68);
    canvas.rotate(-.08 + swing * .012);
    final wing = Path()
      ..moveTo(-2, -15)
      ..cubicTo(10, -13, 17, -4, 16, 8)
      ..cubicTo(15, 17, 10, 23, 5, 25)
      ..cubicTo(2, 21, 0, 17, -1, 13)
      ..cubicTo(-3, 18, -7, 17, -9, 12)
      ..cubicTo(-11, 4, -9, -8, -2, -15)
      ..close();
    canvas.drawPath(wing, _fill(_white));
    canvas.drawPath(wing, _stroke(3.8));
    canvas.restore();

    canvas.drawOval(
      Rect.fromCenter(center: const Offset(72, 54), width: 15, height: 21),
      _fill(_dark),
    );
    canvas.drawCircle(const Offset(69.6, 49.6), 3.3, _fill(Colors.white));
    canvas.drawOval(
      Rect.fromCenter(center: const Offset(74, 68), width: 11, height: 7),
      _fill(_cheek.withValues(alpha: .58)),
    );

    final beak = Path()
      ..moveTo(85, 58)
      ..quadraticBezierTo(92, 60, 97, 65)
      ..quadraticBezierTo(91, 71, 84, 69)
      ..quadraticBezierTo(88, 64, 85, 58)
      ..close();
    canvas.drawPath(beak, _fill(_pink));
    canvas.drawPath(beak, _stroke(3.0));
    canvas.drawLine(const Offset(86.5, 64.5), const Offset(94, 65.5), _stroke(1.9));

    _heart(canvas, const Offset(64, 40), 4.7, const Color(0xFFFF8C95));
    _sideHat(canvas);
  }

  void _frontWing(Canvas canvas, Offset origin, int dir, double swing) {
    canvas.save();
    canvas.translate(origin.dx, origin.dy);
    canvas.rotate(dir * (.055 + swing * .012));
    final wing = Path()
      ..moveTo(0, -15)
      ..cubicTo(dir * 10, -12, dir * 13, -1, dir * 11, 10)
      ..cubicTo(dir * 10, 17, dir * 6, 22, dir * 2, 23)
      ..cubicTo(dir * 1, 18, -dir * 1, 15, -dir * 3, 13)
      ..cubicTo(-dir * 2, 18, -dir * 7, 16, -dir * 8, 10)
      ..cubicTo(-dir * 10, 1, -dir * 7, -10, 0, -15)
      ..close();
    canvas.drawPath(wing, _fill(_white));
    canvas.drawPath(wing, _stroke(3.7));
    canvas.restore();
  }

  void _backWing(Canvas canvas, Offset origin, int dir, double swing) {
    canvas.save();
    canvas.translate(origin.dx, origin.dy);
    canvas.rotate(dir * (.045 + swing * .010));
    final wing = Path()
      ..moveTo(0, -14)
      ..cubicTo(dir * 9, -10, dir * 12, 0, dir * 10, 10)
      ..cubicTo(dir * 8, 18, dir * 4, 21, dir * 1, 22)
      ..cubicTo(0, 17, -dir * 2, 14, -dir * 4, 12)
      ..cubicTo(-dir * 5, 15, -dir * 8, 13, -dir * 8, 8)
      ..cubicTo(-dir * 9, 0, -dir * 6, -10, 0, -14)
      ..close();
    canvas.drawPath(wing, _fill(_white));
    canvas.drawPath(wing, _stroke(3.7));
    canvas.restore();
  }

  void _frontFoot(Canvas canvas, Offset c) {
    final foot = Path()
      ..moveTo(c.dx - 10, c.dy)
      ..cubicTo(c.dx - 12, c.dy + 5, c.dx - 8, c.dy + 9, c.dx - 3, c.dy + 8)
      ..cubicTo(c.dx, c.dy + 12, c.dx + 4, c.dy + 11, c.dx + 5, c.dy + 7)
      ..cubicTo(c.dx + 10, c.dy + 9, c.dx + 13, c.dy + 5, c.dx + 10, c.dy)
      ..close();
    canvas.drawPath(foot, _fill(_footPink));
    canvas.drawPath(foot, _stroke(3.1));
  }

  void _sideFoot(Canvas canvas, Offset c, double width) {
    final foot = RRect.fromRectAndRadius(
      Rect.fromCenter(center: c, width: width, height: 10.5),
      const Radius.circular(7),
    );
    canvas.drawRRect(foot, _fill(_footPink));
    canvas.drawRRect(foot, _stroke(3.0));
  }

  void _heart(Canvas canvas, Offset c, double r, Color color) {
    final path = Path()
      ..moveTo(c.dx, c.dy + r)
      ..cubicTo(c.dx - r * 1.35, c.dy + r * .15, c.dx - r * .9, c.dy - r, c.dx, c.dy - r * .2)
      ..cubicTo(c.dx + r * .9, c.dy - r, c.dx + r * 1.35, c.dy + r * .15, c.dx, c.dy + r)
      ..close();
    canvas.drawPath(path, _fill(color));
  }

  void _frontHat(Canvas canvas, {required bool back}) {
    // Large soft chef/captain crown with three rounded lobes.
    final crown = Path()
      ..moveTo(20, 31)
      ..cubicTo(18, 23, 22, 17, 29, 14)
      ..cubicTo(34, 8, 43, 7, 50, 11)
      ..cubicTo(57, 7, 67, 8, 73, 14)
      ..cubicTo(82, 16, 87, 23, 84, 31)
      ..quadraticBezierTo(53, 25, 20, 31)
      ..close();
    canvas.drawPath(crown, _fill(_white));
    canvas.drawPath(crown, _stroke(4.2));

    final band = Path()
      ..moveTo(20, 31)
      ..quadraticBezierTo(52, 24.5, 84, 31)
      ..lineTo(81.5, 38)
      ..quadraticBezierTo(52, 33.5, 22.5, 38)
      ..close();
    canvas.drawPath(band, _fill(_dark));
    canvas.drawPath(band, _stroke(3.3));

    final goldBand = Paint()
      ..color = _gold
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4.2
      ..strokeCap = StrokeCap.round
      ..isAntiAlias = true;
    final stripe = Path()
      ..moveTo(24, 31.8)
      ..quadraticBezierTo(52, 27, 80, 31.8);
    canvas.drawPath(stripe, goldBand);

    if (!back) {
      _heart(canvas, const Offset(52, 19), 6.2, _gold);
      canvas.drawCircle(const Offset(49.7, 15.9), 2.0, _fill(Colors.white));
    }
  }

  void _sideHat(Canvas canvas) {
    final crown = Path()
      ..moveTo(25, 32)
      ..cubicTo(24, 24, 29, 17, 37, 14)
      ..cubicTo(43, 9, 54, 9, 60, 14)
      ..cubicTo(70, 14, 80, 20, 82, 29)
      ..quadraticBezierTo(57, 25, 25, 32)
      ..close();
    canvas.drawPath(crown, _fill(_white));
    canvas.drawPath(crown, _stroke(4.1));

    final brim = Path()
      ..moveTo(27, 31)
      ..quadraticBezierTo(59, 24.5, 87, 32)
      ..quadraticBezierTo(82, 39, 64, 38)
      ..lineTo(31, 38)
      ..close();
    canvas.drawPath(brim, _fill(_dark));
    canvas.drawPath(brim, _stroke(3.2));

    final goldBand = Paint()
      ..color = _gold
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4.0
      ..strokeCap = StrokeCap.round
      ..isAntiAlias = true;
    canvas.drawLine(const Offset(31, 31.5), const Offset(78, 29), goldBand);

    _heart(canvas, const Offset(63, 18), 5.5, _gold);
    canvas.drawCircle(const Offset(61, 15), 1.8, _fill(Colors.white));
  }

  @override
  bool shouldRepaint(covariant _ChickHeroPainter oldDelegate) =>
      oldDelegate.facing != facing ||
      oldDelegate.step != step ||
      oldDelegate.speedRatio != speedRatio;
}

class _BrightFieldPainter extends CustomPainter {
  const _BrightFieldPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final bg = const LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: <Color>[
        Color(0xFFEAF6D8),
        Color(0xFFD8EDBE),
        Color(0xFFC7E4AA),
      ],
    ).createShader(rect);
    canvas.drawRect(rect, Paint()..shader = bg);

    // Soft layered grass so the field reads as a place, not a flat board.
    final farGrass = Paint()..color = const Color(0xFFB6D998).withValues(alpha: .42);
    final nearGrass = Paint()..color = const Color(0xFF94C77B).withValues(alpha: .23);
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(size.width * .11, size.height * .16),
        width: size.width * .34,
        height: 76,
      ),
      farGrass,
    );
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(size.width * .88, size.height * .20),
        width: size.width * .38,
        height: 86,
      ),
      farGrass,
    );
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(size.width * .10, size.height * .77),
        width: size.width * .42,
        height: 110,
      ),
      nearGrass,
    );
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(size.width * .91, size.height * .71),
        width: size.width * .43,
        height: 104,
      ),
      nearGrass,
    );

    // A narrow winding path keeps the battlefield readable while giving depth.
    final path = Path()
      ..moveTo(size.width * .38, size.height)
      ..cubicTo(
        size.width * .36,
        size.height * .82,
        size.width * .52,
        size.height * .69,
        size.width * .50,
        size.height * .52,
      )
      ..cubicTo(
        size.width * .47,
        size.height * .36,
        size.width * .58,
        size.height * .22,
        size.width * .52,
        0,
      )
      ..lineTo(size.width * .64, 0)
      ..cubicTo(
        size.width * .69,
        size.height * .20,
        size.width * .57,
        size.height * .37,
        size.width * .61,
        size.height * .55,
      )
      ..cubicTo(
        size.width * .66,
        size.height * .73,
        size.width * .48,
        size.height * .84,
        size.width * .55,
        size.height,
      )
      ..close();
    canvas.drawPath(
      path,
      Paint()..color = const Color(0xFFF0DDAA).withValues(alpha: .62),
    );
    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3
        ..color = const Color(0xFFD4C58E).withValues(alpha: .18),
    );

    // Small grass blades around the edges. No giant circles/rings.
    final blade = Paint()
      ..color = const Color(0xFF79AF67).withValues(alpha: .43)
      ..strokeWidth = 1.6
      ..strokeCap = StrokeCap.round;
    const grassSeeds = <Offset>[
      Offset(.07, .09), Offset(.18, .24), Offset(.91, .10), Offset(.82, .32),
      Offset(.09, .53), Offset(.20, .67), Offset(.90, .57), Offset(.82, .84),
      Offset(.12, .90), Offset(.72, .91), Offset(.95, .38), Offset(.05, .36),
    ];
    for (final seed in grassSeeds) {
      final p = Offset(seed.dx * size.width, seed.dy * size.height);
      canvas.drawLine(p, p + const Offset(-4, -9), blade);
      canvas.drawLine(p, p + const Offset(1, -11), blade);
      canvas.drawLine(p, p + const Offset(5, -7), blade);
    }

    // Tiny flowers and stones add charm but stay away from combat silhouettes.
    final petal = Paint()..color = const Color(0xFFFFFAF3).withValues(alpha: .95);
    final flowerCenter = Paint()..color = const Color(0xFFF0BD59);
    final pinkPetal = Paint()..color = const Color(0xFFF7C2D5).withValues(alpha: .88);
    const flowerSeeds = <Offset>[
      Offset(.18, .14), Offset(.10, .43), Offset(.86, .13), Offset(.90, .45),
      Offset(.16, .83), Offset(.84, .79), Offset(.29, .61), Offset(.72, .62),
    ];
    for (var i = 0; i < flowerSeeds.length; i++) {
      final p = Offset(flowerSeeds[i].dx * size.width, flowerSeeds[i].dy * size.height);
      final pp = i.isOdd ? pinkPetal : petal;
      canvas.drawCircle(p + const Offset(-3, 0), 2.5, pp);
      canvas.drawCircle(p + const Offset(3, 0), 2.5, pp);
      canvas.drawCircle(p + const Offset(0, -3), 2.5, pp);
      canvas.drawCircle(p + const Offset(0, 3), 2.5, pp);
      canvas.drawCircle(p, 1.7, flowerCenter);
    }

    final stone = Paint()..color = const Color(0xFF91A98B).withValues(alpha: .30);
    const stones = <Offset>[Offset(.28, .35), Offset(.74, .27), Offset(.22, .74), Offset(.78, .88)];
    for (final seed in stones) {
      final p = Offset(seed.dx * size.width, seed.dy * size.height);
      canvas.drawOval(Rect.fromCenter(center: p, width: 15, height: 8), stone);
      canvas.drawOval(
        Rect.fromCenter(center: p + const Offset(-2, -2), width: 7, height: 3),
        Paint()..color = Colors.white.withValues(alpha: .18),
      );
    }

    // Gentle sunlight from the upper-right; kept very subtle for readability.
    final light = RadialGradient(
      center: const Alignment(.72, -.72),
      radius: .92,
      colors: <Color>[
        const Color(0xFFFFF6C9).withValues(alpha: .16),
        Colors.transparent,
      ],
    ).createShader(rect);
    canvas.drawRect(rect, Paint()..shader = light);
  }

  @override
  bool shouldRepaint(covariant _BrightFieldPainter oldDelegate) => false;
}
