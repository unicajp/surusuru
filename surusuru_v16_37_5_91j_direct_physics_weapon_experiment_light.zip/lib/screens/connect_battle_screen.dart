// V91j EXPERIMENT: direct-physics weapon control. Easy rollback: remove this light patch and restore V91i.
import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../game/game_controller.dart';
import '../sfx_manager.dart';

class ConnectBattleScreen extends StatefulWidget {
  final GameController controller;
  final int stageId;

  const ConnectBattleScreen({
    super.key,
    required this.controller,
    required this.stageId,
  });

  @override
  State<ConnectBattleScreen> createState() => _ConnectBattleScreenState();
}

enum _EnemyWeight { small, medium, large }

class _Enemy {
  _Enemy({
    required this.x,
    required this.y,
    required this.phase,
    required this.type,
    required this.weight,
    required this.size,
    required this.hp,
    this.isBoss = false,
  }) : maxHp = hp;

  double x;
  double y;
  final double phase;
  final int type;
  final _EnemyWeight weight;
  final double size;
  int hp;
  final int maxHp;
  final bool isBoss;
  Offset velocity = Offset.zero;
  double pop = 1.0;
  double flash = 0.0;
  int lastHitMs = 0;
  int lastAttackSerial = -1;
  int lastSkillHitMs = 0;
}

class _BreakableCrate {
  _BreakableCrate({required this.x, required this.y, this.hp = 2}) : maxHp = hp;
  double x;
  double y;
  int hp;
  final int maxHp;
  double flash = 0;
  double breakProgress = 1;
  int lastAttackSerial = -1;
  int lastSkillHitMs = 0;
}

class _SlashFx {
  _SlashFx(this.position, this.life, this.power, this.faceRight);
  Offset position;
  double life;
  final double power;
  final bool faceRight;
}

class _ConnectBattleScreenState extends State<ConnectBattleScreen> {
  Timer? _timer;
  DateTime _last = DateTime.now();
  Size _field = Size.zero;

  Offset _hero = const Offset(160, 420);
  Offset _target = const Offset(160, 420);
  Offset _velocity = Offset.zero;
  Offset _downPoint = Offset.zero;
  bool _holding = false;
  bool _pressingSkill = false;
  bool _attack = false;
  double _attackTime = 0;
  double _time = 0;
  double _scroll = 0;
  double _furthestScroll = 0;
  double _checkpointFloor = 0;
  double _startHeroX = 0;

  // V91g: the old 2800px prototype ended before the movement could breathe.
  // Keep the fast follow, but make the stage a real run with several encounters.
  static const double _stageLength = 7200;
  static const double _maxBacktrack = 900;

  double _tilt = 0;
  bool _faceRight = true;
  int _attackSerial = 0;
  double _impactDrag = 0;
  double _hitStop = 0;
  double _screenShake = 0;
  int _defeated = 0;

  double _playerHp = 100;
  static const double _playerMaxHp = 100;
  double _skillGauge = 0;
  bool _skillActive = false;
  double _skillTime = 0;
  bool _stageClear = false;
  bool _clearTransitionStarted = false;
  double _clearTime = 0;
  bool _bossAnnounced = false;

  // V91h: gesture/action state and slower camera.
  final List<Offset> _gesturePoints = <Offset>[];
  int _gestureStartMs = 0;
  int _lastTapMs = 0;
  Offset _lastTapPoint = Offset.zero;
  bool _dashAction = false;
  double _dashTime = 0;
  bool _jumpAction = false;
  double _jumpTime = 0;
  bool _heavyAttack = false;
  static const double _cameraMaxSpeed = 430;

  // V91j experimental control: the hero is a grabbed weapon, not a list of
  // tap/swipe commands. Finger speed becomes cutting power; heavy targets
  // physically snag the hero and can be scrub-cut while the finger keeps moving.
  Offset _pointerVelocity = Offset.zero;
  Offset _lastPointer = Offset.zero;
  int _lastPointerMs = 0;
  double _motionEnergy = 0;
  double _scrubDistance = 0;
  _Enemy? _snaggedEnemy;
  _BreakableCrate? _snaggedCrate;
  int _lastKineticHitMs = 0;
  double _releaseGlide = 0;

  final math.Random _rng = math.Random();
  final List<_Enemy> _enemies = <_Enemy>[];
  final List<_BreakableCrate> _crates = <_BreakableCrate>[];
  final List<_SlashFx> _slashFx = <_SlashFx>[];

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(milliseconds: 16), (_) => _tick());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _seed(Size size) {
    if (_field != Size.zero) return;
    _field = size;
    _hero = Offset(size.width * .36, size.height * .72);
    _target = _hero;
    _startHeroX = _hero.dx;

    double y(double t) => size.height * t;
    // Deterministic world positions. Off-screen enemies simply wait farther
    // along the stage; they are not recycled behind the player anymore.
    void enemy(double worldX, double yRatio, int type, _EnemyWeight weight, double sizePx, int hp, {bool boss = false}) {
      _enemies.add(_Enemy(
        x: _startHeroX + worldX,
        y: y(yRatio),
        phase: worldX * .013 + type,
        type: type,
        weight: weight,
        size: sizePx,
        hp: hp,
        isBoss: boss,
      ));
    }

    // Opening: many light targets to establish the "slice straight through" feel.
    enemy(420, .72, 0, _EnemyWeight.small, 43, 1);
    enemy(560, .68, 4, _EnemyWeight.small, 45, 1);
    enemy(710, .74, 2, _EnemyWeight.small, 43, 1);
    enemy(850, .69, 0, _EnemyWeight.small, 44, 1);

    // First mixed pack.
    enemy(1180, .72, 3, _EnemyWeight.medium, 65, 3);
    enemy(1340, .67, 1, _EnemyWeight.small, 44, 1);
    enemy(1490, .74, 4, _EnemyWeight.small, 45, 1);
    enemy(1650, .70, 2, _EnemyWeight.medium, 68, 3);

    // Mid-stage clusters.
    enemy(2050, .68, 0, _EnemyWeight.small, 42, 1);
    enemy(2160, .74, 4, _EnemyWeight.small, 44, 1);
    enemy(2280, .70, 2, _EnemyWeight.small, 43, 1);
    enemy(2410, .73, 1, _EnemyWeight.medium, 68, 3);
    enemy(2750, .70, 3, _EnemyWeight.large, 102, 10);
    enemy(3020, .67, 0, _EnemyWeight.small, 42, 1);
    enemy(3140, .74, 4, _EnemyWeight.small, 44, 1);
    enemy(3260, .69, 2, _EnemyWeight.small, 43, 1);
    enemy(3400, .72, 3, _EnemyWeight.medium, 66, 3);

    // Late-stage rush.
    enemy(3900, .70, 1, _EnemyWeight.medium, 70, 3);
    enemy(4050, .74, 0, _EnemyWeight.small, 43, 1);
    enemy(4180, .68, 4, _EnemyWeight.small, 45, 1);
    enemy(4320, .72, 2, _EnemyWeight.small, 44, 1);
    enemy(4480, .69, 3, _EnemyWeight.medium, 68, 3);
    enemy(4850, .71, 4, _EnemyWeight.large, 108, 11);
    enemy(5200, .68, 0, _EnemyWeight.small, 42, 1);
    enemy(5330, .74, 2, _EnemyWeight.small, 44, 1);
    enemy(5460, .70, 4, _EnemyWeight.small, 44, 1);
    enemy(5600, .72, 1, _EnemyWeight.medium, 70, 3);
    enemy(5900, .68, 3, _EnemyWeight.medium, 72, 4);
    enemy(6080, .74, 0, _EnemyWeight.small, 43, 1);

    // The BOSS marker now corresponds to an actual large enemy.
    enemy(6900, .72, 3, _EnemyWeight.large, 158, 34, boss: true);

    _crates.addAll(<_BreakableCrate>[
      _BreakableCrate(x: _startHeroX + 980, y: y(.78)),
      _BreakableCrate(x: _startHeroX + 1860, y: y(.78), hp: 3),
      _BreakableCrate(x: _startHeroX + 2520, y: y(.78)),
      _BreakableCrate(x: _startHeroX + 3560, y: y(.78), hp: 3),
      _BreakableCrate(x: _startHeroX + 4660, y: y(.78)),
      _BreakableCrate(x: _startHeroX + 5740, y: y(.78), hp: 3),
      _BreakableCrate(x: _startHeroX + 6320, y: y(.78)),
    ]);
  }

  _Enemy? get _boss {
    for (final enemy in _enemies) {
      if (enemy.isBoss) return enemy;
    }
    return null;
  }

  void _tick() {
    if (!mounted || _field == Size.zero) return;
    final now = DateTime.now();
    double dt = now.difference(_last).inMicroseconds / 1000000;
    _last = now;
    dt = dt.clamp(0.0, .035);
    _time += dt;

    if (_stageClear) {
      _clearTime += dt;
    }

    if (_dashAction) {
      _dashTime += dt;
      if (_dashTime >= .28) {
        _dashAction = false;
        _dashTime = 0;
      }
    }
    if (_jumpAction) {
      _jumpTime += dt;
      if (_jumpTime >= .52) {
        _jumpAction = false;
        _jumpTime = 0;
      }
    }

    _motionEnergy = math.max(0, _motionEnergy - dt * 1.35);
    _releaseGlide = math.max(0, _releaseGlide - dt * 2.8);
    _hitStop = math.max(0, _hitStop - dt);
    _impactDrag = math.max(0, _impactDrag - dt * 2.8);
    _screenShake = math.max(0, _screenShake - dt * 7.0);
    for (final fx in _slashFx) {
      fx.life -= dt * 4.6;
    }
    _slashFx.removeWhere((fx) => fx.life <= 0);

    for (final crate in _crates) {
      crate.flash = math.max(0, crate.flash - dt * 7);
      if (crate.hp <= 0 && crate.breakProgress < 1) {
        crate.breakProgress = (crate.breakProgress + dt * 3.6).clamp(0.0, 1.0);
      }
    }

    if (_skillActive) {
      _skillTime += dt;
      _attack = true;
      _attackTime = (_attackTime + dt) % .54;
      _resolveSkillHits();
      if (_skillTime >= 1.25) {
        _skillActive = false;
        _skillTime = 0;
        _attack = false;
        _attackTime = 0;
      }
    } else if (_attack) {
      _attackTime += dt;
      if (_attackTime >= .54) {
        _attack = false;
        _attackTime = 0;
        _heavyAttack = false;
      }
    }

    final previousHero = _hero;
    final delta = _target - _hero;
    final response = _holding ? 22.0 : 8.5;
    final velocityGain = _holding ? 11.6 : (_releaseGlide > 0 ? 1.8 : 3.2);
    final snagMultiplier = 1.0 - _impactDrag * .58;
    final movementLockedByAttack = _attack && !_holding && !_skillActive && !_dashAction && _releaseGlide <= 0;
    Offset desiredVelocity = movementLockedByAttack ? Offset.zero : delta * velocityGain * snagMultiplier;
    if (_holding && _pointerVelocity.distance > 10) {
      // The pointer contributes momentum directly. Fast sweeps feel like a swung weapon
      // instead of the old fixed-speed dash action.
      desiredVelocity += _pointerVelocity * .26;
    }
    final follow = 1.0 - math.exp(-response * dt);
    _velocity += (desiredVelocity - _velocity) * follow;

    final speed = _velocity.distance;
    if (speed > 1180) _velocity = _velocity / speed * 1180;
    final movementScale = _hitStop > 0 ? .20 : (1.0 - _impactDrag * .28);
    _hero += _velocity * dt * movementScale;
    if (_dashAction) {
      final dashEase = 1.0 - (_dashTime / .28).clamp(0.0, 1.0);
      _hero += Offset((_faceRight ? 1 : -1) * (420 + 260 * dashEase) * dt, 0);
    }

    // Keep normal finger-follow movement on the ground band. Upward gestures
    // become an automatic jump arc instead of leaving the sprite floating.
    final minY = _field.height * .67;
    final maxY = _field.height * .82;
    _hero = Offset(
      _hero.dx.clamp(48.0, _field.width - 48.0),
      _hero.dy.clamp(minY, maxY),
    );
    _applyBodyCollisions(previousHero);
    _resolveKineticContacts();

    if (_velocity.dx.abs() > 45) _faceRight = _velocity.dx >= 0;

    final leftAnchor = _field.width * .30;
    final rightAnchor = _field.width * .62;
    double cameraDelta = 0;

    final maxCameraStep = _cameraMaxSpeed * dt;
    if (_hero.dx > rightAnchor && _velocity.dx > 0) {
      final requested = _hero.dx - rightAnchor;
      cameraDelta = requested.clamp(0.0, maxCameraStep);
      final next = (_scroll + cameraDelta).clamp(0.0, _stageLength);
      cameraDelta = next - _scroll;
      _hero = Offset(_hero.dx - cameraDelta, _hero.dy);
      _hero = Offset(math.min(_hero.dx, _field.width * .76), _hero.dy);
    } else if (_hero.dx < leftAnchor && _velocity.dx < 0) {
      final requested = _hero.dx - leftAnchor;
      final allowedFloor = math.max(_checkpointFloor, _furthestScroll - _maxBacktrack);
      final limited = requested.clamp(-maxCameraStep, 0.0);
      final nextScroll = (_scroll + limited).clamp(allowedFloor, _stageLength);
      cameraDelta = nextScroll - _scroll;
      _hero = Offset(_hero.dx - cameraDelta, _hero.dy);
      _hero = Offset(math.max(_hero.dx, _field.width * .22), _hero.dy);
    }

    if (cameraDelta != 0) {
      _scroll = (_scroll + cameraDelta).clamp(0.0, _stageLength);
      for (final enemy in _enemies) {
        enemy.x -= cameraDelta;
      }
      for (final crate in _crates) {
        crate.x -= cameraDelta;
      }
    }

    _furthestScroll = math.max(_furthestScroll, _scroll);
    if (_furthestScroll >= 5400) {
      _checkpointFloor = 5400;
    } else if (_furthestScroll >= 3600) {
      _checkpointFloor = 3600;
    } else if (_furthestScroll >= 1800) {
      _checkpointFloor = 1800;
    }

    if (!_bossAnnounced && _furthestScroll > _stageLength - 1100) {
      _bossAnnounced = true;
      SfxManager.instance.chanceStepUp();
      HapticFeedback.mediumImpact();
    }

    for (final enemy in _enemies) {
      if (enemy.hp <= 0) {
        if (enemy.pop < 1) enemy.pop = (enemy.pop + dt * 4.5).clamp(0.0, 1.0);
        continue;
      }
      enemy.flash = math.max(0, enemy.flash - dt * 6.5);
      final wanderPower = enemy.isBoss ? .20 : (enemy.weight == _EnemyWeight.large ? .35 : .65);
      final wander = Offset(
            math.sin(_time * .9 + enemy.phase),
            math.cos(_time * 1.07 + enemy.phase),
          ) *
          wanderPower;
      enemy.velocity = (enemy.velocity + wander * dt) * math.pow(.92, dt * 60).toDouble();
      enemy.x += enemy.velocity.dx * dt * 60;
      enemy.y += enemy.velocity.dy * dt * 60;
      final minEY = _field.height * .60;
      final maxEY = _field.height * .81;
      if (enemy.y < minEY || enemy.y > maxEY) {
        enemy.velocity = Offset(enemy.velocity.dx, -enemy.velocity.dy * .75);
        enemy.y = enemy.y.clamp(minEY, maxEY);
      }
      if (enemy.isBoss && _bossAnnounced) {
        final leftBossWall = _field.width * .48;
        final rightBossWall = _field.width - enemy.size * .48;
        if (enemy.x < leftBossWall || enemy.x > rightBossWall) {
          enemy.x = enemy.x.clamp(leftBossWall, rightBossWall);
          enemy.velocity = Offset(-enemy.velocity.dx * .35, enemy.velocity.dy);
        }
      }
    }

    // V91j normal contact damage is resolved from real movement energy instead
    // of a tap/swipe command. Skill keeps its own wider hit resolver.

    final wantedTilt = (_velocity.dx / 850).clamp(-.09, .09);
    _tilt += (wantedTilt - _tilt) * math.min(1, dt * 10);
    setState(() {});
  }

  Rect get _skillButtonRect => Rect.fromLTWH(
        _field.width - 94,
        _field.height - 104,
        76,
        76,
      );

  double get _jumpHeight {
    if (!_jumpAction) return 0;
    final t = (_jumpTime / .52).clamp(0.0, 1.0);
    return math.sin(t * math.pi) * 74;
  }

  Offset _groundTarget(Offset p) => Offset(
        p.dx,
        p.dy.clamp(_field.height * .67, _field.height * .82),
      );

  void _down(Offset p) {
    if (_stageClear) return;
    if (_skillButtonRect.contains(p)) {
      _pressingSkill = true;
      _holding = false;
      _target = _hero;
      _activateSkill();
      return;
    }
    final now = DateTime.now().millisecondsSinceEpoch;
    _gesturePoints
      ..clear()
      ..add(p);
    _gestureStartMs = now;
    _holding = true;
    _downPoint = p;
    _lastPointer = p;
    _lastPointerMs = now;
    _pointerVelocity = Offset.zero;
    _scrubDistance = 0;
    _snaggedEnemy = null;
    _snaggedCrate = null;
    _target = _groundTarget(p);
  }

  void _move(Offset p) {
    if (_pressingSkill || _stageClear) return;
    final now = DateTime.now().millisecondsSinceEpoch;
    final ms = math.max(1, now - _lastPointerMs);
    final step = p - _lastPointer;
    final instant = step * (1000.0 / ms);
    _pointerVelocity += (instant - _pointerVelocity) * .58;
    _motionEnergy = math.max(_motionEnergy, (_pointerVelocity.distance / 1050).clamp(0.0, 1.35));
    _scrubDistance += step.distance;
    _lastPointer = p;
    _lastPointerMs = now;
    _holding = true;
    if (_gesturePoints.isEmpty || (p - _gesturePoints.last).distance > 7) {
      _gesturePoints.add(p);
      if (_gesturePoints.length > 22) _gesturePoints.removeAt(0);
    }
    _target = _groundTarget(p);
    if (step.dx.abs() > 2) _faceRight = step.dx >= 0;
  }

  void _up(Offset p) {
    if (_pressingSkill) {
      _pressingSkill = false;
      return;
    }
    if (_stageClear) return;
    _holding = false;
    _snaggedEnemy = null;
    _snaggedCrate = null;
    // Release does not map to a canned attack. A fast hand movement simply leaves
    // a short amount of momentum, so the same trace can end in a natural fling.
    final fling = _pointerVelocity.distance.clamp(0.0, 900.0);
    if (fling > 260) {
      _velocity += _pointerVelocity / math.max(1.0, _pointerVelocity.distance) * (fling * .34);
      _releaseGlide = .42;
    }
    _target = _hero;
    _gesturePoints.clear();
  }

  void _applyBodyCollisions(Offset previousHero) {
    final heroCenter = Offset(_hero.dx, _hero.dy - 28);

    bool blocked = false;
    double strongest = 0;
    _Enemy? touchingEnemy;
    _BreakableCrate? touchingCrate;
    for (final enemy in _enemies) {
      if (enemy.hp <= 0) continue;
      final enemyCenter = Offset(enemy.x, enemy.y - enemy.size * .44);
      final rx = 24 + enemy.size * .34;
      final ry = 30 + enemy.size * .28;
      if ((heroCenter.dx - enemyCenter.dx).abs() < rx &&
          (heroCenter.dy - enemyCenter.dy).abs() < ry) {
        // Light monsters can be cut through if the player actually swings fast.
        // Medium/large monsters behave as physical anchors and snag the hero.
        if (enemy.weight == _EnemyWeight.small && _motionEnergy > .28) {
          touchingEnemy ??= enemy;
          continue;
        }
        blocked = true;
        touchingEnemy ??= enemy;
        strongest = math.max(strongest, switch (enemy.weight) {
          _EnemyWeight.small => .28,
          _EnemyWeight.medium => .62,
          _EnemyWeight.large => enemy.isBoss ? .96 : .82,
        });
      }
    }
    for (final crate in _crates) {
      if (crate.hp <= 0) continue;
      final c = Offset(crate.x, crate.y - 30);
      if ((heroCenter.dx - c.dx).abs() < 50 && (heroCenter.dy - c.dy).abs() < 54) {
        blocked = true;
        touchingCrate ??= crate;
        strongest = math.max(strongest, .76);
      }
    }
    if (blocked) {
      // Preserve a little vertical/tangential movement so dragging around a heavy
      // target feels like levering the sword instead of freezing completely.
      _hero = Offset(previousHero.dx, _hero.dy * .72 + previousHero.dy * .28);
      _velocity = Offset(_velocity.dx * .08, _velocity.dy * .62);
      _impactDrag = math.max(_impactDrag, strongest);
    }
    _snaggedEnemy = touchingEnemy;
    _snaggedCrate = touchingCrate;
  }

  void _resolveKineticContacts() {
    if (_stageClear || _skillActive) return;
    final speedEnergy = math.max(_motionEnergy, (_velocity.distance / 980).clamp(0.0, 1.25));
    if (speedEnergy < .20 && _snaggedEnemy == null && _snaggedCrate == null) return;
    final now = DateTime.now().millisecondsSinceEpoch;
    final heroCenter = Offset(_hero.dx, _hero.dy - 38);
    final dir = _velocity.distance > 35
        ? _velocity / _velocity.distance
        : Offset(_faceRight ? 1 : -1, 0);
    final bladeCenter = heroCenter + dir * (44 + 30 * speedEnergy.clamp(0.0, 1.0));

    _Enemy? candidate = _snaggedEnemy;
    if (candidate == null) {
      double best = double.infinity;
      for (final enemy in _enemies) {
        if (enemy.hp <= 0) continue;
        final c = Offset(enemy.x, enemy.y - enemy.size * .46);
        final dx = (c.dx - bladeCenter.dx).abs();
        final dy = (c.dy - bladeCenter.dy).abs();
        if (dx < 48 + enemy.size * .36 && dy < 44 + enemy.size * .30) {
          final d = (c - bladeCenter).distanceSquared;
          if (d < best) {
            best = d;
            candidate = enemy;
          }
        }
      }
    }

    if (candidate != null && candidate.hp > 0) {
      final interval = candidate.weight == _EnemyWeight.large ? 92 : candidate.weight == _EnemyWeight.medium ? 135 : 190;
      final requiredScrub = candidate.weight == _EnemyWeight.large ? 13.0 : candidate.weight == _EnemyWeight.medium ? 20.0 : 0.0;
      final canHit = now - candidate.lastHitMs >= interval &&
          (candidate.weight == _EnemyWeight.small ? speedEnergy > .30 : (_scrubDistance >= requiredScrub || speedEnergy > .72));
      if (canHit) {
        _attack = true;
        _attackTime = .23; // show the active middle of the slash animation
        _attackSerial++;
        candidate.lastHitMs = now;
        candidate.lastAttackSerial = _attackSerial;
        final center = Offset(candidate.x, candidate.y - candidate.size * .46);
        _hitEnemy(candidate, center, skill: false);
        _scrubDistance = 0;
        _lastKineticHitMs = now;
      }
    }

    final crate = _snaggedCrate;
    if (crate != null && crate.hp > 0 && now - _lastKineticHitMs > 150 && (_scrubDistance > 18 || speedEnergy > .72)) {
      _attack = true;
      _attackTime = .23;
      _attackSerial++;
      crate.lastAttackSerial = _attackSerial;
      _hitCrate(crate, Offset(crate.x, crate.y - 30), skill: false);
      _scrubDistance = 0;
      _lastKineticHitMs = now;
    }
  }

  void _activateSkill() {
    if (_skillGauge < .999 || _skillActive || _stageClear) {
      if (_skillGauge < .999) HapticFeedback.selectionClick();
      return;
    }
    _skillGauge = 0;
    _skillActive = true;
    _skillTime = 0;
    _attack = true;
    _attackTime = 0;
    _attackSerial++;
    _screenShake = 1;
    SfxManager.instance.chanceBattleReversal();
    HapticFeedback.heavyImpact();
  }

  int get _runFrame => ((_time * 9.0).floor() % 5) + 1;
  int get _attackFrame => (((_attackTime / .54) * 6).floor().clamp(0, 5) as int) + 1;

  void _addSkill(double amount) {
    if (_skillActive || _stageClear) return;
    final before = _skillGauge;
    _skillGauge = (_skillGauge + amount).clamp(0.0, 1.0);
    if (before < 1 && _skillGauge >= 1) {
      SfxManager.instance.chanceFlash();
      HapticFeedback.mediumImpact();
    }
  }

  void _resolveSwordHits() {
    final now = DateTime.now().millisecondsSinceEpoch;
    final baseReach = _attackFrame == 4 ? 112.0 : 96.0;
    final reach = baseReach + (_dashAction ? 24 : 0) + (_heavyAttack ? 15 : 0);
    final centerX = _hero.dx + (_faceRight ? reach * .56 : -reach * .56);
    final centerY = _hero.dy - 49 - _jumpHeight;
    final slashCenter = Offset(centerX, centerY);

    for (final enemy in _enemies) {
      if (enemy.hp <= 0) continue;
      final enemyCenter = Offset(enemy.x, enemy.y - enemy.size * .46);
      final rx = reach * .68 + enemy.size * .34;
      final ry = 49.0 + enemy.size * .30;
      if ((enemyCenter.dx - slashCenter.dx).abs() > rx ||
          (enemyCenter.dy - slashCenter.dy).abs() > ry) {
        continue;
      }
      if (enemy.weight == _EnemyWeight.large) {
        if (now - enemy.lastHitMs < 78) continue;
      } else if (enemy.lastAttackSerial == _attackSerial) {
        continue;
      }
      enemy.lastHitMs = now;
      enemy.lastAttackSerial = _attackSerial;
      _hitEnemy(enemy, enemyCenter, skill: false);
    }

    for (final crate in _crates) {
      if (crate.hp <= 0 || crate.lastAttackSerial == _attackSerial) continue;
      final center = Offset(crate.x, crate.y - 30);
      if ((center.dx - slashCenter.dx).abs() > reach * .75 + 30 ||
          (center.dy - slashCenter.dy).abs() > 72) {
        continue;
      }
      crate.lastAttackSerial = _attackSerial;
      _hitCrate(crate, center, skill: false);
    }
  }

  void _resolveSkillHits() {
    final now = DateTime.now().millisecondsSinceEpoch;
    final dir = _faceRight ? 1.0 : -1.0;
    final center = _hero + Offset(dir * 62, -48);
    final radiusX = 210.0;
    final radiusY = 125.0;

    for (final enemy in _enemies) {
      if (enemy.hp <= 0 || now - enemy.lastSkillHitMs < 115) continue;
      final enemyCenter = Offset(enemy.x, enemy.y - enemy.size * .46);
      if ((enemyCenter.dx - center.dx).abs() > radiusX + enemy.size * .25 ||
          (enemyCenter.dy - center.dy).abs() > radiusY + enemy.size * .18) {
        continue;
      }
      enemy.lastSkillHitMs = now;
      _hitEnemy(enemy, enemyCenter, skill: true);
    }

    for (final crate in _crates) {
      if (crate.hp <= 0 || now - crate.lastSkillHitMs < 115) continue;
      final c = Offset(crate.x, crate.y - 30);
      if ((c.dx - center.dx).abs() > radiusX || (c.dy - center.dy).abs() > radiusY) continue;
      crate.lastSkillHitMs = now;
      _hitCrate(crate, c, skill: true);
    }
  }

  void _hitEnemy(_Enemy enemy, Offset center, {required bool skill}) {
    final damage = skill ? 2 : (_heavyAttack ? 2 : 1);
    enemy.hp = math.max(0, enemy.hp - damage);
    enemy.flash = 1;
    final dir = _faceRight ? 1.0 : -1.0;
    final power = switch (enemy.weight) {
      _EnemyWeight.small => 1.0,
      _EnemyWeight.medium => 1.7,
      _EnemyWeight.large => enemy.isBoss ? 3.2 : 2.5,
    };
    final knock = enemy.weight == _EnemyWeight.small
        ? (skill ? 11.5 : 8.2)
        : enemy.weight == _EnemyWeight.medium
            ? (skill ? 7.0 : 4.9)
            : (skill ? 3.8 : 2.2);
    enemy.velocity += Offset(dir * knock, -1.2 - _rng.nextDouble() * 1.5);
    _slashFx.add(_SlashFx(center, 1.0, skill ? power + 1.2 : power, _faceRight));
    _screenShake = math.max(
      _screenShake,
      skill ? .82 : (enemy.weight == _EnemyWeight.small ? .18 : enemy.weight == _EnemyWeight.medium ? .38 : .72),
    );

    if (!skill) {
      _addSkill(switch (enemy.weight) {
        _EnemyWeight.small => .075,
        _EnemyWeight.medium => .11,
        _EnemyWeight.large => enemy.isBoss ? .035 : .055,
      });
    }

    switch (enemy.weight) {
      case _EnemyWeight.small:
        _hitStop = math.max(_hitStop, skill ? .018 : .012);
        _impactDrag = math.max(_impactDrag, skill ? .08 : .04);
        SfxManager.instance.chanceBattleHit();
        HapticFeedback.selectionClick();
        break;
      case _EnemyWeight.medium:
        _hitStop = math.max(_hitStop, skill ? .026 : .032);
        _impactDrag = math.max(_impactDrag, skill ? .18 : .32);
        SfxManager.instance.chanceBattleHit();
        HapticFeedback.lightImpact();
        break;
      case _EnemyWeight.large:
        _hitStop = math.max(_hitStop, skill ? .038 : .052);
        _impactDrag = math.max(_impactDrag, skill ? .40 : .72);
        SfxManager.instance.chanceBattleHit();
        HapticFeedback.mediumImpact();
        break;
    }

    if (enemy.hp <= 0) {
      enemy.pop = 0;
      _defeated++;
      SfxManager.instance.chanceEnemyDown();
      HapticFeedback.heavyImpact();
      _hitStop = math.max(_hitStop, enemy.isBoss ? .13 : (enemy.weight == _EnemyWeight.large ? .095 : .045));
      _screenShake = 1;
      if (enemy.isBoss) {
        _stageClear = true;
        _holding = false;
        _dashAction = false;
        _jumpAction = false;
        _target = _hero;
        _velocity = Offset.zero;
        SfxManager.instance.clear();
        unawaited(_finishStageAndReturn());
      }
    }
  }

  Future<void> _finishStageAndReturn() async {
    if (_clearTransitionStarted) return;
    _clearTransitionStarted = true;
    try {
      await widget.controller.completeRpgStage(widget.stageId);
      await Future<void>.delayed(const Duration(milliseconds: 1200));
      if (!mounted) return;
      Navigator.of(context).pop(true);
    } catch (_) {
      // Keep the clear screen visible instead of losing the result if saving fails.
      _clearTransitionStarted = false;
    }
  }

  void _hitCrate(_BreakableCrate crate, Offset center, {required bool skill}) {
    crate.hp = math.max(0, crate.hp - (skill || _heavyAttack ? 2 : 1));
    crate.flash = 1;
    _slashFx.add(_SlashFx(center, 1, skill ? 2.3 : 1.2, _faceRight));
    _hitStop = math.max(_hitStop, skill ? .026 : .018);
    _screenShake = math.max(_screenShake, skill ? .45 : .24);
    SfxManager.instance.chanceBattleHit();
    HapticFeedback.lightImpact();
    if (!skill) _addSkill(.035);
    if (crate.hp <= 0) {
      crate.breakProgress = 0;
      SfxManager.instance.chanceEnemyDown();
      HapticFeedback.mediumImpact();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF10233A),
      body: SafeArea(
        child: Column(
          children: <Widget>[
            SizedBox(
              height: 58,
              child: Row(
                children: <Widget>[
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                  ),
                  Text(
                    '冒険  STAGE ${widget.stageId}',
                    style: const TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w900),
                  ),
                  const Spacer(),
                  Padding(
                    padding: const EdgeInsets.only(right: 14),
                    child: Text(
                      _stageClear ? 'STAGE CLEAR' : 'BOSSを倒せ！',
                      style: TextStyle(
                        color: _stageClear ? const Color(0xFF8FF0B0) : const Color(0xFFFFD978),
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: LayoutBuilder(
                builder: (context, c) {
                  final size = Size(c.maxWidth, c.maxHeight);
                  _seed(size);
                  return Listener(
                    behavior: HitTestBehavior.opaque,
                    onPointerDown: (e) => _down(e.localPosition),
                    onPointerMove: (e) => _move(e.localPosition),
                    onPointerUp: (e) => _up(e.localPosition),
                    onPointerCancel: (_) {
                      _holding = false;
                      _pressingSkill = false;
                      _target = _hero;
                    },
                    child: Stack(
                      fit: StackFit.expand,
                      children: <Widget>[
                        CustomPaint(painter: _SideScrollFieldPainter(scroll: _scroll)),
                        ..._buildCrates(),
                        ..._buildEnemies(),
                        ..._buildSlashEffects(),
                        if (_holding && _gesturePoints.length >= 2)
                          IgnorePointer(child: CustomPaint(painter: _FingerTracePainter(points: List<Offset>.from(_gesturePoints), energy: _motionEnergy))),
                        if (_skillActive)
                          IgnorePointer(
                            child: CustomPaint(
                              painter: _SkillBurstPainter(progress: (_skillTime / 1.25).clamp(0.0, 1.0), faceRight: _faceRight),
                            ),
                          ),
                        _buildHero(),
                        Positioned(left: 12, right: 12, top: 10, child: _buildProgressLine()),
                        Positioned(left: 12, right: 12, top: 68, child: _buildStatusHud()),
                        Positioned(
                          left: 14,
                          top: 128,
                          child: _hintChip(_bossAnnounced ? 'BOSS AREA  ・  指を動かし続けてジャキジャキ削れ！' : '実験操作：キャラを直接振り回す ・ 速い軌跡ほど強く斬れる' ),
                        ),
                        _buildSkillButton(),
                        if (_bossAnnounced && !_stageClear) _buildBossHud(),
                        if (_stageClear) _buildClearOverlay(),
                      ],
                    ),
                  );
                },
              ),
            ),
            Container(
              height: 50,
              alignment: Alignment.center,
              color: const Color(0xFF0D1C28),
              child: Text(
                _stageClear
                    ? 'BOSS撃破！ ステージクリア'
                    : '技コマンドなし：振る速さ・当て方・引っかかり方そのものが攻撃  ・ BOSS撃破でクリア',
                style: const TextStyle(color: Colors.white70, fontSize: 13, fontWeight: FontWeight.w700),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusHud() {
    return IgnorePointer(
      child: Container(
        height: 52,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(
          color: const Color(0xFF10273C).withValues(alpha: .88),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white.withValues(alpha: .16)),
        ),
        child: Column(
          children: <Widget>[
            _meterRow('HP', _playerHp / _playerMaxHp, const Color(0xFF77E58E), '${_playerHp.round()} / ${_playerMaxHp.round()}'),
            const SizedBox(height: 6),
            _meterRow('SKILL', _skillGauge, _skillGauge >= 1 ? const Color(0xFFFFE66D) : const Color(0xFF66D9FF), _skillGauge >= 1 ? 'READY!' : '${(_skillGauge * 100).round()}%'),
          ],
        ),
      ),
    );
  }

  Widget _meterRow(String label, double value, Color color, String trailing) {
    return Row(
      children: <Widget>[
        SizedBox(
          width: 39,
          child: Text(label, style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w900)),
        ),
        Expanded(
          child: Container(
            height: 9,
            decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(99)),
            alignment: Alignment.centerLeft,
            child: FractionallySizedBox(
              widthFactor: value.clamp(0.0, 1.0),
              child: Container(decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(99))),
            ),
          ),
        ),
        const SizedBox(width: 8),
        SizedBox(
          width: 52,
          child: Text(trailing, textAlign: TextAlign.right, style: TextStyle(color: color, fontSize: 9, fontWeight: FontWeight.w900)),
        ),
      ],
    );
  }

  Widget _buildSkillButton() {
    final ready = _skillGauge >= .999;
    return Positioned(
      right: 18,
      bottom: 28,
      child: IgnorePointer(
        child: AnimatedScale(
          duration: const Duration(milliseconds: 120),
          scale: ready ? 1.0 + math.sin(_time * 8) * .035 : 1,
          child: Container(
            width: 76,
            height: 76,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: ready ? const Color(0xFFFFC84A) : const Color(0xFF38546B).withValues(alpha: .88),
              border: Border.all(color: ready ? Colors.white : Colors.white38, width: ready ? 3 : 2),
              boxShadow: ready
                  ? <BoxShadow>[BoxShadow(color: const Color(0xFFFFE66D).withValues(alpha: .55), blurRadius: 18, spreadRadius: 4)]
                  : const <BoxShadow>[],
            ),
            alignment: Alignment.center,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Icon(Icons.flash_on_rounded, color: ready ? const Color(0xFF713D00) : Colors.white54, size: 27),
                Text(
                  ready ? '必殺技' : '${(_skillGauge * 100).round()}%',
                  style: TextStyle(color: ready ? const Color(0xFF713D00) : Colors.white70, fontSize: 11, fontWeight: FontWeight.w900),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBossHud() {
    final boss = _boss;
    if (boss == null || boss.hp <= 0) return const SizedBox.shrink();
    final ratio = boss.hp / boss.maxHp;
    return Positioned(
      left: 28,
      right: 28,
      top: 166,
      child: IgnorePointer(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: const Color(0xFF4A1720).withValues(alpha: .90),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFFFF9AA8).withValues(alpha: .8)),
          ),
          child: Column(
            children: <Widget>[
              const Row(
                children: <Widget>[
                  Text('BOSS', style: TextStyle(color: Color(0xFFFFD1D7), fontSize: 12, fontWeight: FontWeight.w900)),
                  Spacer(),
                  Text('巨大モンスター', style: TextStyle(color: Colors.white70, fontSize: 10, fontWeight: FontWeight.w800)),
                ],
              ),
              const SizedBox(height: 5),
              Container(
                height: 9,
                decoration: BoxDecoration(color: Colors.black38, borderRadius: BorderRadius.circular(99)),
                alignment: Alignment.centerLeft,
                child: FractionallySizedBox(
                  widthFactor: ratio.clamp(0.0, 1.0).toDouble(),
                  child: Container(decoration: BoxDecoration(color: const Color(0xFFFF6678), borderRadius: BorderRadius.circular(99))),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildClearOverlay() {
    final scale = (0.82 + math.min(1, _clearTime * 4) * .18).clamp(.82, 1.0);
    return Positioned.fill(
      child: IgnorePointer(
        child: Container(
          color: Colors.black.withValues(alpha: .22),
          alignment: Alignment.center,
          child: Transform.scale(
            scale: scale,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 20),
              decoration: BoxDecoration(
                color: const Color(0xFF17314A).withValues(alpha: .94),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: const Color(0xFFFFE07A), width: 2),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  const Text('STAGE CLEAR!', style: TextStyle(color: Color(0xFFFFE07A), fontSize: 28, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 8),
                  Text('BOSS撃破  ・  $_defeated体撃破', style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w800)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildProgressLine() {
    final localAdvance = math.max(0.0, _hero.dx - _startHeroX);
    final worldPosition = (_scroll + localAdvance).clamp(0.0, _stageLength);
    final progress = (worldPosition / _stageLength).clamp(0.0, 1.0);
    final meters = (worldPosition / 10).round();

    return IgnorePointer(
      child: Container(
        height: 52,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(
          color: const Color(0xFF17314A).withValues(alpha: .82),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Colors.white.withValues(alpha: .20)),
        ),
        child: Column(
          children: <Widget>[
            Row(
              children: <Widget>[
                const Text('START', style: TextStyle(color: Colors.white70, fontSize: 9, fontWeight: FontWeight.w900)),
                const Spacer(),
                Text('${meters}m', style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w900)),
                const Spacer(),
                const Text('BOSS', style: TextStyle(color: Color(0xFFFFD978), fontSize: 9, fontWeight: FontWeight.w900)),
              ],
            ),
            const SizedBox(height: 4),
            Expanded(
              child: LayoutBuilder(
                builder: (context, c) {
                  final lineWidth = c.maxWidth;
                  const heroW = 28.0;
                  const heroH = 21.0;
                  final heroLeft = (lineWidth - heroW) * progress;
                  Widget miniHero = Image.asset(
                    'assets/sprites/hero_swordswoman/idle_01.png',
                    width: heroW,
                    height: heroH,
                    fit: BoxFit.contain,
                    alignment: Alignment.bottomCenter,
                    filterQuality: FilterQuality.medium,
                    gaplessPlayback: true,
                  );
                  if (!_faceRight) {
                    miniHero = Transform(
                      alignment: Alignment.center,
                      transform: Matrix4.diagonal3Values(-1, 1, 1),
                      child: miniHero,
                    );
                  }
                  return Stack(
                    clipBehavior: Clip.none,
                    children: <Widget>[
                      Positioned(left: 0, right: 0, top: 10, child: Container(height: 4, decoration: BoxDecoration(color: Colors.white.withValues(alpha: .23), borderRadius: BorderRadius.circular(99)))),
                      Positioned(left: 0, top: 10, child: Container(width: lineWidth * progress, height: 4, decoration: BoxDecoration(color: const Color(0xFFFFD978), borderRadius: BorderRadius.circular(99)))),
                      _progressMarker(lineWidth * .25 - 4, const Color(0xFFFFD978)),
                      _progressMarker(lineWidth * .50 - 4, const Color(0xFFFFB06E)),
                      _progressMarker(lineWidth * .75 - 4, const Color(0xFFFF8D70)),
                      _progressMarker(lineWidth - 8, const Color(0xFFE66B6B)),
                      Positioned(left: heroLeft, top: -5, child: SizedBox(width: heroW, height: heroH, child: miniHero)),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _progressMarker(double left, Color color) {
    return Positioned(
      left: left,
      top: 8,
      child: Container(
        width: 8,
        height: 8,
        decoration: BoxDecoration(color: color, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 1.2)),
      ),
    );
  }

  Widget _hintChip(String text) {
    return IgnorePointer(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
        decoration: BoxDecoration(
          color: const Color(0xFF17314A).withValues(alpha: .76),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Colors.white.withValues(alpha: .20)),
        ),
        child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800)),
      ),
    );
  }

  List<Widget> _buildCrates() {
    return _crates.map((crate) {
      const s = 62.0;
      if (crate.hp <= 0) {
        if (crate.breakProgress >= 1) return const SizedBox.shrink();
        return Positioned(
          left: crate.x - s * .75,
          top: crate.y - s * .95,
          child: IgnorePointer(
            child: SizedBox(width: s * 1.5, height: s * 1.25, child: CustomPaint(painter: _CrateBreakPainter(progress: crate.breakProgress))),
          ),
        );
      }
      return Positioned(
        left: crate.x - s / 2,
        top: crate.y - s,
        child: IgnorePointer(
          child: Opacity(
            opacity: crate.flash > 0 ? .62 : 1,
            child: SizedBox(
              width: s,
              height: s,
              child: CustomPaint(painter: _WoodCratePainter(damage: 1 - crate.hp / crate.maxHp)),
            ),
          ),
        ),
      );
    }).toList();
  }

  List<Widget> _buildEnemies() {
    return _enemies.map((e) {
      final bounce = e.hp > 0 ? math.sin(_time * 3 + e.phase) * (e.weight == _EnemyWeight.large ? 1.5 : 3.0) : 0.0;
      final s = e.size;
      if (e.hp <= 0) {
        if (e.pop >= 1) return const SizedBox.shrink();
        return Positioned(
          left: e.x - s * .65 + math.sin(_time * 71) * _screenShake * 2.2,
          top: e.y - s * .95 + math.cos(_time * 83) * _screenShake * 1.5,
          child: IgnorePointer(
            child: SizedBox(width: s * 1.3, height: s * 1.3, child: CustomPaint(painter: _BattlePopPainter(progress: e.pop))),
          ),
        );
      }

      final hpRatio = e.hp / e.maxHp;
      Widget monster = CustomPaint(
        size: Size.square(s),
        painter: _BattleTsumPainter(type: e.type, selected: e.weight == _EnemyWeight.large),
      );
      if (e.flash > 0) {
        monster = Stack(
          fit: StackFit.expand,
          children: <Widget>[
            monster,
            Opacity(opacity: (e.flash * .72).clamp(0.0, .72), child: Container(decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle))),
          ],
        );
      }

      return Positioned(
        left: e.x - s / 2 + math.sin(_time * 71) * _screenShake * 2.2,
        top: e.y - s + bounce + math.cos(_time * 83) * _screenShake * 1.5,
        child: IgnorePointer(
          child: SizedBox(
            width: s,
            height: s + (e.weight == _EnemyWeight.small ? 0 : 12),
            child: Stack(
              clipBehavior: Clip.none,
              children: <Widget>[
                Positioned(left: 0, top: 0, width: s, height: s, child: monster),
                if (e.isBoss)
                  Positioned(
                    left: 0,
                    right: 0,
                    top: -20,
                    child: Text('BOSS', textAlign: TextAlign.center, style: TextStyle(color: const Color(0xFFFF6478), fontSize: math.max(11, s * .10), fontWeight: FontWeight.w900)),
                  ),
                if (e.weight != _EnemyWeight.small && !e.isBoss)
                  Positioned(
                    left: s * .08,
                    right: s * .08,
                    bottom: 0,
                    child: Container(
                      height: e.weight == _EnemyWeight.large ? 7 : 5,
                      decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(99)),
                      alignment: Alignment.centerLeft,
                      child: FractionallySizedBox(
                        widthFactor: hpRatio.clamp(0.0, 1.0).toDouble(),
                        child: Container(decoration: BoxDecoration(color: e.weight == _EnemyWeight.large ? const Color(0xFFE55F62) : const Color(0xFFFFC857), borderRadius: BorderRadius.circular(99))),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      );
    }).toList();
  }

  List<Widget> _buildSlashEffects() {
    return _slashFx.map((fx) {
      const w = 150.0;
      const h = 96.0;
      return Positioned(
        left: fx.position.dx - w / 2 + math.sin(_time * 71) * _screenShake * 2.2,
        top: fx.position.dy - h / 2 + math.cos(_time * 83) * _screenShake * 1.5,
        child: IgnorePointer(
          child: SizedBox(width: w, height: h, child: CustomPaint(painter: _SwordImpactPainter(life: fx.life, power: fx.power, faceRight: fx.faceRight))),
        ),
      );
    }).toList();
  }

  Widget _buildHero() {
    final speed = _velocity.distance;
    final moving = !_attack && speed > 55;
    final path = _attack
        ? 'assets/sprites/hero_swordswoman/attack_${_attackFrame.toString().padLeft(2, '0')}.png'
        : moving
            ? 'assets/sprites/hero_swordswoman/run_${_runFrame.toString().padLeft(2, '0')}.png'
            : null;

    final bob = moving ? math.sin(_time * 13) * 1.8 : -math.sin(_time * math.pi * 2 * .62) * 1.15;
    final breatheScale = moving || _attack ? 1.0 : 1.0 + math.sin(_time * math.pi * 2 * .72) * .005;

    // V91h: keep the smaller hero; airborne motion is now an automatic jump arc only.
    const boxW = 156.0;
    const boxH = 117.0;

    Widget imageFor(String asset) => Image.asset(
          asset,
          width: boxW,
          height: boxH,
          fit: BoxFit.contain,
          alignment: Alignment.bottomCenter,
          filterQuality: FilterQuality.high,
          gaplessPlayback: true,
        );

    Widget sprite = path != null ? imageFor(path) : imageFor('assets/sprites/hero_swordswoman/idle_01.png');
    if (!_faceRight) {
      sprite = Transform(alignment: Alignment.center, transform: Matrix4.diagonal3Values(-1, 1, 1), child: sprite);
    }

    return Positioned(
      left: _hero.dx - boxW / 2 + math.sin(_time * 71) * _screenShake * 2.2,
      top: _hero.dy - boxH - _jumpHeight + bob + math.cos(_time * 83) * _screenShake * 1.5,
      child: IgnorePointer(
        child: Transform.rotate(
          angle: _tilt,
          alignment: Alignment.bottomCenter,
          child: Transform.scale(scaleY: breatheScale, alignment: Alignment.bottomCenter, child: sprite),
        ),
      ),
    );
  }
}

class _FingerTracePainter extends CustomPainter {
  const _FingerTracePainter({required this.points, required this.energy});
  final List<Offset> points;
  final double energy;

  @override
  void paint(Canvas canvas, Size size) {
    if (points.length < 2) return;
    final path = Path()..moveTo(points.first.dx, points.first.dy);
    for (var i = 1; i < points.length; i++) {
      path.lineTo(points[i].dx, points[i].dy);
    }
    final e = energy.clamp(0.0, 1.0);
    canvas.drawPath(
      path,
      Paint()
        ..color = const Color(0xFFBDEEFF).withValues(alpha: .18 + e * .30)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3 + e * 7
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round,
    );
    if (e > .45) {
      canvas.drawPath(
        path,
        Paint()
          ..color = Colors.white.withValues(alpha: .20 + e * .38)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.4 + e * 2.2
          ..strokeCap = StrokeCap.round,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _FingerTracePainter oldDelegate) => true;
}

class _WoodCratePainter extends CustomPainter {
  const _WoodCratePainter({required this.damage});
  final double damage;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Rect.fromLTWH(size.width * .08, size.height * .10, size.width * .84, size.height * .82);
    final fill = Paint()..color = const Color(0xFFB9783E);
    final dark = Paint()..color = const Color(0xFF744524)..style = PaintingStyle.stroke..strokeWidth = 4;
    canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(6)), fill);
    canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(6)), dark);
    canvas.drawLine(Offset(rect.left + 5, rect.top + 7), Offset(rect.right - 5, rect.bottom - 7), dark);
    canvas.drawLine(Offset(rect.right - 5, rect.top + 7), Offset(rect.left + 5, rect.bottom - 7), dark);
    canvas.drawRect(Rect.fromCenter(center: rect.center, width: size.width * .15, height: size.height * .14), Paint()..color = const Color(0xFFDBA05D));
    if (damage > .01) {
      final crack = Paint()..color = const Color(0xFF5B351D)..strokeWidth = 2.4..strokeCap = StrokeCap.round;
      final c = rect.center;
      canvas.drawLine(c.translate(-6, -2), c.translate(1, 5), crack);
      canvas.drawLine(c.translate(1, 5), c.translate(-4, 13), crack);
      if (damage > .45) canvas.drawLine(c.translate(2, 5), c.translate(11, 10), crack);
    }
  }

  @override
  bool shouldRepaint(covariant _WoodCratePainter oldDelegate) => oldDelegate.damage != damage;
}

class _CrateBreakPainter extends CustomPainter {
  const _CrateBreakPainter({required this.progress});
  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height * .62);
    final life = (1 - progress).clamp(0.0, 1.0);
    final wood = Paint()..color = const Color(0xFF9B6033).withValues(alpha: life);
    for (var i = 0; i < 7; i++) {
      final a = -math.pi * .9 + i * math.pi * 1.8 / 6;
      final dist = 8 + progress * (24 + (i % 3) * 7);
      final p = c + Offset(math.cos(a), math.sin(a) - .45) * dist;
      canvas.save();
      canvas.translate(p.dx, p.dy);
      canvas.rotate(a + progress * (i.isEven ? 2.5 : -2.2));
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: Offset.zero, width: 12, height: 7), const Radius.circular(2)), wood);
      canvas.restore();
    }
    canvas.drawCircle(c, 10 + progress * 28, Paint()..color = Colors.white.withValues(alpha: life * .5)..style = PaintingStyle.stroke..strokeWidth = 2.5);
  }

  @override
  bool shouldRepaint(covariant _CrateBreakPainter oldDelegate) => oldDelegate.progress != progress;
}

class _SkillBurstPainter extends CustomPainter {
  const _SkillBurstPainter({required this.progress, required this.faceRight});
  final double progress;
  final bool faceRight;

  @override
  void paint(Canvas canvas, Size size) {
    final pulse = .5 + .5 * math.sin(progress * math.pi * 12);
    final alpha = (1 - progress * .55).clamp(0.0, 1.0);
    final c = Offset(size.width * (faceRight ? .55 : .45), size.height * .66);
    final ring = Paint()
      ..color = const Color(0xFFBDEEFF).withValues(alpha: alpha * .42)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4 + pulse * 3;
    canvas.drawOval(Rect.fromCenter(center: c, width: 250 + pulse * 35, height: 155 + pulse * 22), ring);
    final slash = Paint()
      ..color = Colors.white.withValues(alpha: alpha * .36)
      ..strokeWidth = 5
      ..strokeCap = StrokeCap.round;
    for (var i = 0; i < 5; i++) {
      final y = c.dy - 65 + i * 31 + math.sin(progress * 20 + i) * 12;
      final dir = faceRight ? 1.0 : -1.0;
      canvas.drawLine(Offset(c.dx - dir * 105, y + 22), Offset(c.dx + dir * 120, y - 20), slash);
    }
  }

  @override
  bool shouldRepaint(covariant _SkillBurstPainter oldDelegate) => true;
}

class _SwordImpactPainter extends CustomPainter {
  const _SwordImpactPainter({required this.life, required this.power, required this.faceRight});
  final double life;
  final double power;
  final bool faceRight;

  @override
  void paint(Canvas canvas, Size size) {
    final t = (1 - life).clamp(0.0, 1.0);
    final alpha = life.clamp(0.0, 1.0);
    final c = Offset(size.width / 2, size.height / 2);
    final dir = faceRight ? 1.0 : -1.0;
    final slash = Paint()
      ..color = Colors.white.withValues(alpha: alpha * .92)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.5 + power * 1.2
      ..strokeCap = StrokeCap.round;
    final blue = Paint()
      ..color = const Color(0xFF66D9FF).withValues(alpha: alpha * .82)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 7 + power * 2.0
      ..strokeCap = StrokeCap.round;

    final p = Path()
      ..moveTo(c.dx - dir * 56, c.dy + 26)
      ..quadraticBezierTo(c.dx + dir * 8, c.dy - 48 - power * 4, c.dx + dir * 62, c.dy - 12);
    canvas.drawPath(p, blue);
    canvas.drawPath(p, slash);

    final spark = Paint()
      ..color = const Color(0xFFFFE08A).withValues(alpha: alpha)
      ..strokeWidth = 2.2
      ..strokeCap = StrokeCap.round;
    final ray = 18 + t * 22 + power * 4;
    for (var i = 0; i < 7; i++) {
      final a = i * math.pi * 2 / 7 + .2;
      final p0 = c + Offset(math.cos(a), math.sin(a)) * (7 + t * 7);
      final p1 = c + Offset(math.cos(a), math.sin(a)) * ray;
      canvas.drawLine(p0, p1, spark);
    }
  }

  @override
  bool shouldRepaint(covariant _SwordImpactPainter oldDelegate) => true;
}

class _BattleTsumPainter extends CustomPainter {
  const _BattleTsumPainter({required this.type, required this.selected});
  final int type;
  final bool selected;

  Paint _gloss(Color light, Color base, Color dark, Offset c, double r) => Paint()
    ..shader = RadialGradient(
      center: const Alignment(-.34, -.42), radius: 1.05,
      colors: [light, base, dark], stops: const [0, .55, 1],
    ).createShader(Rect.fromCircle(center: c, radius: r));

  void _shine(Canvas canvas, Offset c, double r) {
    canvas.drawOval(Rect.fromCenter(center: c + Offset(-r * .28, -r * .38), width: r * .48, height: r * .25), Paint()..color = Colors.white.withValues(alpha: .34));
  }

  void _eyes(Canvas canvas, Offset c, double r, {double y = -.10}) {
    final p = Paint()..color = const Color(0xFF252525);
    canvas.drawCircle(c + Offset(-r * .25, r * y), r * .075, p);
    canvas.drawCircle(c + Offset(r * .25, r * y), r * .075, p);
    final hi = Paint()..color = Colors.white.withValues(alpha: .9);
    canvas.drawCircle(c + Offset(-r * .225, r * (y - .025)), r * .018, hi);
    canvas.drawCircle(c + Offset(r * .275, r * (y - .025)), r * .018, hi);
  }

  void _blush(Canvas canvas, Offset c, double r) {
    final p = Paint()..color = const Color(0x55F38E9E);
    canvas.drawCircle(c + Offset(-r * .48, r * .13), r * .11, p);
    canvas.drawCircle(c + Offset(r * .48, r * .13), r * .11, p);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = math.min(size.width, size.height) / 2;
    canvas.drawOval(Rect.fromCenter(center: c + Offset(0, r * .12), width: r * 1.62, height: r * 1.58), Paint()..color = const Color(0x33000000)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3));
    switch (type) {
      case 0: _drawChick(canvas, c, r); break;
      case 1: _drawFrog(canvas, c, r); break;
      case 2: _drawPenguin(canvas, c, r); break;
      case 3: _drawDog(canvas, c, r); break;
      default: _drawBunny(canvas, c, r);
    }
    if (selected) {
      canvas.drawCircle(c, r * .82, Paint()..color = Colors.white.withValues(alpha: .38)..style = PaintingStyle.stroke..strokeWidth = math.max(2, r * .07));
    }
  }

  void _drawChick(Canvas canvas, Offset c, double r) {
    final body = _gloss(const Color(0xFFFFF08A), const Color(0xFFFFC928), const Color(0xFFE79A00), c, r);
    canvas.drawCircle(c, r * .82, body); _shine(canvas, c, r);
    final wing = Paint()..color = const Color(0xFFFFB51E);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(-r * .66, r * .12), width: r * .28, height: r * .48), wing);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(r * .66, r * .12), width: r * .28, height: r * .48), wing);
    _eyes(canvas, c, r); _blush(canvas, c, r);
    final beak = Path()..moveTo(c.dx-r*.10,c.dy+r*.08)..lineTo(c.dx+r*.12,c.dy+r*.08)..lineTo(c.dx,c.dy+r*.20)..close();
    canvas.drawPath(beak, Paint()..color = const Color(0xFFF18A18));
  }

  void _drawFrog(Canvas canvas, Offset c, double r) {
    final body = _gloss(const Color(0xFFA6F3A9), const Color(0xFF63D46B), const Color(0xFF2C9A42), c, r);
    canvas.drawCircle(c, r*.82, body); _shine(canvas,c,r);
    canvas.drawCircle(c+Offset(-r*.42,-r*.55),r*.25,body); canvas.drawCircle(c+Offset(r*.42,-r*.55),r*.25,body);
    for (final x in [-.42,.42]) { canvas.drawCircle(c+Offset(r*x,-r*.55),r*.11,Paint()..color=Colors.white); canvas.drawCircle(c+Offset(r*x,-r*.55),r*.055,Paint()..color=const Color(0xFF1E2A25)); }
    _blush(canvas,c,r);
    canvas.drawArc(Rect.fromCenter(center:c+Offset(0,r*.12),width:r*.60,height:r*.36),.15,math.pi-.30,false,Paint()..color=const Color(0xFF25873A)..style=PaintingStyle.stroke..strokeWidth=math.max(1.8,r*.07)..strokeCap=StrokeCap.round);
  }

  void _drawPenguin(Canvas canvas, Offset c, double r) {
    final blue=_gloss(const Color(0xFF9DE1FF),const Color(0xFF4F9ED8),const Color(0xFF2464A8),c,r);
    canvas.drawCircle(c,r*.82,blue); _shine(canvas,c,r);
    canvas.drawOval(Rect.fromCenter(center:c+Offset(0,r*.19),width:r,height:r*1.10),Paint()..color=const Color(0xFFEAF6FF));
    final wing=Paint()..color=const Color(0xFF2E6F9F);
    canvas.drawOval(Rect.fromCenter(center:c+Offset(-r*.62,r*.08),width:r*.22,height:r*.56),wing); canvas.drawOval(Rect.fromCenter(center:c+Offset(r*.62,r*.08),width:r*.22,height:r*.56),wing);
    _eyes(canvas,c+Offset(0,-r*.10),r,y:0);
    final beak=Path()..moveTo(c.dx-r*.10,c.dy+r*.01)..lineTo(c.dx+r*.10,c.dy+r*.01)..lineTo(c.dx,c.dy+r*.15)..close(); canvas.drawPath(beak,Paint()..color=const Color(0xFFFF9B2F));
  }

  void _drawDog(Canvas canvas, Offset c, double r) {
    final ear=Paint()..color=const Color(0xFF7453B7);
    canvas.drawOval(Rect.fromCenter(center:c+Offset(-r*.62,-r*.18),width:r*.42,height:r*.72),ear); canvas.drawOval(Rect.fromCenter(center:c+Offset(r*.62,-r*.18),width:r*.42,height:r*.72),ear);
    canvas.drawCircle(c,r*.82,_gloss(const Color(0xFFE4D7FF),const Color(0xFFBFA8F2),const Color(0xFF8060C7),c,r)); _shine(canvas,c,r);
    canvas.drawOval(Rect.fromCenter(center:c+Offset(r*.26,-r*.18),width:r*.36,height:r*.46),ear); _eyes(canvas,c,r); _blush(canvas,c,r); canvas.drawCircle(c+Offset(0,r*.16),r*.09,Paint()..color=const Color(0xFF3E315A));
  }

  void _drawBunny(Canvas canvas, Offset c, double r) {
    final body=_gloss(const Color(0xFFFFE2EE),const Color(0xFFFFA7C7),const Color(0xFFE66B9B),c,r); final inner=Paint()..color=const Color(0xFFFF6F9F);
    canvas.drawOval(Rect.fromCenter(center:c+Offset(-r*.28,-r*.86),width:r*.32,height:r*.88),body); canvas.drawOval(Rect.fromCenter(center:c+Offset(r*.28,-r*.86),width:r*.32,height:r*.88),body);
    canvas.drawOval(Rect.fromCenter(center:c+Offset(-r*.28,-r*.86),width:r*.11,height:r*.55),inner); canvas.drawOval(Rect.fromCenter(center:c+Offset(r*.28,-r*.86),width:r*.11,height:r*.55),inner);
    canvas.drawCircle(c+Offset(0,r*.04),r*.76,body); _shine(canvas,c+Offset(0,r*.04),r*.92); _eyes(canvas,c+Offset(0,r*.02),r); _blush(canvas,c,r); canvas.drawCircle(c+Offset(0,r*.16),r*.06,Paint()..color=const Color(0xFF8C3F61));
  }

  @override bool shouldRepaint(covariant _BattleTsumPainter oldDelegate) => oldDelegate.type != type || oldDelegate.selected != selected;
}

class _BattlePopPainter extends CustomPainter {
  const _BattlePopPainter({required this.progress});
  final double progress;
  @override void paint(Canvas canvas, Size size) {
    final life=(1-progress).clamp(0.0,1.0); final p=Offset(size.width/2,size.height/2); final r=(1-life)*24+5;
    final paint=Paint()..color=Colors.white.withValues(alpha:life)..style=PaintingStyle.stroke..strokeWidth=3;
    canvas.drawCircle(p,r,paint);
    for(var i=0;i<7;i++){final a=i*math.pi*2/7; final a0=p+Offset(math.cos(a),math.sin(a))*r*.65; final a1=p+Offset(math.cos(a),math.sin(a))*r*1.15; canvas.drawLine(a0,a1,paint);}
  }
  @override bool shouldRepaint(covariant _BattlePopPainter oldDelegate)=>oldDelegate.progress!=progress;
}

class _SideScrollFieldPainter extends CustomPainter {
  const _SideScrollFieldPainter({required this.scroll});
  final double scroll;

  @override
  void paint(Canvas canvas, Size size) {
    final sky = Paint()..color = const Color(0xFFBFE8FF);
    canvas.drawRect(Offset.zero & size, sky);

    // distant sky glow
    canvas.drawRect(
      Rect.fromLTWH(0, size.height * .30, size.width, size.height * .28),
      Paint()..color = const Color(0xFFDDF5FF),
    );

    _hills(canvas, size, .10, const Color(0xFF8ECF91), size.height * .43, 54);
    _hills(canvas, size, .24, const Color(0xFF62B975), size.height * .50, 72);

    final grassTop = size.height * .54;
    canvas.drawRect(
      Rect.fromLTWH(0, grassTop, size.width, size.height - grassTop),
      Paint()..color = const Color(0xFF7ED45E),
    );

    // dirt road where the action happens
    final road = Path()
      ..moveTo(0, size.height * .63)
      ..quadraticBezierTo(size.width * .45, size.height * .59, size.width, size.height * .64)
      ..lineTo(size.width, size.height * .86)
      ..quadraticBezierTo(size.width * .50, size.height * .82, 0, size.height * .88)
      ..close();
    canvas.drawPath(road, Paint()..color = const Color(0xFFEBC889));

    final offset = -(scroll % 180);
    for (double x = offset - 180; x < size.width + 180; x += 180) {
      _tree(canvas, Offset(x + 34, grassTop - 8), .88);
      _bush(canvas, Offset(x + 118, grassTop + 6), .82);
      _rock(canvas, Offset(x + 146, size.height * .83), .75);
      _flowers(canvas, Offset(x + 84, size.height * .89));
    }

    final nearOffset = -((scroll * 1.45) % 130);
    for (double x = nearOffset - 130; x < size.width + 130; x += 130) {
      _grassTuft(canvas, Offset(x + 20, size.height * .91));
      _grassTuft(canvas, Offset(x + 86, size.height * .58));
    }
  }

  void _hills(Canvas canvas, Size size, double parallax, Color color, double y, double amp) {
    final phase = -((scroll * parallax) % 240);
    final path = Path()..moveTo(0, size.height);
    path.lineTo(0, y);
    for (double x = phase - 240; x <= size.width + 240; x += 120) {
      path.quadraticBezierTo(x + 60, y - amp, x + 120, y);
    }
    path.lineTo(size.width, size.height);
    path.close();
    canvas.drawPath(path, Paint()..color = color);
  }

  void _tree(Canvas canvas, Offset p, double s) {
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(center: Offset(p.dx, p.dy + 19 * s), width: 12 * s, height: 48 * s),
        Radius.circular(5 * s),
      ),
      Paint()..color = const Color(0xFF875F3D),
    );
    final leaf = Paint()..color = const Color(0xFF3E9C58);
    canvas.drawCircle(Offset(p.dx - 14 * s, p.dy - 4 * s), 22 * s, leaf);
    canvas.drawCircle(Offset(p.dx + 11 * s, p.dy - 8 * s), 25 * s, leaf);
    canvas.drawCircle(Offset(p.dx, p.dy - 25 * s), 25 * s, Paint()..color = const Color(0xFF51B967));
  }

  void _bush(Canvas canvas, Offset p, double s) {
    final paint = Paint()..color = const Color(0xFF49AE5C);
    canvas.drawCircle(Offset(p.dx - 13 * s, p.dy), 16 * s, paint);
    canvas.drawCircle(Offset(p.dx + 2 * s, p.dy - 7 * s), 20 * s, paint);
    canvas.drawCircle(Offset(p.dx + 18 * s, p.dy), 15 * s, paint);
  }

  void _rock(Canvas canvas, Offset p, double s) {
    canvas.drawOval(
      Rect.fromCenter(center: p, width: 28 * s, height: 17 * s),
      Paint()..color = const Color(0xFF8E9A95),
    );
  }

  void _flowers(Canvas canvas, Offset p) {
    for (int i = 0; i < 4; i++) {
      final x = p.dx + i * 9;
      canvas.drawCircle(Offset(x, p.dy), 3.2, Paint()..color = Colors.white);
      canvas.drawCircle(Offset(x, p.dy), 1.2, Paint()..color = const Color(0xFFFFC84A));
    }
  }

  void _grassTuft(Canvas canvas, Offset p) {
    final paint = Paint()
      ..color = const Color(0xFF3F9E4F)
      ..strokeWidth = 2.2
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(p, p.translate(-5, -10), paint);
    canvas.drawLine(p, p.translate(0, -12), paint);
    canvas.drawLine(p, p.translate(6, -9), paint);
  }

  @override
  bool shouldRepaint(covariant _SideScrollFieldPainter oldDelegate) => oldDelegate.scroll != scroll;
}
