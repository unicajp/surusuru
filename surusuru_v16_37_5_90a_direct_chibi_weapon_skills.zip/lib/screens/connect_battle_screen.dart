import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../game/game_controller.dart';
import '../sfx_manager.dart';

class _Enemy { _Enemy(this.pos, {this.boss=false}) : hp=boss?520:70; Offset pos; Offset vel=Offset.zero; final bool boss; int hp; double flash=0; }

class ConnectBattleScreen extends StatefulWidget {
  final GameController controller; final int stageId;
  const ConnectBattleScreen({super.key,required this.controller,required this.stageId});
  @override State<ConnectBattleScreen> createState()=>_ConnectBattleScreenState();
}

class _ConnectBattleScreenState extends State<ConnectBattleScreen> {
  final math.Random _rng=math.Random(); final List<_Enemy> _enemies=[]; final List<Offset> _trail=[];
  Timer? _timer; Size _field=Size.zero; Offset _hero=Offset.zero,_heroVel=Offset.zero,_finger=Offset.zero; bool _seeded=false,_dragging=false,_finished=false; int _heroHp=100; double _skillFx=0; String _skill='';
  @override void initState(){super.initState();_timer=Timer.periodic(const Duration(milliseconds:16),(_)=>_tick());}
  @override void dispose(){_timer?.cancel();super.dispose();}
  void _seed(Size s){if(_seeded)return;_seeded=true;_field=s;_hero=Offset(s.width*.5,s.height*.76);_finger=_hero;final n=8+widget.stageId.clamp(1,10);for(int i=0;i<n;i++){_enemies.add(_Enemy(Offset(28+_rng.nextDouble()*(s.width-56),45+_rng.nextDouble()*s.height*.45)));}if(widget.stageId%5==0)_enemies.add(_Enemy(Offset(s.width*.5,70),boss:true));}
  void _tick(){if(!mounted||!_seeded||_finished)return;const dt=.016;if(_dragging){final d=_finger-_hero;_heroVel=_heroVel*.72+d*7.8;_hero+=_heroVel*dt;}else{_heroVel*=.86;_hero+=_heroVel*dt;}
    _hero=Offset(_hero.dx.clamp(22,_field.width-22),_hero.dy.clamp(28,_field.height-22));
    for(final e in _enemies){if(e.hp<=0)continue;e.flash=math.max(0,e.flash-dt);final d=_hero-e.pos;final dist=d.distance;if(dist>1)e.vel=e.vel*.92+d/dist*(e.boss?19:27)*dt;e.pos+=e.vel;if(dist<(e.boss?42:29)){if(_dragging){final speed=_heroVel.distance;final dmg=(8+speed*.11).clamp(8,32).round();e.hp=math.max(0,e.hp-dmg);e.flash=.12;e.vel-=d/math.max(dist,1)*(3+speed*.025);SfxManager.instance.chanceBattleHit();}else{_heroHp=math.max(0,_heroHp-(e.boss?2:1));}}
    }
    _skillFx=math.max(0,_skillFx-dt);if(_heroHp<=0){_finished=true;_timer?.cancel();}if(_enemies.every((e)=>e.hp<=0))_win();if(mounted)setState((){});
  }
  void _down(DragStartDetails d){_dragging=true;_finger=d.localPosition;_trail..clear()..add(d.localPosition);SfxManager.instance.battleSururu();}
  void _move(DragUpdateDetails d){_finger=d.localPosition;_trail.add(d.localPosition);if(_trail.length>45)_trail.removeAt(0);}
  void _up(DragEndDetails d){_dragging=false;_recognize();_trail.clear();}
  void _recognize(){if(_trail.length<5)return;double length=0;for(int i=1;i<_trail.length;i++)length+=(_trail[i]-_trail[i-1]).distance;final close=(_trail.first-_trail.last).distance;String skill;int damage;double radius;if(length>150&&close<55){skill='ぐるぐる斬り！';damage=45;radius=105;}else{int turns=0;double last=0;for(int i=2;i<_trail.length;i++){final a=_trail[i-1]-_trail[i-2],b=_trail[i]-_trail[i-1];final cross=a.dx*b.dy-a.dy*b.dx;if(cross.abs()>8&&last!=0&&cross.sign!=last.sign)turns++;if(cross.abs()>8)last=cross.sign;}if(turns>=3){skill='ジグザグ連撃！';damage=38;radius=82;}else if(length>120){skill='スラッシュ！';damage=28;radius=65;}else return;}
    for(final e in _enemies){if(e.hp>0&&(e.pos-_hero).distance<radius){e.hp=math.max(0,e.hp-damage);e.flash=.25;}}
    _skill=skill;_skillFx=.7;SfxManager.instance.surusuru();
  }
  Future<void> _win()async{if(_finished)return;_finished=true;_timer?.cancel();await widget.controller.completeRpgStage(widget.stageId);if(!mounted)return;await showDialog(context:context,builder:(c)=>AlertDialog(title:const Text('STAGE CLEAR! 🎉'),content:const Text('指先で敵をすべて倒しました！'),actions:[FilledButton(onPressed:()=>Navigator.pop(c),child:const Text('OK'))]));if(mounted)Navigator.pop(context);}
  @override Widget build(BuildContext context)=>Scaffold(backgroundColor:const Color(0xFF142434),body:SafeArea(child:Column(children:[Padding(padding:const EdgeInsets.symmetric(horizontal:6,vertical:4),child:Row(children:[IconButton(onPressed:()=>Navigator.pop(context),icon:const Icon(Icons.arrow_back,color:Colors.white)),Text('冒険  STAGE ${widget.stageId}',style:const TextStyle(color:Colors.white,fontSize:18,fontWeight:FontWeight.w900)),const Spacer(),Text('HP $_heroHp',style:const TextStyle(color:Color(0xFF8FF0A8),fontWeight:FontWeight.w900))])),Container(margin:const EdgeInsets.fromLTRB(12,0,12,6),padding:const EdgeInsets.symmetric(horizontal:12,vertical:7),decoration:BoxDecoration(color:Colors.white10,borderRadius:BorderRadius.circular(14)),child:const Text('キャラをつかんで敵へ！  ─ 直線 / ○ 円 / ⚡ ジグザグで技発動',style:TextStyle(color:Colors.white,fontSize:12,fontWeight:FontWeight.w800))),Expanded(child:LayoutBuilder(builder:(c,b){final s=Size(b.maxWidth,b.maxHeight);_field=s;_seed(s);return GestureDetector(behavior:HitTestBehavior.opaque,onPanStart:_down,onPanUpdate:_move,onPanEnd:_up,child:CustomPaint(size:s,painter:_DirectBattlePainter(_hero,_heroVel,_enemies,_trail,_dragging,_skill,_skillFx)));})),Container(padding:const EdgeInsets.symmetric(horizontal:14,vertical:8),color:const Color(0xFF0D1925),child:Row(children:[const Text('🗡️ ぷにブレード  Lv.1',style:TextStyle(color:Colors.white,fontWeight:FontWeight.w900)),const Spacer(),Text('${_enemies.where((e)=>e.hp>0).length} ENEMIES',style:const TextStyle(color:Color(0xFFFFD86B),fontWeight:FontWeight.w900))]))])));
}

class _DirectBattlePainter extends CustomPainter {final Offset hero,vel;final List<_Enemy> enemies;final List<Offset> trail;final bool dragging;final String skill;final double fx;_DirectBattlePainter(this.hero,this.vel,this.enemies,this.trail,this.dragging,this.skill,this.fx);
 @override void paint(Canvas canvas,Size size){final bg=Paint()..shader=const LinearGradient(begin:Alignment.topCenter,end:Alignment.bottomCenter,colors:[Color(0xFF294A5A),Color(0xFF18372F)]).createShader(Offset.zero&size);canvas.drawRect(Offset.zero&size,bg);canvas.drawOval(Rect.fromCenter(center:Offset(size.width*.5,size.height*.55),width:size.width*.95,height:size.height*.8),Paint()..color=const Color(0x223DD58B));
 if(trail.length>1){final p=Path()..moveTo(trail.first.dx,trail.first.dy);for(final x in trail.skip(1))p.lineTo(x.dx,x.dy);canvas.drawPath(p,Paint()..color=const Color(0xAAFFF19A)..strokeWidth=5..style=PaintingStyle.stroke..strokeCap=StrokeCap.round);}
 for(final e in enemies){if(e.hp<=0)continue;final r=e.boss?30.0:17.0;canvas.drawOval(Rect.fromCenter(center:e.pos+Offset(0,r*.8),width:r*1.5,height:r*.45),Paint()..color=Colors.black26);canvas.drawCircle(e.pos,r,Paint()..color=e.flash>0?Colors.white:(e.boss?const Color(0xFFD84A65):const Color(0xFF7B4C9E)));final tp=TextPainter(text:TextSpan(text:e.boss?'👹':'👾',style:TextStyle(fontSize:e.boss?36:21)),textDirection:TextDirection.ltr)..layout();tp.paint(canvas,e.pos-Offset(tp.width/2,tp.height/2));final max=e.boss?520:70;canvas.drawRect(Rect.fromLTWH(e.pos.dx-r,e.pos.dy-r-8,r*2,4),Paint()..color=Colors.black45);canvas.drawRect(Rect.fromLTWH(e.pos.dx-r,e.pos.dy-r-8,r*2*e.hp/max,4),Paint()..color=const Color(0xFFFF6D7E));}
 final speed=vel.distance;canvas.save();canvas.translate(hero.dx,hero.dy);canvas.rotate((vel.dx/900).clamp(-.22,.22));final squash=(speed/700).clamp(0.0,.12);canvas.scale(1+squash,1-squash);canvas.translate(-22,-22);_BattleRoundCharacterPainter(type:0).paint(canvas,const Size(44,44));canvas.restore();if(dragging)canvas.drawCircle(hero,27,Paint()..color=const Color(0x6686F5FF)..style=PaintingStyle.stroke..strokeWidth=3);
 if(fx>0){final tp=TextPainter(text:TextSpan(text:skill,style:TextStyle(color:Colors.white,fontSize:22,fontWeight:FontWeight.w900,shadows:[Shadow(blurRadius:8,color:Colors.black.withValues(alpha:.8))])),textDirection:TextDirection.ltr)..layout();tp.paint(canvas,Offset(size.width/2-tp.width/2,size.height*.18));}}
 @override bool shouldRepaint(covariant CustomPainter oldDelegate)=>true;}
class _BattleRoundCharacterPainter {
  final int type;

  const _BattleRoundCharacterPainter({required this.type});

  Paint _gloss(Color light, Color base, Color dark, Offset c, double r) {
    return Paint()
      ..shader = RadialGradient(
        center: const Alignment(-.34, -.42),
        radius: 1.05,
        colors: <Color>[light, base, dark],
        stops: const <double>[0, .55, 1],
      ).createShader(Rect.fromCircle(center: c, radius: r));
  }

  void _bodyShine(Canvas canvas, Offset c, double r) {
    canvas.drawOval(
      Rect.fromCenter(
        center: c + Offset(-r * .28, -r * .38),
        width: r * .48,
        height: r * .25,
      ),
      Paint()..color = Colors.white.withValues(alpha: .34),
    );
  }

  void paint(Canvas canvas, Size size) {
    final Offset c = Offset(size.width / 2, size.height / 2);
    final double r = math.min(size.width, size.height) / 2;
    final Paint shadow = Paint()
      ..color = const Color(0x33000000)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3);
    canvas.drawOval(
      Rect.fromCenter(
        center: c + Offset(0, r * .12),
        width: r * 1.62,
        height: r * 1.58,
      ),
      shadow,
    );

    switch (type) {
      case 0:
        _drawChick(canvas, c, r);
        break;
      case 1:
        _drawFrog(canvas, c, r);
        break;
      case 2:
        _drawPenguin(canvas, c, r);
        break;
      case 3:
        _drawDog(canvas, c, r);
        break;
      default:
        _drawBunny(canvas, c, r);
    }
  }

  void _eyes(Canvas canvas, Offset c, double r, {double y = -.10}) {
    final Paint eye = Paint()..color = const Color(0xFF252525);
    canvas.drawCircle(c + Offset(-r * .25, r * y), r * .075, eye);
    canvas.drawCircle(c + Offset(r * .25, r * y), r * .075, eye);
    final Paint hi = Paint()..color = Colors.white.withValues(alpha: .9);
    canvas.drawCircle(c + Offset(-r * .225, r * (y - .025)), r * .018, hi);
    canvas.drawCircle(c + Offset(r * .275, r * (y - .025)), r * .018, hi);
  }

  void _blush(Canvas canvas, Offset c, double r) {
    final Paint paint = Paint()..color = const Color(0x55F38E9E);
    canvas.drawCircle(c + Offset(-r * .48, r * .13), r * .11, paint);
    canvas.drawCircle(c + Offset(r * .48, r * .13), r * .11, paint);
  }

  void _drawChick(Canvas canvas, Offset c, double r) {
    final Paint body = _gloss(
      const Color(0xFFFFF08A),
      const Color(0xFFFFC928),
      const Color(0xFFE79A00),
      c,
      r,
    );
    canvas.drawCircle(c, r * .82, body);
    _bodyShine(canvas, c, r);
    final Paint wing = Paint()..color = const Color(0xFFFFB51E);
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(-r * .66, r * .12), width: r * .28, height: r * .48),
      wing,
    );
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(r * .66, r * .12), width: r * .28, height: r * .48),
      wing,
    );
    _eyes(canvas, c, r);
    _blush(canvas, c, r);
    final Path beak = Path()
      ..moveTo(c.dx - r * .10, c.dy + r * .08)
      ..lineTo(c.dx + r * .12, c.dy + r * .08)
      ..lineTo(c.dx, c.dy + r * .20)
      ..close();
    canvas.drawPath(beak, Paint()..color = const Color(0xFFF18A18));
  }

  void _drawFrog(Canvas canvas, Offset c, double r) {
    final Paint body = _gloss(
      const Color(0xFFA6F3A9),
      const Color(0xFF63D46B),
      const Color(0xFF2C9A42),
      c,
      r,
    );
    final Paint deep = Paint()..color = const Color(0xFF25873A);
    canvas.drawCircle(c, r * .82, body);
    _bodyShine(canvas, c, r);
    canvas.drawCircle(c + Offset(-r * .42, -r * .55), r * .25, body);
    canvas.drawCircle(c + Offset(r * .42, -r * .55), r * .25, body);
    canvas.drawCircle(c + Offset(-r * .42, -r * .55), r * .11, Paint()..color = Colors.white);
    canvas.drawCircle(c + Offset(r * .42, -r * .55), r * .11, Paint()..color = Colors.white);
    canvas.drawCircle(c + Offset(-r * .42, -r * .55), r * .055, Paint()..color = const Color(0xFF1E2A25));
    canvas.drawCircle(c + Offset(r * .42, -r * .55), r * .055, Paint()..color = const Color(0xFF1E2A25));
    _blush(canvas, c, r);
    final Paint smile = Paint()
      ..color = deep.color
      ..style = PaintingStyle.stroke
      ..strokeWidth = math.max(1.8, r * .07)
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(
      Rect.fromCenter(center: c + Offset(0, r * .12), width: r * .60, height: r * .36),
      .15,
      math.pi - .30,
      false,
      smile,
    );
  }

  void _drawPenguin(Canvas canvas, Offset c, double r) {
    final Paint blue = _gloss(
      const Color(0xFF9DE1FF),
      const Color(0xFF4F9ED8),
      const Color(0xFF2464A8),
      c,
      r,
    );
    final Paint deepBlue = Paint()..color = const Color(0xFF2E6F9F);
    final Paint belly = Paint()..color = const Color(0xFFEAF6FF);
    canvas.drawCircle(c, r * .82, blue);
    _bodyShine(canvas, c, r);
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(0, r * .19), width: r * 1.00, height: r * 1.10),
      belly,
    );
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(-r * .62, r * .08), width: r * .22, height: r * .56),
      deepBlue,
    );
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(r * .62, r * .08), width: r * .22, height: r * .56),
      deepBlue,
    );
    _eyes(canvas, c + Offset(0, -r * .10), r, y: 0);
    final Path beak = Path()
      ..moveTo(c.dx - r * .10, c.dy + r * .01)
      ..lineTo(c.dx + r * .10, c.dy + r * .01)
      ..lineTo(c.dx, c.dy + r * .15)
      ..close();
    canvas.drawPath(beak, Paint()..color = const Color(0xFFFF9B2F));
  }

  void _drawDog(Canvas canvas, Offset c, double r) {
    final Paint ear = Paint()..color = const Color(0xFF7453B7);
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(-r * .62, -r * .18), width: r * .42, height: r * .72),
      ear,
    );
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(r * .62, -r * .18), width: r * .42, height: r * .72),
      ear,
    );
    canvas.drawCircle(
      c,
      r * .82,
      _gloss(
        const Color(0xFFE4D7FF),
        const Color(0xFFBFA8F2),
        const Color(0xFF8060C7),
        c,
        r,
      ),
    );
    _bodyShine(canvas, c, r);
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(r * .26, -r * .18), width: r * .36, height: r * .46),
      ear,
    );
    _eyes(canvas, c, r);
    _blush(canvas, c, r);
    canvas.drawCircle(c + Offset(0, r * .16), r * .09, Paint()..color = const Color(0xFF3E315A));
  }

  void _drawBunny(Canvas canvas, Offset c, double r) {
    final Paint body = _gloss(
      const Color(0xFFFFE2EE),
      const Color(0xFFFFA7C7),
      const Color(0xFFE66B9B),
      c,
      r,
    );
    final Paint inner = Paint()..color = const Color(0xFFFF6F9F);
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(-r * .28, -r * .86), width: r * .32, height: r * .88),
      body,
    );
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(r * .28, -r * .86), width: r * .32, height: r * .88),
      body,
    );
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(-r * .28, -r * .86), width: r * .11, height: r * .55),
      inner,
    );
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(r * .28, -r * .86), width: r * .11, height: r * .55),
      inner,
    );
    canvas.drawCircle(c + Offset(0, r * .04), r * .76, body);
    _bodyShine(canvas, c + Offset(0, r * .04), r * .92);
    _eyes(canvas, c + Offset(0, r * .02), r);
    _blush(canvas, c, r);
    canvas.drawCircle(c + Offset(0, r * .16), r * .06, Paint()..color = const Color(0xFF8C3F61));
  }
}

// V52: 5v5 front/back formation, half-size characters, bottom controls, visible attack FX.
