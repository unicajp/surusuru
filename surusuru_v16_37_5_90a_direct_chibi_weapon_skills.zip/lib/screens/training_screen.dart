import 'package:flutter/material.dart';
import '../game/game_controller.dart';
import '../sfx_manager.dart';
import '../widgets/game_bottom_nav.dart';
import 'rpg_home_screen.dart';
import 'shop_screen.dart';
import 'stage_map_screen.dart';
import 'surusuru_play_screen.dart';

class TrainingScreen extends StatelessWidget {
  final GameController controller;
  const TrainingScreen({super.key, required this.controller});

  void _replace(BuildContext context, Widget screen) {
    SfxManager.instance.tap();
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => screen));
  }

  @override
  Widget build(BuildContext context) {
    const weapons = [
      ('🗡️', 'ぷにブレード', '直線なぞり', 'Lv.1', .28),
      ('⛓️', 'ぐるぐるチェーン', '円なぞり', 'Lv.1', .48),
      ('⚡', 'ビリビリロッド', 'ジグザグ', 'Lv.1', .18),
    ];
    const skills = [
      ('○', 'ぐるぐる斬り', '円を閉じると周囲を一掃'),
      ('⚡', 'ジグザグ連撃', '切り返すほど連撃アップ'),
      ('➜', 'スラッシュ', '長く速く振るほど威力アップ'),
    ];
    return Scaffold(
      backgroundColor: const Color(0xFFF5F0E6),
      body: SafeArea(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
            child: Row(children: [
              const Text('⚒️', style: TextStyle(fontSize: 27)),
              const SizedBox(width: 8),
              const Text('武器・スキル育成', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: Color(0xFF3E3229))),
              const Spacer(),
              Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)),
                child: const Text('装備 1 / 3', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900)),
              ),
            ]),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(12, 4, 12, 18),
              children: [
                const Text('武器', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                const SizedBox(height: 7),
                ...weapons.map((w) => Card(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Row(children: [
                      Text(w.$1, style: const TextStyle(fontSize: 36)),
                      const SizedBox(width: 12),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(w.$2, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                        Text('${w.$3}  ・  ${w.$4}', style: const TextStyle(color: Color(0xFF786B61), fontSize: 12)),
                        const SizedBox(height: 6),
                        LinearProgressIndicator(value: w.$5, minHeight: 6, borderRadius: BorderRadius.circular(9)),
                      ])),
                      FilledButton.tonal(onPressed: SfxManager.instance.tap, child: const Text('強化')),
                    ]),
                  ),
                )),
                const SizedBox(height: 14),
                const Text('なぞりスキル', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                const SizedBox(height: 7),
                ...skills.map((s) => Card(
                  child: ListTile(
                    leading: CircleAvatar(child: Text(s.$1)),
                    title: Text(s.$2, style: const TextStyle(fontWeight: FontWeight.w900)),
                    subtitle: Text(s.$3),
                    trailing: const Text('習得済', style: TextStyle(color: Color(0xFF4B9A63), fontWeight: FontWeight.w900)),
                  ),
                )),
              ],
            ),
          ),
          GameBottomNav(
            active: 'training',
            onAdventure: () => _replace(context, StageMapScreen(controller: controller)),
            onShop: () => _replace(context, ShopScreen(controller: controller)),
            onSurusuru: () => _replace(context, SurusuruPlayScreen(controller: controller)),
            onTraining: () {},
            onMap: () => _replace(context, RpgHomeScreen(controller: controller)),
          ),
        ]),
      ),
    );
  }
}
