import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../game/game_controller.dart';

class ConnectBattleScreen extends StatefulWidget {
  final GameController controller;
  final int stageId;

  const ConnectBattleScreen({
    super.key,
    required this.controller,
    required this.stageId,
  });

  @override
  State<ConnectBattleScreen> createState() => _ConnectBattleScreenState();
}

class _DummyEnemy {
  _DummyEnemy(this.pos, this.phase);
  Offset pos;
  final double phase;
}

class _ConnectBattleScreenState extends State<ConnectBattleScreen> {
  Timer? _timer;
  DateTime _last = DateTime.now();
  Size _field = Size.zero;

  Offset _hero = const Offset(190, 360);
  Offset _velocity = Offset.zero;
  Offset _target = const Offset(190, 360);
  bool _holding = false;
  double _time = 0;
  double _tilt = 0;
  final List<Offset> _trail = <Offset>[];
  final List<_DummyEnemy> _enemies = <_DummyEnemy>[];

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(milliseconds: 16), (_) => _tick());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _seed(Size size) {
    if (_field != Size.zero) return;
    _field = size;
    _hero = Offset(size.width * .5, size.height * .72);
    _target = _hero;
    _enemies.addAll(<_DummyEnemy>[
      _DummyEnemy(Offset(size.width * .22, size.height * .28), .2),
      _DummyEnemy(Offset(size.width * .50, size.height * .20), 1.5),
      _DummyEnemy(Offset(size.width * .78, size.height * .31), 2.8),
    ]);
  }

  void _tick() {
    if (!mounted || _field == Size.zero) return;
    final now = DateTime.now();
    double dt = now.difference(_last).inMicroseconds / 1000000;
    _last = now;
    dt = dt.clamp(0.0, .035);
    _time += dt;

    // Spring-like follow: the finger is a target, not the character position.
    final Offset delta = _target - _hero;
    final double spring = _holding ? 28.0 : 12.0;
    final double damping = _holding ? 8.2 : 6.8;
    _velocity += delta * spring * dt;
    _velocity *= math.exp(-damping * dt);

    // Keep enough inertia to overshoot on sudden stops, but cap extreme speed.
    final double speed = _velocity.distance;
    if (speed > 1050) _velocity = _velocity / speed * 1050;
    _hero += _velocity * dt;
    _hero = Offset(
      _hero.dx.clamp(38.0, _field.width - 38.0),
      _hero.dy.clamp(54.0, _field.height - 48.0),
    );

    final double wantedTilt = (_velocity.dx / 520).clamp(-.34, .34);
    _tilt += (wantedTilt - _tilt) * math.min(1, dt * 10);

    if (_velocity.distance > 90) {
      _trail.insert(0, _hero);
      if (_trail.length > 8) _trail.removeLast();
    } else if (_trail.isNotEmpty && (_time * 30).floor().isEven) {
      _trail.removeLast();
    }
    setState(() {});
  }

  void _down(Offset p) {
    setState(() {
      _holding = true;
      _target = p;
    });
  }

  void _move(Offset p) {
    _holding = true;
    _target = p;
  }

  void _up() {
    // On release, stop pulling. The target becomes the current position so
    // residual velocity produces a tiny natural overshoot before settling.
    _holding = false;
    _target = _hero;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF122433),
      body: SafeArea(
        child: Column(
          children: <Widget>[
            SizedBox(
              height: 64,
              child: Row(
                children: <Widget>[
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    '冒険  STAGE ${widget.stageId}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const Spacer(),
                  const Padding(
                    padding: EdgeInsets.only(right: 18),
                    child: Text(
                      '操作テスト',
                      style: TextStyle(
                        color: Color(0xFFFFD978),
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: LayoutBuilder(
                builder: (context, c) {
                  final size = Size(c.maxWidth, c.maxHeight);
                  _seed(size);
                  return Listener(
                    behavior: HitTestBehavior.opaque,
                    onPointerDown: (e) => _down(e.localPosition),
                    onPointerMove: (e) => _move(e.localPosition),
                    onPointerUp: (_) => _up(),
                    onPointerCancel: (_) => _up(),
                    child: CustomPaint(
                      size: Size.infinite,
                      painter: _BattlePrototypePainter(
                        hero: _hero,
                        velocity: _velocity,
                        tilt: _tilt,
                        time: _time,
                        holding: _holding,
                        target: _target,
                        trail: _trail,
                        enemies: _enemies,
                      ),
                    ),
                  );
                },
              ),
            ),
            Container(
              height: 58,
              alignment: Alignment.center,
              color: const Color(0xFF0D1C28),
              child: const Text(
                '指で動かして、剣士の重さと追従感を確認',
                style: TextStyle(
                  color: Colors.white70,
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BattlePrototypePainter extends CustomPainter {
  const _BattlePrototypePainter({
    required this.hero,
    required this.velocity,
    required this.tilt,
    required this.time,
    required this.holding,
    required this.target,
    required this.trail,
    required this.enemies,
  });

  final Offset hero;
  final Offset velocity;
  final double tilt;
  final double time;
  final bool holding;
  final Offset target;
  final List<Offset> trail;
  final List<_DummyEnemy> enemies;

  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()..color = const Color(0xFFF3EFD7);
    canvas.drawRect(Offset.zero & size, bg);

    // Subtle battlefield rings keep depth without looking like a puzzle board.
    final ring = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..color = const Color(0xFF8DB58C).withValues(alpha: .14);
    for (double r = 90; r < size.width * .85; r += 82) {
      canvas.drawCircle(Offset(size.width / 2, size.height * .48), r, ring);
    }

    for (final e in enemies) {
      _drawMonster(canvas, e.pos + Offset(0, math.sin(time * 2 + e.phase) * 3));
    }

    final speed = velocity.distance;
    if (speed > 220) {
      for (var i = trail.length - 1; i >= 0; i--) {
        final alpha = (1 - i / math.max(1, trail.length)) * .10;
        _drawHero(canvas, trail[i], tilt, time, alpha: alpha, ghost: true);
      }
    }

    if (holding) {
      canvas.drawCircle(
        target,
        16,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..color = Colors.white.withValues(alpha: .16),
      );
    }

    _drawHero(canvas, hero, tilt, time, alpha: 1);
  }

  void _drawHero(
    Canvas canvas,
    Offset p,
    double lean,
    double t, {
    required double alpha,
    bool ghost = false,
  }) {
    canvas.save();

    final speed = velocity.distance;
    final moveRatio = (speed / 420).clamp(0.0, 1.0).toDouble();
    final facing = (velocity.dx / 320).clamp(-1.0, 1.0).toDouble();
    final sideTurn = facing.abs();
    final stepPhase = t * (7.0 + moveRatio * 5.0);
    final stride = ghost ? 0.0 : math.sin(stepPhase) * 2.8 * moveRatio;
    final bob = ghost ? 0.0 : math.sin(stepPhase * 2) * 1.4 * moveRatio;
    final bodyLean = lean * .55 + facing * .035 * moveRatio;

    canvas.translate(p.dx, p.dy + bob);
    canvas.rotate(bodyLean);
    canvas.scale(1.10, 1.10);

    Color c(Color color, [double mul = 1]) =>
        color.withValues(alpha: (alpha * mul).clamp(0.0, 1.0));

    final outline = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.8
      ..strokeJoin = StrokeJoin.round
      ..strokeCap = StrokeCap.round
      ..color = c(const Color(0xFF55465F), .66);

    canvas.drawOval(
      Rect.fromCenter(center: const Offset(0, 31), width: 46, height: 10),
      Paint()..color = const Color(0xFF6A6857).withValues(alpha: alpha * .16),
    );

    // Soft skirt/cape silhouette first so the whole body clearly reads as rear view.
    final skirt = Path()
      ..moveTo(-15, 4)
      ..quadraticBezierTo(-19, 16, -18, 23)
      ..quadraticBezierTo(0, 29, 18, 23)
      ..quadraticBezierTo(19, 16, 15, 4)
      ..close();
    canvas.drawPath(skirt, Paint()..color = c(const Color(0xFF6F79B8)));
    canvas.drawPath(skirt, outline);

    // Legs and boots: short, rounded and slightly animated for a cute 3-head-tall look.
    void leg(double x, double dy, bool near) {
      final legPaint = Paint()
        ..color = c(near ? const Color(0xFFF3D7C7) : const Color(0xFFE9C9B8));
      final rr = RRect.fromRectAndRadius(
        Rect.fromLTWH(x - 4.2, 19 + dy, 8.4, 12),
        const Radius.circular(4),
      );
      canvas.drawRRect(rr, legPaint);
      canvas.drawRRect(rr, outline);
      final boot = RRect.fromRectAndRadius(
        Rect.fromLTWH(x - 6.5, 27 + dy, 13, 7),
        const Radius.circular(4),
      );
      canvas.drawRRect(boot, Paint()..color = c(const Color(0xFF7A5A72)));
      canvas.drawRRect(boot, outline);
    }
    leg(-7.5, stride, facing <= 0);
    leg(7.5, -stride, facing >= 0);

    // Torso is deliberately symmetric from the back. Horizontal movement shifts
    // the whole torso together with the head instead of twisting only the head.
    canvas.save();
    canvas.translate(facing * 2.8, 0);
    canvas.rotate(facing * .055 * sideTurn);
    final torso = Path()
      ..moveTo(-14, -14)
      ..quadraticBezierTo(-19, -10, -18, -3)
      ..lineTo(-14, 13)
      ..quadraticBezierTo(0, 18, 14, 13)
      ..lineTo(18, -3)
      ..quadraticBezierTo(19, -10, 14, -14)
      ..quadraticBezierTo(0, -19, -14, -14)
      ..close();
    canvas.drawPath(torso, Paint()..color = c(const Color(0xFF7EA6D8)));
    canvas.drawPath(torso, outline);

    // Rear sailor-like collar and small ribbon make the silhouette feminine
    // without needing an image asset or front-facing facial details.
    final collar = Path()
      ..moveTo(-12, -13)
      ..lineTo(0, -4)
      ..lineTo(12, -13)
      ..lineTo(9, -17)
      ..lineTo(0, -10)
      ..lineTo(-9, -17)
      ..close();
    canvas.drawPath(collar, Paint()..color = c(const Color(0xFFF6F4FA)));
    canvas.drawPath(collar, outline);
    canvas.drawCircle(const Offset(0, 7), 3.6, Paint()..color = c(const Color(0xFFF0B5C8)));
    canvas.restore();

    // Arms follow the same rear/three-quarter turn as the torso.
    final armSwing = ghost ? 0.0 : math.sin(stepPhase) * .10 * moveRatio;
    final skin = const Color(0xFFF2C7AF);
    canvas.save();
    canvas.translate(-15 + facing * 2.2, -7);
    canvas.rotate(-.08 - armSwing * .55 + facing * .035);
    final armL = RRect.fromRectAndRadius(
      const Rect.fromLTWH(-4.5, 0, 9, 22),
      const Radius.circular(5),
    );
    canvas.drawRRect(armL, Paint()..color = c(const Color(0xFF7197C8)));
    canvas.drawRRect(armL, outline);
    canvas.drawCircle(const Offset(0, 21), 4.5, Paint()..color = c(skin));
    canvas.restore();

    canvas.save();
    canvas.translate(15 + facing * 3.0, -7);
    canvas.rotate(.10 + armSwing * .45 + facing * .025);
    final armR = RRect.fromRectAndRadius(
      const Rect.fromLTWH(-4.5, 0, 9, 22),
      const Radius.circular(5),
    );
    canvas.drawRRect(armR, Paint()..color = c(const Color(0xFF86ADDB)));
    canvas.drawRRect(armR, outline);
    canvas.drawCircle(const Offset(0, 21), 4.7, Paint()..color = c(skin));
    canvas.restore();

    // Sword lives completely to the character's right side. The grip starts at
    // the right hand and the blade extends outward/upward, so it never crosses
    // through the torso. Motion adds a small springy lag rather than a fixed angle.
    final swordLag = ((-velocity.dy - velocity.dx * .10) / 1800)
        .clamp(-.10, .10)
        .toDouble();
    final swordBounce = ghost ? 0.0 : math.sin(stepPhase * .88) * .055 * moveRatio;
    final swordAngle = (-.72 + swordLag + swordBounce).clamp(-.86, -.54).toDouble();
    canvas.save();
    canvas.translate(23 + facing * 3.2, 12);
    canvas.rotate(swordAngle);
    final blade = Path()
      ..moveTo(-3.8, -3)
      ..lineTo(3.8, -3)
      ..lineTo(4.8, -48)
      ..lineTo(0, -61)
      ..lineTo(-4.8, -48)
      ..close();
    canvas.drawPath(blade, Paint()..color = c(const Color(0xFFF7FBFF)));
    canvas.drawPath(blade, outline);
    canvas.drawLine(
      const Offset(0, -8),
      const Offset(0, -50),
      Paint()
        ..strokeWidth = 1.2
        ..color = c(const Color(0xFFB9D2E3)),
    );
    final guard = RRect.fromRectAndRadius(
      const Rect.fromLTWH(-11, -5, 22, 5),
      const Radius.circular(3),
    );
    canvas.drawRRect(guard, Paint()..color = c(const Color(0xFFF1C562)));
    canvas.drawRRect(guard, outline);
    final grip = RRect.fromRectAndRadius(
      const Rect.fromLTWH(-3, 1, 6, 15),
      const Radius.circular(3),
    );
    canvas.drawRRect(grip, Paint()..color = c(const Color(0xFF875A68)));
    canvas.drawRRect(grip, outline);
    canvas.drawCircle(const Offset(0, 18), 3.8, Paint()..color = c(const Color(0xFFF1C562)));
    canvas.restore();

    // Head: cute large rear silhouette with a high ponytail. The entire head,
    // hair and torso turn together to the left/right while remaining back-facing.
    canvas.save();
    canvas.translate(facing * 3.0, -1);
    canvas.rotate(facing * .055 * sideTurn);

    canvas.drawCircle(
      const Offset(0, -28),
      18.8,
      Paint()..color = c(skin),
    );

    final ponyAnchorX = -11.5 - facing * 1.2;
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(ponyAnchorX, -19),
        width: 13 + sideTurn * 2,
        height: 23,
      ),
      Paint()..color = c(const Color(0xFF5A4056)),
    );
    final ribbon = Path()
      ..moveTo(ponyAnchorX - 1, -28)
      ..lineTo(ponyAnchorX - 9, -23)
      ..lineTo(ponyAnchorX - 7, -33)
      ..close()
      ..moveTo(ponyAnchorX + 1, -28)
      ..lineTo(ponyAnchorX + 8, -22)
      ..lineTo(ponyAnchorX + 7, -33)
      ..close();
    canvas.drawPath(ribbon, Paint()..color = c(const Color(0xFFE98DA9)));

    final hair = Path()
      ..moveTo(-19, -29)
      ..quadraticBezierTo(-18, -45, -8, -51)
      ..quadraticBezierTo(0, -56, 10, -50)
      ..quadraticBezierTo(19, -44, 19, -29)
      ..lineTo(17, -14)
      ..quadraticBezierTo(13, -8, 9, -14)
      ..lineTo(5, -9)
      ..lineTo(0, -15)
      ..lineTo(-5, -9)
      ..lineTo(-10, -15)
      ..quadraticBezierTo(-14, -9, -18, -15)
      ..close();
    canvas.drawPath(hair, Paint()..color = c(const Color(0xFF5A4056)));
    canvas.drawPath(hair, outline);

    final shine = Path()
      ..moveTo(-9, -45)
      ..quadraticBezierTo(-2, -51, 8, -47);
    canvas.drawPath(
      shine,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.0
        ..strokeCap = StrokeCap.round
        ..color = c(const Color(0xFF82667E), .72),
    );

    if (sideTurn > .18) {
      final side = facing.sign;
      canvas.drawOval(
        Rect.fromCenter(center: Offset(side * 17.0, -27), width: 4.8, height: 7.0),
        Paint()..color = c(const Color(0xFFE9B69F)),
      );
      // A tiny side fringe appears only on the turning side, keeping the face hidden.
      final fringe = Path()
        ..moveTo(side * 13, -42)
        ..quadraticBezierTo(side * 20, -35, side * 16, -24)
        ..quadraticBezierTo(side * 12, -30, side * 11, -38)
        ..close();
      canvas.drawPath(fringe, Paint()..color = c(const Color(0xFF5A4056)));
    }
    canvas.restore();

    canvas.restore();
  }

  void _drawMonster(Canvas canvas, Offset p) {
    canvas.save();
    canvas.translate(p.dx, p.dy);
    canvas.drawOval(
      const Rect.fromLTWH(-20, 18, 40, 8),
      Paint()..color = const Color(0xFF6E795F).withValues(alpha: .12),
    );

    // Friendly-looking training monster so the prototype arena feels bright,
    // while still being visually distinct from the old round puzzle characters.
    final body = Path()
      ..moveTo(-22, 17)
      ..quadraticBezierTo(-24, -7, -11, -17)
      ..lineTo(-14, -26)
      ..lineTo(-3, -20)
      ..quadraticBezierTo(0, -22, 3, -20)
      ..lineTo(14, -26)
      ..lineTo(11, -16)
      ..quadraticBezierTo(24, -5, 22, 17)
      ..quadraticBezierTo(0, 27, -22, 17)
      ..close();
    canvas.drawPath(body, Paint()..color = const Color(0xFFB9A5DC));
    canvas.drawPath(
      body,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.8
        ..color = const Color(0xFF806BA9),
    );
    canvas.drawCircle(const Offset(-7, -4), 3.4, Paint()..color = const Color(0xFFFFFBF2));
    canvas.drawCircle(const Offset(7, -4), 3.4, Paint()..color = const Color(0xFFFFFBF2));
    canvas.drawCircle(const Offset(-7, -4), 1.4, Paint()..color = const Color(0xFF655A75));
    canvas.drawCircle(const Offset(7, -4), 1.4, Paint()..color = const Color(0xFF655A75));
    canvas.drawArc(
      const Rect.fromLTWH(-7, 2, 14, 9),
      .15,
      math.pi - .3,
      false,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.7
        ..strokeCap = StrokeCap.round
        ..color = const Color(0xFF745F87),
    );
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _BattlePrototypePainter oldDelegate) => true;
}
