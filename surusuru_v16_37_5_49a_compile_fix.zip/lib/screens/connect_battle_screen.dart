import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../game/game_controller.dart';

enum _Role { attacker, tank, support }
class _Unit {
  _Unit(this.pos,this.emoji,this.role,{required this.ally});
  Offset pos; Offset vel=Offset.zero; final String emoji; final _Role role; final bool ally;
  int hp=100; int? target; double cooldown=0; double flash=0;
}

class ConnectBattleScreen extends StatefulWidget {
  final GameController controller; final int stageId;
  const ConnectBattleScreen({super.key,required this.controller,required this.stageId});
  @override State<ConnectBattleScreen> createState()=>_ConnectBattleScreenState();
}

class _ConnectBattleScreenState extends State<ConnectBattleScreen> {
  final r=math.Random(); final allies=<_Unit>[]; final enemies=<_Unit>[];
  Timer? timer; DateTime last=DateTime.now(); int? dragAlly; Offset? finger;
  bool auto=false, finished=false; int speed=1; Size field=Size.zero;
  @override void initState(){super.initState();timer=Timer.periodic(const Duration(milliseconds:33),(_)=>_tick());}
  @override void dispose(){timer?.cancel();super.dispose();}
  void _seed(Size s){if(allies.isNotEmpty)return;field=s;
    allies.addAll([_Unit(Offset(s.width*.18,s.height*.28),'🐥',_Role.attacker,ally:true),_Unit(Offset(s.width*.15,s.height*.55),'🐼',_Role.tank,ally:true),_Unit(Offset(s.width*.22,s.height*.78),'🐰',_Role.support,ally:true)]);
    enemies.addAll([_Unit(Offset(s.width*.76,s.height*.25),'👾',_Role.attacker,ally:false),_Unit(Offset(s.width*.82,s.height*.52),'👹',_Role.attacker,ally:false),_Unit(Offset(s.width*.73,s.height*.78),'🦇',_Role.attacker,ally:false)]);
  }
  void _tick(){if(!mounted||finished||field==Size.zero)return; final now=DateTime.now();var dt=now.difference(last).inMilliseconds/1000;last=now;dt=math.min(.08,dt)*speed;
    for(var k=0;k<(speed==4?2:1);k++)_step(dt/(speed==4?2:1)); if(mounted)setState((){});
  }
  void _step(double dt){
    if(auto) _autoTargets();
    for(var i=0;i<allies.length;i++) _moveAlly(i,dt);
    for(var i=0;i<enemies.length;i++) _moveEnemy(i,dt);
    if(enemies.every((e)=>e.hp<=0)) _win();
    if(allies.every((e)=>e.hp<=0)){finished=true;}
  }
  Offset _wander(_Unit u,double dt,bool left){final cx=left?field.width*.28:field.width*.72; final cy=field.height*.52; final to=Offset(cx,cy)-u.pos; final jitter=Offset((r.nextDouble()-.5)*16,(r.nextDouble()-.5)*16);u.vel=(u.vel*.94)+(to*.003)+jitter*dt;return u.vel;}
  void _moveAlly(int i,double dt){final u=allies[i];if(u.hp<=0)return;u.cooldown=math.max(0,u.cooldown-dt);u.flash=math.max(0,u.flash-dt);
    Offset? goal; bool support=u.role==_Role.support;
    if(u.target!=null){if(support){if(u.target!<allies.length&&allies[u.target!].hp>0)goal=allies[u.target!].pos;else u.target=null;}else{if(u.target!<enemies.length&&enemies[u.target!].hp>0)goal=enemies[u.target!].pos;else u.target=null;}}
    if(goal==null){u.pos+=_wander(u,dt,true)*dt;_clamp(u,true);return;}
    final d=(goal-u.pos).distance;final range=support?62.0:46.0;
    if(d>range){final dir=(goal-u.pos)/d;u.pos+=dir*(52.0+(u.role==_Role.attacker?8:0))*dt;}
    else if(u.cooldown<=0){u.cooldown=support?1.25:.85;if(support){final t=allies[u.target!];t.hp=math.min(100,t.hp+18);t.flash=.25;}else{final t=enemies[u.target!];t.hp=math.max(0,t.hp-(u.role==_Role.tank?12:22));t.flash=.18;}}
    _clamp(u,true);
  }
  void _moveEnemy(int i,double dt){final u=enemies[i];if(u.hp<=0)return;u.cooldown=math.max(0,u.cooldown-dt);u.flash=math.max(0,u.flash-dt);int best=-1;double bd=1e9;for(var j=0;j<allies.length;j++){if(allies[j].hp<=0)continue;final d=(allies[j].pos-u.pos).distance;if(d<bd){bd=d;best=j;}}
    if(best<0)return;final goal=allies[best].pos;if(bd>48){u.pos+=(goal-u.pos)/bd*43*dt;}else if(u.cooldown<=0){u.cooldown=1.15;allies[best].hp=math.max(0,allies[best].hp-9);allies[best].flash=.18;}_clamp(u,false);
  }
  void _clamp(_Unit u,bool left){u.pos=Offset(u.pos.dx.clamp(24.0,field.width-24),u.pos.dy.clamp(35.0,field.height-25));}
  void _autoTargets(){for(var i=0;i<allies.length;i++){final u=allies[i];if(u.hp<=0)continue;if(u.role==_Role.support){int best=-1,h=101;for(var j=0;j<allies.length;j++){if(i!=j&&allies[j].hp>0&&allies[j].hp<h){h=allies[j].hp;best=j;}}u.target=best<0?null:best;}else if(u.target==null||u.target!>=enemies.length||enemies[u.target!].hp<=0){for(var j=0;j<enemies.length;j++)if(enemies[j].hp>0){u.target=j;break;}}}}
  Future<void> _win()async{if(finished)return;finished=true;timer?.cancel();await widget.controller.completeRpgStage(widget.stageId);if(!mounted)return;await showDialog(context:context,builder:(c)=>AlertDialog(title:const Text('勝利！ 🎉'),content:const Text('敵をすべて倒しました！'),actions:[FilledButton(onPressed:()=>Navigator.pop(c),child:const Text('OK'))]));if(mounted)Navigator.pop(context);}
  void _resultMode(){if(finished)return;setState(()=>speed=4);auto=true;}
  void _start(DragStartDetails d){int best=-1;double bd=45;for(var i=0;i<allies.length;i++){if(allies[i].hp<=0)continue;final x=(allies[i].pos-d.localPosition).distance;if(x<bd){bd=x;best=i;}}if(best>=0){dragAlly=best;finger=d.localPosition;setState((){});}}
  void _move(DragUpdateDetails d){if(dragAlly!=null){finger=d.localPosition;setState((){});}}
  void _end(DragEndDetails d){if(dragAlly==null)return;final a=allies[dragAlly!];int best=-1;double bd=52;if(a.role==_Role.support){for(var i=0;i<allies.length;i++){if(i==dragAlly||allies[i].hp<=0)continue;final x=(allies[i].pos-(finger??Offset.zero)).distance;if(x<bd){bd=x;best=i;}}}else{for(var i=0;i<enemies.length;i++){if(enemies[i].hp<=0)continue;final x=(enemies[i].pos-(finger??Offset.zero)).distance;if(x<bd){bd=x;best=i;}}}if(best>=0)a.target=best;dragAlly=null;finger=null;setState((){});}
  @override Widget build(BuildContext context)=>Scaffold(backgroundColor:const Color(0xFF182638),body:SafeArea(child:Column(children:[
    Padding(padding:const EdgeInsets.fromLTRB(6,4,10,4),child:Row(children:[IconButton(onPressed:()=>Navigator.pop(context),icon:const Icon(Icons.arrow_back,color:Colors.white)),Text('冒険  STAGE ${widget.stageId}',style:const TextStyle(color:Colors.white,fontWeight:FontWeight.w900,fontSize:18)),const Spacer(),_modeButton('AUTO',auto,(){setState(()=>auto=!auto);}),const SizedBox(width:5),_modeButton(speed==2?'×2':'倍速',speed==2,(){setState(()=>speed=speed==2?1:2);}),const SizedBox(width:5),_modeButton('結果',speed==4,_resultMode)])),
    const Padding(padding:EdgeInsets.only(bottom:3),child:Text('味方からドラッグしてつなぐ　💚サポートは味方へ',style:TextStyle(color:Color(0xFFFFE18A),fontWeight:FontWeight.w800,fontSize:12))),
    Expanded(child:LayoutBuilder(builder:(c,b){final s=Size(b.maxWidth,b.maxHeight);field=s;_seed(s);return GestureDetector(behavior:HitTestBehavior.opaque,onPanStart:_start,onPanUpdate:_move,onPanEnd:_end,child:CustomPaint(size:s,painter:_FieldPainter(allies,enemies,dragAlly,finger,auto)));}))
  ])));
  Widget _modeButton(String text,bool on,VoidCallback tap)=>SizedBox(height:34,child:FilledButton.tonal(onPressed:tap,style:FilledButton.styleFrom(padding:const EdgeInsets.symmetric(horizontal:10),backgroundColor:on?const Color(0xFFFFD85A):Colors.white12,foregroundColor:on?Colors.black:Colors.white),child:Text(text,style:const TextStyle(fontWeight:FontWeight.w900,fontSize:12))));
}

class _FieldPainter extends CustomPainter{
 final List<_Unit>a,e;final int?drag;final Offset?finger;final bool auto;
 _FieldPainter(this.a,this.e,this.drag,this.finger,this.auto);
 @override void paint(Canvas c,Size s){
  final bg=Paint()..shader=const LinearGradient(begin:Alignment.topCenter,end:Alignment.bottomCenter,colors:[Color(0xFF27415B),Color(0xFF172C35)]).createShader(Offset.zero&s);c.drawRect(Offset.zero&s,bg);
  c.drawOval(Rect.fromCenter(center:Offset(s.width*.5,s.height*.55),width:s.width*.92,height:s.height*.75),Paint()..color=const Color(0x2237C78B));
  final line=Paint()..strokeWidth=2.3..strokeCap=StrokeCap.round;
  for(var i=0;i<a.length;i++){final u=a[i];if(u.hp<=0||u.target==null)continue;Offset? q;if(u.role==_Role.support){if(u.target!<a.length)q=a[u.target!].pos;line.color=const Color(0xAA70F0A5);}else{if(u.target!<e.length)q=e[u.target!].pos;line.color=const Color(0x99FFD86B);}if(q!=null)c.drawLine(u.pos,q,line);}
  if(drag!=null&&finger!=null){line.color=a[drag!].role==_Role.support?const Color(0xFF79F5A9):const Color(0xFFFFE06A);line.strokeWidth=5;c.drawLine(a[drag!].pos,finger!,line);}
  for(var i=0;i<e.length;i++)_unit(c,e[i],false);for(var i=0;i<a.length;i++)_unit(c,a[i],true);
  _label(c,'味方',Offset(18,12),const Color(0xFF8DE7FF));_label(c,'敵',Offset(s.width-48,12),const Color(0xFFFF8D9E));
 }
 void _unit(Canvas c,_Unit u,bool ally){if(u.hp<=0)return;final shadow=Paint()..color=Colors.black26;c.drawOval(Rect.fromCenter(center:u.pos+const Offset(0,18),width:42,height:13),shadow);if(u.flash>0)c.drawCircle(u.pos,30,Paint()..color=Colors.white.withValues(alpha:.5));final tp=TextPainter(text:TextSpan(text:u.emoji,style:const TextStyle(fontSize:35)),textDirection:TextDirection.ltr)..layout();tp.paint(c,u.pos-Offset(tp.width/2,tp.height/2+3));
  final rect=Rect.fromLTWH(u.pos.dx-24,u.pos.dy-31,48,5);c.drawRRect(RRect.fromRectAndRadius(rect,const Radius.circular(4)),Paint()..color=Colors.black45);c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(rect.left,rect.top,48*u.hp/100,5),const Radius.circular(4)),Paint()..color=ally?const Color(0xFF62E58C):const Color(0xFFFF6678));
  if(ally){final mark=u.role==_Role.support?'SUP':u.role==_Role.tank?'DEF':'ATK';_label(c,mark,u.pos+const Offset(-13,24),u.role==_Role.support?const Color(0xFF86F0AD):Colors.white70,9);}
 }
 void _label(Canvas c,String x,Offset p,Color color,[double fs=12]){final t=TextPainter(text:TextSpan(text:x,style:TextStyle(color:color,fontSize:fs,fontWeight:FontWeight.w900)),textDirection:TextDirection.ltr)..layout();t.paint(c,p);}
 @override bool shouldRepaint(covariant CustomPainter oldDelegate)=>true;
}
