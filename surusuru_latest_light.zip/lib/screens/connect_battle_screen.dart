import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../game/game_controller.dart';
import '../sfx_manager.dart';

enum _Element { ice, fire, wind, thunder }
enum _ThingKind { grass, pot, crate, vine, rock, switchPad, torch }

class _Thing {
  _Thing(this.p, this.kind, {this.hp = 1, this.active = false});
  Offset p;
  final _ThingKind kind;
  int hp;
  bool active;
  double flash = 0;

  bool get solid =>
      kind == _ThingKind.crate ||
      kind == _ThingKind.pot ||
      kind == _ThingKind.rock ||
      kind == _ThingKind.vine;

  double get radius => switch (kind) {
        _ThingKind.crate => 35,
        _ThingKind.rock => 42,
        _ThingKind.vine => 34,
        _ThingKind.pot => 25,
        _ => 24,
      };
}

class _Ice {
  _Ice(this.p);
  Offset p;
  Offset v = Offset.zero;
}

class _MagicFx {
  _MagicFx(this.from, this.to, this.e);
  final Offset from, to;
  final _Element e;
  double life = 1;
}

class ConnectBattleScreen extends StatefulWidget {
  final GameController controller;
  final int stageId;
  const ConnectBattleScreen({
    super.key,
    required this.controller,
    required this.stageId,
  });

  @override
  State<ConnectBattleScreen> createState() => _S();
}

class _S extends State<ConnectBattleScreen> {
  static const world = Size(2400, 1900);
  Timer? timer;
  DateTime last = DateTime.now();
  Size view = Size.zero;

  Offset hero = const Offset(330, 1450);
  Offset target = const Offset(330, 1450);
  Offset vel = Offset.zero;
  Offset pointerV = Offset.zero;
  Offset lastPointer = Offset.zero;

  Offset cameraPos = Offset.zero;
  bool cameraReady = false;

  int lastMs = 0;
  bool holding = false;
  bool faceRight = true;
  bool vertical = false;
  bool up = false;
  bool attack = false;
  double attackT = 0;
  double t = 0;
  double shake = 0;

  _Element selected = _Element.ice;
  bool castMode = false;
  _Ice? requestedIce;
  _Ice? carriedIce;
  String notice = '属性ボタンを押すと使い方が表示されます';
  double noticeT = 4;

  final things = <_Thing>[];
  final ices = <_Ice>[];
  final fx = <_MagicFx>[];

  @override
  void initState() {
    super.initState();
    _seed();
    timer = Timer.periodic(const Duration(milliseconds: 16), (_) => _tick());
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  void _seed() {
    final data = <(_ThingKind, double, double, int)>[
      (_ThingKind.grass, 430, 1430, 1),
      (_ThingKind.grass, 470, 1400, 1),
      (_ThingKind.pot, 610, 1370, 2),
      (_ThingKind.crate, 760, 1450, 4),
      (_ThingKind.crate, 820, 1450, 4),
      (_ThingKind.vine, 1030, 1370, 3),
      (_ThingKind.vine, 1030, 1435, 3),
      (_ThingKind.vine, 1030, 1500, 3),
      (_ThingKind.rock, 520, 1060, 99),
      (_ThingKind.rock, 580, 1010, 99),
      (_ThingKind.torch, 780, 1040, 1),
      (_ThingKind.switchPad, 1190, 1180, 1),
      (_ThingKind.crate, 1450, 1040, 4),
      (_ThingKind.pot, 1530, 980, 2),
      (_ThingKind.grass, 1640, 920, 1),
      (_ThingKind.vine, 1740, 790, 3),
      (_ThingKind.rock, 1350, 620, 99),
      (_ThingKind.rock, 1420, 610, 99),
      (_ThingKind.torch, 1760, 520, 1),
      (_ThingKind.switchPad, 2030, 420, 1),
      (_ThingKind.crate, 2020, 900, 4),
      (_ThingKind.pot, 2150, 1060, 2),
      (_ThingKind.grass, 2050, 1420, 1),
      (_ThingKind.crate, 1800, 1510, 4),
    ];
    for (final d in data) {
      things.add(_Thing(Offset(d.$2, d.$3), d.$1, hp: d.$4));
    }
  }

  Offset get cam => cameraPos;
  Offset _w(Offset local) => local + cameraPos;

  void _ensureCamera() {
    if (cameraReady || view == Size.zero) return;
    cameraPos = Offset(
      (hero.dx - view.width * .42).clamp(0.0, math.max(0.0, world.width - view.width)),
      (hero.dy - view.height * .55).clamp(0.0, math.max(0.0, world.height - view.height)),
    );
    cameraReady = true;
  }

  void _updateCamera(double dt) {
    if (!cameraReady || view == Size.zero) return;

    // Hero is allowed to move around the screen first. The camera only follows
    // after crossing this soft zone, so swipes still feel fast and physical.
    final local = hero - cameraPos;
    var desired = cameraPos;
    // Medium dead-zone: not center-locked, but camera starts moving well
    // before the hero reaches the edge of the screen.
    final left = view.width * .36;
    final right = view.width * .64;
    final top = view.height * .34;
    final bottom = view.height * .66;

    if (local.dx < left) desired += Offset(local.dx - left, 0);
    if (local.dx > right) desired += Offset(local.dx - right, 0);
    if (local.dy < top) desired += Offset(0, local.dy - top);
    if (local.dy > bottom) desired += Offset(0, local.dy - bottom);

    desired = Offset(
      desired.dx.clamp(0.0, math.max(0.0, world.width - view.width)),
      desired.dy.clamp(0.0, math.max(0.0, world.height - view.height)),
    );

    var delta = desired - cameraPos;
    final maxStep = 520.0 * dt;
    if (delta.distance > maxStep && delta.distance > 0) {
      delta = delta / delta.distance * maxStep;
    }
    cameraPos += delta * (1 - math.exp(-10 * dt));
  }

  void _tick() {
    if (!mounted || view == Size.zero) return;
    _ensureCamera();
    final n = DateTime.now();
    var dt = n.difference(last).inMicroseconds / 1e6;
    last = n;
    dt = dt.clamp(0, .035);
    t += dt;
    shake = math.max(0, shake - dt * 6);
    noticeT = math.max(0, noticeT - dt);

    if (attack) {
      attackT += dt;
      if (attackT > .28) {
        attack = false;
        attackT = 0;
      }
    }

    for (final f in fx) {
      f.life -= dt * 2.8;
    }
    fx.removeWhere((e) => e.life <= 0);
    for (final o in things) {
      o.flash = math.max(0, o.flash - dt * 5);
    }

    final d = target - hero;
    final desired = d * (holding ? 12.0 : 4.6) +
        (holding ? pointerV * .13 : Offset.zero);
    vel += (desired - vel) * (1 - math.exp(-(holding ? 17 : 8) * dt));
    if (vel.distance > 900) vel = vel / vel.distance * 900;

    final old = hero;
    hero += vel * dt;
    hero = Offset(
      hero.dx.clamp(45.0, world.width - 45),
      hero.dy.clamp(55.0, world.height - 45),
    );
    _collide(old);

    if (requestedIce != null) {
      final i = requestedIce!;
      target = i.p;
      if ((hero - i.p).distance < 62) {
        carriedIce = i;
        requestedIce = null;
        i.v = Offset.zero;
        holding = false;
        target = hero;
        fx.add(_MagicFx(hero + const Offset(0, -20), i.p, _Element.ice));
        _say('キャラクターが氷をつかみました。移動すると一緒に運びます');
        HapticFeedback.mediumImpact();
      }
    }

    for (final i in ices) {
      if (i == carriedIce) continue;
      i.p += i.v * dt;
      i.v *= math.pow(.90, dt * 60).toDouble();
    }

    if (carriedIce != null) {
      carriedIce!.p = hero + _carryOffset();
      carriedIce!.v = Offset.zero;
    }

    if (vel.distance > 40) {
      if (vel.dy.abs() > vel.dx.abs() * .78) {
        vertical = true;
        up = vel.dy < 0;
      } else {
        vertical = false;
        faceRight = vel.dx >= 0;
      }
    }

    _updateCamera(dt);
    setState(() {});
  }

  Offset _carryOffset() {
    if (vertical) return Offset(0, up ? -72 : 70);
    return Offset(faceRight ? 72 : -72, 10);
  }

  void _collide(Offset old) {
    final speed = math.max(vel.distance, pointerV.distance * .7);
    for (final o in things.toList()) {
      if (!o.solid) continue;
      final d = hero - o.p;
      if (d.distance > o.radius + 28) continue;
      if (o.kind == _ThingKind.rock) {
        hero = old;
        vel *= .15;
        continue;
      }
      if (speed > 390) {
        o.flash = 1;
        o.hp -= speed > 720 ? 2 : 1;
        shake = .25;
        HapticFeedback.lightImpact();
        SfxManager.instance.chanceBattleHit();
        if (o.hp <= 0) {
          things.remove(o);
          HapticFeedback.mediumImpact();
        }
      } else {
        hero = old;
        vel *= .12;
      }
    }
  }

  bool _hudArea(Offset local) => local.dy > view.height - 92;

  void _down(Offset local) {
    // Bottom ability UI must never leak into movement/attack input.
    if (_hudArea(local)) return;
    final p = _w(local);

    if (castMode) {
      _cast(p);
      return;
    }

    // Tapping ice issues an order to the character. The player never drags
    // the ice directly; the character walks over and picks it up.
    for (final i in ices.reversed) {
      if ((i.p - p).distance < 55) {
        if (i == carriedIce) {
          _dropIce();
          return;
        }
        requestedIce = i;
        target = i.p;
        holding = false;
        pointerV = Offset.zero;
        _say('氷を指定しました。キャラクターが取りに行きます');
        return;
      }
    }

    requestedIce = null;
    holding = true;
    lastPointer = p;
    lastMs = DateTime.now().millisecondsSinceEpoch;
    pointerV = Offset.zero;
    target = p;
  }

  void _move(Offset local) {
    if (_hudArea(local) || !holding) return;
    final p = _w(local);
    final n = DateTime.now().millisecondsSinceEpoch;
    final ms = math.max(1, n - lastMs);
    final instant = (p - lastPointer) * (1000 / ms);
    pointerV += (instant - pointerV) * .58;
    lastPointer = p;
    lastMs = n;
    target = p;
    if (pointerV.distance > 430) {
      attack = true;
      attackT = 0;
    }
  }

  void _up(Offset local) {
    if (_hudArea(local)) return;
    holding = false;
    if (requestedIce == null) target = hero;
  }

  void _dropIce() {
    if (carriedIce == null) return;
    carriedIce!.v = vel * .22;
    fx.add(_MagicFx(hero, carriedIce!.p, _Element.ice));
    carriedIce = null;
    _say('氷を置きました');
    HapticFeedback.selectionClick();
  }

  void _say(String s, {double seconds = 3.4}) {
    notice = s;
    noticeT = seconds;
  }

  String _instruction(_Element e) => switch (e) {
        _Element.ice => '地面や水をタップ → キャラが氷を生成',
        _Element.fire => '草・ツタをタップ → キャラが炎で焼く',
        _Element.wind => '氷の近くをタップ → キャラが風で飛ばす',
        _Element.thunder => 'スイッチ・松明をタップ → キャラが雷を流す',
      };

  void _selectElement(_Element e) {
    setState(() {
      selected = e;
      castMode = true;
      _say('${_name(e)}：${_instruction(e)}', seconds: 5);
    });
  }

  void _cast(Offset p) {
    castMode = false;
    final from = hero + const Offset(0, -22);
    bool success = false;
    Offset actual = p;

    switch (selected) {
      case _Element.ice:
        ices.add(_Ice(p));
        success = true;
        _say('氷を生成しました。氷をタップするとキャラが取りに行きます', seconds: 5);
        break;
      case _Element.fire:
        _Thing? hit;
        var best = 125.0;
        for (final o in things) {
          if (o.kind != _ThingKind.grass && o.kind != _ThingKind.vine) continue;
          final d = (o.p - p).distance;
          if (d < best) {
            best = d;
            hit = o;
          }
        }
        if (hit != null) {
          actual = hit.p;
          things.remove(hit);
          success = true;
          _say('炎で障害物を焼きました');
        }
        break;
      case _Element.wind:
        for (final i in ices) {
          if (i == carriedIce) continue;
          final d = i.p - p;
          if (d.distance < 210 && d.distance > 1) {
            i.v += d / d.distance * 700;
            actual = i.p;
            success = true;
          }
        }
        if (success) _say('風で氷を押し出しました');
        break;
      case _Element.thunder:
        _Thing? hit;
        var best = 140.0;
        for (final o in things) {
          if (o.kind != _ThingKind.switchPad && o.kind != _ThingKind.torch) continue;
          final d = (o.p - p).distance;
          if (d < best) {
            best = d;
            hit = o;
          }
        }
        if (hit != null) {
          actual = hit.p;
          hit.active = true;
          success = true;
          _say('雷で装置を起動しました');
        }
        break;
    }

    if (success) {
      fx.add(_MagicFx(from, actual, selected));
      HapticFeedback.selectionClick();
    } else {
      _say('そこには${_name(selected)}を使える対象がありません');
      HapticFeedback.lightImpact();
    }
    setState(() {});
  }

  int get runFrame => ((t * 11).floor() % 5) + 1;
  int get vrun => ((t * 9).floor() % 3) + 1;
  int get af => ((attackT / .28 * 6).floor().clamp(0, 5)) + 1;
  int get vaf => ((attackT / .28 * 2).floor().clamp(0, 1)) + 1;

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: const Color(0xff173927),
        body: SafeArea(
          child: Column(
            children: [
              SizedBox(
                height: 52,
                child: Row(
                  children: [
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(Icons.arrow_back, color: Colors.white),
                    ),
                    const Text(
                      '大冒険フィールド',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 19,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const Spacer(),
                    const Padding(
                      padding: EdgeInsets.only(right: 12),
                      child: Text(
                        '探索・破壊・4属性',
                        style: TextStyle(
                          color: Color(0xffffdc7b),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: LayoutBuilder(
                  builder: (context, c) {
                    view = Size(c.maxWidth, c.maxHeight);
                    _ensureCamera();
                    return Listener(
                      behavior: HitTestBehavior.opaque,
                      onPointerDown: (e) => _down(e.localPosition),
                      onPointerMove: (e) => _move(e.localPosition),
                      onPointerUp: (e) => _up(e.localPosition),
                      onPointerCancel: (_) => _up(Offset.zero),
                      child: Stack(
                        children: [
                          Positioned.fill(
                            child: CustomPaint(painter: _WorldPainter(camera: cam)),
                          ),
                          ..._buildTargets(),
                          ..._buildThings(),
                          ..._buildIce(),
                          ..._buildFx(),
                          if (carriedIce != null) _carryBeam(),
                          _heroWidget(),
                          Positioned(
                            left: 10,
                            right: 10,
                            top: 10,
                            child: IgnorePointer(
                              child: AnimatedOpacity(
                                duration: const Duration(milliseconds: 150),
                                opacity: noticeT > 0 || castMode ? 1 : .68,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                                  decoration: BoxDecoration(
                                    color: Colors.black54,
                                    borderRadius: BorderRadius.circular(14),
                                  ),
                                  child: Text(
                                    castMode
                                        ? '${_name(selected)}：${_instruction(selected)}'
                                        : notice,
                                    textAlign: TextAlign.center,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 11,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            left: 0,
                            right: 0,
                            bottom: 10,
                            child: Center(child: _elementBar()),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      );

  String _name(_Element e) => switch (e) {
        _Element.ice => '氷',
        _Element.fire => '炎',
        _Element.wind => '風',
        _Element.thunder => '雷',
      };

  Widget _elementBar() => Container(
        padding: const EdgeInsets.all(6),
        decoration: BoxDecoration(
          color: const Color(0xee102b22),
          borderRadius: BorderRadius.circular(25),
          border: Border.all(color: Colors.white24),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            _eb(_Element.ice, '❄️', '生成'),
            _eb(_Element.fire, '🔥', '焼く'),
            _eb(_Element.wind, '💨', '飛ばす'),
            _eb(_Element.thunder, '⚡', '通電'),
            if (carriedIce != null) _dropButton(),
          ],
        ),
      );

  Widget _eb(_Element e, String s, String sub) => GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => _selectElement(e),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 120),
          margin: const EdgeInsets.symmetric(horizontal: 2),
          width: 58,
          height: 48,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: castMode && selected == e ? Colors.white24 : Colors.transparent,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: castMode && selected == e ? Colors.white70 : Colors.transparent,
              width: 2,
            ),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(s, style: const TextStyle(fontSize: 20, height: 1)),
              const SizedBox(height: 2),
              Text(sub, style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
      );

  Widget _dropButton() => GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: _dropIce,
        child: Container(
          margin: const EdgeInsets.only(left: 3),
          width: 54,
          height: 48,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: const Color(0xff326d7a),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: Colors.white54),
          ),
          child: const Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('🧊', style: TextStyle(fontSize: 18, height: 1)),
              SizedBox(height: 2),
              Text('置く', style: TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
      );

  List<Widget> _buildTargets() {
    if (!castMode) return const [];
    final points = <Offset>[];
    if (selected == _Element.fire) {
      points.addAll(things
          .where((o) => o.kind == _ThingKind.grass || o.kind == _ThingKind.vine)
          .map((o) => o.p));
    } else if (selected == _Element.thunder) {
      points.addAll(things
          .where((o) => o.kind == _ThingKind.switchPad || o.kind == _ThingKind.torch)
          .map((o) => o.p));
    } else if (selected == _Element.wind) {
      points.addAll(ices.where((i) => i != carriedIce).map((i) => i.p));
    }
    return points.map((p) {
      final q = p - cam;
      return Positioned(
        left: q.dx - 34,
        top: q.dy - 34,
        child: IgnorePointer(
          child: Container(
            width: 68,
            height: 68,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white70, width: 3),
              color: Colors.white.withValues(alpha: .08),
            ),
          ),
        ),
      );
    }).toList();
  }

  List<Widget> _buildThings() => things.map((o) {
        final q = o.p - cam;
        return Positioned(
          left: q.dx - 48,
          top: q.dy - 48,
          child: IgnorePointer(
            child: CustomPaint(
              size: const Size(96, 96),
              painter: _ThingPainter(o.kind, o.flash, o.active),
            ),
          ),
        );
      }).toList();

  List<Widget> _buildIce() => ices.map((i) {
        final q = i.p - cam;
        return Positioned(
          left: q.dx - 37,
          top: q.dy - 42,
          child: IgnorePointer(
            child: CustomPaint(
              size: const Size(74, 74),
              painter: const _IcePainter(),
            ),
          ),
        );
      }).toList();

  List<Widget> _buildFx() => fx.map((f) {
        final a = f.from - cam;
        final b = f.to - cam;
        return Positioned.fill(
          child: IgnorePointer(
            child: CustomPaint(painter: _MagicPainter(a, b, f.e, f.life)),
          ),
        );
      }).toList();

  Widget _carryBeam() {
    final a = hero - cam + const Offset(0, -20);
    final b = carriedIce!.p - cam;
    return Positioned.fill(
      child: IgnorePointer(
        child: CustomPaint(painter: _CarryPainter(a, b)),
      ),
    );
  }

  Widget _heroWidget() {
    final moving = !attack && vel.distance > 48;
    final pref = up ? 'up' : 'down';
    final path = attack && vertical
        ? 'assets/sprites/hero_swordswoman/${pref}_attack_${vaf.toString().padLeft(2, '0')}.png'
        : attack
            ? 'assets/sprites/hero_swordswoman/attack_${af.toString().padLeft(2, '0')}.png'
            : moving && vertical
                ? 'assets/sprites/hero_swordswoman/${pref}_run_${vrun.toString().padLeft(2, '0')}.png'
                : moving
                    ? 'assets/sprites/hero_swordswoman/run_${runFrame.toString().padLeft(2, '0')}.png'
                    : 'assets/sprites/hero_swordswoman/idle_01.png';
    Widget im = Image.asset(
      path,
      width: 156,
      height: 117,
      fit: BoxFit.contain,
      gaplessPlayback: true,
    );
    if (!vertical && !faceRight) {
      im = Transform(
        alignment: Alignment.center,
        transform: Matrix4.diagonal3Values(-1, 1, 1),
        child: im,
      );
    }
    final q = hero - cam;
    return Positioned(
      left: q.dx - 78 + math.sin(t * 70) * shake * 2,
      top: q.dy - 84,
      child: IgnorePointer(child: im),
    );
  }
}

class _WorldPainter extends CustomPainter {
  const _WorldPainter({required this.camera});
  final Offset camera;

  @override
  void paint(Canvas c, Size s) {
    c.drawRect(Offset.zero & s, Paint()..color = const Color(0xff74b85a));
    c.save();
    c.translate(-camera.dx, -camera.dy);
    final path = Paint()..color = const Color(0xffd8bd7b);
    c.drawPath(
      Path()
        ..moveTo(220, 1510)
        ..cubicTo(650, 1300, 850, 1500, 1100, 1210)
        ..cubicTo(1370, 900, 1640, 1080, 1850, 700)
        ..cubicTo(2000, 520, 2170, 500, 2260, 350),
      path,
    );
    final water = Paint()..color = const Color(0xff58aeda);
    c.drawRRect(
      RRect.fromRectAndRadius(
        const Rect.fromLTWH(1120, 720, 500, 260),
        const Radius.circular(90),
      ),
      water,
    );
    c.drawRRect(
      RRect.fromRectAndRadius(
        const Rect.fromLTWH(1820, 1120, 420, 250),
        const Radius.circular(80),
      ),
      water,
    );
    final dark = Paint()..color = const Color(0xff4b8d45);
    for (int x = 80; x < 2380; x += 180) {
      c.drawCircle(Offset(x.toDouble(), 90), 55, dark);
      c.drawCircle(Offset(x.toDouble(), 1810), 55, dark);
    }
    for (int y = 180; y < 1780; y += 180) {
      c.drawCircle(Offset(70, y.toDouble()), 55, dark);
      c.drawCircle(Offset(2330, y.toDouble()), 55, dark);
    }
    c.restore();
  }

  @override
  bool shouldRepaint(covariant _WorldPainter o) => o.camera != camera;
}

class _ThingPainter extends CustomPainter {
  const _ThingPainter(this.k, this.flash, this.active);
  final _ThingKind k;
  final double flash;
  final bool active;

  @override
  void paint(Canvas c, Size s) {
    final m = s.center(Offset.zero);
    switch (k) {
      case _ThingKind.grass:
        c.drawOval(
          Rect.fromCenter(center: m, width: 60, height: 34),
          Paint()..color = const Color(0xff287b39),
        );
        break;
      case _ThingKind.pot:
        c.drawOval(
          Rect.fromCenter(center: m, width: 44, height: 55),
          Paint()..color = const Color(0xffb86c3d),
        );
        c.drawRect(
          Rect.fromCenter(center: m - const Offset(0, 24), width: 35, height: 8),
          Paint()..color = const Color(0xffe09a60),
        );
        break;
      case _ThingKind.crate:
        c.drawRect(
          Rect.fromCenter(center: m, width: 62, height: 62),
          Paint()..color = const Color(0xffa96d32),
        );
        c.drawLine(
          m - const Offset(25, 25),
          m + const Offset(25, 25),
          Paint()
            ..color = const Color(0xff71441f)
            ..strokeWidth = 7,
        );
        c.drawLine(
          m + const Offset(25, -25),
          m + const Offset(-25, 25),
          Paint()
            ..color = const Color(0xff71441f)
            ..strokeWidth = 7,
        );
        break;
      case _ThingKind.vine:
        c.drawCircle(m, 35, Paint()..color = const Color(0xff236d35));
        for (int i = 0; i < 5; i++) {
          c.drawCircle(
            m + Offset(math.cos(i * 1.25) * 25, math.sin(i * 1.25) * 25),
            12,
            Paint()..color = const Color(0xff4fa94d),
          );
        }
        break;
      case _ThingKind.rock:
        c.drawCircle(m, 40, Paint()..color = const Color(0xff6f7a72));
        break;
      case _ThingKind.switchPad:
        c.drawCircle(
          m,
          31,
          Paint()..color = active ? const Color(0xffffe65c) : const Color(0xff5e6871),
        );
        c.drawCircle(
          m,
          18,
          Paint()..color = active ? Colors.white : const Color(0xff8c9aa4),
        );
        break;
      case _ThingKind.torch:
        c.drawRect(
          Rect.fromCenter(center: m + const Offset(0, 18), width: 8, height: 45),
          Paint()..color = const Color(0xff6f4224),
        );
        c.drawCircle(
          m - const Offset(0, 12),
          active ? 18 : 10,
          Paint()..color = active ? const Color(0xffff8a2b) : const Color(0xff6c6c6c),
        );
        break;
    }
    if (flash > 0) {
      c.drawCircle(
        m,
        43,
        Paint()..color = Colors.white.withValues(alpha: flash * .45),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _ThingPainter o) => true;
}

class _IcePainter extends CustomPainter {
  const _IcePainter();

  @override
  void paint(Canvas c, Size s) {
    final m = s.center(Offset.zero);
    final p = Path()
      ..moveTo(m.dx, m.dy - 34)
      ..lineTo(m.dx + 31, m.dy - 16)
      ..lineTo(m.dx + 27, m.dy + 28)
      ..lineTo(m.dx - 27, m.dy + 28)
      ..lineTo(m.dx - 31, m.dy - 16)
      ..close();
    c.drawPath(p, Paint()..color = const Color(0xff91e8ff));
    c.drawPath(
      p,
      Paint()
        ..color = Colors.white70
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter o) => false;
}

class _MagicPainter extends CustomPainter {
  const _MagicPainter(this.a, this.b, this.e, this.life);
  final Offset a, b;
  final _Element e;
  final double life;

  @override
  void paint(Canvas c, Size s) {
    final col = switch (e) {
      _Element.ice => const Color(0xff8eeaff),
      _Element.fire => const Color(0xffff7b32),
      _Element.wind => const Color(0xffd9fff1),
      _Element.thunder => const Color(0xffffe54d),
    };
    final p = Paint()
      ..color = col.withValues(alpha: life.clamp(0, 1))
      ..strokeWidth = 6
      ..strokeCap = StrokeCap.round;
    c.drawLine(a, b, p);
    c.drawCircle(
      a,
      13 + 10 * (1 - life),
      Paint()..color = col.withValues(alpha: life * .7),
    );
    c.drawCircle(
      b,
      22 + 20 * (1 - life),
      Paint()..color = col.withValues(alpha: life * .45),
    );
  }

  @override
  bool shouldRepaint(covariant _MagicPainter o) => true;
}

class _CarryPainter extends CustomPainter {
  const _CarryPainter(this.a, this.b);
  final Offset a, b;

  @override
  void paint(Canvas c, Size s) {
    final pulse = 0.55 + 0.15 * math.sin(DateTime.now().millisecondsSinceEpoch / 90);
    c.drawLine(
      a,
      b,
      Paint()
        ..color = const Color(0xffbdf4ff).withValues(alpha: pulse)
        ..strokeWidth = 5
        ..strokeCap = StrokeCap.round,
    );
    c.drawCircle(
      a,
      9,
      Paint()..color = const Color(0xffe9fbff).withValues(alpha: .8),
    );
  }

  @override
  bool shouldRepaint(covariant _CarryPainter o) => true;
}
