import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../game/game_controller.dart';

enum _Role { attacker, tank, support }

class _Unit {
  _Unit(
    this.pos,
    this.type,
    this.role, {
    required this.ally,
  });

  Offset pos;
  Offset vel = Offset.zero;
  final int type;
  final _Role role;
  final bool ally;
  int hp = 100;
  int? target;
  double cooldown = 0;
  double flash = 0;
  double attackAnim = 0;
}

class ConnectBattleScreen extends StatefulWidget {
  final GameController controller;
  final int stageId;

  const ConnectBattleScreen({
    super.key,
    required this.controller,
    required this.stageId,
  });

  @override
  State<ConnectBattleScreen> createState() => _ConnectBattleScreenState();
}

class _ConnectBattleScreenState extends State<ConnectBattleScreen> {
  final math.Random _random = math.Random();
  final List<_Unit> _allies = <_Unit>[];
  final List<_Unit> _enemies = <_Unit>[];

  Timer? _timer;
  DateTime _last = DateTime.now();
  int? _selectedSource;
  int? _selectedTarget;
  bool _auto = false;
  bool _finished = false;
  bool _battleStarted = false;
  int _speed = 1;
  Size _field = Size.zero;

  static const double _unitRadius = 15;
  static const double _sameTeamMinDistance = 36;
  static const double _enemyMinDistance = 34;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(
      const Duration(milliseconds: 33),
      (_) => _tick(),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _seed(Size size) {
    if (_allies.isNotEmpty) return;
    _field = size;

    // V52: five allies in the foreground (bottom), five enemies in the back (top).
    const List<double> xs = <double>[.14, .32, .50, .68, .86];
    final double allyY = size.height * .80;
    final double enemyY = size.height * .20;

    _allies.addAll(<_Unit>[
      _Unit(Offset(size.width * xs[0], allyY), 0, _Role.attacker, ally: true),
      _Unit(Offset(size.width * xs[1], allyY - 16), 2, _Role.tank, ally: true),
      _Unit(Offset(size.width * xs[2], allyY + 4), 3, _Role.attacker, ally: true),
      _Unit(Offset(size.width * xs[3], allyY - 16), 1, _Role.attacker, ally: true),
      _Unit(Offset(size.width * xs[4], allyY), 4, _Role.support, ally: true),
    ]);

    _enemies.addAll(<_Unit>[
      _Unit(Offset(size.width * xs[0], enemyY), 1, _Role.attacker, ally: false),
      _Unit(Offset(size.width * xs[1], enemyY + 16), 3, _Role.attacker, ally: false),
      _Unit(Offset(size.width * xs[2], enemyY - 4), 2, _Role.attacker, ally: false),
      _Unit(Offset(size.width * xs[3], enemyY + 16), 0, _Role.attacker, ally: false),
      _Unit(Offset(size.width * xs[4], enemyY), 4, _Role.attacker, ally: false),
    ]);
  }

  void _tick() {
    if (!mounted || _finished || _field == Size.zero) return;

    final DateTime now = DateTime.now();
    var dt = now.difference(_last).inMilliseconds / 1000;
    _last = now;

    if (!_battleStarted) {
      if (mounted) setState(() {});
      return;
    }

    dt = math.min(.08, dt) * _speed;
    final int subSteps = _speed >= 4 ? 2 : 1;
    for (var i = 0; i < subSteps; i++) {
      _step(dt / subSteps);
    }
    if (mounted) setState(() {});
  }

  void _step(double dt) {
    if (_auto) _autoTargets();

    for (var i = 0; i < _allies.length; i++) {
      _moveAlly(i, dt);
    }
    for (var i = 0; i < _enemies.length; i++) {
      _moveEnemy(i, dt);
    }

    _resolveAllCollisions();

    if (_enemies.every((u) => u.hp <= 0)) {
      _win();
    } else if (_allies.every((u) => u.hp <= 0)) {
      _finished = true;
    }
  }

  Offset _wander(_Unit unit, double dt, bool leftSide) {
    final double cx = _field.width * .50;
    final double cy = leftSide ? _field.height * .76 : _field.height * .24;
    final Offset toCenter = Offset(cx, cy) - unit.pos;
    final Offset jitter = Offset(
      (_random.nextDouble() - .5) * 13,
      (_random.nextDouble() - .5) * 13,
    );
    unit.vel = unit.vel * .95 + toCenter * .0025 + jitter * dt;
    return unit.vel;
  }

  void _moveAlly(int index, double dt) {
    final _Unit unit = _allies[index];
    if (unit.hp <= 0) return;

    unit.cooldown = math.max(0, unit.cooldown - dt);
    unit.flash = math.max(0, unit.flash - dt);
    unit.attackAnim = math.max(0, unit.attackAnim - dt);

    final bool support = unit.role == _Role.support;
    Offset? goal;

    if (unit.target != null) {
      if (support) {
        if (unit.target! < _allies.length && _allies[unit.target!].hp > 0) {
          goal = _allies[unit.target!].pos;
        } else {
          unit.target = null;
        }
      } else {
        if (unit.target! < _enemies.length && _enemies[unit.target!].hp > 0) {
          goal = _enemies[unit.target!].pos;
        } else {
          unit.target = null;
        }
      }
    }

    if (goal == null) {
      unit.pos += _wander(unit, dt, true) * dt;
      _clamp(unit);
      return;
    }

    final double distance = (goal - unit.pos).distance;
    final double range = support ? 47 : 38;

    if (distance > range) {
      final Offset dir = (goal - unit.pos) / math.max(distance, .001);
      unit.pos += dir * (unit.role == _Role.attacker ? 66 : 56) * dt;
    } else if (unit.cooldown <= 0) {
      unit.cooldown = support ? 1.25 : .85;
      unit.attackAnim = support ? .30 : .24;
      if (support) {
        final _Unit target = _allies[unit.target!];
        target.hp = math.min(100, target.hp + 18);
        target.flash = .25;
      } else {
        final _Unit target = _enemies[unit.target!];
        target.hp = math.max(0, target.hp - (unit.role == _Role.tank ? 12 : 22));
        target.flash = .18;
      }
    }

    _clamp(unit);
  }

  void _moveEnemy(int index, double dt) {
    final _Unit unit = _enemies[index];
    if (unit.hp <= 0) return;

    unit.cooldown = math.max(0, unit.cooldown - dt);
    unit.flash = math.max(0, unit.flash - dt);
    unit.attackAnim = math.max(0, unit.attackAnim - dt);

    int best = -1;
    double bestDistance = double.infinity;
    for (var i = 0; i < _allies.length; i++) {
      if (_allies[i].hp <= 0) continue;
      final double d = (_allies[i].pos - unit.pos).distance;
      if (d < bestDistance) {
        bestDistance = d;
        best = i;
      }
    }

    if (best < 0) return;
    final Offset goal = _allies[best].pos;

    if (bestDistance > 38) {
      unit.pos += (goal - unit.pos) / math.max(bestDistance, .001) * 43 * dt;
    } else if (unit.cooldown <= 0) {
      unit.cooldown = 1.15;
      unit.attackAnim = .24;
      _allies[best].hp = math.max(0, _allies[best].hp - 9);
      _allies[best].flash = .18;
    }

    _clamp(unit);
  }

  void _resolveAllCollisions() {
    _resolveTeamCollisions(_allies);
    _resolveTeamCollisions(_enemies);

    for (final _Unit ally in _allies) {
      if (ally.hp <= 0) continue;
      for (final _Unit enemy in _enemies) {
        if (enemy.hp <= 0) continue;
        _separatePair(ally, enemy, _enemyMinDistance);
      }
    }
  }

  void _resolveTeamCollisions(List<_Unit> team) {
    for (var i = 0; i < team.length; i++) {
      if (team[i].hp <= 0) continue;
      for (var j = i + 1; j < team.length; j++) {
        if (team[j].hp <= 0) continue;
        _separatePair(team[i], team[j], _sameTeamMinDistance);
      }
    }
  }

  void _separatePair(_Unit a, _Unit b, double minimumDistance) {
    Offset delta = b.pos - a.pos;
    double distance = delta.distance;

    if (distance >= minimumDistance) return;
    if (distance < .001) {
      delta = const Offset(1, 0);
      distance = 1;
    }

    final Offset dir = delta / distance;
    final double push = (minimumDistance - distance) / 2;
    a.pos -= dir * push;
    b.pos += dir * push;
    _clamp(a);
    _clamp(b);
  }

  void _clamp(_Unit unit) {
    unit.pos = Offset(
      unit.pos.dx.clamp(_unitRadius + 4, _field.width - _unitRadius - 4),
      unit.pos.dy.clamp(_unitRadius + 12, _field.height - _unitRadius - 8),
    );
  }

  void _autoTargets() {
    for (var i = 0; i < _allies.length; i++) {
      final _Unit unit = _allies[i];
      if (unit.hp <= 0) continue;

      if (unit.role == _Role.support) {
        int best = -1;
        int lowestHp = 101;
        for (var j = 0; j < _allies.length; j++) {
          if (i == j || _allies[j].hp <= 0) continue;
          if (_allies[j].hp < lowestHp) {
            lowestHp = _allies[j].hp;
            best = j;
          }
        }
        if (best < 0) {
          for (var j = 0; j < _allies.length; j++) {
            if (i != j && _allies[j].hp > 0) {
              best = j;
              break;
            }
          }
        }
        unit.target = best < 0 ? null : best;
      } else if (unit.target == null ||
          unit.target! >= _enemies.length ||
          _enemies[unit.target!].hp <= 0) {
        int best = -1;
        double bestDistance = double.infinity;
        for (var j = 0; j < _enemies.length; j++) {
          if (_enemies[j].hp <= 0) continue;
          final double d = (_enemies[j].pos - unit.pos).distance;
          if (d < bestDistance) {
            bestDistance = d;
            best = j;
          }
        }
        unit.target = best < 0 ? null : best;
      }
    }
  }

  Future<void> _win() async {
    if (_finished) return;
    _finished = true;
    _timer?.cancel();
    await widget.controller.completeRpgStage(widget.stageId);
    if (!mounted) return;

    await showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('勝利！ 🎉'),
        content: const Text('敵をすべて倒しました！'),
        actions: <Widget>[
          FilledButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
    if (mounted) Navigator.pop(context);
  }


  void _resultMode() {
    if (_finished) return;
    if (!_battleStarted) {
      _autoTargets();
      _battleStarted = true;
    }
    setState(() {
      _speed = 4;
      _auto = true;
      _selectedSource = null;
      _selectedTarget = null;
      _last = DateTime.now();
    });
  }

  void _selectSource(int index) {
    if (index < 0 || index >= _allies.length || _allies[index].hp <= 0) return;
    setState(() {
      // Selecting a source always pauses the battlefield so the player can
      // calmly choose the destination. Manual selection also takes priority
      // over AUTO targeting.
      _battleStarted = false;
      _auto = false;
      _selectedSource = index;
      _selectedTarget = null;
      _last = DateTime.now();
    });
  }

  void _tapField(TapUpDetails details) {
    if (_finished) return;
    final Offset pointer = details.localPosition;

    // Allies are always valid as a new source. This also makes retargeting
    // quick: tap another ally and the game remains paused.
    int allyHit = -1;
    double allyDistance = 30;
    for (var i = 0; i < _allies.length; i++) {
      if (_allies[i].hp <= 0) continue;
      final double d = (_allies[i].pos - pointer).distance;
      if (d < allyDistance) {
        allyDistance = d;
        allyHit = i;
      }
    }

    if (_selectedSource == null) {
      if (allyHit >= 0) _selectSource(allyHit);
      return;
    }

    final int sourceIndex = _selectedSource!;
    final _Unit source = _allies[sourceIndex];

    if (source.role == _Role.support) {
      // A support unit connects to another ally. Tapping the selected source
      // again simply keeps it selected; tapping a different ally completes
      // the connection.
      if (allyHit >= 0 && allyHit != sourceIndex) {
        setState(() {
          source.target = allyHit;
          _selectedTarget = allyHit;
        });
        return;
      }
      if (allyHit == sourceIndex) return;
    } else {
      int enemyHit = -1;
      double enemyDistance = 32;
      for (var i = 0; i < _enemies.length; i++) {
        if (_enemies[i].hp <= 0) continue;
        final double d = (_enemies[i].pos - pointer).distance;
        if (d < enemyDistance) {
          enemyDistance = d;
          enemyHit = i;
        }
      }
      if (enemyHit >= 0) {
        setState(() {
          source.target = enemyHit;
          _selectedTarget = enemyHit;
        });
        return;
      }
    }

    // Tapping another ally while choosing an enemy makes that ally the new
    // source, matching the two-tap "source -> destination" flow.
    if (allyHit >= 0 && allyHit != sourceIndex) {
      _selectSource(allyHit);
    }
  }

  void _toggleBattle() {
    if (_finished) return;
    if (_battleStarted) {
      setState(() {
        _battleStarted = false;
        _last = DateTime.now();
      });
      return;
    }

    if (_auto) _autoTargets();
    setState(() {
      _battleStarted = true;
      _selectedSource = null;
      _selectedTarget = null;
      _last = DateTime.now();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF182638),
      body: SafeArea(
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.fromLTRB(6, 4, 10, 2),
              child: Row(
                children: <Widget>[
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                  ),
                  Text(
                    '冒険  STAGE ${widget.stageId}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      fontSize: 18,
                    ),
                  ),
                  const Spacer(),
                  Text(
                    _battleStarted ? '戦闘中' : (_selectedSource == null ? '停止中' : 'つなぐ先を選択'),
                    style: TextStyle(
                      color: _battleStarted
                          ? const Color(0xFFFFE18A)
                          : const Color(0xFF9BE8FF),
                      fontWeight: FontWeight.w900,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: LayoutBuilder(
                builder: (context, box) {
                  final Size size = Size(box.maxWidth, box.maxHeight);
                  _field = size;
                  _seed(size);
                  return GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTapUp: _tapField,
                    child: CustomPaint(
                      size: size,
                      painter: _FieldPainter(
                        _allies,
                        _enemies,
                        _selectedSource,
                        _selectedTarget,
                        _battleStarted,
                      ),
                    ),
                  );
                },
              ),
            ),
            // V52: battle controls moved from the top to the foreground/bottom.
            Container(
              padding: const EdgeInsets.fromLTRB(8, 7, 8, 8),
              decoration: const BoxDecoration(
                color: Color(0xFF101B28),
                border: Border(top: BorderSide(color: Colors.white24)),
              ),
              child: Row(
                children: <Widget>[
                  Expanded(
                    flex: 2,
                    child: SizedBox(
                      height: 42,
                      child: FilledButton.icon(
                        onPressed: _toggleBattle,
                        icon: Icon(
                          _battleStarted ? Icons.pause_rounded : Icons.play_arrow_rounded,
                        ),
                        label: Text(_battleStarted ? '停止' : '再生'),
                        style: FilledButton.styleFrom(
                          backgroundColor: _battleStarted
                              ? const Color(0xFFFF8A80)
                              : const Color(0xFFFFD85A),
                          foregroundColor: Colors.black,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 6),
                  _modeButton('AUTO', _auto, () {
                    setState(() {
                      _auto = !_auto;
                      if (_auto) {
                        _selectedSource = null;
                        _selectedTarget = null;
                        _autoTargets();
                      }
                    });
                  }),
                  const SizedBox(width: 5),
                  _modeButton(_speed == 2 ? '×2' : '倍速', _speed == 2, () {
                    setState(() => _speed = _speed == 2 ? 1 : 2);
                  }),
                  const SizedBox(width: 5),
                  _modeButton('結果', _speed == 4, _resultMode),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _modeButton(String text, bool on, VoidCallback tap) {
    return SizedBox(
      height: 34,
      child: FilledButton.tonal(
        onPressed: tap,
        style: FilledButton.styleFrom(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          backgroundColor: on ? const Color(0xFFFFD85A) : Colors.white12,
          foregroundColor: on ? Colors.black : Colors.white,
        ),
        child: Text(
          text,
          style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12),
        ),
      ),
    );
  }
}

class _FieldPainter extends CustomPainter {
  final List<_Unit> allies;
  final List<_Unit> enemies;
  final int? selectedSource;
  final int? selectedTarget;
  final bool battleStarted;

  _FieldPainter(
    this.allies,
    this.enemies,
    this.selectedSource,
    this.selectedTarget,
    this.battleStarted,
  );

  @override
  void paint(Canvas canvas, Size size) {
    final Paint bg = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: <Color>[Color(0xFF27415B), Color(0xFF172C35)],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, bg);

    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(size.width * .5, size.height * .55),
        width: size.width * .92,
        height: size.height * .75,
      ),
      Paint()..color = const Color(0x2237C78B),
    );

    if (!battleStarted) {
      final Paint divider = Paint()
        ..color = const Color(0x447EDBFF)
        ..strokeWidth = 1.5;
      for (double x = 8; x < size.width; x += 16) {
        canvas.drawLine(
          Offset(x, size.height * .5),
          Offset(math.min(x + 8, size.width), size.height * .5),
          divider,
        );
      }
    }

    final Paint line = Paint()
      ..strokeWidth = 2.5
      ..strokeCap = StrokeCap.round;

    if (selectedSource == null) {
      for (var i = 0; i < allies.length; i++) {
        final _Unit unit = allies[i];
        if (unit.hp <= 0 || unit.target == null) continue;
        Offset? target;
        if (unit.role == _Role.support) {
          if (unit.target! < allies.length) target = allies[unit.target!].pos;
          line.color = const Color(0xCC70F0A5);
        } else {
          if (unit.target! < enemies.length) target = enemies[unit.target!].pos;
          line.color = const Color(0xBBFFD86B);
        }
        if (target != null) {
          canvas.drawLine(unit.pos, target, line);
          if (unit.attackAnim > 0 && unit.role != _Role.support) {
            final Paint hit = Paint()
              ..color = const Color(0xFFFFF0A0)
              ..strokeWidth = 3
              ..strokeCap = StrokeCap.round;
            final Offset c = target;
            canvas.drawLine(c + const Offset(-7, -7), c + const Offset(7, 7), hit);
            canvas.drawLine(c + const Offset(7, -7), c + const Offset(-7, 7), hit);
          }
        }
      }
    }

    // Enemy attacks get the same visible impact mark, so AUTO is fun to watch.
    for (final _Unit enemy in enemies) {
      if (enemy.hp <= 0 || enemy.attackAnim <= 0) continue;
      int best = -1;
      double bestDistance = double.infinity;
      for (var i = 0; i < allies.length; i++) {
        if (allies[i].hp <= 0) continue;
        final double d = (allies[i].pos - enemy.pos).distance;
        if (d < bestDistance) {
          bestDistance = d;
          best = i;
        }
      }
      if (best >= 0) {
        final Offset c = allies[best].pos;
        final Paint hit = Paint()
          ..color = const Color(0xFFFF8A9A)
          ..strokeWidth = 3
          ..strokeCap = StrokeCap.round;
        canvas.drawLine(c + const Offset(-7, -7), c + const Offset(7, 7), hit);
        canvas.drawLine(c + const Offset(7, -7), c + const Offset(-7, 7), hit);
      }
    }

    for (var i = 0; i < enemies.length; i++) {
      final bool selected = selectedSource != null &&
          allies[selectedSource!].role != _Role.support &&
          selectedTarget == i;
      final bool dimmed = selectedSource != null && !selected;
      _drawUnit(canvas, enemies[i], false, dimmed: dimmed, selected: selected);
    }
    for (var i = 0; i < allies.length; i++) {
      final bool isSource = selectedSource == i;
      final bool isSupportTarget = selectedSource != null &&
          allies[selectedSource!].role == _Role.support &&
          selectedTarget == i;
      final bool selected = isSource || isSupportTarget;
      final bool dimmed = selectedSource != null && !selected;
      _drawUnit(canvas, allies[i], true, dimmed: dimmed, selected: selected);
    }

    if (selectedSource != null) {
      final _Unit source = allies[selectedSource!];
      if (selectedTarget != null) {
        final Offset target = source.role == _Role.support
            ? allies[selectedTarget!].pos
            : enemies[selectedTarget!].pos;
        final Paint selectedLine = Paint()
          ..color = source.role == _Role.support
              ? const Color(0xFF8BFFB7)
              : const Color(0xFFFFED79)
          ..strokeWidth = 5
          ..strokeCap = StrokeCap.round;
        canvas.drawLine(source.pos, target, selectedLine);
      }
    }

    if (selectedSource != null) {
      _label(
        canvas,
        selectedTarget == null ? 'つなぐ先をタップ' : '接続OK  ▶ 再生で戦闘再開',
        Offset(size.width * .5 - (selectedTarget == null ? 52 : 88), size.height * .50 - 18),
        const Color(0xFFFFFFFF),
        11,
      );
    }

    _label(canvas, '敵陣', const Offset(16, 10), const Color(0xFFFF8D9E));
    _label(canvas, '自陣', Offset(16, size.height - 26), const Color(0xFF8DE7FF));
  }

  void _drawUnit(
    Canvas canvas,
    _Unit unit,
    bool ally, {
    bool dimmed = false,
    bool selected = false,
  }) {
    if (unit.hp <= 0) return;

    if (dimmed) {
      canvas.saveLayer(
        Rect.fromCircle(center: unit.pos, radius: 32),
        Paint()..color = Colors.white.withValues(alpha: .24),
      );
    }

    if (selected) {
      canvas.drawCircle(
        unit.pos,
        27,
        Paint()
          ..color = ally ? const Color(0xFF86F5FF) : const Color(0xFFFFE36D)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 5,
      );
      canvas.drawCircle(
        unit.pos,
        23,
        Paint()..color = Colors.white.withValues(alpha: .18),
      );
    }

    canvas.drawOval(
      Rect.fromCenter(
        center: unit.pos + const Offset(0, 13),
        width: 27,
        height: 8,
      ),
      Paint()..color = Colors.black26,
    );

    if (unit.flash > 0) {
      canvas.drawCircle(
        unit.pos,
        20,
        Paint()..color = Colors.white.withValues(alpha: .52),
      );
    }

    // Clear visual feedback for attacks/heals: a slash/burst appears while acting.
    if (unit.attackAnim > 0) {
      final double t = (unit.attackAnim / .30).clamp(0.0, 1.0);
      final Paint fx = Paint()
        ..color = unit.role == _Role.support
            ? const Color(0xFF7CFFB1).withValues(alpha: .35 + .55 * t)
            : const Color(0xFFFFE071).withValues(alpha: .35 + .55 * t)
        ..strokeWidth = 3
        ..strokeCap = StrokeCap.round;
      if (unit.role == _Role.support) {
        canvas.drawCircle(unit.pos, 22 + 5 * (1 - t), fx..style = PaintingStyle.stroke);
        canvas.drawLine(unit.pos + const Offset(-5, 0), unit.pos + const Offset(5, 0), fx);
        canvas.drawLine(unit.pos + const Offset(0, -5), unit.pos + const Offset(0, 5), fx);
      } else {
        canvas.drawLine(unit.pos + const Offset(-12, 10), unit.pos + const Offset(10, -12), fx);
        canvas.drawLine(unit.pos + const Offset(-6, 12), unit.pos + const Offset(14, -8), fx..strokeWidth = 1.7);
      }
    }

    canvas.drawCircle(
      unit.pos,
      18,
      Paint()
        ..color = ally ? const Color(0x885EDCF4) : const Color(0x88FF6B7E)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2,
    );

    canvas.save();
    canvas.translate(unit.pos.dx - 15, unit.pos.dy - 15);
    const Size characterSize = Size(30, 30);
    _BattleRoundCharacterPainter(type: unit.type).paint(canvas, characterSize);
    canvas.restore();

    final Rect hpRect = Rect.fromLTWH(unit.pos.dx - 15, unit.pos.dy - 23, 30, 4);
    canvas.drawRRect(
      RRect.fromRectAndRadius(hpRect, const Radius.circular(4)),
      Paint()..color = Colors.black45,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(hpRect.left, hpRect.top, 30 * unit.hp / 100, 4),
        const Radius.circular(4),
      ),
      Paint()..color = ally ? const Color(0xFF62E58C) : const Color(0xFFFF6678),
    );

    if (ally) {
      final String mark = unit.role == _Role.support
          ? 'SUP'
          : unit.role == _Role.tank
              ? 'DEF'
              : 'ATK';
      _label(
        canvas,
        mark,
        unit.pos + const Offset(-10, 18),
        unit.role == _Role.support ? const Color(0xFF86F0AD) : Colors.white70,
        7,
      );
    }

    if (dimmed) canvas.restore();
  }

  void _label(Canvas canvas, String text, Offset pos, Color color, [double fontSize = 12]) {
    final TextPainter painter = TextPainter(
      text: TextSpan(
        text: text,
        style: TextStyle(
          color: color,
          fontSize: fontSize,
          fontWeight: FontWeight.w900,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    painter.paint(canvas, pos);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

// V50: Uses the same round character designs as the old Tsum-Tsum style puzzle.
class _BattleRoundCharacterPainter {
  final int type;

  const _BattleRoundCharacterPainter({required this.type});

  Paint _gloss(Color light, Color base, Color dark, Offset c, double r) {
    return Paint()
      ..shader = RadialGradient(
        center: const Alignment(-.34, -.42),
        radius: 1.05,
        colors: <Color>[light, base, dark],
        stops: const <double>[0, .55, 1],
      ).createShader(Rect.fromCircle(center: c, radius: r));
  }

  void _bodyShine(Canvas canvas, Offset c, double r) {
    canvas.drawOval(
      Rect.fromCenter(
        center: c + Offset(-r * .28, -r * .38),
        width: r * .48,
        height: r * .25,
      ),
      Paint()..color = Colors.white.withValues(alpha: .34),
    );
  }

  void paint(Canvas canvas, Size size) {
    final Offset c = Offset(size.width / 2, size.height / 2);
    final double r = math.min(size.width, size.height) / 2;
    final Paint shadow = Paint()
      ..color = const Color(0x33000000)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3);
    canvas.drawOval(
      Rect.fromCenter(
        center: c + Offset(0, r * .12),
        width: r * 1.62,
        height: r * 1.58,
      ),
      shadow,
    );

    switch (type) {
      case 0:
        _drawChick(canvas, c, r);
        break;
      case 1:
        _drawFrog(canvas, c, r);
        break;
      case 2:
        _drawPenguin(canvas, c, r);
        break;
      case 3:
        _drawDog(canvas, c, r);
        break;
      default:
        _drawBunny(canvas, c, r);
    }
  }

  void _eyes(Canvas canvas, Offset c, double r, {double y = -.10}) {
    final Paint eye = Paint()..color = const Color(0xFF252525);
    canvas.drawCircle(c + Offset(-r * .25, r * y), r * .075, eye);
    canvas.drawCircle(c + Offset(r * .25, r * y), r * .075, eye);
    final Paint hi = Paint()..color = Colors.white.withValues(alpha: .9);
    canvas.drawCircle(c + Offset(-r * .225, r * (y - .025)), r * .018, hi);
    canvas.drawCircle(c + Offset(r * .275, r * (y - .025)), r * .018, hi);
  }

  void _blush(Canvas canvas, Offset c, double r) {
    final Paint paint = Paint()..color = const Color(0x55F38E9E);
    canvas.drawCircle(c + Offset(-r * .48, r * .13), r * .11, paint);
    canvas.drawCircle(c + Offset(r * .48, r * .13), r * .11, paint);
  }

  void _drawChick(Canvas canvas, Offset c, double r) {
    final Paint body = _gloss(
      const Color(0xFFFFF08A),
      const Color(0xFFFFC928),
      const Color(0xFFE79A00),
      c,
      r,
    );
    canvas.drawCircle(c, r * .82, body);
    _bodyShine(canvas, c, r);
    final Paint wing = Paint()..color = const Color(0xFFFFB51E);
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(-r * .66, r * .12), width: r * .28, height: r * .48),
      wing,
    );
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(r * .66, r * .12), width: r * .28, height: r * .48),
      wing,
    );
    _eyes(canvas, c, r);
    _blush(canvas, c, r);
    final Path beak = Path()
      ..moveTo(c.dx - r * .10, c.dy + r * .08)
      ..lineTo(c.dx + r * .12, c.dy + r * .08)
      ..lineTo(c.dx, c.dy + r * .20)
      ..close();
    canvas.drawPath(beak, Paint()..color = const Color(0xFFF18A18));
  }

  void _drawFrog(Canvas canvas, Offset c, double r) {
    final Paint body = _gloss(
      const Color(0xFFA6F3A9),
      const Color(0xFF63D46B),
      const Color(0xFF2C9A42),
      c,
      r,
    );
    final Paint deep = Paint()..color = const Color(0xFF25873A);
    canvas.drawCircle(c, r * .82, body);
    _bodyShine(canvas, c, r);
    canvas.drawCircle(c + Offset(-r * .42, -r * .55), r * .25, body);
    canvas.drawCircle(c + Offset(r * .42, -r * .55), r * .25, body);
    canvas.drawCircle(c + Offset(-r * .42, -r * .55), r * .11, Paint()..color = Colors.white);
    canvas.drawCircle(c + Offset(r * .42, -r * .55), r * .11, Paint()..color = Colors.white);
    canvas.drawCircle(c + Offset(-r * .42, -r * .55), r * .055, Paint()..color = const Color(0xFF1E2A25));
    canvas.drawCircle(c + Offset(r * .42, -r * .55), r * .055, Paint()..color = const Color(0xFF1E2A25));
    _blush(canvas, c, r);
    final Paint smile = Paint()
      ..color = deep.color
      ..style = PaintingStyle.stroke
      ..strokeWidth = math.max(1.8, r * .07)
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(
      Rect.fromCenter(center: c + Offset(0, r * .12), width: r * .60, height: r * .36),
      .15,
      math.pi - .30,
      false,
      smile,
    );
  }

  void _drawPenguin(Canvas canvas, Offset c, double r) {
    final Paint blue = _gloss(
      const Color(0xFF9DE1FF),
      const Color(0xFF4F9ED8),
      const Color(0xFF2464A8),
      c,
      r,
    );
    final Paint deepBlue = Paint()..color = const Color(0xFF2E6F9F);
    final Paint belly = Paint()..color = const Color(0xFFEAF6FF);
    canvas.drawCircle(c, r * .82, blue);
    _bodyShine(canvas, c, r);
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(0, r * .19), width: r * 1.00, height: r * 1.10),
      belly,
    );
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(-r * .62, r * .08), width: r * .22, height: r * .56),
      deepBlue,
    );
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(r * .62, r * .08), width: r * .22, height: r * .56),
      deepBlue,
    );
    _eyes(canvas, c + Offset(0, -r * .10), r, y: 0);
    final Path beak = Path()
      ..moveTo(c.dx - r * .10, c.dy + r * .01)
      ..lineTo(c.dx + r * .10, c.dy + r * .01)
      ..lineTo(c.dx, c.dy + r * .15)
      ..close();
    canvas.drawPath(beak, Paint()..color = const Color(0xFFFF9B2F));
  }

  void _drawDog(Canvas canvas, Offset c, double r) {
    final Paint ear = Paint()..color = const Color(0xFF7453B7);
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(-r * .62, -r * .18), width: r * .42, height: r * .72),
      ear,
    );
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(r * .62, -r * .18), width: r * .42, height: r * .72),
      ear,
    );
    canvas.drawCircle(
      c,
      r * .82,
      _gloss(
        const Color(0xFFE4D7FF),
        const Color(0xFFBFA8F2),
        const Color(0xFF8060C7),
        c,
        r,
      ),
    );
    _bodyShine(canvas, c, r);
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(r * .26, -r * .18), width: r * .36, height: r * .46),
      ear,
    );
    _eyes(canvas, c, r);
    _blush(canvas, c, r);
    canvas.drawCircle(c + Offset(0, r * .16), r * .09, Paint()..color = const Color(0xFF3E315A));
  }

  void _drawBunny(Canvas canvas, Offset c, double r) {
    final Paint body = _gloss(
      const Color(0xFFFFE2EE),
      const Color(0xFFFFA7C7),
      const Color(0xFFE66B9B),
      c,
      r,
    );
    final Paint inner = Paint()..color = const Color(0xFFFF6F9F);
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(-r * .28, -r * .86), width: r * .32, height: r * .88),
      body,
    );
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(r * .28, -r * .86), width: r * .32, height: r * .88),
      body,
    );
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(-r * .28, -r * .86), width: r * .11, height: r * .55),
      inner,
    );
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(r * .28, -r * .86), width: r * .11, height: r * .55),
      inner,
    );
    canvas.drawCircle(c + Offset(0, r * .04), r * .76, body);
    _bodyShine(canvas, c + Offset(0, r * .04), r * .92);
    _eyes(canvas, c + Offset(0, r * .02), r);
    _blush(canvas, c, r);
    canvas.drawCircle(c + Offset(0, r * .16), r * .06, Paint()..color = const Color(0xFF8C3F61));
  }
}

// V52: 5v5 front/back formation, half-size characters, bottom controls, visible attack FX.
