import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../game/game_controller.dart';

class ConnectBattleScreen extends StatefulWidget {
  final GameController controller;
  final int stageId;

  const ConnectBattleScreen({
    super.key,
    required this.controller,
    required this.stageId,
  });

  @override
  State<ConnectBattleScreen> createState() => _ConnectBattleScreenState();
}

class _DummyEnemy {
  _DummyEnemy(this.pos, this.phase);
  Offset pos;
  final double phase;
}

class _ConnectBattleScreenState extends State<ConnectBattleScreen> {
  Timer? _timer;
  DateTime _last = DateTime.now();
  Size _field = Size.zero;

  Offset _hero = const Offset(190, 360);
  Offset _velocity = Offset.zero;
  Offset _target = const Offset(190, 360);
  bool _holding = false;
  double _time = 0;
  double _tilt = 0;
  final List<Offset> _trail = <Offset>[];
  final List<_DummyEnemy> _enemies = <_DummyEnemy>[];

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(milliseconds: 16), (_) => _tick());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _seed(Size size) {
    if (_field != Size.zero) return;
    _field = size;
    _hero = Offset(size.width * .5, size.height * .72);
    _target = _hero;
    _enemies.addAll(<_DummyEnemy>[
      _DummyEnemy(Offset(size.width * .22, size.height * .28), .2),
      _DummyEnemy(Offset(size.width * .50, size.height * .20), 1.5),
      _DummyEnemy(Offset(size.width * .78, size.height * .31), 2.8),
    ]);
  }

  void _tick() {
    if (!mounted || _field == Size.zero) return;
    final now = DateTime.now();
    double dt = now.difference(_last).inMicroseconds / 1000000;
    _last = now;
    dt = dt.clamp(0.0, .035);
    _time += dt;

    // Spring-like follow: the finger is a target, not the character position.
    final Offset delta = _target - _hero;
    final double spring = _holding ? 28.0 : 12.0;
    final double damping = _holding ? 8.2 : 6.8;
    _velocity += delta * spring * dt;
    _velocity *= math.exp(-damping * dt);

    // Keep enough inertia to overshoot on sudden stops, but cap extreme speed.
    final double speed = _velocity.distance;
    if (speed > 1050) _velocity = _velocity / speed * 1050;
    _hero += _velocity * dt;
    _hero = Offset(
      _hero.dx.clamp(38.0, _field.width - 38.0),
      _hero.dy.clamp(54.0, _field.height - 48.0),
    );

    final double wantedTilt = (_velocity.dx / 520).clamp(-.34, .34);
    _tilt += (wantedTilt - _tilt) * math.min(1, dt * 10);

    if (_velocity.distance > 90) {
      _trail.insert(0, _hero);
      if (_trail.length > 8) _trail.removeLast();
    } else if (_trail.isNotEmpty && (_time * 30).floor().isEven) {
      _trail.removeLast();
    }
    setState(() {});
  }

  void _down(Offset p) {
    setState(() {
      _holding = true;
      _target = p;
    });
  }

  void _move(Offset p) {
    _holding = true;
    _target = p;
  }

  void _up() {
    // On release, stop pulling. The target becomes the current position so
    // residual velocity produces a tiny natural overshoot before settling.
    _holding = false;
    _target = _hero;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF122433),
      body: SafeArea(
        child: Column(
          children: <Widget>[
            SizedBox(
              height: 64,
              child: Row(
                children: <Widget>[
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    '冒険  STAGE ${widget.stageId}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const Spacer(),
                  const Padding(
                    padding: EdgeInsets.only(right: 18),
                    child: Text(
                      '操作テスト',
                      style: TextStyle(
                        color: Color(0xFFFFD978),
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: LayoutBuilder(
                builder: (context, c) {
                  final size = Size(c.maxWidth, c.maxHeight);
                  _seed(size);
                  return Listener(
                    behavior: HitTestBehavior.opaque,
                    onPointerDown: (e) => _down(e.localPosition),
                    onPointerMove: (e) => _move(e.localPosition),
                    onPointerUp: (_) => _up(),
                    onPointerCancel: (_) => _up(),
                    child: CustomPaint(
                      size: Size.infinite,
                      painter: _BattlePrototypePainter(
                        hero: _hero,
                        velocity: _velocity,
                        tilt: _tilt,
                        time: _time,
                        holding: _holding,
                        target: _target,
                        trail: _trail,
                        enemies: _enemies,
                      ),
                    ),
                  );
                },
              ),
            ),
            Container(
              height: 58,
              alignment: Alignment.center,
              color: const Color(0xFF0D1C28),
              child: const Text(
                '指で動かして、剣士の重さと追従感を確認',
                style: TextStyle(
                  color: Colors.white70,
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BattlePrototypePainter extends CustomPainter {
  const _BattlePrototypePainter({
    required this.hero,
    required this.velocity,
    required this.tilt,
    required this.time,
    required this.holding,
    required this.target,
    required this.trail,
    required this.enemies,
  });

  final Offset hero;
  final Offset velocity;
  final double tilt;
  final double time;
  final bool holding;
  final Offset target;
  final List<Offset> trail;
  final List<_DummyEnemy> enemies;

  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()..color = const Color(0xFF173B3B);
    canvas.drawRect(Offset.zero & size, bg);

    // Subtle battlefield rings keep depth without looking like a puzzle board.
    final ring = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..color = Colors.white.withValues(alpha: .045);
    for (double r = 90; r < size.width * .85; r += 82) {
      canvas.drawCircle(Offset(size.width / 2, size.height * .48), r, ring);
    }

    for (final e in enemies) {
      _drawMonster(canvas, e.pos + Offset(0, math.sin(time * 2 + e.phase) * 3));
    }

    final speed = velocity.distance;
    if (speed > 220) {
      for (var i = trail.length - 1; i >= 0; i--) {
        final alpha = (1 - i / math.max(1, trail.length)) * .10;
        _drawHero(canvas, trail[i], tilt, time, alpha: alpha, ghost: true);
      }
    }

    if (holding) {
      canvas.drawCircle(
        target,
        16,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..color = Colors.white.withValues(alpha: .16),
      );
    }

    _drawHero(canvas, hero, tilt, time, alpha: 1);
  }

  void _drawHero(
    Canvas canvas,
    Offset p,
    double lean,
    double t, {
    required double alpha,
    bool ghost = false,
  }) {
    canvas.save();

    final speed = velocity.distance;
    final moveRatio = (speed / 420).clamp(0.0, 1.0).toDouble();
    final facing = (velocity.dx / 360).clamp(-1.0, 1.0).toDouble();
    final sideTurn = facing.abs();
    final stepPhase = t * (7.5 + moveRatio * 5.0);
    final stride = ghost ? 0.0 : math.sin(stepPhase) * 3.4 * moveRatio;
    final bob = ghost ? 0.0 : math.sin(stepPhase * 2) * 1.7 * moveRatio;
    final shoulderRock = ghost ? 0.0 : math.sin(stepPhase) * .045 * moveRatio;

    canvas.translate(p.dx, p.dy + bob);
    canvas.rotate(lean * .72 + shoulderRock);
    canvas.scale(1.08, 1.08);

    Color c(Color color, [double mul = 1]) =>
        color.withValues(alpha: (alpha * mul).clamp(0.0, 1.0));

    final outline = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0
      ..strokeJoin = StrokeJoin.round
      ..strokeCap = StrokeCap.round
      ..color = c(const Color(0xFF172333), .74);

    // Soft ground shadow gives the fighter a grounded JRPG-sprite feeling.
    canvas.drawOval(
      Rect.fromCenter(center: const Offset(0, 31), width: 48, height: 12),
      Paint()..color = Colors.black.withValues(alpha: alpha * .24),
    );

    // Short cape/scarf: anchored at both shoulders and dragged by movement.
    final capePull = Offset(
      (-velocity.dx * .018).clamp(-15.0, 15.0),
      (-velocity.dy * .006).clamp(-6.0, 8.0),
    );
    final cape = Path()
      ..moveTo(-13, -12)
      ..quadraticBezierTo(-22 + capePull.dx * .35, -4 + capePull.dy,
          -26 + capePull.dx, 10 + capePull.dy)
      ..quadraticBezierTo(-9 + capePull.dx * .45, 8, -3, 4)
      ..lineTo(5, -9)
      ..close();
    canvas.drawPath(cape, Paint()..color = c(const Color(0xFFB83F52)));
    canvas.drawPath(cape, outline);

    // Legs are tapered rather than rectangular. The alternating stance reads
    // as a tiny run cycle even when the finger movement is subtle.
    void leg(double x, double dy, bool near) {
      final pants = Path()
        ..moveTo(x - 5, 12 + dy)
        ..lineTo(x + 5, 12 + dy)
        ..lineTo(x + 4, 28 + dy)
        ..quadraticBezierTo(x, 31 + dy, x - 4, 28 + dy)
        ..close();
      canvas.drawPath(
        pants,
        Paint()..color = c(near ? const Color(0xFF314663) : const Color(0xFF26384F)),
      );
      canvas.drawPath(pants, outline);

      final boot = RRect.fromRectAndRadius(
        Rect.fromLTWH(x - 7, 25 + dy, 14, 8),
        const Radius.circular(4),
      );
      canvas.drawRRect(boot, Paint()..color = c(const Color(0xFF4D342E)));
      canvas.drawRRect(boot, outline);
    }

    leg(-8.5, stride, facing <= 0);
    leg(8.5, -stride, facing >= 0);

    // Body silhouette: shoulders taper into a narrow waist instead of looking
    // like stacked rectangles.
    canvas.save();
    canvas.translate(facing * 2.2, 0);
    final torso = Path()
      ..moveTo(-19, -8)
      ..quadraticBezierTo(-16, -15, -9, -16)
      ..lineTo(9, -16)
      ..quadraticBezierTo(16, -15, 19, -8)
      ..lineTo(16, 17)
      ..quadraticBezierTo(0, 22, -16, 17)
      ..close();
    canvas.drawPath(torso, Paint()..color = c(const Color(0xFF416FA3)));
    canvas.drawPath(torso, outline);

    // Small back armor plate, collar and belt add detail without turning the
    // prototype into a fixed image asset.
    final plate = Path()
      ..moveTo(-10, -7)
      ..lineTo(10, -7)
      ..lineTo(8, 8)
      ..quadraticBezierTo(0, 13, -8, 8)
      ..close();
    canvas.drawPath(plate, Paint()..color = c(const Color(0xFF91A8BA)));
    canvas.drawPath(
      plate,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.4
        ..color = c(const Color(0xFF61798E)),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(const Rect.fromLTWH(-8, -16, 16, 6), const Radius.circular(3)),
      Paint()..color = c(const Color(0xFFCFD9E0)),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(const Rect.fromLTWH(-17, 10, 34, 6), const Radius.circular(2)),
      Paint()..color = c(const Color(0xFF75482F)),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(const Rect.fromLTWH(-3, 9, 6, 8), const Radius.circular(2)),
      Paint()..color = c(const Color(0xFFE2B750)),
    );
    canvas.restore();

    // Arms are articulated as upper-arm + glove. The sword arm reacts more to
    // movement so the weapon feels attached to the fighter rather than pasted on.
    final swordArmLift = (-velocity.dy / 900).clamp(-.10, .16).toDouble();
    final armSwing = ghost ? 0.0 : math.sin(stepPhase) * .12 * moveRatio;

    canvas.save();
    canvas.translate(-16 + facing * 1.6, -6);
    canvas.rotate(-armSwing * .7 + facing * .05);
    final leftArm = RRect.fromRectAndRadius(
      const Rect.fromLTWH(-5, 0, 10, 25),
      const Radius.circular(5),
    );
    canvas.drawRRect(leftArm, Paint()..color = c(const Color(0xFF315B85)));
    canvas.drawRRect(leftArm, outline);
    canvas.drawCircle(const Offset(0, 22), 5, Paint()..color = c(const Color(0xFF6B4937)));
    canvas.restore();

    canvas.save();
    canvas.translate(16 + facing * 2.0, -7);
    canvas.rotate(.20 + swordArmLift + armSwing * .55 - facing * .04);
    final rightArm = RRect.fromRectAndRadius(
      const Rect.fromLTWH(-5, 0, 10, 24),
      const Radius.circular(5),
    );
    canvas.drawRRect(rightArm, Paint()..color = c(const Color(0xFF4A7EB2)));
    canvas.drawRRect(rightArm, outline);
    canvas.drawCircle(const Offset(0, 22), 5.2, Paint()..color = c(const Color(0xFF6B4937)));
    canvas.restore();

    // Sword. Keep its resting direction strongly upper-right, while adding a
    // restrained lag/swing based on velocity so it visibly responds to motion.
    final swingWave = ghost ? 0.0 : math.sin(stepPhase * .92) * .10 * moveRatio;
    final inertiaSwing = ((-velocity.dy + velocity.dx * .18) / 1600)
        .clamp(-.13, .13)
        .toDouble();
    final swordAngle = (-.68 + swingWave + inertiaSwing).clamp(-.88, -.42).toDouble();

    canvas.save();
    canvas.translate(19 + facing * 2.4, 9);
    canvas.rotate(swordAngle);

    // A broader fantasy blade gives a clearer silhouette at phone size.
    final blade = Path()
      ..moveTo(-4, 2)
      ..lineTo(4, 2)
      ..lineTo(5, -46)
      ..lineTo(0, -59)
      ..lineTo(-5, -46)
      ..close();
    canvas.drawPath(blade, Paint()..color = c(const Color(0xFFF4F8FA)));
    canvas.drawPath(blade, outline);
    canvas.drawPath(
      Path()
        ..moveTo(0, -4)
        ..lineTo(0, -49),
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.4
        ..color = c(const Color(0xFFB7CBD8)),
    );
    final guard = RRect.fromRectAndRadius(
      const Rect.fromLTWH(-12, -1, 24, 6),
      const Radius.circular(3),
    );
    canvas.drawRRect(guard, Paint()..color = c(const Color(0xFFE7B643)));
    canvas.drawRRect(guard, outline);
    final grip = RRect.fromRectAndRadius(
      const Rect.fromLTWH(-3, 4, 6, 16),
      const Radius.circular(2),
    );
    canvas.drawRRect(grip, Paint()..color = c(const Color(0xFF6D4433)));
    canvas.drawRRect(grip, outline);
    canvas.drawCircle(const Offset(0, 21), 4, Paint()..color = c(const Color(0xFFE7B643)));
    canvas.restore();

    // Head and hair. Default is a clear back-of-head. Horizontal movement shifts
    // the head and exposes only the appropriate side ear/cheek edge.
    canvas.save();
    canvas.translate(facing * 3.4, -1.0);
    canvas.rotate(facing * .07 * sideTurn);

    canvas.drawCircle(
      const Offset(0, -28),
      18.3,
      Paint()..color = c(const Color(0xFFF2BE91)),
    );

    final hair = Path()
      ..moveTo(-18.5, -29)
      ..quadraticBezierTo(-18, -46, -7, -50)
      ..quadraticBezierTo(2, -54, 12, -48)
      ..quadraticBezierTo(20, -42, 19, -28)
      ..lineTo(17, -18)
      ..lineTo(11, -12)
      ..lineTo(7, -20)
      ..lineTo(2, -13)
      ..lineTo(-3, -20)
      ..lineTo(-8, -13)
      ..lineTo(-13, -21)
      ..lineTo(-18, -17)
      ..quadraticBezierTo(-20, -22, -18.5, -29)
      ..close();
    canvas.drawPath(hair, Paint()..color = c(const Color(0xFF49352E)));
    canvas.drawPath(hair, outline);

    // Small highlight separates the hair mass from the dark battlefield.
    final hairHighlight = Path()
      ..moveTo(-9, -44)
      ..quadraticBezierTo(-2, -50, 7, -47)
      ..quadraticBezierTo(11, -46, 13, -42);
    canvas.drawPath(
      hairHighlight,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.2
        ..strokeCap = StrokeCap.round
        ..color = c(const Color(0xFF675047), .75),
    );

    if (sideTurn > .14) {
      final side = facing.sign;
      final earCenter = Offset(side * 17.2, -28.0);
      canvas.drawOval(
        Rect.fromCenter(center: earCenter, width: 5.0, height: 7.5),
        Paint()..color = c(const Color(0xFFE6AA7E)),
      );
      canvas.drawArc(
        Rect.fromCenter(center: earCenter, width: 3.0, height: 4.5),
        -.8,
        1.6,
        false,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1
          ..color = c(const Color(0xFFB77A62)),
      );
    }
    canvas.restore();

    // Neck/collar overlaps the lower hair to visually connect head and torso.
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(center: Offset(facing * 2.0, -11), width: 18, height: 7),
        const Radius.circular(3),
      ),
      Paint()..color = c(const Color(0xFFD8E1E6)),
    );

    canvas.restore();
  }

  void _drawMonster(Canvas canvas, Offset p) {
    canvas.save();
    canvas.translate(p.dx, p.dy);
    canvas.drawOval(const Rect.fromLTWH(-22, 19, 44, 10), Paint()..color = Colors.black.withValues(alpha: .18));

    // Horned slime/beast hybrid: still simple, but no round puzzle-face sprite.
    final body = Path()
      ..moveTo(-24, 20)
      ..quadraticBezierTo(-27, -8, -13, -18)
      ..lineTo(-18, -31)
      ..lineTo(-4, -22)
      ..quadraticBezierTo(0, -25, 4, -22)
      ..lineTo(18, -31)
      ..lineTo(13, -17)
      ..quadraticBezierTo(28, -6, 24, 20)
      ..quadraticBezierTo(0, 31, -24, 20)
      ..close();
    canvas.drawPath(body, Paint()..color = const Color(0xFF7650A4));
    canvas.drawPath(body, Paint()..style = PaintingStyle.stroke..strokeWidth = 2..color = const Color(0xFF4C3473));
    canvas.drawCircle(const Offset(-8, -5), 3, Paint()..color = const Color(0xFFFFE65C));
    canvas.drawCircle(const Offset(8, -5), 3, Paint()..color = const Color(0xFFFFE65C));
    canvas.drawCircle(const Offset(-8, -5), 1.4, Paint()..color = const Color(0xFF241B31));
    canvas.drawCircle(const Offset(8, -5), 1.4, Paint()..color = const Color(0xFF241B31));
    canvas.drawLine(const Offset(-7, 8), const Offset(7, 8), Paint()..strokeWidth = 2..color = const Color(0xFF3A274E));
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _BattlePrototypePainter oldDelegate) => true;
}
