import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../game/game_controller.dart';

class ConnectBattleScreen extends StatefulWidget {
  final GameController controller;
  final int stageId;

  const ConnectBattleScreen({
    super.key,
    required this.controller,
    required this.stageId,
  });

  @override
  State<ConnectBattleScreen> createState() => _ConnectBattleScreenState();
}

class _DummyEnemy {
  _DummyEnemy(this.pos, this.phase);
  Offset pos;
  final double phase;
}

class _ConnectBattleScreenState extends State<ConnectBattleScreen> {
  Timer? _timer;
  DateTime _last = DateTime.now();
  Size _field = Size.zero;

  Offset _hero = const Offset(190, 360);
  Offset _velocity = Offset.zero;
  Offset _target = const Offset(190, 360);
  bool _holding = false;
  double _time = 0;
  double _tilt = 0;
  final List<_DummyEnemy> _enemies = <_DummyEnemy>[];

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(milliseconds: 16), (_) => _tick());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _seed(Size size) {
    if (_field != Size.zero) return;
    _field = size;
    _hero = Offset(size.width * .50, size.height * .74);
    _target = _hero;
    _enemies.addAll(<_DummyEnemy>[
      _DummyEnemy(Offset(size.width * .22, size.height * .29), .2),
      _DummyEnemy(Offset(size.width * .50, size.height * .20), 1.5),
      _DummyEnemy(Offset(size.width * .78, size.height * .31), 2.8),
    ]);
  }

  void _tick() {
    if (!mounted || _field == Size.zero) return;
    final now = DateTime.now();
    double dt = now.difference(_last).inMicroseconds / 1000000;
    _last = now;
    dt = dt.clamp(0.0, .035);
    _time += dt;

    final delta = _target - _hero;
    final spring = _holding ? 28.0 : 12.0;
    final damping = _holding ? 8.2 : 6.8;
    _velocity += delta * spring * dt;
    _velocity *= math.exp(-damping * dt);

    final speed = _velocity.distance;
    if (speed > 1050) _velocity = _velocity / speed * 1050;
    _hero += _velocity * dt;
    _hero = Offset(
      _hero.dx.clamp(44.0, _field.width - 44.0),
      _hero.dy.clamp(58.0, _field.height - 52.0),
    );

    final wantedTilt = (_velocity.dx / 650).clamp(-.15, .15);
    _tilt += (wantedTilt - _tilt) * math.min(1, dt * 10);
    setState(() {});
  }

  void _down(Offset p) {
    setState(() {
      _holding = true;
      _target = p;
    });
  }

  void _move(Offset p) {
    _holding = true;
    _target = p;
  }

  void _up() {
    _holding = false;
    _target = _hero;
  }

  String get _heroFacing {
    final speed = _velocity.distance;
    if (speed < 65) return 'back';

    final ax = _velocity.dx.abs();
    final ay = _velocity.dy.abs();
    if (ax > ay * .82) {
      return _velocity.dx >= 0 ? 'right' : 'left';
    }

    // Screen Y grows downward: moving toward the player shows her face,
    // moving toward the enemies keeps the rear view.
    return _velocity.dy > 0 ? 'front' : 'back';
  }

  int get _walkFrame {
    if (_velocity.distance < 65) return 0;
    return ((_time * 7).floor() & 1);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF142536),
      body: SafeArea(
        child: Column(
          children: <Widget>[
            SizedBox(
              height: 64,
              child: Row(
                children: <Widget>[
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    '冒険  STAGE ${widget.stageId}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const Spacer(),
                  const Padding(
                    padding: EdgeInsets.only(right: 18),
                    child: Text(
                      '操作テスト',
                      style: TextStyle(
                        color: Color(0xFFFFD978),
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: LayoutBuilder(
                builder: (context, c) {
                  final size = Size(c.maxWidth, c.maxHeight);
                  _seed(size);
                  return Listener(
                    behavior: HitTestBehavior.opaque,
                    onPointerDown: (e) => _down(e.localPosition),
                    onPointerMove: (e) => _move(e.localPosition),
                    onPointerUp: (_) => _up(),
                    onPointerCancel: (_) => _up(),
                    child: Stack(
                      fit: StackFit.expand,
                      children: <Widget>[
                        const CustomPaint(painter: _BrightFieldPainter()),
                        ..._buildEnemies(),
                        if (_holding)
                          Positioned(
                            left: _target.dx - 14,
                            top: _target.dy - 14,
                            child: IgnorePointer(
                              child: Container(
                                width: 28,
                                height: 28,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: Colors.white.withValues(alpha: .28),
                                    width: 2,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        _buildHero(),
                      ],
                    ),
                  );
                },
              ),
            ),
            Container(
              height: 58,
              alignment: Alignment.center,
              color: const Color(0xFF0D1C28),
              child: const Text(
                '指で動かして、ちび剣士の追従感を確認',
                style: TextStyle(
                  color: Colors.white70,
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildEnemies() {
    return _enemies.map((e) {
      final bounce = math.sin(_time * 2.4 + e.phase) * 3;
      final frame = (((_time * 3 + e.phase).floor()) & 1);
      const w = 64.0;
      const h = 64.0;
      return Positioned(
        left: e.pos.dx - w / 2,
        top: e.pos.dy - h / 2 + bounce,
        child: IgnorePointer(
          child: Image.asset(
            'assets/sprites/enemy_forest_$frame.png',
            width: w,
            height: h,
            fit: BoxFit.contain,
            filterQuality: FilterQuality.none,
          ),
        ),
      );
    }).toList();
  }

  Widget _buildHero() {
    const w = 96.0;
    const h = 116.0;
    final speedRatio = (_velocity.distance / 430).clamp(0.0, 1.0);
    final bob = _velocity.distance < 65
        ? math.sin(_time * 2.2) * .8
        : math.sin(_time * 13) * 1.8 * speedRatio;

    // The sword has its own small delayed swing instead of being baked into
    // the sprite. This keeps it on the outside of the body and makes the
    // character feel less like a rigid card being dragged around.
    final lateralSwing = (_velocity.dx / 760).clamp(-.11, .11);
    final verticalSwing = (_velocity.dy / 900).clamp(-.07, .07);
    final runPulse = math.sin(_time * 11.5) * .035 * speedRatio;
    final swordAngle = -.84 + lateralSwing + verticalSwing + runPulse;

    final heroSprite = Image.asset(
      'assets/sprites/hero_${_heroFacing}_$_walkFrame.png',
      width: w,
      height: h,
      fit: BoxFit.contain,
      filterQuality: FilterQuality.medium,
    );

    return Positioned(
      left: _hero.dx - w / 2,
      top: _hero.dy - h * .66 + bob,
      child: IgnorePointer(
        child: Transform.rotate(
          angle: _tilt,
          alignment: Alignment.bottomCenter,
          child: SizedBox(
            width: w,
            height: h,
            child: Stack(
              clipBehavior: Clip.none,
              children: <Widget>[
                Positioned.fill(child: heroSprite),
                Positioned.fill(
                  child: CustomPaint(
                    painter: _HeroSwordPainter(
                      angle: swordAngle,
                      speedRatio: speedRatio,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _HeroSwordPainter extends CustomPainter {
  const _HeroSwordPainter({required this.angle, required this.speedRatio});

  final double angle;
  final double speedRatio;

  @override
  void paint(Canvas canvas, Size size) {
    final grip = Offset(size.width * .72, size.height * .69);
    canvas.save();
    canvas.translate(grip.dx, grip.dy);
    canvas.rotate(angle);

    // Small shadow behind the weapon helps it read clearly on pale fields.
    final shadow = Paint()
      ..color = const Color(0xFF553D62).withValues(alpha: .20)
      ..strokeCap = StrokeCap.round
      ..strokeWidth = 8;
    canvas.drawLine(const Offset(-7, 4), const Offset(48, 4), shadow);

    final blade = Path()
      ..moveTo(4, -5)
      ..lineTo(52, -4)
      ..lineTo(63, 0)
      ..lineTo(52, 4)
      ..lineTo(4, 5)
      ..close();
    canvas.drawPath(blade, Paint()..color = const Color(0xFFF8FBFF));
    canvas.drawPath(
      blade,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = const Color(0xFF5B5070),
    );
    canvas.drawLine(
      const Offset(12, -2),
      const Offset(51, -1),
      Paint()
        ..strokeCap = StrokeCap.round
        ..strokeWidth = 1.5
        ..color = const Color(0xFFC7DDF5),
    );

    final guard = Paint()
      ..color = const Color(0xFFE9B64D)
      ..strokeCap = StrokeCap.round
      ..strokeWidth = 7;
    canvas.drawLine(const Offset(-2, -10), const Offset(-2, 10), guard);
    canvas.drawLine(
      const Offset(-4, 0),
      const Offset(-18, 0),
      Paint()
        ..color = const Color(0xFF8A536A)
        ..strokeCap = StrokeCap.round
        ..strokeWidth = 7,
    );
    canvas.drawCircle(
      const Offset(-19, 0),
      4.5 + speedRatio * .5,
      Paint()..color = const Color(0xFFF2C35B),
    );
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _HeroSwordPainter oldDelegate) =>
      oldDelegate.angle != angle || oldDelegate.speedRatio != speedRatio;
}


class _BrightFieldPainter extends CustomPainter {
  const _BrightFieldPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final bg = const LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: <Color>[
        Color(0xFFEAF6D8),
        Color(0xFFD8EDBE),
        Color(0xFFC7E4AA),
      ],
    ).createShader(rect);
    canvas.drawRect(rect, Paint()..shader = bg);

    // Soft layered grass so the field reads as a place, not a flat board.
    final farGrass = Paint()..color = const Color(0xFFB6D998).withValues(alpha: .42);
    final nearGrass = Paint()..color = const Color(0xFF94C77B).withValues(alpha: .23);
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(size.width * .11, size.height * .16),
        width: size.width * .34,
        height: 76,
      ),
      farGrass,
    );
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(size.width * .88, size.height * .20),
        width: size.width * .38,
        height: 86,
      ),
      farGrass,
    );
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(size.width * .10, size.height * .77),
        width: size.width * .42,
        height: 110,
      ),
      nearGrass,
    );
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(size.width * .91, size.height * .71),
        width: size.width * .43,
        height: 104,
      ),
      nearGrass,
    );

    // A narrow winding path keeps the battlefield readable while giving depth.
    final path = Path()
      ..moveTo(size.width * .38, size.height)
      ..cubicTo(
        size.width * .36,
        size.height * .82,
        size.width * .52,
        size.height * .69,
        size.width * .50,
        size.height * .52,
      )
      ..cubicTo(
        size.width * .47,
        size.height * .36,
        size.width * .58,
        size.height * .22,
        size.width * .52,
        0,
      )
      ..lineTo(size.width * .64, 0)
      ..cubicTo(
        size.width * .69,
        size.height * .20,
        size.width * .57,
        size.height * .37,
        size.width * .61,
        size.height * .55,
      )
      ..cubicTo(
        size.width * .66,
        size.height * .73,
        size.width * .48,
        size.height * .84,
        size.width * .55,
        size.height,
      )
      ..close();
    canvas.drawPath(
      path,
      Paint()..color = const Color(0xFFF0DDAA).withValues(alpha: .62),
    );
    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3
        ..color = const Color(0xFFD4C58E).withValues(alpha: .18),
    );

    // Small grass blades around the edges. No giant circles/rings.
    final blade = Paint()
      ..color = const Color(0xFF79AF67).withValues(alpha: .43)
      ..strokeWidth = 1.6
      ..strokeCap = StrokeCap.round;
    const grassSeeds = <Offset>[
      Offset(.07, .09), Offset(.18, .24), Offset(.91, .10), Offset(.82, .32),
      Offset(.09, .53), Offset(.20, .67), Offset(.90, .57), Offset(.82, .84),
      Offset(.12, .90), Offset(.72, .91), Offset(.95, .38), Offset(.05, .36),
    ];
    for (final seed in grassSeeds) {
      final p = Offset(seed.dx * size.width, seed.dy * size.height);
      canvas.drawLine(p, p + const Offset(-4, -9), blade);
      canvas.drawLine(p, p + const Offset(1, -11), blade);
      canvas.drawLine(p, p + const Offset(5, -7), blade);
    }

    // Tiny flowers and stones add charm but stay away from combat silhouettes.
    final petal = Paint()..color = const Color(0xFFFFFAF3).withValues(alpha: .95);
    final flowerCenter = Paint()..color = const Color(0xFFF0BD59);
    final pinkPetal = Paint()..color = const Color(0xFFF7C2D5).withValues(alpha: .88);
    const flowerSeeds = <Offset>[
      Offset(.18, .14), Offset(.10, .43), Offset(.86, .13), Offset(.90, .45),
      Offset(.16, .83), Offset(.84, .79), Offset(.29, .61), Offset(.72, .62),
    ];
    for (var i = 0; i < flowerSeeds.length; i++) {
      final p = Offset(flowerSeeds[i].dx * size.width, flowerSeeds[i].dy * size.height);
      final pp = i.isOdd ? pinkPetal : petal;
      canvas.drawCircle(p + const Offset(-3, 0), 2.5, pp);
      canvas.drawCircle(p + const Offset(3, 0), 2.5, pp);
      canvas.drawCircle(p + const Offset(0, -3), 2.5, pp);
      canvas.drawCircle(p + const Offset(0, 3), 2.5, pp);
      canvas.drawCircle(p, 1.7, flowerCenter);
    }

    final stone = Paint()..color = const Color(0xFF91A98B).withValues(alpha: .30);
    const stones = <Offset>[Offset(.28, .35), Offset(.74, .27), Offset(.22, .74), Offset(.78, .88)];
    for (final seed in stones) {
      final p = Offset(seed.dx * size.width, seed.dy * size.height);
      canvas.drawOval(Rect.fromCenter(center: p, width: 15, height: 8), stone);
      canvas.drawOval(
        Rect.fromCenter(center: p + const Offset(-2, -2), width: 7, height: 3),
        Paint()..color = Colors.white.withValues(alpha: .18),
      );
    }

    // Gentle sunlight from the upper-right; kept very subtle for readability.
    final light = RadialGradient(
      center: const Alignment(.72, -.72),
      radius: .92,
      colors: <Color>[
        const Color(0xFFFFF6C9).withValues(alpha: .16),
        Colors.transparent,
      ],
    ).createShader(rect);
    canvas.drawRect(rect, Paint()..shader = light);
  }

  @override
  bool shouldRepaint(covariant _BrightFieldPainter oldDelegate) => false;
}
