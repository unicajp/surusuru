import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../game/game_controller.dart';
import '../sfx_manager.dart';

class ConnectBattleScreen extends StatefulWidget {
  final GameController controller;
  final int stageId;

  const ConnectBattleScreen({
    super.key,
    required this.controller,
    required this.stageId,
  });

  @override
  State<ConnectBattleScreen> createState() => _ConnectBattleScreenState();
}

enum _EnemyWeight { small, medium, large }

class _Enemy {
  _Enemy({
    required this.x,
    required this.y,
    required this.phase,
    required this.type,
    required this.weight,
    required this.size,
    required this.hp,
  }) : maxHp = hp;

  double x;
  double y;
  final double phase;
  final int type;
  final _EnemyWeight weight;
  final double size;
  int hp;
  final int maxHp;
  Offset velocity = Offset.zero;
  double pop = 1.0;
  double flash = 0.0;
  int lastHitMs = 0;
  int lastAttackSerial = -1;
}

class _SlashFx {
  _SlashFx(this.position, this.life, this.power, this.faceRight);
  Offset position;
  double life;
  final double power;
  final bool faceRight;
}

class _ConnectBattleScreenState extends State<ConnectBattleScreen> {
  Timer? _timer;
  DateTime _last = DateTime.now();
  Size _field = Size.zero;

  Offset _hero = const Offset(160, 420);
  Offset _target = const Offset(160, 420);
  Offset _velocity = Offset.zero;
  Offset _downPoint = Offset.zero;
  bool _holding = false;
  bool _attack = false;
  double _attackTime = 0;
  double _time = 0;
  double _scroll = 0;
  double _furthestScroll = 0;
  double _checkpointFloor = 0;
  double _startHeroX = 0;
  static const double _stageLength = 2800;
  static const double _maxBacktrack = 650;
  double _tilt = 0;
  bool _faceRight = true;
  int _attackSerial = 0;
  double _impactDrag = 0;
  double _hitStop = 0;
  double _screenShake = 0;
  int _defeated = 0;
  final math.Random _rng = math.Random();

  final List<_Enemy> _enemies = <_Enemy>[];
  final List<_SlashFx> _slashFx = <_SlashFx>[];

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(milliseconds: 16), (_) => _tick());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _seed(Size size) {
    if (_field != Size.zero) return;
    _field = size;
    _hero = Offset(size.width * .36, size.height * .70);
    _target = _hero;
    _startHeroX = _hero.dx;
    _enemies.addAll(<_Enemy>[
      _Enemy(x: size.width * .78, y: size.height * .70, phase: .2, type: 0, weight: _EnemyWeight.small, size: 48, hp: 1),
      _Enemy(x: size.width * 1.02, y: size.height * .67, phase: 1.1, type: 4, weight: _EnemyWeight.small, size: 50, hp: 1),
      _Enemy(x: size.width * 1.28, y: size.height * .72, phase: 2.0, type: 2, weight: _EnemyWeight.small, size: 48, hp: 1),
      _Enemy(x: size.width * 1.55, y: size.height * .68, phase: 2.8, type: 3, weight: _EnemyWeight.medium, size: 72, hp: 3),
      _Enemy(x: size.width * 1.88, y: size.height * .71, phase: 3.6, type: 1, weight: _EnemyWeight.medium, size: 76, hp: 3),
      _Enemy(x: size.width * 2.28, y: size.height * .69, phase: 4.4, type: 4, weight: _EnemyWeight.large, size: 118, hp: 12),
    ]);
  }

  void _tick() {
    if (!mounted || _field == Size.zero) return;
    final now = DateTime.now();
    double dt = now.difference(_last).inMicroseconds / 1000000;
    _last = now;
    dt = dt.clamp(0.0, .035);
    _time += dt;
    _hitStop = math.max(0, _hitStop - dt);
    _impactDrag = math.max(0, _impactDrag - dt * 2.8);
    _screenShake = math.max(0, _screenShake - dt * 7.0);
    for (final fx in _slashFx) { fx.life -= dt * 4.6; }
    _slashFx.removeWhere((fx) => fx.life <= 0);

    if (_attack) {
      _attackTime += dt;
      if (_attackTime >= .54) {
        _attack = false;
        _attackTime = 0;
      }
    }

    final delta = _target - _hero;

    // Finger-first follow: instead of a loose spring, steer velocity directly
    // toward the pointer. This keeps a tiny softness while removing the
    // noticeable delay between the finger and the character.
    final response = _holding ? 24.0 : 12.0;
    final velocityGain = _holding ? 13.8 : 4.8;
    final snagMultiplier = 1.0 - _impactDrag * .62;
    final desiredVelocity = delta * velocityGain * snagMultiplier;
    final follow = 1.0 - math.exp(-response * dt);
    _velocity += (desiredVelocity - _velocity) * follow;

    final speed = _velocity.distance;
    if (speed > 1650) _velocity = _velocity / speed * 1650;
    final movementScale = _hitStop > 0 ? .20 : (1.0 - _impactDrag * .28);
    _hero += _velocity * dt * movementScale;

    final minY = _field.height * .57;
    final maxY = _field.height * .80;
    _hero = Offset(
      _hero.dx.clamp(58.0, _field.width - 58.0),
      _hero.dy.clamp(minY, maxY),
    );

    if (_velocity.dx.abs() > 45) _faceRight = _velocity.dx >= 0;

    // Portrait side-scroller camera: the hero can move freely in a central
    // band. Reaching either edge scrolls the world in that direction.
    // Backtracking is allowed, but only within the recent area and never
    // behind a passed checkpoint.
    final leftAnchor = _field.width * .30;
    final rightAnchor = _field.width * .62;
    double cameraDelta = 0;

    if (_hero.dx > rightAnchor && _velocity.dx > 0) {
      cameraDelta = _hero.dx - rightAnchor;
      _hero = Offset(rightAnchor, _hero.dy);
    } else if (_hero.dx < leftAnchor && _velocity.dx < 0) {
      final requested = _hero.dx - leftAnchor; // negative
      final allowedFloor = math.max(_checkpointFloor, _furthestScroll - _maxBacktrack);
      final nextScroll = (_scroll + requested).clamp(allowedFloor, _stageLength);
      cameraDelta = nextScroll - _scroll;
      _hero = Offset(_hero.dx - cameraDelta, _hero.dy);
    }

    if (cameraDelta != 0) {
      _scroll = (_scroll + cameraDelta).clamp(0.0, _stageLength);
      for (final enemy in _enemies) {
        enemy.x -= cameraDelta;
      }
    }

    _furthestScroll = math.max(_furthestScroll, _scroll);
    if (_furthestScroll >= 1800) {
      _checkpointFloor = 1800;
    } else if (_furthestScroll >= 900) {
      _checkpointFloor = 900;
    }

    for (final enemy in _enemies) {
      if (enemy.hp <= 0) {
        if (enemy.pop < 1) enemy.pop = (enemy.pop + dt * 4.5).clamp(0.0, 1.0);
        continue;
      }
      enemy.flash = math.max(0, enemy.flash - dt * 6.5);
      final wander = Offset(math.sin(_time * .9 + enemy.phase), math.cos(_time * 1.07 + enemy.phase)) * .65;
      enemy.velocity = (enemy.velocity + wander * dt) * math.pow(.92, dt * 60).toDouble();
      enemy.x += enemy.velocity.dx * dt * 60;
      enemy.y += enemy.velocity.dy * dt * 60;
      final minEY = _field.height * .60;
      final maxEY = _field.height * .79;
      if (enemy.y < minEY || enemy.y > maxEY) {
        enemy.velocity = Offset(enemy.velocity.dx, -enemy.velocity.dy * .75);
        enemy.y = enemy.y.clamp(minEY, maxEY);
      }
      if (enemy.x < -140 && _velocity.dx > 0) {
        enemy.x = _field.width + 240 + _rng.nextDouble() * 300;
        enemy.y = _field.height * (.64 + _rng.nextDouble() * .10);
      }
    }

    if (_attack && _attackFrame >= 3 && _attackFrame <= 5) {
      _resolveSwordHits();
    }

    final wantedTilt = (_velocity.dx / 850).clamp(-.09, .09);
    _tilt += (wantedTilt - _tilt) * math.min(1, dt * 10);
    setState(() {});
  }

  void _down(Offset p) {
    _holding = true;
    _downPoint = p;
    _target = Offset(p.dx, p.dy.clamp(_field.height * .57, _field.height * .80));
  }

  void _move(Offset p) {
    _holding = true;
    _target = Offset(p.dx, p.dy.clamp(_field.height * .57, _field.height * .80));
  }

  void _up(Offset p) {
    final tap = (p - _downPoint).distance < 18;
    _holding = false;
    _target = _hero;
    if (tap) {
      _attack = true;
      _attackTime = 0;
      _attackSerial++;
      SfxManager.instance.tap();
    }
  }

  int get _runFrame => ((_time * 9.0).floor() % 5) + 1;
  int get _attackFrame => (((_attackTime / .54) * 6).floor().clamp(0, 5) as int) + 1;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF10233A),
      body: SafeArea(
        child: Column(
          children: <Widget>[
            SizedBox(
              height: 58,
              child: Row(
                children: <Widget>[
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                  ),
                  Text(
                    '冒険  STAGE ${widget.stageId}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 19,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const Spacer(),
                  const Padding(
                    padding: EdgeInsets.only(right: 14),
                    child: Text(
                      '横スクロール試作',
                      style: TextStyle(
                        color: Color(0xFFFFD978),
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: LayoutBuilder(
                builder: (context, c) {
                  final size = Size(c.maxWidth, c.maxHeight);
                  _seed(size);
                  return Listener(
                    behavior: HitTestBehavior.opaque,
                    onPointerDown: (e) => _down(e.localPosition),
                    onPointerMove: (e) => _move(e.localPosition),
                    onPointerUp: (e) => _up(e.localPosition),
                    onPointerCancel: (_) {
                      _holding = false;
                      _target = _hero;
                    },
                    child: Stack(
                      fit: StackFit.expand,
                      children: <Widget>[
                        CustomPaint(
                          painter: _SideScrollFieldPainter(scroll: _scroll),
                        ),
                        ..._buildEnemies(),
                        ..._buildSlashEffects(),
                        _buildHero(),
                        Positioned(
                          left: 12,
                          right: 12,
                          top: 10,
                          child: _buildProgressLine(),
                        ),
                        Positioned(
                          left: 14,
                          top: 70,
                          child: _hintChip('ドラッグ：移動  /  タップ：斬撃  ・  敵の重さで手応えが変化'),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
            Container(
              height: 50,
              alignment: Alignment.center,
              color: const Color(0xFF0D1C28),
              child: const Text(
                '小型はスパッ、中型はザクッ、大型はジャキジャキ引っかかる斬撃試作',
                style: TextStyle(
                  color: Colors.white70,
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _resolveSwordHits() {
    final now = DateTime.now().millisecondsSinceEpoch;
    final reach = _attackFrame == 4 ? 122.0 : 105.0;
    final centerX = _hero.dx + (_faceRight ? reach * .56 : -reach * .56);
    final centerY = _hero.dy - 57;
    final slashCenter = Offset(centerX, centerY);

    for (final enemy in _enemies) {
      if (enemy.hp <= 0) continue;
      final enemyCenter = Offset(enemy.x, enemy.y - enemy.size * .46);
      final rx = reach * .68 + enemy.size * .34;
      final ry = 54.0 + enemy.size * .30;
      final dx = (enemyCenter.dx - slashCenter.dx).abs();
      final dy = (enemyCenter.dy - slashCenter.dy).abs();
      if (dx > rx || dy > ry) continue;

      if (enemy.weight == _EnemyWeight.large) {
        if (now - enemy.lastHitMs < 78) continue;
      } else {
        if (enemy.lastAttackSerial == _attackSerial) continue;
      }

      enemy.lastHitMs = now;
      enemy.lastAttackSerial = _attackSerial;
      _hitEnemy(enemy, enemyCenter);
    }
  }

  void _hitEnemy(_Enemy enemy, Offset center) {
    enemy.hp--;
    enemy.flash = 1;
    final dir = _faceRight ? 1.0 : -1.0;
    final power = switch (enemy.weight) {
      _EnemyWeight.small => 1.0,
      _EnemyWeight.medium => 1.7,
      _EnemyWeight.large => 2.5,
    };
    enemy.velocity += Offset(dir * (enemy.weight == _EnemyWeight.small ? 8.2 : enemy.weight == _EnemyWeight.medium ? 4.9 : 2.2), -1.2 - _rng.nextDouble() * 1.5);
    _slashFx.add(_SlashFx(center, 1.0, power, _faceRight));
    _screenShake = math.max(_screenShake, enemy.weight == _EnemyWeight.small ? .18 : enemy.weight == _EnemyWeight.medium ? .38 : .72);

    switch (enemy.weight) {
      case _EnemyWeight.small:
        _hitStop = math.max(_hitStop, .012);
        _impactDrag = math.max(_impactDrag, .04);
        SfxManager.instance.chanceBattleHit();
        HapticFeedback.selectionClick();
        break;
      case _EnemyWeight.medium:
        _hitStop = math.max(_hitStop, .032);
        _impactDrag = math.max(_impactDrag, .32);
        SfxManager.instance.chanceBattleHit();
        HapticFeedback.lightImpact();
        break;
      case _EnemyWeight.large:
        _hitStop = math.max(_hitStop, .052);
        _impactDrag = math.max(_impactDrag, .72);
        SfxManager.instance.chanceBattleHit();
        HapticFeedback.mediumImpact();
        break;
    }

    if (enemy.hp <= 0) {
      enemy.pop = 0;
      _defeated++;
      SfxManager.instance.chanceEnemyDown();
      HapticFeedback.heavyImpact();
      _hitStop = math.max(_hitStop, enemy.weight == _EnemyWeight.large ? .095 : .045);
      _screenShake = 1;
    }
  }

  Widget _buildProgressLine() {
    final localAdvance = math.max(0.0, _hero.dx - _startHeroX);
    final worldPosition = (_scroll + localAdvance).clamp(0.0, _stageLength);
    final progress = (worldPosition / _stageLength).clamp(0.0, 1.0);
    final meters = (worldPosition / 10).round();

    return IgnorePointer(
      child: Container(
        height: 52,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(
          color: const Color(0xFF17314A).withValues(alpha: .82),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Colors.white.withValues(alpha: .20)),
        ),
        child: Column(
          children: <Widget>[
            Row(
              children: <Widget>[
                const Text(
                  'START',
                  style: TextStyle(color: Colors.white70, fontSize: 9, fontWeight: FontWeight.w900),
                ),
                const Spacer(),
                Text(
                  '${meters}m',
                  style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w900),
                ),
                const Spacer(),
                const Text(
                  'BOSS',
                  style: TextStyle(color: Color(0xFFFFD978), fontSize: 9, fontWeight: FontWeight.w900),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Expanded(
              child: LayoutBuilder(
                builder: (context, c) {
                  final lineWidth = c.maxWidth;
                  const heroW = 30.0;
                  const heroH = 23.0;
                  final heroLeft = (lineWidth - heroW) * progress;
                  Widget miniHero = Image.asset(
                    'assets/sprites/hero_swordswoman/idle_01.png',
                    width: heroW,
                    height: heroH,
                    fit: BoxFit.contain,
                    alignment: Alignment.bottomCenter,
                    filterQuality: FilterQuality.medium,
                    gaplessPlayback: true,
                  );
                  if (!_faceRight) {
                    miniHero = Transform(
                      alignment: Alignment.center,
                      transform: Matrix4.diagonal3Values(-1, 1, 1),
                      child: miniHero,
                    );
                  }

                  return Stack(
                    clipBehavior: Clip.none,
                    children: <Widget>[
                      Positioned(
                        left: 0,
                        right: 0,
                        top: 10,
                        child: Container(
                          height: 4,
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: .23),
                            borderRadius: BorderRadius.circular(99),
                          ),
                        ),
                      ),
                      Positioned(
                        left: 0,
                        top: 10,
                        child: Container(
                          width: lineWidth * progress,
                          height: 4,
                          decoration: BoxDecoration(
                            color: const Color(0xFFFFD978),
                            borderRadius: BorderRadius.circular(99),
                          ),
                        ),
                      ),
                      _progressMarker(lineWidth * .32 - 4, const Color(0xFFFFD978)),
                      _progressMarker(lineWidth * .64 - 4, const Color(0xFFFF9F6E)),
                      _progressMarker(lineWidth - 8, const Color(0xFFE66B6B)),
                      Positioned(
                        left: heroLeft,
                        top: -6,
                        child: SizedBox(width: heroW, height: heroH, child: miniHero),
                      ),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _progressMarker(double left, Color color) {
    return Positioned(
      left: left,
      top: 8,
      child: Container(
        width: 8,
        height: 8,
        decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white, width: 1.2),
        ),
      ),
    );
  }

  Widget _hintChip(String text) {
    return IgnorePointer(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
        decoration: BoxDecoration(
          color: const Color(0xFF17314A).withValues(alpha: .76),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Colors.white.withValues(alpha: .20)),
        ),
        child: Text(
          text,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 11,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
    );
  }

  List<Widget> _buildEnemies() {
    return _enemies.map((e) {
      final bounce = e.hp > 0 ? math.sin(_time * 3 + e.phase) * (e.weight == _EnemyWeight.large ? 1.5 : 3.0) : 0.0;
      final s = e.size;
      if (e.hp <= 0) {
        if (e.pop >= 1) return const SizedBox.shrink();
        return Positioned(
          left: e.x - s * .65 + math.sin(_time * 71) * _screenShake * 2.2,
          top: e.y - s * .95 + math.cos(_time * 83) * _screenShake * 1.5,
          child: IgnorePointer(
            child: SizedBox(
              width: s * 1.3,
              height: s * 1.3,
              child: CustomPaint(painter: _BattlePopPainter(progress: e.pop)),
            ),
          ),
        );
      }

      final hpRatio = e.hp / e.maxHp;
      Widget monster = CustomPaint(
        size: Size.square(s),
        painter: _BattleTsumPainter(type: e.type, selected: e.weight == _EnemyWeight.large),
      );
      if (e.flash > 0) {
        monster = Stack(
          fit: StackFit.expand,
          children: <Widget>[
            monster,
            Opacity(
              opacity: (e.flash * .72).clamp(0.0, .72),
              child: Container(decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle)),
            ),
          ],
        );
      }

      return Positioned(
        left: e.x - s / 2 + math.sin(_time * 71) * _screenShake * 2.2,
        top: e.y - s + bounce + math.cos(_time * 83) * _screenShake * 1.5,
        child: IgnorePointer(
          child: SizedBox(
            width: s,
            height: s + (e.weight == _EnemyWeight.small ? 0 : 10),
            child: Stack(
              clipBehavior: Clip.none,
              children: <Widget>[
                Positioned(left: 0, top: 0, width: s, height: s, child: monster),
                if (e.weight != _EnemyWeight.small)
                  Positioned(
                    left: s * .08,
                    right: s * .08,
                    bottom: 0,
                    child: Container(
                      height: e.weight == _EnemyWeight.large ? 7 : 5,
                      decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(99)),
                      alignment: Alignment.centerLeft,
                      child: FractionallySizedBox(
                        widthFactor: hpRatio.clamp(0.0, 1.0).toDouble(),
                        child: Container(
                          decoration: BoxDecoration(
                            color: e.weight == _EnemyWeight.large ? const Color(0xFFE55F62) : const Color(0xFFFFC857),
                            borderRadius: BorderRadius.circular(99),
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      );
    }).toList();
  }

  List<Widget> _buildSlashEffects() {
    return _slashFx.map((fx) {
      const w = 150.0;
      const h = 96.0;
      return Positioned(
        left: fx.position.dx - w / 2 + math.sin(_time * 71) * _screenShake * 2.2,
        top: fx.position.dy - h / 2 + math.cos(_time * 83) * _screenShake * 1.5,
        child: IgnorePointer(
          child: SizedBox(
            width: w,
            height: h,
            child: CustomPaint(
              painter: _SwordImpactPainter(
                life: fx.life,
                power: fx.power,
                faceRight: fx.faceRight,
              ),
            ),
          ),
        ),
      );
    }).toList();
  }

  Widget _buildHero() {
    final speed = _velocity.distance;
    final moving = !_attack && speed > 55;
    final path = _attack
        ? 'assets/sprites/hero_swordswoman/attack_${_attackFrame.toString().padLeft(2, '0')}.png'
        : moving
            ? 'assets/sprites/hero_swordswoman/run_${_runFrame.toString().padLeft(2, '0')}.png'
            : null;

    // V91f: use one idle sprite only. The old two-frame cross-fade created
    // a visible double-image/afterimage because the sword and hair positions
    // differ between idle_01 and idle_02. Soft life now comes only from
    // Flutter-side bob/breath/tilt, so the silhouette stays crisp.
    final bob = moving
        ? math.sin(_time * 13) * 2.0
        : -math.sin(_time * math.pi * 2 * .62) * 1.35;
    final breatheScale = moving || _attack
        ? 1.0
        : 1.0 + math.sin(_time * math.pi * 2 * .72) * .005;

    const boxW = 190.0;
    const boxH = 142.5;

    Widget imageFor(String asset) => Image.asset(
          asset,
          width: boxW,
          height: boxH,
          fit: BoxFit.contain,
          alignment: Alignment.bottomCenter,
          filterQuality: FilterQuality.high,
          gaplessPlayback: true,
        );

    Widget sprite = path != null
        ? imageFor(path)
        : imageFor('assets/sprites/hero_swordswoman/idle_01.png');

    if (!_faceRight) {
      sprite = Transform(
        alignment: Alignment.center,
        transform: Matrix4.diagonal3Values(-1, 1, 1),
        child: sprite,
      );
    }

    return Positioned(
      left: _hero.dx - boxW / 2 + math.sin(_time * 71) * _screenShake * 2.2,
      top: _hero.dy - boxH + bob + math.cos(_time * 83) * _screenShake * 1.5,
      child: IgnorePointer(
        child: Transform.rotate(
          angle: _tilt,
          alignment: Alignment.bottomCenter,
          child: Transform.scale(
            scaleY: breatheScale,
            alignment: Alignment.bottomCenter,
            child: sprite,
          ),
        ),
      ),
    );
  }

}

class _SwordImpactPainter extends CustomPainter {
  const _SwordImpactPainter({required this.life, required this.power, required this.faceRight});
  final double life;
  final double power;
  final bool faceRight;

  @override
  void paint(Canvas canvas, Size size) {
    final t = (1 - life).clamp(0.0, 1.0);
    final alpha = life.clamp(0.0, 1.0);
    final c = Offset(size.width / 2, size.height / 2);
    final dir = faceRight ? 1.0 : -1.0;
    final slash = Paint()
      ..color = Colors.white.withValues(alpha: alpha * .92)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.5 + power * 1.2
      ..strokeCap = StrokeCap.round;
    final blue = Paint()
      ..color = const Color(0xFF66D9FF).withValues(alpha: alpha * .82)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 7 + power * 2.0
      ..strokeCap = StrokeCap.round;

    final p = Path()
      ..moveTo(c.dx - dir * 56, c.dy + 26)
      ..quadraticBezierTo(c.dx + dir * 8, c.dy - 48 - power * 4, c.dx + dir * 62, c.dy - 12);
    canvas.drawPath(p, blue);
    canvas.drawPath(p, slash);

    final spark = Paint()
      ..color = const Color(0xFFFFE08A).withValues(alpha: alpha)
      ..strokeWidth = 2.2
      ..strokeCap = StrokeCap.round;
    final ray = 18 + t * 22 + power * 4;
    for (var i = 0; i < 7; i++) {
      final a = i * math.pi * 2 / 7 + .2;
      final p0 = c + Offset(math.cos(a), math.sin(a)) * (7 + t * 7);
      final p1 = c + Offset(math.cos(a), math.sin(a)) * ray;
      canvas.drawLine(p0, p1, spark);
    }
  }

  @override
  bool shouldRepaint(covariant _SwordImpactPainter oldDelegate) => true;
}

class _BattleTsumPainter extends CustomPainter {
  const _BattleTsumPainter({required this.type, required this.selected});
  final int type;
  final bool selected;

  Paint _gloss(Color light, Color base, Color dark, Offset c, double r) => Paint()
    ..shader = RadialGradient(
      center: const Alignment(-.34, -.42), radius: 1.05,
      colors: [light, base, dark], stops: const [0, .55, 1],
    ).createShader(Rect.fromCircle(center: c, radius: r));

  void _shine(Canvas canvas, Offset c, double r) {
    canvas.drawOval(Rect.fromCenter(center: c + Offset(-r * .28, -r * .38), width: r * .48, height: r * .25), Paint()..color = Colors.white.withValues(alpha: .34));
  }

  void _eyes(Canvas canvas, Offset c, double r, {double y = -.10}) {
    final p = Paint()..color = const Color(0xFF252525);
    canvas.drawCircle(c + Offset(-r * .25, r * y), r * .075, p);
    canvas.drawCircle(c + Offset(r * .25, r * y), r * .075, p);
    final hi = Paint()..color = Colors.white.withValues(alpha: .9);
    canvas.drawCircle(c + Offset(-r * .225, r * (y - .025)), r * .018, hi);
    canvas.drawCircle(c + Offset(r * .275, r * (y - .025)), r * .018, hi);
  }

  void _blush(Canvas canvas, Offset c, double r) {
    final p = Paint()..color = const Color(0x55F38E9E);
    canvas.drawCircle(c + Offset(-r * .48, r * .13), r * .11, p);
    canvas.drawCircle(c + Offset(r * .48, r * .13), r * .11, p);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = math.min(size.width, size.height) / 2;
    canvas.drawOval(Rect.fromCenter(center: c + Offset(0, r * .12), width: r * 1.62, height: r * 1.58), Paint()..color = const Color(0x33000000)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3));
    switch (type) {
      case 0: _drawChick(canvas, c, r); break;
      case 1: _drawFrog(canvas, c, r); break;
      case 2: _drawPenguin(canvas, c, r); break;
      case 3: _drawDog(canvas, c, r); break;
      default: _drawBunny(canvas, c, r);
    }
    if (selected) {
      canvas.drawCircle(c, r * .82, Paint()..color = Colors.white.withValues(alpha: .38)..style = PaintingStyle.stroke..strokeWidth = math.max(2, r * .07));
    }
  }

  void _drawChick(Canvas canvas, Offset c, double r) {
    final body = _gloss(const Color(0xFFFFF08A), const Color(0xFFFFC928), const Color(0xFFE79A00), c, r);
    canvas.drawCircle(c, r * .82, body); _shine(canvas, c, r);
    final wing = Paint()..color = const Color(0xFFFFB51E);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(-r * .66, r * .12), width: r * .28, height: r * .48), wing);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(r * .66, r * .12), width: r * .28, height: r * .48), wing);
    _eyes(canvas, c, r); _blush(canvas, c, r);
    final beak = Path()..moveTo(c.dx-r*.10,c.dy+r*.08)..lineTo(c.dx+r*.12,c.dy+r*.08)..lineTo(c.dx,c.dy+r*.20)..close();
    canvas.drawPath(beak, Paint()..color = const Color(0xFFF18A18));
  }

  void _drawFrog(Canvas canvas, Offset c, double r) {
    final body = _gloss(const Color(0xFFA6F3A9), const Color(0xFF63D46B), const Color(0xFF2C9A42), c, r);
    canvas.drawCircle(c, r*.82, body); _shine(canvas,c,r);
    canvas.drawCircle(c+Offset(-r*.42,-r*.55),r*.25,body); canvas.drawCircle(c+Offset(r*.42,-r*.55),r*.25,body);
    for (final x in [-.42,.42]) { canvas.drawCircle(c+Offset(r*x,-r*.55),r*.11,Paint()..color=Colors.white); canvas.drawCircle(c+Offset(r*x,-r*.55),r*.055,Paint()..color=const Color(0xFF1E2A25)); }
    _blush(canvas,c,r);
    canvas.drawArc(Rect.fromCenter(center:c+Offset(0,r*.12),width:r*.60,height:r*.36),.15,math.pi-.30,false,Paint()..color=const Color(0xFF25873A)..style=PaintingStyle.stroke..strokeWidth=math.max(1.8,r*.07)..strokeCap=StrokeCap.round);
  }

  void _drawPenguin(Canvas canvas, Offset c, double r) {
    final blue=_gloss(const Color(0xFF9DE1FF),const Color(0xFF4F9ED8),const Color(0xFF2464A8),c,r);
    canvas.drawCircle(c,r*.82,blue); _shine(canvas,c,r);
    canvas.drawOval(Rect.fromCenter(center:c+Offset(0,r*.19),width:r,height:r*1.10),Paint()..color=const Color(0xFFEAF6FF));
    final wing=Paint()..color=const Color(0xFF2E6F9F);
    canvas.drawOval(Rect.fromCenter(center:c+Offset(-r*.62,r*.08),width:r*.22,height:r*.56),wing); canvas.drawOval(Rect.fromCenter(center:c+Offset(r*.62,r*.08),width:r*.22,height:r*.56),wing);
    _eyes(canvas,c+Offset(0,-r*.10),r,y:0);
    final beak=Path()..moveTo(c.dx-r*.10,c.dy+r*.01)..lineTo(c.dx+r*.10,c.dy+r*.01)..lineTo(c.dx,c.dy+r*.15)..close(); canvas.drawPath(beak,Paint()..color=const Color(0xFFFF9B2F));
  }

  void _drawDog(Canvas canvas, Offset c, double r) {
    final ear=Paint()..color=const Color(0xFF7453B7);
    canvas.drawOval(Rect.fromCenter(center:c+Offset(-r*.62,-r*.18),width:r*.42,height:r*.72),ear); canvas.drawOval(Rect.fromCenter(center:c+Offset(r*.62,-r*.18),width:r*.42,height:r*.72),ear);
    canvas.drawCircle(c,r*.82,_gloss(const Color(0xFFE4D7FF),const Color(0xFFBFA8F2),const Color(0xFF8060C7),c,r)); _shine(canvas,c,r);
    canvas.drawOval(Rect.fromCenter(center:c+Offset(r*.26,-r*.18),width:r*.36,height:r*.46),ear); _eyes(canvas,c,r); _blush(canvas,c,r); canvas.drawCircle(c+Offset(0,r*.16),r*.09,Paint()..color=const Color(0xFF3E315A));
  }

  void _drawBunny(Canvas canvas, Offset c, double r) {
    final body=_gloss(const Color(0xFFFFE2EE),const Color(0xFFFFA7C7),const Color(0xFFE66B9B),c,r); final inner=Paint()..color=const Color(0xFFFF6F9F);
    canvas.drawOval(Rect.fromCenter(center:c+Offset(-r*.28,-r*.86),width:r*.32,height:r*.88),body); canvas.drawOval(Rect.fromCenter(center:c+Offset(r*.28,-r*.86),width:r*.32,height:r*.88),body);
    canvas.drawOval(Rect.fromCenter(center:c+Offset(-r*.28,-r*.86),width:r*.11,height:r*.55),inner); canvas.drawOval(Rect.fromCenter(center:c+Offset(r*.28,-r*.86),width:r*.11,height:r*.55),inner);
    canvas.drawCircle(c+Offset(0,r*.04),r*.76,body); _shine(canvas,c+Offset(0,r*.04),r*.92); _eyes(canvas,c+Offset(0,r*.02),r); _blush(canvas,c,r); canvas.drawCircle(c+Offset(0,r*.16),r*.06,Paint()..color=const Color(0xFF8C3F61));
  }

  @override bool shouldRepaint(covariant _BattleTsumPainter oldDelegate) => oldDelegate.type != type || oldDelegate.selected != selected;
}

class _BattlePopPainter extends CustomPainter {
  const _BattlePopPainter({required this.progress});
  final double progress;
  @override void paint(Canvas canvas, Size size) {
    final life=(1-progress).clamp(0.0,1.0); final p=Offset(size.width/2,size.height/2); final r=(1-life)*24+5;
    final paint=Paint()..color=Colors.white.withValues(alpha:life)..style=PaintingStyle.stroke..strokeWidth=3;
    canvas.drawCircle(p,r,paint);
    for(var i=0;i<7;i++){final a=i*math.pi*2/7; final a0=p+Offset(math.cos(a),math.sin(a))*r*.65; final a1=p+Offset(math.cos(a),math.sin(a))*r*1.15; canvas.drawLine(a0,a1,paint);}
  }
  @override bool shouldRepaint(covariant _BattlePopPainter oldDelegate)=>oldDelegate.progress!=progress;
}

class _SideScrollFieldPainter extends CustomPainter {
  const _SideScrollFieldPainter({required this.scroll});
  final double scroll;

  @override
  void paint(Canvas canvas, Size size) {
    final sky = Paint()..color = const Color(0xFFBFE8FF);
    canvas.drawRect(Offset.zero & size, sky);

    // distant sky glow
    canvas.drawRect(
      Rect.fromLTWH(0, size.height * .30, size.width, size.height * .28),
      Paint()..color = const Color(0xFFDDF5FF),
    );

    _hills(canvas, size, .10, const Color(0xFF8ECF91), size.height * .43, 54);
    _hills(canvas, size, .24, const Color(0xFF62B975), size.height * .50, 72);

    final grassTop = size.height * .54;
    canvas.drawRect(
      Rect.fromLTWH(0, grassTop, size.width, size.height - grassTop),
      Paint()..color = const Color(0xFF7ED45E),
    );

    // dirt road where the action happens
    final road = Path()
      ..moveTo(0, size.height * .63)
      ..quadraticBezierTo(size.width * .45, size.height * .59, size.width, size.height * .64)
      ..lineTo(size.width, size.height * .86)
      ..quadraticBezierTo(size.width * .50, size.height * .82, 0, size.height * .88)
      ..close();
    canvas.drawPath(road, Paint()..color = const Color(0xFFEBC889));

    final offset = -(scroll % 180);
    for (double x = offset - 180; x < size.width + 180; x += 180) {
      _tree(canvas, Offset(x + 34, grassTop - 8), .88);
      _bush(canvas, Offset(x + 118, grassTop + 6), .82);
      _rock(canvas, Offset(x + 146, size.height * .83), .75);
      _flowers(canvas, Offset(x + 84, size.height * .89));
    }

    final nearOffset = -((scroll * 1.45) % 130);
    for (double x = nearOffset - 130; x < size.width + 130; x += 130) {
      _grassTuft(canvas, Offset(x + 20, size.height * .91));
      _grassTuft(canvas, Offset(x + 86, size.height * .58));
    }
  }

  void _hills(Canvas canvas, Size size, double parallax, Color color, double y, double amp) {
    final phase = -((scroll * parallax) % 240);
    final path = Path()..moveTo(0, size.height);
    path.lineTo(0, y);
    for (double x = phase - 240; x <= size.width + 240; x += 120) {
      path.quadraticBezierTo(x + 60, y - amp, x + 120, y);
    }
    path.lineTo(size.width, size.height);
    path.close();
    canvas.drawPath(path, Paint()..color = color);
  }

  void _tree(Canvas canvas, Offset p, double s) {
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(center: Offset(p.dx, p.dy + 19 * s), width: 12 * s, height: 48 * s),
        Radius.circular(5 * s),
      ),
      Paint()..color = const Color(0xFF875F3D),
    );
    final leaf = Paint()..color = const Color(0xFF3E9C58);
    canvas.drawCircle(Offset(p.dx - 14 * s, p.dy - 4 * s), 22 * s, leaf);
    canvas.drawCircle(Offset(p.dx + 11 * s, p.dy - 8 * s), 25 * s, leaf);
    canvas.drawCircle(Offset(p.dx, p.dy - 25 * s), 25 * s, Paint()..color = const Color(0xFF51B967));
  }

  void _bush(Canvas canvas, Offset p, double s) {
    final paint = Paint()..color = const Color(0xFF49AE5C);
    canvas.drawCircle(Offset(p.dx - 13 * s, p.dy), 16 * s, paint);
    canvas.drawCircle(Offset(p.dx + 2 * s, p.dy - 7 * s), 20 * s, paint);
    canvas.drawCircle(Offset(p.dx + 18 * s, p.dy), 15 * s, paint);
  }

  void _rock(Canvas canvas, Offset p, double s) {
    canvas.drawOval(
      Rect.fromCenter(center: p, width: 28 * s, height: 17 * s),
      Paint()..color = const Color(0xFF8E9A95),
    );
  }

  void _flowers(Canvas canvas, Offset p) {
    for (int i = 0; i < 4; i++) {
      final x = p.dx + i * 9;
      canvas.drawCircle(Offset(x, p.dy), 3.2, Paint()..color = Colors.white);
      canvas.drawCircle(Offset(x, p.dy), 1.2, Paint()..color = const Color(0xFFFFC84A));
    }
  }

  void _grassTuft(Canvas canvas, Offset p) {
    final paint = Paint()
      ..color = const Color(0xFF3F9E4F)
      ..strokeWidth = 2.2
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(p, p.translate(-5, -10), paint);
    canvas.drawLine(p, p.translate(0, -12), paint);
    canvas.drawLine(p, p.translate(6, -9), paint);
  }

  @override
  bool shouldRepaint(covariant _SideScrollFieldPainter oldDelegate) => oldDelegate.scroll != scroll;
}
