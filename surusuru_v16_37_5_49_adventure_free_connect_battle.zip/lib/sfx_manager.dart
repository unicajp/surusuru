import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// V16.25.1: cute/magical SFX palette + ascending trace sounds.
/// Assets are intentionally one-file-per-action so they can be replaced later
/// without changing puzzle code.
class SfxManager extends ChangeNotifier {
  SfxManager._();
  static final SfxManager instance = SfxManager._();

  final AudioPlayer _bgm = AudioPlayer();
  double _volumePercent = 100;
  double _bgmPercent = 38;
  bool _bgmStarted = false;
  DateTime? _lastTraceAt;

  double get volumePercent => _volumePercent;
  double get bgmPercent => _bgmPercent;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    _volumePercent = prefs.getDouble('sfx_volume') ?? 100;
    _bgmPercent = prefs.getDouble('bgm_volume') ?? 38;
    await _bgm.setReleaseMode(ReleaseMode.loop);
  }

  Future<void> setVolumePercent(double value) async {
    _volumePercent = value.clamp(0, 300).toDouble();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('sfx_volume', _volumePercent);
    notifyListeners();
  }

  Future<void> setBgmPercent(double value) async {
    _bgmPercent = value.clamp(0, 100).toDouble();
    await _bgm.setVolume(_bgmPercent / 100);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('bgm_volume', _bgmPercent);
    notifyListeners();
  }

  Future<void> startPuzzleBgm() async {
    if (_bgmStarted) return;
    _bgmStarted = true;
    await _bgm.setVolume(_bgmPercent / 100);
    await _bgm.play(AssetSource('audio/bgm_puzzle.wav'));
  }

  Future<void> pauseBgm() async {
    if (!_bgmStarted) return;
    await _bgm.pause();
  }

  Future<void> resumeBgm() async {
    if (!_bgmStarted) return;
    await _bgm.resume();
  }

  Future<void> stopBgm() async { _bgmStarted = false; await _bgm.stop(); }

  Future<void> _play(String file, {double gain = 1}) async {
    if (_volumePercent <= 0) return;
    try {
      final player = AudioPlayer();
      await player.setVolume((_volumePercent / 100 * gain).clamp(0, 1));
      player.onPlayerComplete.first.then((_) => player.dispose());
      await player.play(AssetSource('audio/$file'));
    } catch (_) {}
  }

  void traceStep(int count) {
    final now = DateTime.now();
    if (_lastTraceAt != null && now.difference(_lastTraceAt!).inMilliseconds < 45) return;
    _lastTraceAt = now;
    final step = count.clamp(1, 8);
    _play('trace_$step.wav', gain: step >= 4 ? .98 : .82);
  }

  void tap() => _play('tap.wav', gain: .82);
  void trace() => traceStep(1);
  void merge() => _play('clear.wav');
  void specialMerge(int level) {
    _play(level >= 3 ? 'reward.wav' : 'spawn.wav', gain: level >= 3 ? 1.0 : .9);
  }
  void clear() => _play('clear.wav');
  void bomb() => _play('bomb.wav');
  void line() => _play('line.wav');
  void lightning() => _play('lightning.wav');
  void core() => _play('core.wav');
  void reaction() => _play('reaction.wav');
  void surusuru() => _play('surusuru.wav');
  void spawn() => _play('spawn.wav', gain: .72);
  void reward() => _play('reward.wav');
  void error() => _play('error.wav');
  void unlock() => _play('unlock.wav');
  void test() => _play('reward.wav');
}
