import 'package:flutter/material.dart';

class SuruCharacter {
  final int id; final String name; final String emoji; final String attribute; final String role; final String skill; final Color color;
  const SuruCharacter(this.id,this.name,this.emoji,this.attribute,this.role,this.skill,this.color);
}

const suruCharacters = <SuruCharacter>[
  SuruCharacter(0,'ピピ','🐥','光','ボム','6個以上でボムを作りやすい',Color(0xFFFFC928)),
  SuruCharacter(1,'ケロ','🐸','森','変換','周囲を自分色に変えやすい',Color(0xFF55C85B)),
  SuruCharacter(2,'ペン','🐧','水','連鎖','落下連鎖のダメージUP',Color(0xFF4F9ED8)),
  SuruCharacter(3,'モコ','🐻','闇','破壊','ボムの爆発範囲UP',Color(0xFF9B7BE8)),
  SuruCharacter(4,'ミミ','🐰','花','長なぞり','長くつなぐほど攻撃UP',Color(0xFFFF7EAE)),
  SuruCharacter(5,'コン','🦊','炎','速攻','最初の3手の攻撃UP',Color(0xFFFF8A4C)),
  SuruCharacter(6,'シロ','🐶','風','補助','特殊ピース出現率UP',Color(0xFF66D7C5)),
  SuruCharacter(7,'ネネ','🐱','月','虹','レインボー効果UP',Color(0xFF7D82F2)),
  SuruCharacter(8,'ポポ','🐼','星','スコア','CHAIN倍率UP',Color(0xFF607D8B)),
  SuruCharacter(9,'ララ','🦄','夢','万能','属性相性を少し無視する',Color(0xFFE96CC8)),
];
