class GameState {
  static const int boardColumns = 6;
  static const int boardRows = 7;
  static const int boardSize = boardColumns * boardRows;

  final List<int?> board;

  int energy;
  int maxEnergy;
  int coins;
  int gems;
  int level;
  int xp;

  GameState({
    required this.board,
    this.energy = 100,
    this.maxEnergy = 100,
    this.coins = 0,
    this.gems = 10,
    this.level = 1,
    this.xp = 0,
  });

  factory GameState.initial() {
    return GameState(board: List<int?>.filled(boardSize, null));
  }

  Map<String, dynamic> toJson() {
    return {
      'board': board,
      'energy': energy,
      'maxEnergy': maxEnergy,
      'coins': coins,
      'gems': gems,
      'level': level,
      'xp': xp,
    };
  }

  factory GameState.fromJson(Map<String, dynamic> json) {
    final rawBoard = json['board'];

    final board = <int?>[];

    if (rawBoard is List) {
      for (final value in rawBoard.take(boardSize)) {
        if (value == null) {
          board.add(null);
        } else if (value is int) {
          board.add(value);
        } else if (value is num) {
          board.add(value.toInt());
        } else {
          board.add(int.tryParse(value.toString()));
        }
      }
    }

    while (board.length < boardSize) {
      board.add(null);
    }

    return GameState(
      board: board,
      energy: (json['energy'] as num?)?.toInt() ?? 100,
      maxEnergy: (json['maxEnergy'] as num?)?.toInt() ?? 100,
      coins: (json['coins'] as num?)?.toInt() ?? 0,
      gems: (json['gems'] as num?)?.toInt() ?? 10,
      level: (json['level'] as num?)?.toInt() ?? 1,
      xp: (json['xp'] as num?)?.toInt() ?? 0,
    );
  }
}
