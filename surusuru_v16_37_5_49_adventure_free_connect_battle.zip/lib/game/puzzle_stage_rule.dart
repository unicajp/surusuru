import 'package:flutter/material.dart';

enum PuzzleStageKind {
  warmup,
  exactChain,
  bombWorkshop,
  lineWorkshop,
  monoPrecision,
  reaction,
  lightningWorkshop,
  mixedSpecials,
  efficiency,
  surusuruLab,
}

class PuzzleStageRule {
  final int id;
  final String title;
  final String subtitle;
  final String icon;
  final PuzzleStageKind kind;
  final int moves;
  final int goal;
  final int pieceCount;
  final Color color;
  final int pieceTypes;
  final int startingSpecials;
  final bool bombEveryMove;

  const PuzzleStageRule({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.kind,
    required this.moves,
    required this.goal,
    required this.pieceCount,
    required this.color,
    this.pieceTypes = 4,
    this.startingSpecials = 0,
    this.bombEveryMove = false,
  });

  bool get oneType => pieceTypes == 1;
}

const puzzleStageRules = <PuzzleStageRule>[
  PuzzleStageRule(
    id: 1,
    title: 'まずは狙って消す',
    subtitle: '4個以上を3回つないで、特殊ピースの作り方を覚えよう',
    icon: '🎯',
    kind: PuzzleStageKind.warmup,
    moves: 12,
    goal: 3,
    pieceCount: 44,
    color: Color(0xFF58C9FF),
  ),
  PuzzleStageRule(
    id: 2,
    title: '4で止めろ',
    subtitle: 'ちょうど4個つなぎを3回成功させよう。長くつなげば正解とは限らない',
    icon: '4️⃣',
    kind: PuzzleStageKind.exactChain,
    moves: 12,
    goal: 3,
    pieceCount: 44,
    color: Color(0xFFFFC857),
  ),
  PuzzleStageRule(
    id: 3,
    title: 'ボム工房',
    subtitle: 'ボムを作るだけではダメ。3個起爆して盤面を動かそう',
    icon: '💣',
    kind: PuzzleStageKind.bombWorkshop,
    moves: 14,
    goal: 3,
    pieceCount: 44,
    color: Color(0xFFFF8A5B),
    startingSpecials: 1,
  ),
  PuzzleStageRule(
    id: 4,
    title: 'ライン研究所',
    subtitle: 'ちょうど5個でラインを作り、2回発動させよう',
    icon: '➕',
    kind: PuzzleStageKind.lineWorkshop,
    moves: 14,
    goal: 2,
    pieceCount: 44,
    color: Color(0xFF66D4FF),
  ),
  PuzzleStageRule(
    id: 5,
    title: 'ひといろ精密操作',
    subtitle: '1種類だけ。ちょうど6個つなぎを3回決めよう',
    icon: '🐥',
    kind: PuzzleStageKind.monoPrecision,
    moves: 8,
    goal: 3,
    pieceCount: 34,
    color: Color(0xFFFFD84D),
    pieceTypes: 1,
  ),
  PuzzleStageRule(
    id: 6,
    title: 'REACTION入門',
    subtitle: '特殊ピースを特殊ピースに巻き込んで、2 REACTION以上を起こそう',
    icon: '⚡',
    kind: PuzzleStageKind.reaction,
    moves: 12,
    goal: 2,
    pieceCount: 44,
    color: Color(0xFFFF63C2),
    startingSpecials: 3,
  ),
  PuzzleStageRule(
    id: 7,
    title: '雷の通り道',
    subtitle: 'ちょうど6個で雷を作り、2回発動させよう',
    icon: '🌩️',
    kind: PuzzleStageKind.lightningWorkshop,
    moves: 14,
    goal: 2,
    pieceCount: 44,
    color: Color(0xFF9F8CFF),
  ),
  PuzzleStageRule(
    id: 8,
    title: '特殊ミックス',
    subtitle: '1手の中で2種類以上の特殊ピースを連鎖発動させよう',
    icon: '🧪',
    kind: PuzzleStageKind.mixedSpecials,
    moves: 14,
    goal: 1,
    pieceCount: 44,
    color: Color(0xFF63E0B0),
    startingSpecials: 4,
  ),
  PuzzleStageRule(
    id: 9,
    title: '10手の設計図',
    subtitle: '大量落下は禁止。10手で70個消そう。特殊連鎖を使うほど有利',
    icon: '🧠',
    kind: PuzzleStageKind.efficiency,
    moves: 10,
    goal: 70,
    pieceCount: 46,
    color: Color(0xFF6EC8FF),
  ),
  PuzzleStageRule(
    id: 10,
    title: 'SURUSURU LAB',
    subtitle: '最大4 REACTION以上を起こして実験エリアを突破しよう',
    icon: '🌈',
    kind: PuzzleStageKind.surusuruLab,
    moves: 16,
    goal: 4,
    pieceCount: 46,
    color: Color(0xFFFF5AA5),
    startingSpecials: 3,
  ),
];

PuzzleStageRule puzzleRule(int id) =>
    puzzleStageRules[(id - 1).clamp(0, puzzleStageRules.length - 1)];
