import 'package:flutter/material.dart';

class StageDefinition {
  final int id;
  final String placeId;
  final String title;
  final String request;
  final String icon;
  final String generatorId;
  final int targetLevel;
  final int targetCount;
  final Color accent;
  final Color boardTint;

  const StageDefinition({
    required this.id,
    required this.placeId,
    required this.title,
    required this.request,
    required this.icon,
    required this.generatorId,
    required this.targetLevel,
    required this.targetCount,
    required this.accent,
    required this.boardTint,
  });
}

const List<StageDefinition> allStages = [
  StageDefinition(id:1, placeId:'home', title:'朝のしたく', request:'芽を育てて、朝の準備をしよう', icon:'🪴', generatorId:'farm', targetLevel:2, targetCount:1, accent:Color(0xFFFFB75E), boardTint:Color(0xFFF6E6C9)),
  StageDefinition(id:2, placeId:'home', title:'キッチンを整えよう', request:'少し育った素材を2つそろえよう', icon:'🍳', generatorId:'farm', targetLevel:2, targetCount:2, accent:Color(0xFFFF9E80), boardTint:Color(0xFFF9DED4)),
  StageDefinition(id:3, placeId:'home', title:'庭のお手入れ', request:'もっと育てて庭をにぎやかにしよう', icon:'🌿', generatorId:'farm', targetLevel:3, targetCount:1, accent:Color(0xFF87C96E), boardTint:Color(0xFFDDF2D3)),
  StageDefinition(id:4, placeId:'home', title:'家具をそろえよう', request:'高いレベルの素材を完成させよう', icon:'🪑', generatorId:'farm', targetLevel:4, targetCount:1, accent:Color(0xFFC99A72), boardTint:Color(0xFFF0E0D2)),
  StageDefinition(id:5, placeId:'home', title:'わたしのおうち完成！', request:'最後の特別な素材を作ろう', icon:'🏠', generatorId:'farm', targetLevel:5, targetCount:1, accent:Color(0xFFE9AFC3), boardTint:Color(0xFFF7DCE7)),

  StageDefinition(id:6, placeId:'cafe', title:'カウンターの準備', request:'ミミのために最初のドリンク素材を作ろう', icon:'🥤', generatorId:'drink', targetLevel:12, targetCount:1, accent:Color(0xFF71C9D4), boardTint:Color(0xFFD8F2F4)),
  StageDefinition(id:7, placeId:'cafe', title:'ふたり分のドリンク', request:'同じドリンクを2つ用意しよう', icon:'🥛', generatorId:'drink', targetLevel:12, targetCount:2, accent:Color(0xFF64BFC9), boardTint:Color(0xFFD1EEF0)),
  StageDefinition(id:8, placeId:'cafe', title:'新メニュー試作', request:'ひとつ上のドリンクを完成させよう', icon:'🧋', generatorId:'drink', targetLevel:13, targetCount:1, accent:Color(0xFF8CB7E8), boardTint:Color(0xFFDDE9F8)),
  StageDefinition(id:9, placeId:'cafe', title:'人気メニューを作ろう', request:'ミミのおすすめを2つそろえよう', icon:'☕', generatorId:'drink', targetLevel:14, targetCount:2, accent:Color(0xFFC99D7D), boardTint:Color(0xFFF2E3D8)),
  StageDefinition(id:10, placeId:'cafe', title:'ミミのカフェ OPEN！', request:'看板ドリンクを完成させよう', icon:'✨', generatorId:'drink', targetLevel:15, targetCount:1, accent:Color(0xFFFF8FB3), boardTint:Color(0xFFF8DCE7)),

  StageDefinition(id:11, placeId:'bakery', title:'小麦の香り', request:'パン作りの最初の材料を用意しよう', icon:'🌾', generatorId:'sweet', targetLevel:22, targetCount:1, accent:Color(0xFFE8B35F), boardTint:Color(0xFFF4E6C8)),
  StageDefinition(id:12, placeId:'bakery', title:'朝のパンを焼こう', request:'パン素材を2つそろえよう', icon:'🥖', generatorId:'sweet', targetLevel:22, targetCount:2, accent:Color(0xFFD99C55), boardTint:Color(0xFFF1DFC5)),
  StageDefinition(id:13, placeId:'bakery', title:'ふわふわ生地', request:'一段上のパン素材にしよう', icon:'🥐', generatorId:'sweet', targetLevel:23, targetCount:1, accent:Color(0xFFF0B967), boardTint:Color(0xFFF7E7CB)),
  StageDefinition(id:14, placeId:'bakery', title:'棚いっぱいのパン', request:'上質なパンを2つ作ろう', icon:'🍞', generatorId:'sweet', targetLevel:24, targetCount:2, accent:Color(0xFFCE8B55), boardTint:Color(0xFFF0D9C8)),
  StageDefinition(id:15, placeId:'bakery', title:'ベーカリー OPEN！', request:'最高のパンを完成させよう', icon:'🎉', generatorId:'sweet', targetLevel:25, targetCount:1, accent:Color(0xFFFFA75E), boardTint:Color(0xFFF7E2CF)),

  StageDefinition(id:16, placeId:'sweets', title:'おやつの材料集め', request:'甘い素材を用意しよう', icon:'🍓', generatorId:'sweet', targetLevel:22, targetCount:3, accent:Color(0xFFF48DA8), boardTint:Color(0xFFF8DDE5)),
  StageDefinition(id:17, placeId:'sweets', title:'クリームの準備', request:'甘い素材をひとつ上へ育てよう', icon:'🧁', generatorId:'sweet', targetLevel:23, targetCount:2, accent:Color(0xFFE78BBE), boardTint:Color(0xFFF3DDEF)),
  StageDefinition(id:18, placeId:'sweets', title:'ショーケースを埋めよう', request:'ケーキ素材を3つそろえよう', icon:'🍰', generatorId:'sweet', targetLevel:24, targetCount:3, accent:Color(0xFFD889CE), boardTint:Color(0xFFF1DDF3)),
  StageDefinition(id:19, placeId:'sweets', title:'特別なおやつ', request:'高級スイーツを2つ完成させよう', icon:'🍮', generatorId:'sweet', targetLevel:25, targetCount:2, accent:Color(0xFFFFA5B8), boardTint:Color(0xFFF9DFE4)),
  StageDefinition(id:20, placeId:'sweets', title:'おやつ工房 OPEN！', request:'最後のごほうびスイーツを作ろう', icon:'🎀', generatorId:'sweet', targetLevel:25, targetCount:3, accent:Color(0xFFFF7EA9), boardTint:Color(0xFFF8D5E1)),

  StageDefinition(id:21, placeId:'flower', title:'小さな花を育てよう', request:'最初の花素材を作ろう', icon:'🌱', generatorId:'flower', targetLevel:32, targetCount:1, accent:Color(0xFF88C77A), boardTint:Color(0xFFDDF0D8)),
  StageDefinition(id:22, placeId:'flower', title:'花束の準備', request:'花素材を2つそろえよう', icon:'🌷', generatorId:'flower', targetLevel:32, targetCount:2, accent:Color(0xFFFF8EB5), boardTint:Color(0xFFF7DEE8)),
  StageDefinition(id:23, placeId:'flower', title:'店先を彩ろう', request:'色鮮やかな花を作ろう', icon:'🌼', generatorId:'flower', targetLevel:33, targetCount:2, accent:Color(0xFFFFC95A), boardTint:Color(0xFFF7EDCD)),
  StageDefinition(id:24, placeId:'flower', title:'大きなアレンジ', request:'上質な花を2つ完成させよう', icon:'💐', generatorId:'flower', targetLevel:34, targetCount:2, accent:Color(0xFFC891DF), boardTint:Color(0xFFEFE1F5)),
  StageDefinition(id:25, placeId:'flower', title:'はなまる花店 OPEN！', request:'特別な花を完成させよう', icon:'🌸', generatorId:'flower', targetLevel:35, targetCount:1, accent:Color(0xFFFF8CA8), boardTint:Color(0xFFF8DDE4)),

  StageDefinition(id:26, placeId:'goods', title:'店の道具をそろえよう', request:'キッチン素材を作って道具を準備しよう', icon:'🧺', generatorId:'kitchen', targetLevel:42, targetCount:1, accent:Color(0xFF79B7D3), boardTint:Color(0xFFDDECF4)),
  StageDefinition(id:27, placeId:'goods', title:'商品を並べよう', request:'同じ素材を2つそろえよう', icon:'🛍️', generatorId:'kitchen', targetLevel:42, targetCount:2, accent:Color(0xFF8AA6E0), boardTint:Color(0xFFE0E7F6)),
  StageDefinition(id:28, placeId:'goods', title:'ちょっと珍しい商品', request:'一段上の素材を2つ作ろう', icon:'🎁', generatorId:'kitchen', targetLevel:43, targetCount:2, accent:Color(0xFFC193DD), boardTint:Color(0xFFEDE2F4)),
  StageDefinition(id:29, placeId:'goods', title:'目玉商品を作ろう', request:'高レベルの商品を完成させよう', icon:'💎', generatorId:'kitchen', targetLevel:44, targetCount:2, accent:Color(0xFF70C5C4), boardTint:Color(0xFFDDF2F1)),
  StageDefinition(id:30, placeId:'goods', title:'ひみつ雑貨店 OPEN！', request:'最後の特別商品を完成させよう', icon:'⭐', generatorId:'kitchen', targetLevel:45, targetCount:1, accent:Color(0xFFFFB83F), boardTint:Color(0xFFF7E9C8)),
];

StageDefinition stageById(int id) => allStages.firstWhere((s) => s.id == id);
