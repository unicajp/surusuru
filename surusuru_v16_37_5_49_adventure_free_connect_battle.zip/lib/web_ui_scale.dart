import 'package:flutter/foundation.dart';

/// Compact every explicit UI component metric on Web while keeping the
/// browser viewport itself at 100% width/height. Native is unchanged.
const double webUiScale = kIsWeb ? 0.50 : 1.0;
