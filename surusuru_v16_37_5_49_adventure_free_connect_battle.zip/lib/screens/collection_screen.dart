import 'package:flutter/material.dart';

import '../widgets/app_bottom_nav.dart';

import '../web_ui_scale.dart';

import '../game/game_controller.dart';
import '../sfx_manager.dart';
import '../widgets/merge_item.dart';

class CollectionScreen extends StatelessWidget {
  final GameController controller;

  const CollectionScreen({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    const maxLevel = 10;

    return Scaffold(
      backgroundColor: const Color(0xFFFFF9F5),
      appBar: AppBar(
        leadingWidth: 72 * webUiScale,
        leading: IconButton(
          tooltip: '戻る',
          onPressed: () { SfxManager.instance.tap(); Navigator.of(context).maybePop(); },
          icon: const Icon(Icons.arrow_back_rounded, size: 40 * webUiScale),
        ),
        elevation: 0,
        backgroundColor: const Color(0xFFFFF9F5),
        foregroundColor: const Color(0xFF624D48),
        centerTitle: true,
        title: const Text('図鑑', style: TextStyle(fontWeight: FontWeight.w900)),
      ),
      bottomNavigationBar: AppBottomNav(controller: controller, active: 'collection'),
      body: AnimatedBuilder(
        animation: controller,
        builder: (context, _) {
          final found = List<int>.generate(
            maxLevel,
            (index) => index + 1,
          ).where(controller.isDiscovered).length;

          return SafeArea(
            top: false,
            child: Column(
              children: [
                Container(
                  margin: const EdgeInsets.fromLTRB(16 * webUiScale, 8 * webUiScale, 16 * webUiScale, 14 * webUiScale),
                  padding: const EdgeInsets.all(14 * webUiScale),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFECE5),
                    borderRadius: BorderRadius.circular(18 * webUiScale),
                    border: Border.all(color: const Color(0xFFF0D6CC)),
                  ),
                  child: Row(
                    children: [
                      const Text(
                        'COLLECTION',
                        style: TextStyle(
                          fontSize: 19 * webUiScale,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.5 * webUiScale,
                          color: Color(0xFFA56F65),
                        ),
                      ),
                      const Spacer(),
                      Text(
                        '$found / $maxLevel',
                        style: const TextStyle(
                          fontSize: 20 * webUiScale,
                          fontWeight: FontWeight.w900,
                          color: Color(0xFF674D48),
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: GridView.builder(
                    padding: const EdgeInsets.fromLTRB(16 * webUiScale, 0, 16 * webUiScale, 24 * webUiScale),
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 3,
                          crossAxisSpacing: 10 * webUiScale,
                          mainAxisSpacing: 10 * webUiScale,
                          childAspectRatio: 0.92,
                        ),
                    itemCount: maxLevel,
                    itemBuilder: (context, index) {
                      final level = index + 1;
                      final unlocked = controller.isDiscovered(level);

                      return AnimatedContainer(
                        duration: const Duration(milliseconds: 180),
                        decoration: BoxDecoration(
                          color: unlocked
                              ? const Color(0xFFFFF1E9)
                              : const Color(0xFFF3EEEC),
                          borderRadius: BorderRadius.circular(18 * webUiScale),
                          border: Border.all(
                            color: unlocked
                                ? const Color(0xFFE8C9BC)
                                : const Color(0xFFE2DDDA),
                          ),
                          boxShadow: unlocked
                              ? const [
                                  BoxShadow(
                                    color: Color(0x10000000),
                                    blurRadius: 8,
                                    offset: Offset(0, 3 * webUiScale),
                                  ),
                                ]
                              : null,
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            if (unlocked)
                              MergeItem(level: level)
                            else
                              const Text(
                                '?',
                                style: TextStyle(
                                  fontSize: 34 * webUiScale,
                                  fontWeight: FontWeight.w900,
                                  color: Color(0xFFBEB3AF),
                                ),
                              ),
                            const SizedBox(height: 8 * webUiScale),
                            Text(
                              unlocked ? 'Lv.$level' : '未発見',
                              style: TextStyle(
                                fontSize: 19 * webUiScale,
                                fontWeight: FontWeight.w800,
                                color: unlocked
                                    ? const Color(0xFF70534D)
                                    : const Color(0xFFA99F9B),
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
