import 'package:flutter/material.dart';

import '../widgets/app_bottom_nav.dart';

import '../web_ui_scale.dart';

import '../game/game_controller.dart';
import '../sfx_manager.dart';

class DailyRewardScreen extends StatelessWidget {
  final GameController controller;

  const DailyRewardScreen({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF9F5),
      appBar: AppBar(
        leadingWidth: 86 * webUiScale,
        leading: IconButton(
          tooltip: '戻る',
          onPressed: () { SfxManager.instance.tap(); Navigator.of(context).maybePop(); },
          icon: const Icon(Icons.arrow_back_rounded, size: 48 * webUiScale),
        ),
        backgroundColor: const Color(0xFFFFF9F5),
        foregroundColor: const Color(0xFF674F49),
        elevation: 0,
        centerTitle: true,
        title: const Text(
          'デイリーボーナス',
          style: TextStyle(fontSize: 38 * webUiScale, fontWeight: FontWeight.w900),
        ),
      ),
      bottomNavigationBar: AppBottomNav(controller: controller, active: 'daily'),
      body: AnimatedBuilder(
        animation: controller,
        builder: (context, _) {
          final ready = controller.dailyRewardReady;
          final nextDay = controller.nextDailyStreak;

          return SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.all(18 * webUiScale),
              child: Column(
                children: [
                  const SizedBox(height: 18 * webUiScale),

                  const Text('🎁', style: TextStyle(fontSize: 78 * webUiScale)),

                  const SizedBox(height: 12 * webUiScale),

                  Text(
                    ready ? '$nextDay日目のプレゼント' : '今日のプレゼント受取済み',
                    style: const TextStyle(
                      fontSize: 34 * webUiScale,
                      fontWeight: FontWeight.w900,
                      color: Color(0xFF654D48),
                    ),
                  ),

                  const SizedBox(height: 8 * webUiScale),

                  Text(
                    '連続ログイン ${controller.loginStreak}日',
                    style: const TextStyle(
                      fontSize: 27 * webUiScale,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF9A7A72),
                    ),
                  ),

                  const SizedBox(height: 26 * webUiScale),

                  Container(
                    padding: const EdgeInsets.all(18 * webUiScale),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFECE3),
                      borderRadius: BorderRadius.circular(22 * webUiScale),
                      border: Border.all(color: const Color(0xFFEFD3C7)),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        _RewardItem(
                          icon: '🪙',
                          value: '${controller.nextDailyCoinReward}',
                          label: 'コイン',
                        ),
                        _RewardItem(
                          icon: '⚡',
                          value: '${controller.nextDailyEnergyReward}',
                          label: 'エネルギー',
                        ),
                        _RewardItem(
                          icon: '💎',
                          value: nextDay >= 7 ? '1' : '-',
                          label: '7日目',
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 26 * webUiScale),

                  SizedBox(
                    width: double.infinity,
                    height: 98 * webUiScale,
                    child: FilledButton(
                      onPressed: ready
                          ? () async {
                              SfxManager.instance.tap();
                              final ok = await controller.claimDailyReward();

                              if (!context.mounted || !ok) {
                                SfxManager.instance.error();
                                return;
                              }
                              SfxManager.instance.reward();

                              ScaffoldMessenger.of(context)
                                ..hideCurrentSnackBar()
                                ..showSnackBar(
                                  const SnackBar(
                                    behavior: SnackBarBehavior.floating,
                                    content: Text('デイリーボーナスを受け取りました！'),
                                  ),
                                );
                            }
                          : null,
                      style: FilledButton.styleFrom(
                        backgroundColor: const Color(0xFFE9A89B),
                        disabledBackgroundColor: const Color(0xFFE3D8D4),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(18 * webUiScale),
                        ),
                      ),
                      child: Text(
                        ready ? '受け取る' : 'また明日',
                        style: const TextStyle(
                          fontSize: 32 * webUiScale,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 18 * webUiScale),

                  const Text(
                    '7日ごとに 💎 もプレゼント',
                    style: TextStyle(
                      fontSize: 28 * webUiScale,
                      color: Color(0xFFA1847D),
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class _RewardItem extends StatelessWidget {
  final String icon;
  final String value;
  final String label;

  const _RewardItem({
    required this.icon,
    required this.value,
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(icon, style: const TextStyle(fontSize: 60 * webUiScale)),
        const SizedBox(height: 5),
        Text(
          value,
          style: const TextStyle(
            fontSize: 34 * webUiScale,
            fontWeight: FontWeight.w900,
            color: Color(0xFF654D48),
          ),
        ),
        Text(
          label,
          style: const TextStyle(
            fontSize: 28 * webUiScale,
            color: Color(0xFF9D7D75),
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }
}
