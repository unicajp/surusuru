import 'package:flutter/material.dart';

import '../widgets/app_bottom_nav.dart';

import '../web_ui_scale.dart';

import '../game/game_controller.dart';
import 'shop_interior_screen.dart';
import 'level_path_screen.dart';
import 'mission_screen.dart';

class WorldScreen extends StatefulWidget {
  final GameController controller;
  const WorldScreen({super.key, required this.controller});

  @override
  State<WorldScreen> createState() => _WorldScreenState();
}

class _WorldScreenState extends State<WorldScreen> {
  GameController get c => widget.controller;


  @override
  void initState() {
    super.initState();
    c.addListener(_refresh);
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    c.removeListener(_refresh);
    super.dispose();
  }


  Future<void> _claimReadyReward() async {
    final placeId = c.nextPlaceReady;
    if (placeId == null) return;
    final ok = await c.unlockPlace(placeId);
    if (!ok || !mounted) return;
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30 * webUiScale)),
        child: Container(
          padding: const EdgeInsets.all(24 * webUiScale),
          decoration: BoxDecoration(
            gradient: const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFFFFF6B7), Colors.white]),
            borderRadius: BorderRadius.circular(30 * webUiScale),
            border: Border.all(color: const Color(0xFFFFB52E), width: 4),
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('🎉 NEW OPEN!', style: TextStyle(fontSize: 34 * webUiScale, fontWeight: FontWeight.w900, color: Color(0xFFE96B31))),
            const SizedBox(height: 14 * webUiScale),
            Text(c.placeTitle(placeId), textAlign: TextAlign.center, style: const TextStyle(fontSize: 30 * webUiScale, fontWeight: FontWeight.w900)),
            const SizedBox(height: 10 * webUiScale),
            const Text('街に新しい建物が完成しました！\nタップして店内のお手伝いを始めよう。', textAlign: TextAlign.center, style: TextStyle(fontSize: 20 * webUiScale, fontWeight: FontWeight.w700)),
            const SizedBox(height: 20 * webUiScale),
            SizedBox(width: double.infinity, height: 72 * webUiScale, child: FilledButton(onPressed: () => Navigator.pop(dialogContext), style: FilledButton.styleFrom(backgroundColor: const Color(0xFF67C92F)), child: const Text('街を見てみる！', style: TextStyle(fontSize: 27 * webUiScale, fontWeight: FontWeight.w900)))),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7FCF8),
      bottomNavigationBar: AppBottomNav(controller: c, active: 'world'),
      body: SafeArea(
        child: Column(
          children: [
            _topStatus(),
            _purposeCard(),
            if (c.nextPlaceReady != null) _unlockCard(),
            Expanded(child: _townArea()),
            const SizedBox.shrink(),
          ],
        ),
      ),
    );
  }

  Widget _topStatus() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12 * webUiScale, 10 * webUiScale, 12 * webUiScale, 6 * webUiScale),
      child: Row(
        children: [
          _statusPill('⭐', 'Lv.${c.state.level}'),
          _statusPill('⚡', '${c.state.energy}/${c.state.maxEnergy}'),
          _statusPill('🪙', '${c.state.coins}'),
          _statusPill('💎', '${c.state.gems}'),
        ],
      ),
    );
  }

  Widget _statusPill(String icon, String text) {
    return Expanded(
      child: Container(
        height: 48 * webUiScale,
        margin: const EdgeInsets.symmetric(horizontal: 3 * webUiScale),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18 * webUiScale),
          border: Border.all(color: const Color(0xFFDCEEE9), width: 2),
          boxShadow: const [BoxShadow(color: Color(0x12000000), blurRadius: 8, offset: Offset(0, 3 * webUiScale))],
        ),
        child: Text('$icon $text', style: const TextStyle(fontSize: 18 * webUiScale, fontWeight: FontWeight.w900)),
      ),
    );
  }

  Widget _purposeCard() {
    return Container(
      margin: const EdgeInsets.fromLTRB(12 * webUiScale, 4 * webUiScale, 12 * webUiScale, 7 * webUiScale),
      padding: const EdgeInsets.fromLTRB(16 * webUiScale, 12 * webUiScale, 16 * webUiScale, 12 * webUiScale),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFFFFF2BE), Color(0xFFFFE0EE)]),
        borderRadius: BorderRadius.circular(22 * webUiScale),
        border: Border.all(color: const Color(0xFFFFC75F), width: 2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Text('🌱', style: TextStyle(fontSize: 30 * webUiScale)),
              SizedBox(width: 8 * webUiScale),
              Text('すくすくタウン', style: TextStyle(fontSize: 27 * webUiScale, fontWeight: FontWeight.w900, color: Color(0xFF4B6356))),
            ],
          ),
          const SizedBox(height: 4),
          Text('ショップ ${[1,3,5,7,9,10].where((lv) => lv == 1 || c.levelRewardClaimed(lv)).length} / 6　・　街レベル ${c.state.level}',
              style: const TextStyle(fontSize: 18 * webUiScale, fontWeight: FontWeight.w800, color: Color(0xFF6F756F))),
          const SizedBox(height: 2 * webUiScale),
        ],
      ),
    );
  }

  Widget _unlockCard() {
    final placeId = c.nextPlaceReady!;
    return _UnlockPulse(
      child: GestureDetector(
        onTap: _claimReadyReward,
        child: Container(
          margin: const EdgeInsets.fromLTRB(12 * webUiScale, 0, 12 * webUiScale, 8 * webUiScale),
          padding: const EdgeInsets.symmetric(horizontal: 16 * webUiScale, vertical: 12 * webUiScale),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFFFFC53D), Color(0xFFFF7F5C)]),
            borderRadius: BorderRadius.circular(22 * webUiScale),
            border: Border.all(color: Colors.white, width: 3),
            boxShadow: const [BoxShadow(color: Color(0x88FF9C38), blurRadius: 22, spreadRadius: 4)],
          ),
          child: Row(children: [
            const Text('🎁', style: TextStyle(fontSize: 42 * webUiScale)),
            const SizedBox(width: 12 * webUiScale),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('新しい建物をOPENできる！', style: TextStyle(fontSize: 22 * webUiScale, fontWeight: FontWeight.w900, color: Colors.white)),
              Text(c.placeTitle(placeId), style: const TextStyle(fontSize: 20 * webUiScale, fontWeight: FontWeight.w900, color: Colors.white)),
            ])),
            Container(padding: const EdgeInsets.symmetric(horizontal: 16 * webUiScale, vertical: 12 * webUiScale), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18 * webUiScale)), child: const Text('OPEN！', style: TextStyle(fontSize: 22 * webUiScale, fontWeight: FontWeight.w900, color: Color(0xFFE6653E)))),
          ]),
        ),
      ),
    );
  }

  Widget _townArea() {
    final shops = <({String id, String emoji, String name, String owner, int stageStart, int stageEnd})>[
      (id:'home', emoji:'🏠', name:'わたしのおうち', owner:'わたし', stageStart:1, stageEnd:5),
      (id:'cafe', emoji:'☕', name:'ミミのカフェ', owner:'🐰 ミミ', stageStart:6, stageEnd:10),
      (id:'bakery', emoji:'🥐', name:'ふわふわベーカリー', owner:'🐱 ニャコ', stageStart:11, stageEnd:15),
      (id:'sweets', emoji:'🍰', name:'おやつ工房', owner:'🦊 コン', stageStart:16, stageEnd:20),
      (id:'flower', emoji:'🌷', name:'はなまる花店', owner:'🐶 ポチ', stageStart:21, stageEnd:25),
      (id:'goods', emoji:'🎁', name:'ひみつ雑貨店', owner:'🐼 パン', stageStart:26, stageEnd:30),
    ];
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12 * webUiScale),
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(26 * webUiScale), border: Border.all(color: const Color(0xFF9EDFCB), width: 3)),
      child: LayoutBuilder(builder: (context, box) {
        final positions = <Offset>[
          Offset(box.maxWidth*.06, box.maxHeight*.08), Offset(box.maxWidth*.60, box.maxHeight*.12),
          Offset(box.maxWidth*.12, box.maxHeight*.39), Offset(box.maxWidth*.61, box.maxHeight*.43),
          Offset(box.maxWidth*.10, box.maxHeight*.69), Offset(box.maxWidth*.57, box.maxHeight*.72),
        ];
        return Stack(children:[
          Positioned.fill(child: CustomPaint(painter: _TownPainter(level:c.state.level))),
          if (c.secretTownRewardUnlocked(1))
            Positioned(
              left: 18 * webUiScale,
              bottom: 18 * webUiScale,
              child: IgnorePointer(
                child: Container(
                  padding: const EdgeInsets.all(7 * webUiScale),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha:.84),
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: const Color(0xFFFFD45C),
                      width: 2,
                    ),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0x66FFD54F),
                        blurRadius: 14,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: const Text(
                    '🌸',
                    style: TextStyle(fontSize: 34 * webUiScale),
                  ),
                ),
              ),
            ),
          ...List.generate(shops.length, (i) {
            final shop=shops[i]; final unlocked=c.placeUnlocked(shop.id);
            final claimable=c.canUnlockPlace(shop.id);
            final card=GestureDetector(
              onTap: claimable ? _claimReadyReward : unlocked ? ()=>_openPlace(shop.emoji,shop.name,shop.owner,shop.stageStart,shop.stageEnd,i==0) : null,
              child: Container(width:132 * webUiScale,padding:const EdgeInsets.symmetric(vertical:10 * webUiScale,horizontal:6 * webUiScale),decoration:BoxDecoration(
                color: unlocked?Colors.white.withValues(alpha:.96):const Color(0xFFE1E6E2),borderRadius:BorderRadius.circular(22 * webUiScale),
                border:Border.all(color:claimable?const Color(0xFFFF8B36):unlocked?const Color(0xFFFFC45C):const Color(0xFFBBC3BE),width:claimable?4:2.5),
                boxShadow:claimable?const[BoxShadow(color:Color(0x99FF9C38),blurRadius:22,spreadRadius:4)]:unlocked?const[BoxShadow(color:Color(0x33000000),blurRadius:10,offset:Offset(0,4 * webUiScale))]:null),
                child:Column(mainAxisSize:MainAxisSize.min,children:[Text(claimable?'🎁':unlocked?shop.emoji:'🔒',style:const TextStyle(fontSize:44 * webUiScale)),
                  Text(claimable?'タップでOPEN！':unlocked?shop.name:'🔒 未開放',textAlign:TextAlign.center,style:TextStyle(fontSize:16 * webUiScale,fontWeight:FontWeight.w900,color:claimable?const Color(0xFFE56632):const Color(0xFF604F48))),
                  if(unlocked) Text('STAGE ${shop.stageStart}-${shop.stageEnd}',style:const TextStyle(fontSize:12 * webUiScale,fontWeight:FontWeight.w800,color:Color(0xFF9A7463))) ])),
            );
            return Positioned(left:positions[i].dx,top:positions[i].dy,child:claimable?_UnlockPulse(child:card):card);
          }),
        ]);
      }),
    );
  }

  void _openPlace(String emoji, String name, String owner, int start, int end, bool isHome) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => ShopInteriorScreen(
      controller: c, placeName: name, owner: owner, emoji: emoji,
      stageStart: start, stageEnd: end, isHome: isHome,
    )));
  }

  void _continueStory() {
    int next = 1;
    for (var i = 1; i <= 30; i++) {
      if (!c.stageCleared(i)) { next = i; break; }
    }
    final ranges = <({String id,String emoji,String name,String owner,int start,int end,bool home})>[
      (id:'home',emoji:'🏠',name:'わたしのおうち',owner:'わたし',start:1,end:5,home:true),
      (id:'cafe',emoji:'☕',name:'ミミのカフェ',owner:'🐰 ミミ',start:6,end:10,home:false),
      (id:'bakery',emoji:'🥐',name:'ふわふわベーカリー',owner:'🐱 ニャコ',start:11,end:15,home:false),
      (id:'sweets',emoji:'🍰',name:'おやつ工房',owner:'🦊 コン',start:16,end:20,home:false),
      (id:'flower',emoji:'🌷',name:'はなまる花店',owner:'🐶 ポチ',start:21,end:25,home:false),
      (id:'goods',emoji:'🎁',name:'ひみつ雑貨店',owner:'🐼 パン',start:26,end:30,home:false),
    ];
    final r = ranges.firstWhere((e) => next >= e.start && next <= e.end);
    if (!c.placeUnlocked(r.id)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('街で新しい建物をOPENしよう！', style: TextStyle(fontSize:20 * webUiScale,fontWeight:FontWeight.w800))));
      return;
    }
    _openPlace(r.emoji,r.name,r.owner,r.start,r.end,r.home);
  }

  Widget _bottomActions(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12 * webUiScale, 8 * webUiScale, 12 * webUiScale, 12 * webUiScale),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(child: _smallAction(context, 'タスク', '${c.missionMergeCount}/3', Icons.assignment_rounded, () => Navigator.push(context, MaterialPageRoute(builder: (_) => MissionScreen(controller: c))))),
              const SizedBox(width: 8 * webUiScale),
              Expanded(child: _smallAction(context, 'レベルパス', '次の解放を見る', Icons.card_giftcard_rounded, () => Navigator.push(context, MaterialPageRoute(builder: (_) => LevelPathScreen(controller: c))))),
            ],
          ),
          const SizedBox(height: 8 * webUiScale),
          SizedBox(
            width: double.infinity,
            height: 70 * webUiScale,
            child: FilledButton.icon(
              onPressed: _continueStory,
              icon: const Icon(Icons.auto_awesome_rounded, size: 34 * webUiScale),
              label: const Text('次のお手伝いへ', style: TextStyle(fontSize: 24 * webUiScale, fontWeight: FontWeight.w900)),
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFF29AFC0),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22 * webUiScale)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _smallAction(BuildContext context, String title, String sub, IconData icon, VoidCallback onTap) {
    return SizedBox(
      height: 68 * webUiScale,
      child: FilledButton.tonalIcon(
        onPressed: onTap,
        icon: Icon(icon, size: 27 * webUiScale),
        label: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(title, style: const TextStyle(fontSize: 20 * webUiScale, fontWeight: FontWeight.w900)),
            Text(sub, style: const TextStyle(fontSize: 14 * webUiScale, fontWeight: FontWeight.w800)),
          ],
        ),
      ),
    );
  }
}

class _UnlockPulse extends StatefulWidget {
  final Widget child;
  const _UnlockPulse({required this.child});

  @override
  State<_UnlockPulse> createState() => _UnlockPulseState();
}

class _UnlockPulseState extends State<_UnlockPulse> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 850))..repeat(reverse: true);
    _scale = Tween<double>(begin: .985, end: 1.025).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => ScaleTransition(scale: _scale, child: widget.child);
}

class _TownPainter extends CustomPainter {
  final int level;
  const _TownPainter({required this.level});

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Offset.zero & size, Paint()..color = const Color(0xFFCFF4EE));
    canvas.drawRect(Rect.fromLTWH(0, size.height * .20, size.width, size.height * .80), Paint()..color = const Color(0xFFBFE8A8));

    final road = Paint()..color = const Color(0xFFE9D2AA);
    final path = Path()
      ..moveTo(size.width * .42, size.height)
      ..quadraticBezierTo(size.width * .58, size.height * .68, size.width * .48, size.height * .47)
      ..quadraticBezierTo(size.width * .38, size.height * .28, size.width * .52, size.height * .18)
      ..lineTo(size.width * .66, size.height * .18)
      ..quadraticBezierTo(size.width * .55, size.height * .30, size.width * .63, size.height * .48)
      ..quadraticBezierTo(size.width * .72, size.height * .70, size.width * .62, size.height)
      ..close();
    canvas.drawPath(path, road);

    canvas.drawOval(Rect.fromCenter(center: Offset(size.width * .18, size.height * .76), width: 120 * webUiScale, height: 68 * webUiScale), Paint()..color = const Color(0xFF87D7DF));

    for (var i = 0; i < 9; i++) {
      final x = 35.0 + (i % 3) * (size.width - 70) / 2.5;
      final y = 55.0 + (i ~/ 3) * (size.height - 120) / 2.5;
      canvas.drawCircle(Offset(x, y), 17, Paint()..color = const Color(0xFF68B978));
      canvas.drawRect(Rect.fromCenter(center: Offset(x, y + 19 * webUiScale), width: 7, height: 22 * webUiScale), Paint()..color = const Color(0xFF9B7450));
    }
  }

  @override
  bool shouldRepaint(covariant _TownPainter oldDelegate) => oldDelegate.level != level;
}
