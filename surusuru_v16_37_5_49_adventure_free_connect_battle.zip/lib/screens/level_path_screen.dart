import 'package:flutter/material.dart';

import '../widgets/app_bottom_nav.dart';

import '../web_ui_scale.dart';
import '../game/game_controller.dart';

class LevelPathScreen extends StatelessWidget {
  final GameController controller;
  const LevelPathScreen({super.key, required this.controller});

  static const _titles = <String>[
    'ファーム解放',
    '最初の住人',
    'ドリンク解放',
    '新しい箱マス',
    'スイーツ解放',
    '街の飾り',
    'フラワー解放',
    '広場を拡張',
    'キッチン解放',
    '特別な仲間',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F9FF),
      appBar: AppBar(
        toolbarHeight: 72 * webUiScale,
        title: const Text('レベルパス', style: TextStyle(fontSize: 30 * webUiScale, fontWeight: FontWeight.w900)),
        leadingWidth: 74 * webUiScale,
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.arrow_back_rounded, size: 38 * webUiScale),
        ),
      ),
      bottomNavigationBar: AppBottomNav(controller: controller, active: ''),
      body: ListView.builder(
        padding: const EdgeInsets.all(16 * webUiScale),
        itemCount: 10,
        itemBuilder: (context, i) {
          final lv = i + 1;
          final reached = controller.state.level >= lv;
          final isWorld = GameController.worldRewardLevels.contains(lv);
          final isBoard = GameController.blockedUnlockLevels.values.contains(lv) && !isWorld;
          final claimed = lv == 1 || (isWorld && controller.levelRewardClaimed(lv)) ||
              (isBoard && controller.allBoardCellsForLevelUnlocked(lv));
          final waiting = reached && !claimed;

          String status;
          if (claimed) {
            status = '✓ 解放済み';
          } else if (!reached) {
            status = '🔒 Lv.$lvで到達';
          } else if (isBoard) {
            status = '✨ 盤面でタップして解放';
          } else {
            status = '🎁 街でタップして解放';
          }

          return Container(
            margin: const EdgeInsets.only(bottom: 12 * webUiScale),
            padding: const EdgeInsets.all(16 * webUiScale),
            decoration: BoxDecoration(
              gradient: waiting
                  ? const LinearGradient(colors: [Color(0xFFFFF1A8), Color(0xFFFFD289)])
                  : null,
              color: waiting ? null : claimed ? const Color(0xFFE8FFF0) : Colors.white,
              borderRadius: BorderRadius.circular(22 * webUiScale),
              border: Border.all(
                color: waiting ? const Color(0xFFFF9A3D) : claimed ? const Color(0xFF65C98D) : const Color(0xFFD6E0E8),
                width: waiting ? 3 : 2,
              ),
              boxShadow: waiting ? const [BoxShadow(color: Color(0x55FF9A3D), blurRadius: 14, spreadRadius: 2)] : null,
            ),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundColor: waiting ? const Color(0xFFFF8B43) : claimed ? const Color(0xFF42B8C6) : const Color(0xFFCBD4DA),
                  child: Text('$lv', style: const TextStyle(fontSize: 25 * webUiScale, fontWeight: FontWeight.w900, color: Colors.white)),
                ),
                const SizedBox(width: 16 * webUiScale),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(_titles[i], style: const TextStyle(fontSize: 25 * webUiScale, fontWeight: FontWeight.w900)),
                      const SizedBox(height: 4),
                      Text(status, style: TextStyle(fontSize: 17 * webUiScale, fontWeight: FontWeight.w900, color: waiting ? const Color(0xFFDF6532) : const Color(0xFF67767A))),
                    ],
                  ),
                ),
                Text(claimed ? '✅' : waiting ? '👆' : '🔒', style: const TextStyle(fontSize: 32 * webUiScale)),
              ],
            ),
          );
        },
      ),
    );
  }
}
