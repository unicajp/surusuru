import 'package:flutter/material.dart';

import '../widgets/app_bottom_nav.dart';

import '../web_ui_scale.dart';

import '../game/game_controller.dart';
import '../sfx_manager.dart';

class MissionScreen extends StatelessWidget {
  final GameController controller;

  const MissionScreen({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF9F5),
      appBar: AppBar(
        leadingWidth: 86 * webUiScale,
        leading: IconButton(
          tooltip: '戻る',
          onPressed: () { SfxManager.instance.tap(); Navigator.of(context).maybePop(); },
          icon: const Icon(Icons.arrow_back_rounded, size: 48 * webUiScale),
        ),
        backgroundColor: const Color(0xFFFFF9F5),
        foregroundColor: const Color(0xFF674F49),
        elevation: 0,
        centerTitle: true,
        title: const Text(
          '今日のミッション',
          style: TextStyle(fontSize: 38 * webUiScale, fontWeight: FontWeight.w900),
        ),
      ),
      bottomNavigationBar: AppBottomNav(controller: controller, active: 'mission'),
      body: AnimatedBuilder(
        animation: controller,
        builder: (context, _) {
          return SafeArea(
            top: false,
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16 * webUiScale, 10 * webUiScale, 16 * webUiScale, 28 * webUiScale),
              children: [
                _MissionCard(
                  controller: controller,
                  id: 1,
                  icon: controller.generatorEmoji(controller.featuredMissionGeneratorId),
                  title: controller.featuredMissionTitle,
                ),
                const SizedBox(height: 12 * webUiScale),
                _MissionCard(
                  controller: controller,
                  id: 2,
                  icon: '✨',
                  title: '✨ 3回マージする',
                ),
                const SizedBox(height: 12 * webUiScale),
                _MissionCard(
                  controller: controller,
                  id: 3,
                  icon: '🌟',
                  title: '📦 注文を2件納品する',
                ),
                const SizedBox(height: 18 * webUiScale),
                const Text(
                  'ミッションは毎日リセットされます',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 28 * webUiScale,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFFA28A83),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _MissionCard extends StatelessWidget {
  final GameController controller;
  final int id;
  final String icon;
  final String title;

  const _MissionCard({
    required this.controller,
    required this.id,
    required this.icon,
    required this.title,
  });

  @override
  Widget build(BuildContext context) {
    final progress = controller.missionProgress(id);
    final target = controller.missionTarget(id);
    final reward = controller.missionReward(id);
    final completed = controller.missionCompleted(id);
    final claimed = controller.missionClaimed(id);

    final ratio = (progress / target).clamp(0.0, 1.0);

    return Container(
      padding: const EdgeInsets.all(22 * webUiScale),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF0E9),
        borderRadius: BorderRadius.circular(20 * webUiScale),
        border: Border.all(
          color: completed ? const Color(0xFFE8B09F) : const Color(0xFFF0D8CE),
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 62 * webUiScale,
                height: 62 * webUiScale,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: const Color(0xFFFFE3D8),
                  borderRadius: BorderRadius.circular(15 * webUiScale),
                ),
                child: Text(icon, style: const TextStyle(fontSize: 40 * webUiScale)),
              ),
              const SizedBox(width: 12 * webUiScale),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 32 * webUiScale,
                        fontWeight: FontWeight.w900,
                        color: Color(0xFF654D48),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${progress.clamp(0, target)} / $target',
                      style: const TextStyle(
                        fontSize: 28 * webUiScale,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF9A7A73),
                      ),
                    ),
                  ],
                ),
              ),
              Text(
                '🪙 $reward',
                style: const TextStyle(
                  fontSize: 28 * webUiScale,
                  fontWeight: FontWeight.w900,
                  color: Color(0xFF72594E),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12 * webUiScale),
          ClipRRect(
            borderRadius: BorderRadius.circular(99 * webUiScale),
            child: LinearProgressIndicator(
              value: ratio,
              minHeight: 12 * webUiScale,
              backgroundColor: const Color(0xFFEADDD8),
              color: const Color(0xFFE9A69A),
            ),
          ),
          const SizedBox(height: 12 * webUiScale),
          SizedBox(
            width: double.infinity,
            height: 92 * webUiScale,
            child: FilledButton(
              onPressed: completed && !claimed
                  ? () async {
                      SfxManager.instance.tap();
                      final ok = await controller.claimMission(id);

                      if (!context.mounted || !ok) {
                        SfxManager.instance.error();
                        return;
                      }
                      SfxManager.instance.reward();

                      ScaffoldMessenger.of(context)
                        ..hideCurrentSnackBar()
                        ..showSnackBar(
                          SnackBar(
                            behavior: SnackBarBehavior.floating,
                            content: Text('🪙 $reward コインを受け取りました！'),
                          ),
                        );
                    }
                  : null,
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFFE8A092),
                disabledBackgroundColor: const Color(0xFFE2D9D5),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14 * webUiScale),
                ),
              ),
              child: Text(
                claimed
                    ? '受取済み'
                    : completed
                    ? '報酬を受け取る'
                    : '挑戦中',
                style: const TextStyle(
                  fontSize: 28 * webUiScale,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
