import 'package:flutter/material.dart';
import '../game/game_controller.dart';

class StickerCollectionScreen extends StatelessWidget {
  final GameController controller;
  const StickerCollectionScreen({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    final ids = <String>[...GameController.suruStickerIds, 'daily_star'];
    return Scaffold(
      backgroundColor: const Color(0xFF08163A),
      appBar: AppBar(
        backgroundColor: const Color(0xFF08163A),
        foregroundColor: Colors.white,
        title: const Text('SURUSURU COLLECTION', style: TextStyle(fontWeight: FontWeight.w900)),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: const Color(0xFF13275B),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: const Color(0xFF4B78C9)),
              ),
              child: Text(
                '宝箱を開けてシールを集めよう！\n${controller.suruStickers.length} / ${ids.length} COLLECTION',
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, height: 1.45),
              ),
            ),
          ),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(14),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: .9,
              ),
              itemCount: ids.length,
              itemBuilder: (context, i) {
                final id = ids[i];
                final owned = controller.suruStickers.contains(id);
                return AnimatedOpacity(
                  opacity: owned ? 1 : .35,
                  duration: const Duration(milliseconds: 200),
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: owned
                            ? const [Color(0xFF214B93), Color(0xFF14285A)]
                            : const [Color(0xFF25304E), Color(0xFF171E34)],
                      ),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: owned ? const Color(0xFF7DE8FF) : Colors.white24),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(owned ? (GameController.suruStickerEmoji[id] ?? '✨') : '？', style: const TextStyle(fontSize: 38)),
                        const SizedBox(height: 7),
                        Text(
                          owned ? (GameController.suruStickerName[id] ?? id) : '???',
                          textAlign: TextAlign.center,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 11),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
