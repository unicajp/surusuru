import 'package:flutter/material.dart';

import '../game/game_controller.dart';
import '../sfx_manager.dart';
import '../widgets/app_bottom_nav.dart';
import 'game_screen.dart';

class HomeRoomScreen extends StatefulWidget {
  final GameController controller;

  const HomeRoomScreen({
    super.key,
    required this.controller,
  });

  @override
  State<HomeRoomScreen> createState() => _HomeRoomScreenState();
}

class _HomeRoomScreenState extends State<HomeRoomScreen> {
  GameController get c => widget.controller;

  static const items = <String, (String, String)>{
    'rug_basic': ('ラグ', '🟫'),
    'sofa_cream': ('クリームソファ', '🛋️'),
    'table_round': ('丸テーブル', '🪑'),
    'plant_leaf': ('観葉植物', '🪴'),
    'lamp_moon': ('ムーンライト', '🌙'),
    'shelf_wood': ('ウッドシェルフ', '🗄️'),
    'bed_cloud': ('雲のベッド', '🛏️'),
    'poster_chain': ('CHAIN MASTER', '🏆'),
  };

  static const clothes = <String, (String, String)>{
    'casual': ('いつもの服', '👕'),
    'pink_dress': ('ピンクドレス', '👗'),
    'blue_knit': ('ブルーニット', '🧥'),
    'star_pajama': ('星のパジャマ', '🩱'),
  };

  Future<void> _shop() async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  '家具ショップ',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  '🪙 ${c.state.coins}',
                  style: const TextStyle(fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 8),
                SizedBox(
                  height: 310,
                  child: GridView.count(
                    crossAxisCount: 2,
                    childAspectRatio: 1.7,
                    children: items.entries
                        .where((e) => e.key != 'poster_chain')
                        .map((e) {
                      final owned = c.ownedHomeItems.contains(e.key);
                      final price = GameController.homeItemPrices[e.key] ?? 0;

                      return Card(
                        child: InkWell(
                          onTap: () async {
                            if (!owned) {
                              final ok = await c.buyHomeItem(e.key);
                              if (!ok && mounted) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text('コインが足りません'),
                                  ),
                                );
                              }
                            } else {
                              await c.togglePlacedHomeItem(e.key);
                            }
                            setSheet(() {});
                            if (mounted) setState(() {});
                          },
                          child: Padding(
                            padding: const EdgeInsets.all(8),
                            child: Row(
                              children: [
                                Text(
                                  e.value.$2,
                                  style: const TextStyle(fontSize: 30),
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        e.value.$1,
                                        style: const TextStyle(
                                          fontWeight: FontWeight.w900,
                                        ),
                                      ),
                                      Text(
                                        owned
                                            ? (c.placedHomeItems.contains(e.key)
                                                ? '配置中・タップで収納'
                                                : '所持済・タップで配置')
                                            : '🪙 $price',
                                        style: const TextStyle(fontSize: 11),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _settings() async {
    SfxManager.instance.tap();
    bool requestReset = false;

    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) => AlertDialog(
          title: const Text(
            '⚙️ 設定',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
          ),
          content: SizedBox(
            width: 420,
            child: AnimatedBuilder(
              animation: SfxManager.instance,
              builder: (context, _) => Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    '効果音  ${SfxManager.instance.volumePercent.round()}%',
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  Slider(
                    min: 0,
                    max: 300,
                    divisions: 30,
                    value: SfxManager.instance.volumePercent,
                    onChanged: (value) {
                      SfxManager.instance.setVolumePercent(value);
                      setDialogState(() {});
                    },
                    onChangeEnd: (_) => SfxManager.instance.tap(),
                  ),
                    const SizedBox(height: 8),
                    Text(
                      'BGM  ${SfxManager.instance.bgmPercent.round()}%',
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
                    ),
                    Slider(
                      min: 0,
                      max: 100,
                      divisions: 20,
                      value: SfxManager.instance.bgmPercent,
                      onChanged: (value) {
                        SfxManager.instance.setBgmPercent(value);
                        setDialogState(() {});
                      },
                    ),
                  SizedBox(
                    height: 48,
                    child: FilledButton.icon(
                      onPressed: () => SfxManager.instance.test(),
                      icon: const Icon(Icons.volume_up_rounded),
                      label: const Text(
                        '効果音をテスト',
                        style: TextStyle(fontWeight: FontWeight.w900),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Divider(),
                  const SizedBox(height: 8),
                  const Text(
                    'データ管理',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 8),
                  FilledButton.tonalIcon(
                    onPressed: () {
                      requestReset = true;
                      Navigator.pop(dialogContext);
                    },
                    icon: const Icon(Icons.delete_forever_rounded),
                    label: const Text(
                      'プレイデータを消去',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'レベル・コイン・家具・服・図鑑・ミッションなどを最初の状態に戻します。',
                    style: TextStyle(fontSize: 11, color: Color(0xFF7A6760)),
                  ),
                ],
              ),
            ),
          ),
          actions: [
            FilledButton(
              onPressed: () {
                SfxManager.instance.tap();
                Navigator.pop(dialogContext);
              },
              child: const Text('閉じる'),
            ),
          ],
        ),
      ),
    );

    if (!requestReset || !mounted) return;

    final reset = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text(
          'プレイデータを消去しますか？',
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
        content: const Text(
          'この操作は元に戻せません。\nLv.1から最初の状態に戻します。',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('キャンセル'),
          ),
          FilledButton.icon(
            onPressed: () => Navigator.pop(dialogContext, true),
            icon: const Icon(Icons.delete_forever_rounded),
            label: const Text('消去する'),
          ),
        ],
      ),
    );

    if (reset != true || !mounted) return;
    await c.resetAllProgress();
    if (!mounted) return;
    setState(() {});
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('プレイデータを消去しました。')),
    );
  }

  Future<void> _wardrobe() async {
    await showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'クローゼット',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                ...clothes.entries.map((e) {
                  final owned = c.ownedClothes.contains(e.key);
                  return ListTile(
                    leading: Text(
                      e.value.$2,
                      style: const TextStyle(fontSize: 30),
                    ),
                    title: Text(e.value.$1),
                    subtitle: Text(
                      owned
                          ? (c.equippedClothes == e.key
                              ? '着用中'
                              : 'タップで着替え')
                          : '🪙 ${GameController.clothesPrices[e.key]}',
                    ),
                    onTap: () async {
                      if (owned) {
                        await c.equipClothes(e.key);
                      } else {
                        await c.buyClothes(e.key);
                      }
                      setSheet(() {});
                      if (mounted) setState(() {});
                    },
                  );
                }),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF8F0),
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 6),
              child: Row(
                children: [
                  const Text(
                    'surusuru',
                    style: TextStyle(
                      fontSize: 25,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const Spacer(),
                  Text(
                    '🪙 ${c.state.coins}',
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(width: 10),
                  IconButton(
                    onPressed: _wardrobe,
                    icon: const Icon(Icons.checkroom_rounded),
                  ),
                  IconButton(
                    tooltip: '設定',
                    onPressed: _settings,
                    icon: const Icon(Icons.settings_rounded),
                  ),
                  IconButton(
                    onPressed: _shop,
                    icon: const Icon(Icons.storefront_rounded),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFEEDB),
                    borderRadius: BorderRadius.circular(28),
                    border: Border.all(
                      color: const Color(0xFFE6CBAF),
                      width: 2,
                    ),
                  ),
                  child: Stack(
                    children: [
                      Positioned.fill(
                        child: CustomPaint(painter: _RoomPainter()),
                      ),
                      ...c.placedHomeItems
                          .toList()
                          .asMap()
                          .entries
                          .map((x) {
                        final e = items[x.value];
                        if (e == null) return const SizedBox.shrink();
                        final col = x.key % 3;
                        final row = x.key ~/ 3;
                        return Positioned(
                          left: 30.0 + col * 95,
                          top: 120.0 + row * 90,
                          child: Draggable<String>(
                            data: x.value,
                            feedback: Material(
                              color: Colors.transparent,
                              child: Text(
                                e.$2,
                                style: const TextStyle(fontSize: 52),
                              ),
                            ),
                            childWhenDragging:
                                const SizedBox(width: 52, height: 52),
                            child: Text(
                              e.$2,
                              style: const TextStyle(fontSize: 52),
                            ),
                          ),
                        );
                      }),
                      Positioned(
                        left: 18,
                        bottom: 18,
                        child: Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: .85),
                            borderRadius: BorderRadius.circular(18),
                          ),
                          child: Row(
                            children: [
                              Text(
                                clothes[c.equippedClothes]?.$2 ?? '👕',
                                style: const TextStyle(fontSize: 42),
                              ),
                              const SizedBox(width: 8),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    'わたしの部屋',
                                    style:
                                        TextStyle(fontWeight: FontWeight.w900),
                                  ),
                                  Text(
                                    'BEST ${c.puzzleBestChain} CHAIN',
                                    style: const TextStyle(fontSize: 11),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        right: 18,
                        bottom: 18,
                        child: FilledButton.icon(
                          onPressed: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => GameScreen(controller: c),
                            ),
                          ),
                          icon: const Icon(Icons.auto_awesome),
                          label: const Text('パズルで稼ぐ'),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            AppBottomNav(controller: c, active: 'home'),
          ],
        ),
      ),
    );
  }
}

class _RoomPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..color = const Color(0xFFFFF8EA);
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height * .58), p);

    p.color = const Color(0xFFDDBE9D);
    canvas.drawRect(
      Rect.fromLTWH(0, size.height * .58, size.width, size.height * .42),
      p,
    );

    p.color = const Color(0xFFBFE2F2);
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(size.width * .62, 35, size.width * .25, 90),
        const Radius.circular(12),
      ),
      p,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
