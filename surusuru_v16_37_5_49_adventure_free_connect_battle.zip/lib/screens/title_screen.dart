import 'package:flutter/material.dart';

import '../web_ui_scale.dart';

import '../game/game_controller.dart';
import '../sfx_manager.dart';
import 'rpg_home_screen.dart';

class TitleScreen extends StatefulWidget {
  const TitleScreen({super.key});

  @override
  State<TitleScreen> createState() => _TitleScreenState();
}

class _TitleScreenState extends State<TitleScreen> {
  final GameController controller = GameController();

  Future<void>? _loadFuture;

  bool loading = false;
  double progress = 0;

  Future<void> startGame() async {
    if (loading) return;
    SfxManager.instance.tap();

    setState(() {
      loading = true;
      progress = 0.12;
    });

    await Future<void>.delayed(const Duration(milliseconds: 40));

    if (!mounted) return;

    setState(() => progress = 0.35);

    await (_loadFuture ??= controller.load());

    if (!mounted) return;

    setState(() => progress = 0.82);

    await Future<void>.delayed(const Duration(milliseconds: 80));

    if (!mounted) return;

    setState(() => progress = 1);

    await Future<void>.delayed(const Duration(milliseconds: 70));

    if (!mounted) return;

    Navigator.of(context).pushReplacement(
      PageRouteBuilder<void>(
        transitionDuration: const Duration(milliseconds: 260),
        pageBuilder: (_, animation, secondary) {
          return RpgHomeScreen(controller: controller);
        },
        transitionsBuilder: (_, animation, secondary, child) {
          return FadeTransition(opacity: animation, child: child);
        },
      ),
    );
  }

  @override
  void initState() {
    super.initState();

    // タイトル画面の描画を待たず、
    // セーブデータを裏で先読みする。
    _loadFuture = controller.load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFFFFCF8), Color(0xFFFFEFF4)],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: Transform.translate(
              offset: const Offset(0, -18 * webUiScale),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  FractionallySizedBox(
                    widthFactor: 0.68,
                    child: FittedBox(
                      fit: BoxFit.contain,
                      child: const Text(
                        'surusuru',
                        textAlign: TextAlign.center,
                        maxLines: 1,
                        style: TextStyle(
                          fontSize: 150 * webUiScale,
                          height: 0.90,
                          fontWeight: FontWeight.w900,
                          letterSpacing: -3.2 * webUiScale,
                          color: Color(0xFF4C3E45),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12 * webUiScale),
                  const SizedBox(height: 18 * webUiScale),
                  const Text('🐥   🐸   🐧   🐰', style: TextStyle(fontSize: 68 * webUiScale)),
                  const SizedBox(height: 34 * webUiScale),
                  if (!loading)
                    GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: startGame,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 72 * webUiScale,
                          vertical: 28 * webUiScale,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.58),
                          borderRadius: BorderRadius.circular(99 * webUiScale),
                        ),
                        child: const Text(
                          'TAP TO START',
                          style: TextStyle(
                            fontSize: 30 * webUiScale,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 3.5 * webUiScale,
                            color: Color(0xFF955D70),
                          ),
                        ),
                      ),
                    )
                  else
                    SizedBox(
                      width: 380 * webUiScale,
                      child: Column(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(99 * webUiScale),
                            child: LinearProgressIndicator(
                              value: progress,
                              minHeight: 20 * webUiScale,
                              backgroundColor: const Color(0xFFF0D9E1),
                              color: const Color(0xFFA56277),
                            ),
                          ),
                          const SizedBox(height: 16 * webUiScale),
                          Text(
                            'Loading... ${(progress * 100).round()}%',
                            style: const TextStyle(
                              fontSize: 52 * webUiScale,
                              fontWeight: FontWeight.w700,
                              color: Color(0xFF947982),
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
