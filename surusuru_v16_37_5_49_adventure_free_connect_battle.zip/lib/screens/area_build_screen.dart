import 'package:flutter/material.dart';
import '../game/game_controller.dart';
import '../sfx_manager.dart';

class AreaBuildScreen extends StatefulWidget {
  final GameController controller;
  const AreaBuildScreen({super.key, required this.controller});
  @override
  State<AreaBuildScreen> createState() => _AreaBuildScreenState();
}

class _AreaBuildScreenState extends State<AreaBuildScreen> {
  Future<void> _pick(String id) async {
    final ok = await widget.controller.chooseSuruAreaBoost(id);
    if (ok) SfxManager.instance.unlock();
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.controller;
    final remaining = GameController.suruBoostIds.where((e) => !c.suruAreaBoosts.contains(e)).toList();
    return Scaffold(
      backgroundColor: const Color(0xFF071638),
      appBar: AppBar(
        backgroundColor: const Color(0xFF071638),
        foregroundColor: Colors.white,
        title: Text('AREA ${c.suruAreaId} BUILD', style: const TextStyle(fontWeight: FontWeight.w900)),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: const Color(0xFF14295E), borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFF6B83FF))),
              child: Text(
                'このエリアだけの能力を最大3つ選べます。\n宝箱を初クリアすると PICK を獲得。エリア10クリアでリセット。\n\nPICK ${c.suruBuildCredits}　選択 ${c.suruAreaBoosts.length}/3',
                style: const TextStyle(color: Colors.white, height: 1.5, fontWeight: FontWeight.w800),
              ),
            ),
            const SizedBox(height: 18),
            const Text('ACTIVE BUILD', style: TextStyle(color: Color(0xFF7DE8FF), fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            if (c.suruAreaBoosts.isEmpty)
              const Text('まだ能力なし', style: TextStyle(color: Colors.white54))
            else
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: c.suruAreaBoosts.map((id) => Chip(
                  label: Text(GameController.suruBoostName[id] ?? id),
                  avatar: const Text('✨'),
                )).toList(),
              ),
            const SizedBox(height: 18),
            const Text('POWER UP', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            Expanded(
              child: ListView.builder(
                itemCount: remaining.length,
                itemBuilder: (context, i) {
                  final id = remaining[i];
                  final canPick = c.suruBuildCredits > 0 && c.suruAreaBoosts.length < 3;
                  return Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    decoration: BoxDecoration(color: const Color(0xFF122657), borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFF365FA8))),
                    child: ListTile(
                      leading: const Text('✨', style: TextStyle(fontSize: 26)),
                      title: Text(GameController.suruBoostName[id] ?? id, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
                      subtitle: Text(GameController.suruBoostDescription[id] ?? '', style: const TextStyle(color: Colors.white70)),
                      trailing: FilledButton.tonal(onPressed: canPick ? () => _pick(id) : null, child: const Text('選ぶ')),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
