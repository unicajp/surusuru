import 'package:flutter/material.dart';

import '../widgets/app_bottom_nav.dart';

import '../web_ui_scale.dart';

import '../game/game_controller.dart';
import '../game/stage_definition.dart';
import 'game_screen.dart';

class ShopInteriorScreen extends StatelessWidget {
  final GameController controller;
  final String placeName;
  final String owner;
  final String emoji;
  final int stageStart;
  final int stageEnd;
  final bool isHome;

  const ShopInteriorScreen({
    super.key,
    required this.controller,
    required this.placeName,
    required this.owner,
    required this.emoji,
    required this.stageStart,
    required this.stageEnd,
    this.isHome = false,
  });

  String get _placeId {
    if (isHome) return 'home';
    if (stageStart == 6) return 'cafe';
    if (stageStart == 11) return 'bakery';
    if (stageStart == 16) return 'sweets';
    if (stageStart == 21) return 'flower';
    return 'goods';
  }

  @override
  Widget build(BuildContext context) {
    final stages = allStages.where((s) => s.id >= stageStart && s.id <= stageEnd).toList();
    final cleared = stages.where((s) => controller.stageCleared(s.id)).length;

    return Scaffold(
      backgroundColor: const Color(0xFFFFFBF5),
      appBar: AppBar(
        backgroundColor: const Color(0xFFFFFBF5),
        title: Text('$emoji $placeName'),
      ),
      bottomNavigationBar: AppBottomNav(controller: controller, active: ''),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(14 * webUiScale, 4 * webUiScale, 14 * webUiScale, 10 * webUiScale),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(isHome ? 'わたしのおうち' : '$owner の場所', style: const TextStyle(fontSize: 28 * webUiScale, fontWeight: FontWeight.w900, color: Color(0xFF614E48))),
                        const SizedBox(height: 4),
                        Text('お手伝い $cleared / 5', style: const TextStyle(fontSize: 19 * webUiScale, fontWeight: FontWeight.w800, color: Color(0xFF8E756B))),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16 * webUiScale, vertical: 10 * webUiScale),
                    decoration: BoxDecoration(color: const Color(0xFFFFE8B8), borderRadius: BorderRadius.circular(18 * webUiScale)),
                    child: Text('${((cleared / 5) * 100).round()}%', style: const TextStyle(fontSize: 22 * webUiScale, fontWeight: FontWeight.w900, color: Color(0xFF7A5D3C))),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12 * webUiScale, 0, 12 * webUiScale, 12 * webUiScale),
                child: _InteriorScene(
                  placeId: _placeId,
                  stages: stages,
                  controller: controller,
                  onTapStage: (stage) => _openStage(context, stage),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _openStage(BuildContext context, StageDefinition stage) async {
    final available = controller.stageAvailable(stage.id);
    if (!available) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('まずは前のステージをクリアしよう！', style: const TextStyle(fontSize: 20 * webUiScale, fontWeight: FontWeight.w800))),
      );
      return;
    }

    final go = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28 * webUiScale)),
        title: Row(children: [Text(stage.icon, style: const TextStyle(fontSize: 42 * webUiScale)), const SizedBox(width: 10 * webUiScale), Expanded(child: Text('STAGE ${stage.id}', style: const TextStyle(fontSize: 28 * webUiScale, fontWeight: FontWeight.w900)))]),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(stage.title, style: const TextStyle(fontSize: 25 * webUiScale, fontWeight: FontWeight.w900)),
            const SizedBox(height: 8 * webUiScale),
            Text(stage.request, style: const TextStyle(fontSize: 20 * webUiScale, height: 1.35, fontWeight: FontWeight.w700)),
            if (controller.stageCleared(stage.id)) ...[
              const SizedBox(height: 12 * webUiScale),
              const Text('✅ クリア済み・何度でも遊べます', style: TextStyle(fontSize: 18 * webUiScale, fontWeight: FontWeight.w900, color: Color(0xFF4E9A69))),
            ],
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('あとで', style: TextStyle(fontSize: 20 * webUiScale))),
          FilledButton(
            onPressed: () => Navigator.pop(d, true),
            style: FilledButton.styleFrom(backgroundColor: stage.accent),
            child: const Text('パズルへ！', style: TextStyle(fontSize: 22 * webUiScale, fontWeight: FontWeight.w900)),
          ),
        ],
      ),
    );
    if (go == true && context.mounted) {
      await Navigator.push(context, MaterialPageRoute(builder: (_) => GameScreen(controller: controller, stage: stage)));
    }
  }
}

class _InteriorScene extends StatelessWidget {
  final String placeId;
  final List<StageDefinition> stages;
  final GameController controller;
  final ValueChanged<StageDefinition> onTapStage;

  const _InteriorScene({required this.placeId, required this.stages, required this.controller, required this.onTapStage});

  @override
  Widget build(BuildContext context) {
    final palette = _palette(placeId);
    final positions = _positions(placeId);
    final props = _props(placeId);
    final completion = stages.where((s) => controller.stageCleared(s.id)).length;

    return LayoutBuilder(
      builder: (context, box) {
        return Container(
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(
            gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [palette.$1, palette.$2]),
            borderRadius: BorderRadius.circular(30 * webUiScale),
            border: Border.all(color: palette.$3, width: 3),
            boxShadow: const [BoxShadow(color: Color(0x22000000), blurRadius: 16, offset: Offset(0, 7 * webUiScale))],
          ),
          child: Stack(
            children: [
              Positioned(left: 0, right: 0, top: box.maxHeight * .55, bottom: 0, child: Container(color: palette.$4)),
              Positioned(left: 18 * webUiScale, top: 18 * webUiScale, child: _WallDecor(placeId: placeId)),
              Positioned(right: 18 * webUiScale, top: 20 * webUiScale, child: Text(_roomEmoji(placeId), style: const TextStyle(fontSize: 66 * webUiScale))),
              ...List.generate(props.length, (i) {
                final visible = i < completion || i == 0;
                final p = props[i];
                return Positioned(
                  left: box.maxWidth * p.$1,
                  top: box.maxHeight * p.$2,
                  child: AnimatedOpacity(
                    duration: const Duration(milliseconds: 350),
                    opacity: visible ? 1 : .18,
                    child: AnimatedScale(
                      duration: const Duration(milliseconds: 350),
                      scale: visible ? 1 : .82,
                      child: Text(p.$3, style: TextStyle(fontSize: p.$4)),
                    ),
                  ),
                );
              }),
              ...List.generate(stages.length, (i) {
                final stage = stages[i];
                final pos = positions[i];
                final cleared = controller.stageCleared(stage.id);
                final available = controller.stageAvailable(stage.id);
                return Positioned(
                  left: box.maxWidth * pos.dx - 50,
                  top: box.maxHeight * pos.dy - 48,
                  child: _StageHotspot(stage: stage, cleared: cleared, available: available, onTap: () => onTapStage(stage)),
                );
              }),

            ],
          ),
        );
      },
    );
  }

  (Color, Color, Color, Color) _palette(String id) => switch (id) {
    'home' => (const Color(0xFFFFF1D9), const Color(0xFFFFE1D1), const Color(0xFFE0B98C), const Color(0xFFD8B48A)),
    'cafe' => (const Color(0xFFFFECD9), const Color(0xFFFFD7C4), const Color(0xFFD89A76), const Color(0xFFC99772)),
    'bakery' => (const Color(0xFFFFEBC9), const Color(0xFFFFD9A9), const Color(0xFFD79E55), const Color(0xFFC78B4B)),
    'sweets' => (const Color(0xFFFFE4EF), const Color(0xFFFBD1E3), const Color(0xFFD790B3), const Color(0xFFD9A5BD)),
    'flower' => (const Color(0xFFEAF6DC), const Color(0xFFD8EDC7), const Color(0xFF86B86F), const Color(0xFFADCF96)),
    _ => (const Color(0xFFE8E8FA), const Color(0xFFD6D9F4), const Color(0xFF8D91C5), const Color(0xFFAAAED6)),
  };

  List<Offset> _positions(String id) => switch (id) {
    'home' => const [Offset(.19,.28), Offset(.66,.25), Offset(.34,.49), Offset(.72,.56), Offset(.43,.72)],
    'cafe' => const [Offset(.18,.34), Offset(.51,.25), Offset(.78,.39), Offset(.31,.61), Offset(.68,.70)],
    'bakery' => const [Offset(.21,.28), Offset(.54,.33), Offset(.78,.25), Offset(.30,.62), Offset(.68,.67)],
    'sweets' => const [Offset(.20,.31), Offset(.54,.24), Offset(.78,.42), Offset(.31,.63), Offset(.69,.70)],
    'flower' => const [Offset(.18,.32), Offset(.50,.24), Offset(.78,.35), Offset(.31,.64), Offset(.68,.69)],
    _ => const [Offset(.20,.28), Offset(.54,.25), Offset(.79,.38), Offset(.31,.63), Offset(.68,.70)],
  };

  List<(double,double,String,double)> _props(String id) => switch (id) {
    'home' => const [(0.07,.58,'🛋️',68),(0.63,.18,'🪟',72),(0.58,.57,'🪴',58),(0.18,.15,'🖼️',50),(0.40,.45,'🧸',46)],
    'cafe' => const [(0.06,.60,'🪑',62),(0.57,.52,'☕',54),(0.68,.14,'🧁',48),(0.14,.18,'🌿',50),(0.40,.52,'🍰',52)],
    'bakery' => const [(0.06,.58,'🥖',62),(0.58,.54,'🍞',60),(0.69,.15,'🧺',54),(0.12,.18,'🌾',52),(0.40,.47,'🥐',56)],
    'sweets' => const [(0.07,.59,'🍰',64),(0.59,.54,'🧁',58),(0.69,.15,'🍬',52),(0.13,.17,'🎀',48),(0.40,.46,'🍮',54)],
    'flower' => const [(0.07,.58,'🌷',62),(0.59,.54,'💐',62),(0.68,.15,'🌼',54),(0.12,.17,'🪴',52),(0.40,.47,'🌸',56)],
    _ => const [(0.07,.58,'🎁',62),(0.59,.54,'🧸',58),(0.68,.15,'🕯️',52),(0.12,.17,'🪄',50),(0.40,.47,'💎',54)],
  };

  String _roomEmoji(String id) => switch (id) {'home'=>'🏠','cafe'=>'☕','bakery'=>'🥐','sweets'=>'🍰','flower'=>'🌷',_=>'🎁'};
  String _guide(String id, int n) => n >= 5 ? '🎉 5つのお手伝い完了！ この場所は完成です' : '光っているアイコンをタップして、次のお手伝いへ！';
}

class _WallDecor extends StatelessWidget {
  final String placeId;
  const _WallDecor({required this.placeId});
  @override
  Widget build(BuildContext context) {
    final text = switch (placeId) {'home'=>'MY ROOM','cafe'=>'MIMI CAFE','bakery'=>'BAKERY','sweets'=>'SWEETS','flower'=>'FLOWER SHOP',_=>'GOODS'};
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16 * webUiScale, vertical: 9 * webUiScale),
      decoration: BoxDecoration(color: Colors.white.withValues(alpha:.72), borderRadius: BorderRadius.circular(16 * webUiScale)),
      child: Text(text, style: const TextStyle(fontSize: 17 * webUiScale, fontWeight: FontWeight.w900, letterSpacing: 1.3 * webUiScale, color: Color(0xFF7D655D))),
    );
  }
}

class _StageHotspot extends StatefulWidget {
  final StageDefinition stage;
  final bool cleared;
  final bool available;
  final VoidCallback onTap;
  const _StageHotspot({required this.stage, required this.cleared, required this.available, required this.onTap});
  @override State<_StageHotspot> createState() => _StageHotspotState();
}

class _StageHotspotState extends State<_StageHotspot> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync:this, duration:const Duration(milliseconds:900))..repeat(reverse:true);
  @override void dispose(){_c.dispose();super.dispose();}
  @override Widget build(BuildContext context){
    return AnimatedBuilder(animation:_c,builder:(context,child){
      final glow = widget.available && !widget.cleared ? .5 + _c.value*.5 : 0.0;
      return Transform.scale(scale:widget.available && !widget.cleared ? 1 + _c.value*.07 : 1,child:GestureDetector(
        onTap: widget.onTap,
        child: Container(
          width:100 * webUiScale,height:96 * webUiScale,
          decoration:BoxDecoration(
            color:widget.cleared?const Color(0xFFF1FFF2):widget.available?Colors.white:const Color(0xCCDFE3E2),
            borderRadius:BorderRadius.circular(24 * webUiScale),
            border:Border.all(color:widget.cleared?const Color(0xFF68B978):widget.available?widget.stage.accent:const Color(0xFFB8BFBD),width:widget.available?3:2),
            boxShadow:widget.available&&!widget.cleared?[BoxShadow(color:widget.stage.accent.withValues(alpha:glow),blurRadius:20,spreadRadius:4)]:const[],
          ),
          child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
            Text(widget.available?widget.stage.icon:'🔒',style:const TextStyle(fontSize:34 * webUiScale)),
            Text('${widget.stage.id}',style:const TextStyle(fontSize:18 * webUiScale,fontWeight:FontWeight.w900)),
            Text(widget.cleared?'CLEAR':widget.available?'PLAY':'LOCK',style:TextStyle(fontSize:12 * webUiScale,fontWeight:FontWeight.w900,color:widget.cleared?const Color(0xFF4B9A60):const Color(0xFF765E55))),
          ]),
        ),
      ));
    });
  }
}
