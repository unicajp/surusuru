import 'package:flutter/material.dart';
import '../game/game_controller.dart';
import '../sfx_manager.dart';

class DailyChestScreen extends StatefulWidget {
  final GameController controller;
  const DailyChestScreen({super.key, required this.controller});
  @override
  State<DailyChestScreen> createState() => _DailyChestScreenState();
}

class _DailyChestScreenState extends State<DailyChestScreen> {
  Future<void> _claim() async {
    final ok = await widget.controller.claimSuruDailyChest();
    if (!mounted) return;
    if (ok) {
      SfxManager.instance.reward();
      await showDialog<void>(
        context: context,
        builder: (d) => AlertDialog(
          title: const Text('DAILY CHEST OPEN! ✨'),
          content: const Text('🪙 +250\n🌟 デイリースター シールGET!'),
          actions: [FilledButton(onPressed: () => Navigator.pop(d), child: const Text('やった！'))],
        ),
      );
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.controller;
    final p = c.suruDailyProgress;
    return Scaffold(
      backgroundColor: const Color(0xFF09173B),
      appBar: AppBar(
        backgroundColor: const Color(0xFF09173B),
        foregroundColor: Colors.white,
        title: const Text('TODAY', style: TextStyle(fontWeight: FontWeight.w900)),
      ),
      body: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          children: [
            const Text('今日の3ステージ', style: TextStyle(color: Color(0xFF7DE8FF), fontSize: 28, fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            const Text('好きなステージを遊んで宝箱を3回開けよう。', style: TextStyle(color: Colors.white70)),
            const SizedBox(height: 24),
            ...List.generate(3, (i) {
              final done = p > i;
              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: done ? const Color(0xFF173F5B) : const Color(0xFF142654),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: done ? const Color(0xFF6FF7C7) : const Color(0xFF426CB2)),
                ),
                child: Row(
                  children: [
                    Text(done ? '✅' : '${i + 1}', style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: Colors.white)),
                    const SizedBox(width: 14),
                    Expanded(child: Text('${i + 1}個目の宝箱を開ける', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900))),
                    Text(done ? 'CLEAR' : '${p}/3', style: TextStyle(color: done ? const Color(0xFF6FF7C7) : Colors.white70, fontWeight: FontWeight.w900)),
                  ],
                ),
              );
            }),
            const Spacer(),
            AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              width: 180,
              height: 130,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: c.canClaimSuruDailyChest ? const Color(0xFFAC6B24) : const Color(0xFF4B4D63),
                borderRadius: BorderRadius.circular(28),
                border: Border.all(color: c.canClaimSuruDailyChest ? const Color(0xFFFFD76A) : Colors.white24, width: 3),
                boxShadow: c.canClaimSuruDailyChest ? const [BoxShadow(color: Color(0x88FFD65A), blurRadius: 28)] : null,
              ),
              child: Text(c.suruDailyChestClaimed ? '✅\nOPENED' : '🎁\nDAILY CHEST', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900)),
            ),
            const SizedBox(height: 18),
            SizedBox(
              width: double.infinity,
              height: 58,
              child: FilledButton(
                onPressed: c.canClaimSuruDailyChest ? _claim : null,
                style: FilledButton.styleFrom(backgroundColor: const Color(0xFFFF5AA5)),
                child: Text(c.suruDailyChestClaimed ? '受け取り済み' : p >= 3 ? 'デイリー宝箱を開ける！' : 'あと ${3 - p}ステージ', style: const TextStyle(fontWeight: FontWeight.w900)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
