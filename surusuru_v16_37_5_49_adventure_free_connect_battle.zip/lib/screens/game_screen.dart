import 'package:flutter/material.dart';

import '../widgets/app_bottom_nav.dart';
import 'package:flutter/foundation.dart';

import '../web_ui_scale.dart';

import '../game/game_controller.dart';
import '../game/game_state.dart';
import '../game/stage_definition.dart';
import '../widgets/merge_item.dart';
import '../widgets/free_pile_puzzle.dart';
import '../sfx_manager.dart';

import 'collection_screen.dart';

import 'daily_reward_screen.dart';

import 'mission_screen.dart';
import 'world_screen.dart';

class GameScreen extends StatefulWidget {
  final GameController controller;
  final StageDefinition? stage;

  const GameScreen({super.key, required this.controller, this.stage});

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  int? _lastShownDiscoveryLevel;

  GameController get controller => widget.controller;
  StageDefinition? get stage => widget.stage;

  int? dragFrom;
  int? hoverCell;
  bool generatorPressed = false;
  bool _spawning = false;
  bool _autoMergeInFlight = false;
  bool _slideActionInFlight = false;
  int? _swipeFrom;
  double _swipeDx = 0;
  double _swipeDy = 0;
  int? _slideAnimFrom;
  int? _slideAnimTo;
  int _slideAnimSerial = 0;
  int? _slideContactTarget;
  bool _autoDeliveryInFlight = false;
  int _secretMergeStreak = 0;
  bool _secretCompleteVisualShown = false;
  int _deliverySparkSerial = 0;
  final GlobalKey _screenKey = GlobalKey();
  final Map<String, GlobalKey> _generatorKeys = <String, GlobalKey>{
    for (final id in GameController.generatorCells.keys) id: GlobalKey(),
  };
  String _activeGeneratorId = 'farm';
  final GlobalKey _boardKey = GlobalKey();
  final GlobalKey _orderKey = GlobalKey();
  int _tutorialStep = -1;

  @override
  void initState() {
    super.initState();
    controller.addListener(_refresh);
    _tutorialStep = -1;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      setState(() {});
    });
  }

  @override
  void dispose() {
    controller.removeListener(_refresh);
    super.dispose();
  }

  void _openMission() {
    SfxManager.instance.tap();
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => MissionScreen(controller: controller),
      ),
    );
  }

  void _openDailyReward() {
    SfxManager.instance.tap();
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => DailyRewardScreen(controller: controller),
      ),
    );
  }

  void _openCollection() {
    SfxManager.instance.tap();
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => CollectionScreen(controller: controller),
      ),
    );
  }

  Future<void> _openDevMenu() async {
    SfxManager.instance.tap();
    bool requestReset = false;
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) {
          return AlertDialog(
            title: const Text('⚙️ 設定', style: TextStyle(fontSize: 32 * webUiScale, fontWeight: FontWeight.w900)),
            content: SizedBox(
              width: 430 * webUiScale,
              child: AnimatedBuilder(
                animation: SfxManager.instance,
                builder: (context, _) => Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text('効果音  ${SfxManager.instance.volumePercent.round()}%', style: const TextStyle(fontSize: 25 * webUiScale, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 8 * webUiScale),
                    Slider(
                      min: 0,
                      max: 300,
                      divisions: 30,
                      value: SfxManager.instance.volumePercent,
                      label: '${SfxManager.instance.volumePercent.round()}%',
                      onChanged: (value) {
                        SfxManager.instance.setVolumePercent(value);
                        setDialogState(() {});
                      },
                      onChangeEnd: (_) => SfxManager.instance.tap(),
                    ),
                    const Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [Text('0%', style: TextStyle(fontSize: 22 * webUiScale, fontWeight: FontWeight.w800)), Text('300%', style: TextStyle(fontSize: 22 * webUiScale, fontWeight: FontWeight.w800))],
                    ),
                    const SizedBox(height: 12 * webUiScale),
                    SizedBox(
                      height: 72 * webUiScale,
                      child: FilledButton.icon(
                        onPressed: () => SfxManager.instance.test(),
                        icon: const Icon(Icons.volume_up_rounded, size: 40 * webUiScale),
                        label: const Text('効果音をテスト', style: TextStyle(fontSize: 24 * webUiScale, fontWeight: FontWeight.w900)),
                      ),
                    ),
                    const SizedBox(height: 18 * webUiScale),
                    const Divider(),
                    const SizedBox(height: 12 * webUiScale),
                    const Text('開発用', style: TextStyle(fontSize: 22 * webUiScale, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 8 * webUiScale),
                    FilledButton.tonal(
                      onPressed: () {
                        requestReset = true;
                        Navigator.pop(dialogContext);
                      },
                      child: const Text('プレイデータを完全初期化', style: TextStyle(fontSize: 21 * webUiScale, fontWeight: FontWeight.w900)),
                    ),
                  ],
                ),
              ),
            ),
            actions: [
              FilledButton(
                onPressed: () { SfxManager.instance.tap(); Navigator.pop(dialogContext); },
                child: const Text('閉じる', style: TextStyle(fontSize: 22 * webUiScale, fontWeight: FontWeight.w900)),
              ),
            ],
          );
        },
      ),
    );
    if (!requestReset || !mounted) return;
    final reset = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('本当に初期化しますか？', style: TextStyle(fontSize: 28 * webUiScale, fontWeight: FontWeight.w900)),
        content: const Text('現在のパズル盤面を最初からやり直します。', style: TextStyle(fontSize: 23 * webUiScale, height: 1.4)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('キャンセル', style: TextStyle(fontSize: 21 * webUiScale))),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('完全初期化', style: TextStyle(fontSize: 22 * webUiScale, fontWeight: FontWeight.w900))),
        ],
      ),
    );
    if (reset != true || !mounted) return;
    await controller.resetAllProgress();
    await controller.prepareSlidePuzzle(stage?.id ?? 1, force: true);
    if (!mounted) return;
    setState(() => _tutorialStep = -1);
    SfxManager.instance.unlock();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(behavior: SnackBarBehavior.floating, content: Text('プレイデータを完全初期化しました。パズルを再生成しました。', style: TextStyle(fontSize: 22 * webUiScale, fontWeight: FontWeight.w800))),
    );
  }

  void _refresh() {
    if (mounted) setState(() {});
  }


  Future<void> _discoverSecret(int secretId) async {
    final currentStage = stage;
    if (currentStage == null || currentStage.id != 1) return;

    final wasComplete = controller.stageSecretsComplete(1);
    final added = await controller.discoverStageSecret(1, secretId);
    if (!added || !mounted) return;

    SfxManager.instance.reward();
    setState(() {});

    if (!wasComplete &&
        controller.stageSecretsComplete(1) &&
        !_secretCompleteVisualShown) {
      _secretCompleteVisualShown = true;
      await showDialog<void>(
        context: context,
        barrierDismissible: true,
        builder: (d) => AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(28 * webUiScale),
          ),
          content: const Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('✨', style: TextStyle(fontSize: 52 * webUiScale)),
              SizedBox(height: 4 * webUiScale),
              Text('🌸', style: TextStyle(fontSize: 76 * webUiScale)),
            ],
          ),
          actionsAlignment: MainAxisAlignment.center,
          actions: [
            FilledButton(
              onPressed: () => Navigator.pop(d),
              child: const Icon(Icons.check_rounded),
            ),
          ],
        ),
      );
    }
  }

  Future<void> _checkBoardSecrets() async {
    if (stage?.id != 1) return;

    // Secret 3: Lv.5 beside the faintly glowing hidden cell (index 12).
    if (const <int>[5, 11, 13, 19]
        .any((i) => controller.state.board[i] == 5)) {
      await _discoverSecret(3);
    }

    // Secret 4: keep three Lv.2 pieces on the board at once.
    if (controller.countLevel(2) >= 3) {
      await _discoverSecret(4);
    }
  }

  Future<void> _checkMergeSecrets(int mergedCell) async {
    if (stage?.id != 1) return;
    final mergedLevel = controller.state.board[mergedCell];
    if (mergedLevel == null) return;

    _secretMergeStreak++;

    // Secret 1: create Lv.3 in the center 3x3.
    final row = mergedCell ~/ GameState.boardColumns;
    final col = mergedCell % GameState.boardColumns;
    if (mergedLevel == 3 &&
        row >= 2 &&
        row <= 4 &&
        col >= 2 &&
        col <= 4) {
      await _discoverSecret(1);
    }

    // Secret 2: three successful merges in succession.
    if (_secretMergeStreak >= 3) {
      await _discoverSecret(2);
    }

    // Secret 5: create Lv.6 on the faintly glowing cell (index 31).
    if (mergedLevel == 6 && mergedCell == 31) {
      await _discoverSecret(5);
    }

    await _checkBoardSecrets();
  }

  Widget _buildSecretProgressDots() {
    if (stage?.id != 1) return const SizedBox.shrink();
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(5, (index) {
        final found = controller.stageSecretFound(1, index + 1);
        return AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          margin: const EdgeInsets.only(left: 4 * webUiScale),
          width: 9 * webUiScale,
          height: 9 * webUiScale,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: found
                ? const Color(0xFFFFD45C)
                : const Color(0x55968B83),
            border: Border.all(
              color: found
                  ? const Color(0xFFFFB341)
                  : const Color(0x66968B83),
            ),
            boxShadow: found
                ? const [
                    BoxShadow(
                      color: Color(0x99FFD54F),
                      blurRadius: 8,
                      spreadRadius: 1,
                    ),
                  ]
                : null,
          ),
        );
      }),
    );
  }

  double _stageSatisfaction() {
    final currentStage = stage;
    if (currentStage == null) return 0.0;
    if (controller.stageCleared(currentStage.id)) return 1.0;
    final step = controller.stageRequestStep(currentStage.id);
    final total = GameController.stageRequestCountForStage(currentStage.id);
    if (total <= 0) return 0.0;
    return (step / total).clamp(0.0, 1.0);
  }

  Map<int, int> _currentStageRequirements() {
    final currentStage = stage;
    if (currentStage == null) {
      return <int, int>{controller.orderTargetLevel: 1};
    }

    final step = controller.stageRequestStep(currentStage.id)
        .clamp(0, GameController.stageRequestCountForStage(currentStage.id) - 1);

    // Stage 1 is a 20-request learning curve. It starts with simple pieces,
    // gradually introduces simultaneous requirements and ends with all Lv.1-6.
    if (currentStage.id == 1) {
      // Four-series puzzle: every request asks the player to manage
      // multiple colored series at the same time.
      const requests = <Map<int, int>>[
        // 1: all four series reach Lv.2.
        {2: 1, 12: 1, 22: 1, 32: 1},
        // 2-3: split Lv.3 goals.
        {3: 1, 13: 1},
        {23: 1, 33: 1},
        // 4: four Lv.2 pieces, two of each series.
        {2: 2, 12: 2, 22: 2, 32: 2},
        // 5: all four series reach Lv.3.
        {3: 1, 13: 1, 23: 1, 33: 1},
        // 6-7: introduce Lv.4.
        {4: 1, 24: 1},
        {14: 1, 34: 1},
        // 8: mixed board management.
        {2: 1, 13: 1, 22: 1, 33: 1},
        // 9: all four series reach Lv.4.
        {4: 1, 14: 1, 24: 1, 34: 1},
        // 10-11: introduce Lv.5.
        {5: 1, 15: 1},
        {25: 1, 35: 1},
        // 12: mixed Lv.3/Lv.4.
        {3: 1, 14: 1, 23: 1, 34: 1},
        // 13: all four Lv.5.
        {5: 1, 15: 1, 25: 1, 35: 1},
        // 14-17: introduce every series' Lv.6 one by one.
        {6: 1},
        {16: 1},
        {26: 1},
        {36: 1},
        // 18: preserve all four Lv.5 at once.
        {5: 1, 15: 1, 25: 1, 35: 1},
        // 19: high-level mixed final rehearsal.
        {6: 1, 15: 1, 26: 1, 35: 1},
        // 20: final order — all four series at Lv.6.
        {6: 1, 16: 1, 26: 1, 36: 1},
      ];
      return requests[step];
    }

    final target = currentStage.targetLevel;
    final chainBase = target < 10 ? 1 : (target ~/ 10) * 10 + 1;
    final previous = target - 1 < chainBase ? chainBase : target - 1;

    if (target == chainBase) {
      switch (step) {
        case 0:
          return <int, int>{chainBase: 2};
        case 1:
          return <int, int>{chainBase: 3};
        default:
          return <int, int>{chainBase: 4};
      }
    }

    switch (step) {
      case 0:
        return <int, int>{chainBase: 2, if (previous != chainBase) previous: 1};
      case 1:
        return <int, int>{previous: 2, target: 1};
      default:
        return <int, int>{chainBase: 2, previous: 2, target: 1};
    }
  }

  List<MapEntry<int, int>> _matchingRequirementCells(
    Map<int, int> requirements,
  ) {
    final result = <MapEntry<int, int>>[];
    for (final requirement in requirements.entries) {
      var remaining = requirement.value;
      for (var i = 0; i < controller.state.board.length && remaining > 0; i++) {
        if (controller.state.board[i] == requirement.key) {
          result.add(MapEntry<int, int>(requirement.key, i));
          remaining--;
        }
      }
    }
    return result;
  }

  Future<void> _checkAutoRequirement() async {
    if (_autoDeliveryInFlight || !mounted) return;

    final requirements = _currentStageRequirements();
    if (!controller.boardHasRequirements(requirements)) return;

    _autoDeliveryInFlight = true;
    if (mounted) setState(() {});

    final matchedCells = _matchingRequirementCells(requirements);
    for (final matched in matchedCells) {
      if (!mounted) return;
      await _playDeliveryFlight(matched.key, matched.value);
      await Future<void>.delayed(const Duration(milliseconds: 35));
    }

    if (!mounted) return;
    SfxManager.instance.reward();

    final currentStage = stage;
    final success = currentStage == null
        ? await controller.claimStarterOrder()
        : await controller.claimStageRequirement(
            stageId: currentStage.id,
            requirements: requirements,
          );

    if (!mounted) return;
    if (!success) {
      _autoDeliveryInFlight = false;
      setState(() {});
      return;
    }

    if (currentStage != null) {
      final stageFinished = controller.stageCleared(currentStage.id);
      if (stageFinished) {
        _autoDeliveryInFlight = false;
        setState(() {});
        await _showStageClearVisual(currentStage);
        return;
      }

      // Move straight to the next request. If its items are already on the board,
      // the next post-frame check completes it automatically too.
      _autoDeliveryInFlight = false;
      setState(() {});
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _checkAutoRequirement();
      });
      return;
    }

    _autoDeliveryInFlight = false;
    setState(() {});
  }

  Future<void> _showStageClearVisual(StageDefinition currentStage) async {
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      barrierDismissible: true,
      builder: (d) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30 * webUiScale),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              '✨',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 56 * webUiScale),
            ),
            const SizedBox(height: 8 * webUiScale),
            const Text(
              'STAGE CLEAR!',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 28 * webUiScale, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 8 * webUiScale),
            Text(
              currentStage.icon,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 76 * webUiScale),
            ),
          ],
        ),
        actionsAlignment: MainAxisAlignment.center,
        actions: [
          FilledButton(
            onPressed: () => Navigator.pop(d),
            child: const Icon(Icons.check_rounded),
          ),
        ],
      ),
    );
  }

  Future<void> _claimOrder() async {
    await _checkAutoRequirement();
  }

  Future<void> _spawn([String generatorId = 'farm']) async {
    if (_spawning) return;
    _spawning = true;
    _activeGeneratorId = generatorId;
    if (mounted) setState(() => generatorPressed = true);
    int? success;
    try {
      success = await controller.spawnFromGenerator(generatorId);
      if (success != null && mounted) {
        SfxManager.instance.spawn();
        await Future<void>.delayed(const Duration(milliseconds: 30));
        if (mounted) _playSpawnFlight(generatorId, success);
        _secretMergeStreak = 0;
        await _checkBoardSecrets();
        await _checkAutoRequirement();
        if (!controller.tutorialCompleted && generatorId == 'farm' && _tutorialStep <= 1) {
          final baseCount = controller.countLevel(1);
          setState(() => _tutorialStep = baseCount >= 2 ? 2 : 1);
        }
      }
      await Future<void>.delayed(const Duration(milliseconds: 180));
      if (!mounted) return;
      if (success == null) {
        SfxManager.instance.error();
        final text = controller.state.energy <= 0
            ? 'エネルギーが足りません'
            : 'まだ使えないジェネレーターか、盤面に空きがありません';
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          behavior: SnackBarBehavior.floating,
          content: Text(text, style: const TextStyle(fontSize: 24 * webUiScale, fontWeight: FontWeight.w800)),
          duration: const Duration(milliseconds: 1100),
        ));
      }
    } finally {
      _spawning = false;
      if (mounted) setState(() => generatorPressed = false);
    }
  }

  void _playSpawnFlight(String generatorId, int index) {
    final screenBox = _screenKey.currentContext?.findRenderObject() as RenderBox?;
    final generatorBox = _generatorKeys[generatorId]?.currentContext?.findRenderObject() as RenderBox?;
    final boardBox = _boardKey.currentContext?.findRenderObject() as RenderBox?;
    if (screenBox == null || generatorBox == null || boardBox == null) return;

    final startGlobal = generatorBox.localToGlobal(generatorBox.size.center(Offset.zero));
    final boardGlobal = boardBox.localToGlobal(Offset.zero);
    final start = screenBox.globalToLocal(startGlobal);
    final boardTopLeft = screenBox.globalToLocal(boardGlobal);

    const pad = 6.0;
    final innerW = boardBox.size.width - (pad * 2);
    final innerH = boardBox.size.height - (pad * 2);
    final cellW = innerW / GameState.boardColumns;
    final cellH = innerH / GameState.boardRows;
    final col = index % GameState.boardColumns;
    final row = index ~/ GameState.boardColumns;
    final end = boardTopLeft + Offset(
      pad + cellW * (col + .5),
      pad + cellH * (row + .5),
    );

    final level = controller.state.board[index] ?? 1;
    final overlay = Overlay.of(context);
    late OverlayEntry entry;
    entry = OverlayEntry(
      builder: (_) => _SpawnFlight(
        start: start,
        end: end,
        emoji: MergeItem.icons[level] ?? '🌱',
        onDone: () => entry.remove(),
      ),
    );
    overlay.insert(entry);
  }

  @override
  Widget build(BuildContext context) {
    final state = controller.state;

    return Scaffold(
      backgroundColor: const Color(0xFF061344),
      body: SafeArea(
        bottom: false,
        child: Stack(
          key: _screenKey,
          children: [
            Column(
              children: [
                _buildTopBar(state),
                const SizedBox.shrink(),
                const SizedBox.shrink(),
                _buildOrderArea(),
                const SizedBox.shrink(),
                const SizedBox(height: 3 * webUiScale),
                Expanded(child: _buildBoard()),
                const SizedBox(height: 2 * webUiScale),
              ],
            ),
          ],
        ),
      ),
      bottomNavigationBar: AppBottomNav(controller: controller),
    );
  }

  Widget _buildTutorialCard() => const SizedBox.shrink();

  Widget _buildProgressGuide() {
    final level = controller.state.level;
    String text;
    if (level < 2) {
      text = '次は Lv.2：盤面の雲がひらくよ';
    } else if (level < 3) {
      text = '次は Lv.3：🥤 ドリンクジェネレーター解放';
    } else if (level < 4) {
      text = '次は Lv.4：新しい箱マスがひらく';
    } else if (level < 5) {
      text = '次は Lv.5：🍰 スイーツジェネレーター解放';
    } else if (level < 6) {
      text = '次は Lv.6：プレゼントマス解放';
    } else if (level < 7) {
      text = '次は Lv.7：🌸 フラワージェネレーター解放';
    } else if (level < 8) {
      text = '次は Lv.8：ロックエリア解放';
    } else if (level < 9) {
      text = '次は Lv.9：🍳 キッチンジェネレーター解放';
    } else if (level < 10) {
      text = '次は Lv.10：最後の謎マスがひらく';
    } else {
      text = 'Lv.10到達！ここから注文の組み合わせが広がります';
    }
    return Container(
      margin: const EdgeInsets.fromLTRB(12 * webUiScale, 8 * webUiScale, 12 * webUiScale, 0),
      padding: const EdgeInsets.symmetric(horizontal: 16 * webUiScale, vertical: 9 * webUiScale),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFFEAF9FF), Color(0xFFFFF0FA)]),
        borderRadius: BorderRadius.circular(16 * webUiScale),
        border: Border.all(color: const Color(0xFFB7DDE7), width: 1.4),
      ),
      child: Row(children: [
        const Text('✨', style: TextStyle(fontSize: 24 * webUiScale)),
        const SizedBox(width: 8 * webUiScale),
        Expanded(child: Text(text, style: const TextStyle(fontSize: 20 * webUiScale, fontWeight: FontWeight.w900, color: Color(0xFF41636B)))),
      ]),
    );
  }

  Widget _buildStageHeader() {
    final s = stage!;
    return Container(
      margin: const EdgeInsets.fromLTRB(12 * webUiScale, 2 * webUiScale, 12 * webUiScale, 6 * webUiScale),
      padding: const EdgeInsets.symmetric(horizontal: 16 * webUiScale, vertical: 12 * webUiScale),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [s.accent.withValues(alpha: .92), s.accent.withValues(alpha: .65)]),
        borderRadius: BorderRadius.circular(20 * webUiScale),
        boxShadow: [BoxShadow(color: s.accent.withValues(alpha:.25), blurRadius: 12, offset: const Offset(0,4 * webUiScale))],
      ),
      child: Row(children: [
        Text(s.icon, style: const TextStyle(fontSize: 40 * webUiScale)),
        const SizedBox(width: 10 * webUiScale),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('STAGE ${s.id}  ${s.title}', style: const TextStyle(fontSize: 22 * webUiScale, fontWeight: FontWeight.w900, color: Colors.white)),
          Text(s.request, style: const TextStyle(fontSize: 16 * webUiScale, fontWeight: FontWeight.w800, color: Colors.white)),
        ])),
      ]),
    );
  }


  Widget _buildTopBar(GameState state) {
    final needed = controller.xpNeeded(state.level);
    final progress = (state.xp / needed).clamp(0.0, 1.0);

    return Padding(
      padding: const EdgeInsets.fromLTRB(12 * webUiScale, 5 * webUiScale, 12 * webUiScale, 3 * webUiScale),
      child: Column(
        children: [
          Row(
            children: [
              Text(
                'Lv.${state.level}',
                style: const TextStyle(
                  fontSize: 25 * webUiScale,
                  fontWeight: FontWeight.w900,
                  color: Colors.white,
                ),
              ),
              const SizedBox(width: 10 * webUiScale),
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(99 * webUiScale),
                  child: LinearProgressIndicator(
                    value: progress,
                    minHeight: 9 * webUiScale,
                    backgroundColor: const Color(0xFF213474),
                    color: const Color(0xFF62F1D4),
                  ),
                ),
              ),
              const SizedBox(width: 10 * webUiScale),
              _StatusChip(icon: '⚡', value: '${state.energy}/${state.maxEnergy}'),
              const SizedBox(width: 5),
              _StatusChip(icon: '💎', value: '${state.gems}'),
              const SizedBox(width: 5),
              _StatusChip(icon: '🪙', value: '${state.coins}'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildBottomNavigation() {
    final double barHeight = kIsWeb ? 58 : 76;
    final double iconSize = kIsWeb ? 22 : 28;
    final double labelSize = kIsWeb ? 10 : 12.5;

    Widget navItem({
      required IconData icon,
      required String label,
      required VoidCallback onTap,
      bool attention = false,
      bool emphasized = false,
    }) {
      return Expanded(
        child: InkWell(
          onTap: onTap,
          child: SizedBox(
            height: barHeight,
            child: Stack(
              alignment: Alignment.center,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: emphasized ? (kIsWeb ? 46 : 56) : null,
                      height: emphasized ? (kIsWeb ? 46 : 56) : null,
                      decoration: emphasized
                          ? const BoxDecoration(
                              color: Color(0xFF36B5C3),
                              shape: BoxShape.circle,
                            )
                          : null,
                      alignment: Alignment.center,
                      child: Icon(
                        icon,
                        size: emphasized ? iconSize * 1.35 : iconSize,
                        color: emphasized ? Colors.white : const Color(0xFF41636B),
                      ),
                    ),
                    SizedBox(height: emphasized ? 0 : 2),
                    Text(
                      label,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: emphasized ? labelSize * 1.08 : labelSize,
                        fontWeight: FontWeight.w900,
                        color: const Color(0xFF41636B),
                      ),
                    ),
                  ],
                ),
                if (attention)
                  Positioned(
                    top: kIsWeb ? 6 : 8,
                    right: kIsWeb ? 13 : 17,
                    child: Container(
                      width: kIsWeb ? 8 : 10,
                      height: kIsWeb ? 8 : 10,
                      decoration: const BoxDecoration(
                        color: Color(0xFFE96D72),
                        shape: BoxShape.circle,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      );
    }

    return SafeArea(
      top: false,
      child: Material(
        color: const Color(0xFFFDFEFE),
        elevation: 12,
        child: Container(
          decoration: const BoxDecoration(
            border: Border(top: BorderSide(color: Color(0xFFD7ECEB), width: 1)),
          ),
          child: Row(
            children: [
              navItem(
                icon: Icons.card_giftcard_rounded,
                label: 'デイリー',
                onTap: _openDailyReward,
              ),
              navItem(
                icon: Icons.assignment_rounded,
                label: 'ミッション',
                attention: controller.hasClaimableMission,
                onTap: _openMission,
              ),
              navItem(
                icon: Icons.home_rounded,
                label: '街',
                emphasized: true,
                onTap: () {
                  SfxManager.instance.tap();
                  Navigator.of(context).pushReplacement(
                    MaterialPageRoute(builder: (_) => WorldScreen(controller: controller)),
                  );
                },
              ),
              navItem(
                icon: Icons.menu_book_rounded,
                label: '図鑑',
                onTap: _openCollection,
              ),
              navItem(
                icon: Icons.settings_rounded,
                label: '設定',
                onTap: _openDevMenu,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildWorldUnlockBanner() {
    final level = controller.nextWorldRewardReady!;
    return Padding(
      padding: const EdgeInsets.fromLTRB(10 * webUiScale, 3 * webUiScale, 10 * webUiScale, 8 * webUiScale),
      child: _AttentionPulse(
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(20 * webUiScale),
            onTap: () {
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => WorldScreen(controller: controller)),
              );
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16 * webUiScale, vertical: 13 * webUiScale),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Color(0xFFFFC53D), Color(0xFFFF7C59)]),
                borderRadius: BorderRadius.circular(20 * webUiScale),
                border: Border.all(color: Colors.white, width: 3),
                boxShadow: const [BoxShadow(color: Color(0x77FF963A), blurRadius: 18, spreadRadius: 3)],
              ),
              child: Row(
                children: [
                  const Text('🎁', style: TextStyle(fontSize: 38 * webUiScale)),
                  const SizedBox(width: 10 * webUiScale),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('🎉 新しいショップを解放できます！',
                            style: TextStyle(fontSize: 25 * webUiScale, fontWeight: FontWeight.w900, color: Colors.white)),
                        Text('Lv.$level  ${controller.levelRewardTitle(level)}',
                            style: const TextStyle(fontSize: 18 * webUiScale, fontWeight: FontWeight.w900, color: Colors.white)),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 13 * webUiScale, vertical: 10 * webUiScale),
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16 * webUiScale)),
                    child: const Text('街で解放！', style: TextStyle(fontSize: 22 * webUiScale, fontWeight: FontWeight.w900, color: Color(0xFFE6653E))),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildOrderArea() {
    return Padding(
      key: _orderKey,
      padding: const EdgeInsets.fromLTRB(
        18 * webUiScale,
        2 * webUiScale,
        18 * webUiScale,
        4 * webUiScale,
      ),
      child: Row(
        children: [
          Container(
            width: 34 * webUiScale,
            height: 34 * webUiScale,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFF253B87),
              border: Border.all(color: const Color(0xFF7C8DFF), width: 1.2),
            ),
            child: const Text('〰', style: TextStyle(fontSize: 18 * webUiScale, color: Colors.white)),
          ),
          const SizedBox(width: 9 * webUiScale),
          const Expanded(
            child: Text(
              '同じものを3つ以上なぞる',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 16 * webUiScale,
                fontWeight: FontWeight.w900,
                color: Colors.white,
              ),
            ),
          ),
          const SizedBox(width: 8 * webUiScale),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10 * webUiScale, vertical: 5 * webUiScale),
            decoration: BoxDecoration(
              color: const Color(0xFF253B87),
              borderRadius: BorderRadius.circular(999),
              border: Border.all(color: const Color(0xFF7C8DFF), width: 1.1),
            ),
            child: const Text(
              'TIME ∞',
              style: TextStyle(
                fontSize: 14 * webUiScale,
                fontWeight: FontWeight.w900,
                color: Color(0xFFFFE76A),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _autoDeliverIfReady(int mergedCell) async {
    await _checkAutoRequirement();
  }

  Future<void> _playDeliveryFlight(int level, int cellIndex) async {
    final overlay = Overlay.of(context);
    final boardRender = _boardKey.currentContext?.findRenderObject();
    final orderRender = _orderKey.currentContext?.findRenderObject();
    final overlayRender = overlay.context.findRenderObject();
    if (boardRender is! RenderBox || orderRender is! RenderBox || overlayRender is! RenderBox) {
      await Future<void>.delayed(const Duration(milliseconds: 240));
      return;
    }

    final rows = GameState.boardRows;
    final cellW = boardRender.size.width / GameState.boardColumns;
    final cellH = boardRender.size.height / rows;
    final col = cellIndex % GameState.boardColumns;
    final row = cellIndex ~/ GameState.boardColumns;
    final startGlobal = boardRender.localToGlobal(Offset((col + .5) * cellW, (row + .5) * cellH));
    final endGlobal = orderRender.localToGlobal(Offset(34 * webUiScale, orderRender.size.height / 2));
    final start = overlayRender.globalToLocal(startGlobal);
    final end = overlayRender.globalToLocal(endGlobal);
    final emoji = MergeItem.icons[level] ?? '⭐';

    late OverlayEntry entry;
    entry = OverlayEntry(
      builder: (_) => IgnorePointer(
        child: TweenAnimationBuilder<double>(
          tween: Tween(begin: 0, end: 1),
          duration: const Duration(milliseconds: 330),
          curve: Curves.easeInOutCubic,
          builder: (_, t, __) {
            final x = start.dx + (end.dx - start.dx) * t;
            final arc = -42 * webUiScale * 4 * t * (1 - t);
            final y = start.dy + (end.dy - start.dy) * t + arc;
            return Stack(children: [
              Positioned(
                left: x - 24 * webUiScale,
                top: y - 24 * webUiScale,
                child: Transform.scale(
                  scale: 1 + .18 * (1 - t),
                  child: Text(emoji, style: const TextStyle(fontSize: 46 * webUiScale)),
                ),
              ),
            ]);
          },
          onEnd: () => entry.remove(),
        ),
      ),
    );
    overlay.insert(entry);
    await Future<void>.delayed(const Duration(milliseconds: 340));
  }

  Future<void> _tryInstantMerge(DragUpdateDetails details) async {
    return;
  }

  Future<void> _performSlideClear(int from, int to) async {
    if (_slideActionInFlight || !controller.canSlideMove(from, to)) return;
    _slideActionInFlight = true;
    final isClear = controller.state.board[from] == controller.state.board[to];
    final serial = ++_slideAnimSerial;
    setState(() {
      _slideAnimFrom = from;
      _slideAnimTo = to;
    });

    // Keep equal-piece contact readable; a normal swap stays snappy.
    await Future<void>.delayed(Duration(milliseconds: isClear ? 210 : 125));
    if (!mounted || serial != _slideAnimSerial) return;
    if (isClear) {
      setState(() => _slideContactTarget = to);
      await Future<void>.delayed(const Duration(milliseconds: 145));
      if (!mounted || serial != _slideAnimSerial) return;
    }

    final ok = await controller.moveOrMerge(from: from, to: to);
    if (ok && isClear) {
      SfxManager.instance.merge();
      if (controller.lastChainCount >= 2) SfxManager.instance.reward();
    } else if (!ok) {
      SfxManager.instance.error();
    }

    if (!mounted) return;
    setState(() {
      _slideAnimFrom = null;
      _slideAnimTo = null;
      _slideContactTarget = null;
      _swipeFrom = null;
      _swipeDx = 0;
      _swipeDy = 0;
      _slideActionInFlight = false;
    });
  }
  bool _isFreshItem(int index) {
    return controller.lastSpawnIndex == index ||
        controller.lastMergeIndex == index;
  }

  Widget _buildGeneratorCell(String id) {
    final unlocked = controller.generatorUnlocked(id);
    final unlockLevel = GameController.generatorUnlockLevels[id] ?? 99;
    final tutorialGuide = !controller.tutorialCompleted && id == 'farm' && (_tutorialStep == 0 || _tutorialStep == 1);
    final orderRelevant = controller.tutorialCompleted && (stage?.generatorId ?? controller.orderGeneratorId) == id && unlocked;
    final guide = tutorialGuide || orderRelevant;
    final pressed = generatorPressed && _activeGeneratorId == id;

    if (!unlocked) {
      return Container(
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFFEAF1F5), Color(0xFFC9D9E2)]),
          borderRadius: BorderRadius.circular(15 * webUiScale),
          border: Border.all(color: const Color(0xFF9BB6C3), width: 1.5),
        ),
        child: Stack(alignment: Alignment.center, children: [
          Opacity(opacity: .45, child: Text(controller.generatorEmoji(id), style: const TextStyle(fontSize: 54 * webUiScale))),
          Positioned(
            top: 5 * webUiScale,
            right: 5 * webUiScale,
            child: Container(
              width: 28 * webUiScale,
              height: 28 * webUiScale,
              alignment: Alignment.center,
              decoration: const BoxDecoration(color: Color(0xEFFFFFFF), shape: BoxShape.circle),
              child: const Text('🔒', style: TextStyle(fontSize: 16 * webUiScale)),
            ),
          ),
        ]),
      );
    }

    return GestureDetector(
      key: _generatorKeys[id],
      behavior: HitTestBehavior.opaque,
      onTap: () => _spawn(id),
      onTapDown: (_) { _activeGeneratorId = id; setState(() => generatorPressed = true); },
      onTapUp: (_) { if (!_spawning) setState(() => generatorPressed = false); },
      onTapCancel: () { if (!_spawning) setState(() => generatorPressed = false); },
      child: AnimatedScale(
        scale: pressed ? .88 : 1,
        duration: const Duration(milliseconds: 90),
        child: Stack(clipBehavior: Clip.none, alignment: Alignment.center, children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft, end: Alignment.bottomRight,
                colors: id == 'farm'
                    ? const [Color(0xFFFFF3A9), Color(0xFFFFC95D)]
                    : const [Color(0xFFE9F8FF), Color(0xFF9DDAF4)],
              ),
              borderRadius: BorderRadius.circular(16 * webUiScale),
              border: Border.all(color: guide ? const Color(0xFFFF7B42) : const Color(0xFF57AFC6), width: guide ? 4 : 2),
              boxShadow: guide
                  ? const [BoxShadow(color: Color(0x99FF9E52), blurRadius: 20, spreadRadius: 3)]
                  : const [BoxShadow(color: Color(0x25000000), blurRadius: 8, offset: Offset(0,3 * webUiScale))],
            ),
            child: Stack(alignment: Alignment.center, children: [
              Text(controller.generatorEmoji(id), style: const TextStyle(fontSize: 58 * webUiScale)),
              Positioned(
                right: 3,
                bottom: 3,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 7 * webUiScale, vertical: 3 * webUiScale),
                  decoration: BoxDecoration(color: const Color(0xF2FFFFFF), borderRadius: BorderRadius.circular(99 * webUiScale)),
                  child: const Text('⚡1', style: TextStyle(fontSize: 17 * webUiScale, fontWeight: FontWeight.w900)),
                ),
              ),
            ]),
          ),
          if (tutorialGuide) const Positioned(left: 14 * webUiScale, right: 14 * webUiScale, top: -48 * webUiScale, child: Center(child: _TutorialFinger(symbol: '👇'))),
        ]),
      ),
    );
  }

  Widget _buildMysteryCell(int index) {
    const visuals = <int, (String, String)>{
      3: ('☁️', '新しいマス'),
      8: ('📦', '箱マス'),
      12: ('🎁', 'ひみつ'),
      36: ('🔒', '新エリア'),
      40: ('🧊', '氷マス'),
      45: ('✨', '特別マス'),
    };
    final v = visuals[index] ?? ('❓', 'ひみつ');
    final unlockLevel = GameController.blockedUnlockLevels[index] ?? 10;
    final ready = controller.canUnlockBoardCell(index);

    final card = GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: ready
          ? () async {
              final ok = await controller.unlockBoardCell(index);
              if (!ok || !mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  behavior: SnackBarBehavior.floating,
                  content: Text('✨ ${v.$2}を解放しました！', style: const TextStyle(fontSize: 20 * webUiScale, fontWeight: FontWeight.w900)),
                ),
              );
            }
          : null,
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: ready
                ? const [Color(0xFFFFF5A8), Color(0xFFFFC45D)]
                : const [Color(0xFFF7FBFF), Color(0xFFDDEAF4)],
          ),
          borderRadius: BorderRadius.circular(12 * webUiScale),
          border: Border.all(color: ready ? const Color(0xFFFF8C3E) : const Color(0xFFB6CCD9), width: ready ? 3.5 : 1.4),
          boxShadow: ready ? const [BoxShadow(color: Color(0x99FFA544), blurRadius: 18, spreadRadius: 3)] : null,
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            Text(ready ? '✨' : v.$1, style: const TextStyle(fontSize: 45 * webUiScale)),
            if (!ready)
              Positioned(
                top: 5 * webUiScale,
                right: 5 * webUiScale,
                child: Container(
                  width: 27 * webUiScale,
                  height: 27 * webUiScale,
                  alignment: Alignment.center,
                  decoration: const BoxDecoration(color: Color(0xEFFFFFFF), shape: BoxShape.circle),
                  child: const Text('🔒', style: TextStyle(fontSize: 15 * webUiScale)),
                ),
              ),
          ],
        ),
      ),
    );
    return ready ? _AttentionPulse(child: card) : card;
  }

  Widget _buildBoard() {
    return FreePilePuzzle(
      key: ValueKey('free-pile-${stage?.id ?? 1}'),
      stageId: stage?.id ?? 1,
      onClear: (count) { SfxManager.instance.merge(); controller.rewardPuzzleClear(count); },
    );
  }

  Widget _buildPlainEmptyCell({int? index}) {
    final hint = stage?.id == 1 &&
        index == 12 &&
        !controller.stageSecretFound(1, 3);
    return Container(
      decoration: BoxDecoration(
        color: const Color(0x40FFFFFF),
        borderRadius: BorderRadius.circular(10 * webUiScale),
        border: Border.all(
          color: hint
              ? const Color(0x99FFD45C)
              : const Color(0x70FFFFFF),
          width: hint ? 1.7 : 1.15,
        ),
        boxShadow: hint
            ? const [
                BoxShadow(
                  color: Color(0x44FFD54F),
                  blurRadius: 7,
                  spreadRadius: 1,
                ),
              ]
            : null,
      ),
      child: hint
          ? const Center(
              child: Opacity(
                opacity: .42,
                child: Text(
                  '✨',
                  style: TextStyle(fontSize: 20 * webUiScale),
                ),
              ),
            )
          : null,
    );
  }

  Widget _buildCell(int index) {
    final value = controller.state.board[index];

    final hovering = hoverCell == index;
    final source = dragFrom == null ? null : controller.state.board[dragFrom!];

    final mergeTarget = hovering &&
        dragFrom != null &&
        controller.canSlideClear(dragFrom!, index);

    const moveTarget = false;

    Widget tile({bool dragging = false}) {
      Color background = value == null
          ? const Color(0x66FFFFFF)
          : MergeItem.seriesSoftColor(value).withValues(alpha: .46);
      Color border = value == null
          ? const Color(0x8AFFFFFF)
          : MergeItem.seriesColor(value).withValues(alpha: .78);
      double borderWidth = value == null ? 0.85 : 1.05;
      final chainFlash = controller.chainFlashCells.contains(index);
      final contactFlash = _slideContactTarget == index;
      if (chainFlash || contactFlash) {
        background = Colors.white.withValues(alpha: .82);
        border = const Color(0xFFFFB84D);
        borderWidth = 2.2 * webUiScale;
      }

      if (moveTarget) {
        background = const Color(0x66FFF7C7);
        border = const Color(0xFFFFD55F);
        borderWidth = 2;
      }

      if (mergeTarget) {
        background = const Color(0x66FFD9EA);
        border = const Color(0xFFFF8FBC);
        borderWidth = 2.5;
      }

      if (false && _tutorialStep == 2 && value == 1) {
        background = const Color(0x88FFF2A8);
        border = const Color(0xFFFF8A3D);
        borderWidth = 4;
      }

      return AnimatedContainer(
        duration: const Duration(milliseconds: 110),
        curve: Curves.easeOut,
        decoration: BoxDecoration(
          color: background,
          borderRadius: BorderRadius.circular(10 * webUiScale),
          border: Border.all(color: border, width: borderWidth),
          boxShadow: (chainFlash || contactFlash)
              ? const [BoxShadow(color: Color(0xAAFFD36B), blurRadius: 13, spreadRadius: 2)]
              : mergeTarget
              ? const [BoxShadow(color: Color(0x77FF8FBC), blurRadius: 8)]
              : const [
                  BoxShadow(
                    color: Color(0x0D000000),
                    blurRadius: 2,
                    offset: Offset(0, 1 * webUiScale),
                  ),
                ],
        ),
        child: value == null
            ? (stage?.id == 1 &&
                    index == 31 &&
                    !controller.stageSecretFound(1, 5)
                ? const Center(
                    child: Opacity(
                      opacity: .38,
                      child: Text(
                        '✨',
                        style: TextStyle(fontSize: 18 * webUiScale),
                      ),
                    ),
                  )
                : null)
            : Stack(
                clipBehavior: Clip.none,
                alignment: Alignment.center,
                children: [
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 125),
                    switchInCurve: Curves.easeOutCubic,
                    switchOutCurve: Curves.easeInCubic,
                    transitionBuilder: (child, animation) {
                      final slide = Tween<Offset>(
                        begin: const Offset(0, -0.32),
                        end: Offset.zero,
                      ).animate(animation);
                      return FadeTransition(
                        opacity: animation,
                        child: SlideTransition(position: slide, child: child),
                      );
                    },
                    child: value == null
                        ? const SizedBox.shrink()
                        : (_slideAnimFrom == index && _slideAnimTo != null)
                            ? TweenAnimationBuilder<double>(
                                key: ValueKey('slide-${_slideAnimSerial}-$index'),
                                tween: Tween<double>(begin: 0, end: 1),
                                duration: const Duration(milliseconds: 230),
                                curve: Curves.easeInOutCubic,
                                builder: (context, t, child) {
                                  final fromRow = index ~/ GameState.boardColumns;
                                  final fromCol = index % GameState.boardColumns;
                                  final toRow = _slideAnimTo! ~/ GameState.boardColumns;
                                  final toCol = _slideAnimTo! % GameState.boardColumns;
                                  final dx = (toCol - fromCol).toDouble();
                                  final dy = (toRow - fromRow).toDouble();
                                  return FractionalTranslation(
                                    translation: Offset(dx * t, dy * t),
                                    child: Transform.scale(
                                      scale: 1 - (0.06 * t),
                                      child: child,
                                    ),
                                  );
                                },
                                child: MergeItem(
                                  level: value,
                                  emphasized: true,
                                ),
                              )
                            : AnimatedScale(
                                scale: (chainFlash || contactFlash) ? 1.10 : 1.0,
                                duration: const Duration(milliseconds: 150),
                                curve: Curves.easeOutBack,
                                child: MergeItem(
                                  key: ValueKey('piece-$index-$value'),
                                  level: value,
                                  dragging: dragging,
                                  emphasized: _isFreshItem(index),
                                ),
                              ),
                  ),
                  if (_tutorialStep == 2 &&
                      value == 1 &&
                      controller.state.board.indexWhere((v) => v == 1) == index)
                    const Positioned(
                      right: 4,
                      top: -42 * webUiScale,
                      child: _TutorialFinger(symbol: '👆'),
                    ),
                ],
              ),
      );
    }

    Widget interactiveTile = tile();
    if (_slideAnimFrom == index) {
      interactiveTile = tile();
    }

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onPanStart: value == null || _slideActionInFlight
          ? null
          : (_) {
              _swipeFrom = index;
              _swipeDx = 0;
              _swipeDy = 0;
              setState(() => dragFrom = index);
            },
      onPanUpdate: value == null || _slideActionInFlight
          ? null
          : (details) {
              if (_swipeFrom != index || _slideActionInFlight) return;
              _swipeDx += details.delta.dx;
              _swipeDy += details.delta.dy;

              const triggerDistance = 7.0;
              if (_swipeDx.abs() < triggerDistance &&
                  _swipeDy.abs() < triggerDistance) return;

              final row = index ~/ GameState.boardColumns;
              final col = index % GameState.boardColumns;
              int? target;
              if (_swipeDx.abs() >= _swipeDy.abs()) {
                final direction = _swipeDx > 0 ? 1 : -1;
                if ((direction < 0 && col > 0) ||
                    (direction > 0 && col < GameState.boardColumns - 1)) {
                  target = index + direction;
                }
              } else {
                final direction = _swipeDy > 0 ? 1 : -1;
                if ((direction < 0 && row > 0) ||
                    (direction > 0 && row < GameState.boardRows - 1)) {
                  target = index + direction * GameState.boardColumns;
                }
              }

              if (target != null && controller.canSlideMove(index, target)) {
                _performSlideClear(index, target);
              }
            },
      onPanEnd: (_) {
        if (_slideActionInFlight) return;
        setState(() {
          _swipeFrom = null;
          _swipeDx = 0;
          _swipeDy = 0;
          dragFrom = null;
          hoverCell = null;
        });
      },
      onPanCancel: () {
        if (_slideActionInFlight) return;
        setState(() {
          _swipeFrom = null;
          _swipeDx = 0;
          _swipeDy = 0;
          dragFrom = null;
          hoverCell = null;
        });
      },
      child: interactiveTile,
    );

  }
}

class _SpawnFlight extends StatefulWidget {
  final Offset start;
  final Offset end;
  final String emoji;
  final VoidCallback onDone;

  const _SpawnFlight({required this.start, required this.end, required this.emoji, required this.onDone});

  @override
  State<_SpawnFlight> createState() => _SpawnFlightState();
}

class _SpawnFlightState extends State<_SpawnFlight> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 520));
  late final Animation<double> _curve = CurvedAnimation(parent: _controller, curve: Curves.easeOutBack);

  @override
  void initState() {
    super.initState();
    _controller.forward().whenComplete(widget.onDone);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: AnimatedBuilder(
        animation: _curve,
        builder: (_, _) {
          final t = _curve.value;
          final pos = Offset.lerp(widget.start, widget.end, t)! + Offset(0, -42 * (1 * webUiScale - (2 * t - 1 * webUiScale).abs()));
          final scale = .55 + (.75 * (t < .65 ? t / .65 : 1));
          return Stack(
            children: [
              Positioned(
                left: pos.dx - 34,
                top: pos.dy - 34,
                child: Transform.scale(
                  scale: scale,
                  child: Container(
                    width: 68 * webUiScale,
                    height: 68 * webUiScale,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: const Color(0xCCFFFFFF),
                      boxShadow: const [BoxShadow(color: Color(0x66FFE07B), blurRadius: 18, spreadRadius: 3)],
                    ),
                    child: Text(widget.emoji, style: const TextStyle(fontSize: 64 * webUiScale)),
                  ),
                ),
              ),
              if (t > .72)
                Positioned(
                  left: widget.end.dx - 36,
                  top: widget.end.dy - 48,
                  child: Opacity(
                    opacity: (1 - t).clamp(0.0, 1.0),
                    child: const Text('💖 ぽんっ！ ✨', style: TextStyle(fontSize: 28 * webUiScale, fontWeight: FontWeight.w900, color: Color(0xFFEE9B38))),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}


class _TutorialFinger extends StatefulWidget {
  final String symbol;

  const _TutorialFinger({required this.symbol});

  @override
  State<_TutorialFinger> createState() => _TutorialFingerState();
}

class _TutorialFingerState extends State<_TutorialFinger>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _offset;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 650),
    )..repeat(reverse: true);
    _offset = Tween<double>(begin: 0, end: 10).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _offset,
      builder: (_, child) => Transform.translate(
        offset: Offset(0, _offset.value),
        child: child,
      ),
      child: Text(
        widget.symbol,
        style: const TextStyle(fontSize: 60 * webUiScale, shadows: [
          Shadow(color: Color(0x55000000), blurRadius: 8, offset: Offset(0, 3 * webUiScale)),
        ]),
      ),
    );
  }
}

class _StatusChip extends StatelessWidget {
  final String icon;
  final String value;

  const _StatusChip({required this.icon, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12 * webUiScale, vertical: 10 * webUiScale),
      decoration: BoxDecoration(
        color: const Color(0xFFF5FFFF),
        borderRadius: BorderRadius.circular(99 * webUiScale),
        border: Border.all(color: const Color(0x22BFA89F), width: 0.7),
      ),
      child: Text(
        '$icon $value',
        style: const TextStyle(
          fontSize: 25 * webUiScale,
          fontWeight: FontWeight.w900,
          color: Color(0xFF35555A),
        ),
      ),
    );
  }
}

// ignore: unused_element
class _AttentionPulse extends StatefulWidget {
  final Widget child;
  const _AttentionPulse({required this.child});

  @override
  State<_AttentionPulse> createState() => _AttentionPulseState();
}

class _AttentionPulseState extends State<_AttentionPulse> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 760))..repeat(reverse: true);
    _scale = Tween<double>(begin: .985, end: 1.025).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => ScaleTransition(scale: _scale, child: widget.child);
}

