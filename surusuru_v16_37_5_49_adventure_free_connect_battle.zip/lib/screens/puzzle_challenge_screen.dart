import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../game/game_controller.dart';
import '../game/puzzle_stage_rule.dart';
import '../widgets/free_pile_puzzle.dart';

class PuzzleChallengeScreen extends StatefulWidget {
  final GameController controller;
  final PuzzleStageRule rule;
  const PuzzleChallengeScreen({
    super.key,
    required this.controller,
    required this.rule,
  });

  @override
  State<PuzzleChallengeScreen> createState() => _PuzzleChallengeScreenState();
}

class _PuzzleChallengeScreenState extends State<PuzzleChallengeScreen> {
  int moves = 0;
  int total = 0;
  int exact4 = 0;
  int exact6 = 0;
  int specialCreates = 0;
  int bombActivations = 0;
  int lineActivations = 0;
  int lightningActivations = 0;
  int bestReaction = 0;
  int mixedReactionSuccess = 0;
  bool done = false;
  bool keyAvailable = false;
  bool phaseTransition = false;

  int get _effectiveMoves => widget.rule.moves + widget.controller.suruExtraMoves;

  Future<void> _moveDetailed(PuzzleMoveResult result) async {
    if (done) return;
    moves++;
    total += result.clearedCount;
    if (result.tracedCount == 4) exact4++;
    if (result.tracedCount == 6) exact6++;
    if (result.createdSpecial > 0) specialCreates++;
    bombActivations += result.activatedSpecialKinds.where((e) => e == 1).length;
    lineActivations += result.activatedSpecialKinds.where((e) => e == 2).length;
    lightningActivations += result.activatedSpecialKinds.where((e) => e == 3).length;
    bestReaction = math.max(bestReaction, result.reactionCount);
    if (result.activatedSpecialKinds.toSet().length >= 2) mixedReactionSuccess++;

    final r = widget.rule;
    final clear = switch (r.kind) {
      PuzzleStageKind.warmup => specialCreates >= r.goal,
      PuzzleStageKind.exactChain => exact4 >= r.goal,
      PuzzleStageKind.bombWorkshop => bombActivations >= r.goal,
      PuzzleStageKind.lineWorkshop => lineActivations >= r.goal,
      PuzzleStageKind.monoPrecision => exact6 >= r.goal,
      PuzzleStageKind.reaction => bestReaction >= r.goal,
      PuzzleStageKind.lightningWorkshop => lightningActivations >= r.goal,
      PuzzleStageKind.mixedSpecials => mixedReactionSuccess >= r.goal,
      PuzzleStageKind.efficiency => total >= r.goal,
      PuzzleStageKind.surusuruLab => bestReaction >= r.goal,
    };

    if (clear && !keyAvailable && !phaseTransition) {
      phaseTransition = true;
      if (mounted) setState(() {});
      await Future<void>.delayed(const Duration(milliseconds: 900));
      if (!mounted) return;
      keyAvailable = true;
      setState(() {});
      await Future<void>.delayed(const Duration(milliseconds: 1700));
      if (!mounted) return;
      phaseTransition = false;
      setState(() {});
      return;
    }

    if (moves >= _effectiveMoves && !keyAvailable) {
      done = true;
      if (!mounted) return;
      showDialog<void>(
        context: context,
        builder: (d) => AlertDialog(
          title: const Text('もう一回！'),
          content: Text('条件達成まであと少し！\n${_progressText(r)}'),
          actions: [
            FilledButton(
              onPressed: () {
                Navigator.pop(d);
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (_) => PuzzleChallengeScreen(
                      controller: widget.controller,
                      rule: r,
                    ),
                  ),
                );
              },
              child: const Text('リトライ'),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(d);
                Navigator.pop(context);
              },
              child: const Text('マップへ'),
            ),
          ],
        ),
      );
    }
    if (mounted) setState(() {});
  }

  Future<void> _treasureOpened() async {
    if (done) return;
    done = true;
    final r = widget.rule;
    await widget.controller.completeRpgStage(r.id);
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (d) => AlertDialog(
        title: const Text('TREASURE OPEN! ✨'),
        content: Text(
          'カギで宝箱を開けた！\n\nSTAGE ${r.id} CLEAR!\n最大REACTION $bestReaction\n🪙 +${100 + r.id * 10 + widget.controller.suruTreasureCoinBonus}\n\n${widget.controller.lastTreasureRewardText}'
          '${widget.controller.suruBuildCredits > 0 ? '\n\n✨ BUILD PICK ${widget.controller.suruBuildCredits} 所持' : ''}'
        ),
        actions: [
          FilledButton(onPressed: () => Navigator.pop(d), child: const Text('マップへ')),
        ],
      ),
    );
    if (mounted) Navigator.pop(context);
  }

  String _progressText(PuzzleStageRule r) => switch (r.kind) {
        PuzzleStageKind.warmup => '特殊作成 $specialCreates / ${r.goal}',
        PuzzleStageKind.exactChain => 'ちょうど4個 $exact4 / ${r.goal}',
        PuzzleStageKind.bombWorkshop => 'ボム起爆 $bombActivations / ${r.goal}',
        PuzzleStageKind.lineWorkshop => 'ライン発動 $lineActivations / ${r.goal}',
        PuzzleStageKind.monoPrecision => 'ちょうど6個 $exact6 / ${r.goal}',
        PuzzleStageKind.reaction => 'BEST REACTION $bestReaction / ${r.goal}',
        PuzzleStageKind.lightningWorkshop => '雷発動 $lightningActivations / ${r.goal}',
        PuzzleStageKind.mixedSpecials => '特殊ミックス $mixedReactionSuccess / ${r.goal}',
        PuzzleStageKind.efficiency => '消去 $total / ${r.goal}',
        PuzzleStageKind.surusuruLab => 'BEST REACTION $bestReaction / ${r.goal}',
      };

  @override
  Widget build(BuildContext context) {
    final r = widget.rule;
    return Scaffold(
      backgroundColor: const Color(0xFF244C35),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF183F31),
              Color(0xFF245E43),
              Color(0xFF173B2E),
            ],
            stops: [0.0, 0.52, 1.0],
          ),
        ),
        child: Stack(
        children: [
          SafeArea(
            child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                  ),
                  Text(
                    'STAGE ${r.id}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const Spacer(),
                  const Text(
                    'TIME ∞',
                    style: TextStyle(
                      color: Color(0xFF78E8FF),
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 12),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: const Color(0xEE26313A),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: const Color(0xFFFFD85A), width: 2.6),
                boxShadow: const [BoxShadow(color: Colors.black38, offset: Offset(0, 4), blurRadius: 3)],
              ),
              child: Row(
                children: [
                  Text(r.icon, style: const TextStyle(fontSize: 34)),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          r.title,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        Text(
                          r.subtitle,
                          style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        '残り ${math.max(0, _effectiveMoves - moves)}手',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        keyAvailable ? '🔑 カギを宝箱まで運ぼう' : _progressText(r),
                        style: TextStyle(
                          color: r.color,
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Expanded(
              child: FreePilePuzzle(
                stageId: r.id,
                pieceTypes: r.pieceTypes,
                targetPieceCount: r.pieceCount,
                oneTypeOnly: r.oneType,
                bombEveryMove: r.bombEveryMove,
                startingSpecials: r.startingSpecials + widget.controller.suruStartingSpecialBonus,
                onMoveDetailed: _moveDetailed,
                keyAvailable: keyAvailable,
                onTreasureOpened: _treasureOpened,
              ),
            ),
          ],
            ),
          ),
          if (phaseTransition)
            Positioned.fill(
              child: IgnorePointer(
                child: Container(
                  color: const Color(0xB8061437),
                  alignment: Alignment.center,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(keyAvailable ? '🔑' : '✨', style: const TextStyle(fontSize: 70)),
                      const SizedBox(height: 12),
                      Text(
                        keyAvailable ? 'PHASE 2' : 'MISSION CLEAR!',
                        style: const TextStyle(color: Colors.white, fontSize: 34, fontWeight: FontWeight.w900,
                          shadows: [Shadow(color: Color(0xFF58DFFF), blurRadius: 22)]),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        keyAvailable ? 'カギを宝箱まで運ぼう！' : 'カギが出現するよ！',
                        style: const TextStyle(color: Color(0xFFFFE66D), fontSize: 20, fontWeight: FontWeight.w900),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      )),
    );
  }
}
