import 'package:flutter/material.dart';
import '../game/game_controller.dart';
import '../game/puzzle_stage_rule.dart';
import 'connect_battle_screen.dart';
import '../sfx_manager.dart';
import 'sticker_collection_screen.dart';
import 'daily_chest_screen.dart';
import 'area_build_screen.dart';

class StageMapScreen extends StatefulWidget {
  final GameController controller;
  const StageMapScreen({super.key, required this.controller});
  @override
  State<StageMapScreen> createState() => _StageMapScreenState();
}

class _StageMapScreenState extends State<StageMapScreen> {
  static const List<Offset> _nodes = <Offset>[
    Offset(.52, .89), Offset(.30, .80), Offset(.61, .70), Offset(.35, .61), Offset(.66, .52),
    Offset(.34, .43), Offset(.61, .34), Offset(.38, .25), Offset(.62, .17), Offset(.49, .08),
  ];

  bool _branchOpen(GameController c, int id) {
    if (c.stageCleared(id)) return true;
    switch (id) {
      case 1: return true;
      case 2: return c.stageCleared(1);
      case 3: return c.stageCleared(1);
      case 4: return c.stageCleared(2);
      case 5: return c.stageCleared(2) || c.stageCleared(3);
      case 6: return c.stageCleared(4);
      case 7: return c.stageCleared(5) || c.stageCleared(6);
      case 8: return c.stageCleared(7);
      case 9: return c.stageCleared(7);
      case 10: return c.stageCleared(8) || c.stageCleared(9);
      default: return c.stageAvailable(id);
    }
  }

  void _open(Widget screen) {
    SfxManager.instance.tap();
    Navigator.push(context, MaterialPageRoute(builder: (_) => screen)).then((_) {
      if (mounted) setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.controller;
    return Scaffold(
      backgroundColor: const Color(0xFF345D37),
      body: Stack(
        children: [
          const Positioned.fill(child: RepaintBoundary(child: _SuruMapBackground())),
          Positioned.fill(child: ColoredBox(color: Colors.black.withValues(alpha: .08))),
          SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(10, 7, 10, 4),
                  child: Row(
                    children: [
                      _MapSquareButton(icon: Icons.arrow_back, onTap: () => Navigator.pop(context)),
                      const SizedBox(width: 8),
                      const _WoodTitle(text: '冒険マップ'),
                      const Spacer(),
                      _GemCounter(text: '${c.suruStickers.length}'),
                    ],
                  ),
                ),
                Expanded(
                  child: LayoutBuilder(
                    builder: (context, box) {
                      final h = box.maxHeight;
                      return Stack(
                        children: [
                          ...List.generate(puzzleStageRules.length < 10 ? puzzleStageRules.length : 10, (i) {
                            final r = puzzleStageRules[i];
                            final p = _nodes[i];
                            final open = _branchOpen(c, r.id);
                            final cleared = c.stageCleared(r.id);
                            return Positioned(
                              left: p.dx * box.maxWidth - 32,
                              top: p.dy * h - 30,
                              child: _StageStone(
                                id: r.id,
                                icon: r.icon,
                                open: open,
                                cleared: cleared,
                                color: r.color,
                                onTap: open ? () => _open(ConnectBattleScreen(controller: c, stageId: r.id)) : null,
                              ),
                            );
                          }),
                          Positioned(
                            right: 10,
                            top: h * .22,
                            child: Column(
                              children: [
                                _SideMapAction(icon: '🎁', label: '宝箱', badge: c.canClaimSuruDailyChest, onTap: () => _open(DailyChestScreen(controller: c))),
                                const SizedBox(height: 12),
                                _SideMapAction(icon: '📒', label: 'シール', onTap: () => _open(StickerCollectionScreen(controller: c))),
                                const SizedBox(height: 12),
                                _SideMapAction(icon: '✨', label: 'BUILD', badge: c.suruBuildCredits > 0, onTap: () => _open(AreaBuildScreen(controller: c))),
                              ],
                            ),
                          ),
                          Positioned(
                            left: 12,
                            bottom: 12,
                            right: 12,
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                              decoration: BoxDecoration(
                                color: const Color(0xEE26313A),
                                borderRadius: BorderRadius.circular(18),
                                border: Border.all(color: const Color(0xFFFFE9A4), width: 3),
                                boxShadow: const [BoxShadow(color: Colors.black45, offset: Offset(0, 4), blurRadius: 3)],
                              ),
                              child: const Row(children: [Text('🏕️', style: TextStyle(fontSize: 28)), SizedBox(width: 9), Expanded(child: Text('道を進んで宝箱を開けよう！', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900))), Text('→', style: TextStyle(color: Color(0xFFFFD445), fontSize: 24, fontWeight: FontWeight.w900))]),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _WoodTitle extends StatelessWidget {
  final String text;
  const _WoodTitle({required this.text});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: const Color(0xFF6E4525),
          borderRadius: BorderRadius.circular(15),
          border: Border.all(color: const Color(0xFFFFE8A6), width: 3),
          boxShadow: const [BoxShadow(color: Colors.black38, offset: Offset(0, 3))],
        ),
        child: Text(text, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 17, shadows: [Shadow(color: Color(0xFF4A2410), offset: Offset(1, 2))])),
      );
}

class _MapSquareButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _MapSquareButton({required this.icon, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(onTap: onTap, child: Container(width: 44, height: 44, decoration: BoxDecoration(color: const Color(0xFF365B78), borderRadius: BorderRadius.circular(13), border: Border.all(color: Colors.white, width: 2.5), boxShadow: const [BoxShadow(color: Colors.black38, offset: Offset(0, 3))]), child: Icon(icon, color: Colors.white)));
}

class _GemCounter extends StatelessWidget {
  final String text;
  const _GemCounter({required this.text});
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8), decoration: BoxDecoration(color: const Color(0xEA23313F), borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.white, width: 2)), child: Row(children: [const Text('💎'), const SizedBox(width: 5), Text(text, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900))]));
}

class _StageStone extends StatelessWidget {
  final int id;
  final String icon;
  final bool open, cleared;
  final Color color;
  final VoidCallback? onTap;
  const _StageStone({required this.id, required this.icon, required this.open, required this.cleared, required this.color, this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 64,
              height: 48,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: open ? const Color(0xFF4E844B) : const Color(0xFF30383A),
                borderRadius: const BorderRadius.all(Radius.elliptical(32, 20)),
                border: Border.all(color: cleared ? const Color(0xFFFFD84A) : const Color(0xFF26321F), width: 3),
                boxShadow: const [BoxShadow(color: Colors.black45, offset: Offset(0, 5), blurRadius: 2)],
              ),
              child: Text(cleared ? '⭐' : open ? icon : '🔒', style: const TextStyle(fontSize: 24)),
            ),
            Transform.translate(
              offset: const Offset(0, -2),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(color: const Color(0xEE252A2E), borderRadius: BorderRadius.circular(9), border: Border.all(color: Colors.white, width: 1.5)),
                child: Text('1-$id', style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w900)),
              ),
            ),
          ],
        ),
      );
}

class _SideMapAction extends StatelessWidget {
  final String icon, label;
  final bool badge;
  final VoidCallback onTap;
  const _SideMapAction({required this.icon, required this.label, required this.onTap, this.badge = false});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            Column(children: [Container(width: 52, height: 52, alignment: Alignment.center, decoration: BoxDecoration(color: const Color(0xEE253547), borderRadius: BorderRadius.circular(15), border: Border.all(color: Colors.white, width: 2.5), boxShadow: const [BoxShadow(color: Colors.black45, offset: Offset(0, 4))]), child: Text(icon, style: const TextStyle(fontSize: 26))), Text(label, style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w900, shadows: [Shadow(color: Colors.black, blurRadius: 2)]))]),
            if (badge) const Positioned(right: -4, top: -4, child: CircleAvatar(radius: 8, backgroundColor: Color(0xFFFF4E3C), child: Text('!', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w900)))),
          ],
        ),
      );
}


class _SuruMapBackground extends StatelessWidget {
  const _SuruMapBackground();

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF285D3A), Color(0xFF3E7C49), Color(0xFF214D37)],
            ),
          ),
        ),
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Color(0x12000000),
                Color(0x00000000),
                Color(0x280A2A1F),
              ],
            ),
          ),
        ),
        const CustomPaint(painter: _AdventureRoadOverlayPainter()),
      ],
    );
  }
}

class _AdventureRoadOverlayPainter extends CustomPainter {
  const _AdventureRoadOverlayPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final sx = size.width / 390.0;
    final sy = size.height / 760.0;
    canvas.save();
    canvas.scale(sx, sy);

    final path = Path()
      ..moveTo(205, 790)
      ..cubicTo(120, 700, 300, 630, 215, 545)
      ..cubicTo(140, 470, 320, 405, 225, 325)
      ..cubicTo(150, 260, 300, 190, 215, 115)
      ..cubicTo(185, 82, 190, 38, 200, -30);

    canvas.drawPath(
      path,
      Paint()
        ..color = const Color(0x7A3B2A15)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 122
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5),
    );
    canvas.drawPath(
      path,
      Paint()
        ..color = const Color(0xFFD6AA5C)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 108
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round,
    );
    canvas.drawPath(
      path,
      Paint()
        ..color = const Color(0xFFF0D081)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 82
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round,
    );
    canvas.drawPath(
      path,
      Paint()
        ..color = const Color(0x55FFF0BD)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 24
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round,
    );

    canvas.save();
    canvas.translate(235, 390);
    canvas.rotate(-0.16);
    final bridge = RRect.fromRectAndRadius(
      const Rect.fromLTWH(-40, -16, 80, 32),
      const Radius.circular(7),
    );
    canvas.drawRRect(
      bridge,
      Paint()..color = const Color(0xFF69442A),
    );
    for (double y = -12; y <= 8; y += 10) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(-34, y, 68, 7),
          const Radius.circular(2),
        ),
        Paint()..color = const Color(0xFFBE7A43),
      );
    }
    canvas.restore();

    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
