import 'package:flutter/material.dart';

import '../widgets/app_bottom_nav.dart';

import '../web_ui_scale.dart';
import '../game/game_controller.dart';
import 'game_screen.dart';

class AreaSelectScreen extends StatelessWidget {
  final GameController controller;
  const AreaSelectScreen({super.key, required this.controller});

  static const areas = [
    ('🌱','はじまりの広場','基本のマージを楽しもう',1),
    ('🌳','森の入口','新しい住人と素材に出会える',2),
    ('🥤','水辺ストリート','ドリンク系の注文が登場',3),
    ('🍰','お菓子通り','スイーツ系の注文が登場',5),
    ('🌸','花咲く丘','フラワー系の注文が登場',7),
    ('🍳','にぎわいキッチン','料理系の注文が登場',9),
    ('✨','星空広場','特別な街のエリア',10),
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: const Color(0xFFFFFBF4),
    appBar: AppBar(title: const Text('パズルエリア'), centerTitle: true, backgroundColor: const Color(0xFFFFFBF4)),
    bottomNavigationBar: AppBottomNav(controller: controller, active: ''),
    body: ListView.separated(
      padding: const EdgeInsets.fromLTRB(16 * webUiScale,12 * webUiScale,16 * webUiScale,28 * webUiScale), itemCount: areas.length, separatorBuilder: (_, child)=>const SizedBox(height:12 * webUiScale),
      itemBuilder: (context,i) {
        final a=areas[i]; final unlocked=a.$4==1 || controller.levelRewardClaimed(a.$4);
        return AnimatedOpacity(opacity: unlocked?1:.55, duration: const Duration(milliseconds:200), child: Container(
          padding: const EdgeInsets.all(16 * webUiScale),
          decoration: BoxDecoration(gradient: unlocked?const LinearGradient(colors:[Color(0xFFFFFFFF),Color(0xFFFFF0C9)]):null,color: unlocked?null:const Color(0xFFE7E7E7),borderRadius:BorderRadius.circular(24 * webUiScale),border:Border.all(color:unlocked?const Color(0xFFFFC44D):const Color(0xFFBDBDBD),width:2),boxShadow:unlocked?const[BoxShadow(color:Color(0x22000000),blurRadius:10,offset:Offset(0,4 * webUiScale))]:null),
          child: Row(children:[Text(unlocked?a.$1:'🔒',style:const TextStyle(fontSize:52 * webUiScale)),const SizedBox(width:14 * webUiScale),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(a.$2,style:const TextStyle(fontSize:26 * webUiScale,fontWeight:FontWeight.w900)),const SizedBox(height:3),Text(unlocked?a.$3:'街Lv.${a.$4}で解放',style:const TextStyle(fontSize:18 * webUiScale,fontWeight:FontWeight.w700))])),if(unlocked) FilledButton(onPressed:()=>Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>GameScreen(controller:controller))),style:FilledButton.styleFrom(backgroundColor:const Color(0xFFFF8A3D),padding:const EdgeInsets.symmetric(horizontal:18 * webUiScale,vertical:18 * webUiScale)),child:const Text('遊ぶ！',style:TextStyle(fontSize:22 * webUiScale,fontWeight:FontWeight.w900)))])
        ));
      })
  );
}
