import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../web_ui_scale.dart';
import '../sfx_manager.dart';

class PuzzleMoveResult {
  final int tracedCount;
  final int clearedCount;
  final int createdSpecial;
  final int reactionCount;
  final List<int> activatedSpecialKinds;

  const PuzzleMoveResult({
    required this.tracedCount,
    required this.clearedCount,
    required this.createdSpecial,
    required this.reactionCount,
    required this.activatedSpecialKinds,
  });
}

class FreePilePuzzle extends StatefulWidget {
  final int stageId;
  final ValueChanged<int>? onClear;
  final int pieceTypes;
  final int targetPieceCount;
  final bool oneTypeOnly;
  final bool bombEveryMove;
  final int refillMultiplier;
  final int startingSpecials;
  final ValueChanged<PuzzleMoveResult>? onMoveDetailed;
  final bool keyAvailable;
  final VoidCallback? onTreasureOpened;

  const FreePilePuzzle({
    super.key,
    required this.stageId,
    this.onClear,
    this.pieceTypes = 4,
    this.targetPieceCount = 44,
    this.oneTypeOnly = false,
    this.bombEveryMove = false,
    this.refillMultiplier = 1,
    this.startingSpecials = 0,
    this.onMoveDetailed,
    this.keyAvailable = false,
    this.onTreasureOpened,
  });

  @override
  State<FreePilePuzzle> createState() => _FreePilePuzzleState();
}

class _PilePiece {
  _PilePiece({
    required this.id,
    required this.type,
    required this.x,
    required this.y,
    required this.rotation,
    this.vx = 0,
    this.vy = 0,
    this.special = 0,
    this.specialLevel = 1,
  });

  final int id;
  final int type;
  double x;
  double y;
  double vx;
  double vy;
  final double rotation;
  int special; // 0 normal, 1 bomb item, 2 line item, 3 lightning item, 4 rainbow wildcard
  int specialLevel; // Lv1-Lv3 for bomb/line/lightning. Rainbow always behaves as Lv1.
  // V16.29 plush deformation: visual-only squash/stretch. Physics body stays circular.
  double plushX = 1.0;
  double plushY = 1.0;
}


class _FreePilePuzzleState extends State<FreePilePuzzle> with WidgetsBindingObserver {
  int get _pieceTypes => widget.oneTypeOnly ? 1 : widget.pieceTypes.clamp(1, 4).toInt();
  int get _targetPieceCount => widget.targetPieceCount;
  // V16.20.6: five deliberately separated theme colors.
  // Yellow / green / blue / purple / pink stay readable even in a dense pile.
  static const List<Color> _edge = [
    Color(0xFFFFC928), // chick - yellow
    Color(0xFF55C85B), // frog - green
    Color(0xFF4F9ED8), // penguin - blue
    Color(0xFF9B7BE8), // dog - purple
    Color(0xFFFF7EAE), // bunny - pink
  ];

  final List<_PilePiece> _pieces = <_PilePiece>[];
  final List<int> _traceIds = <int>[];
  final Set<int> _burstIds = <int>{};
  Offset? _tracePointer;
  late math.Random _random;
  Size _boardSize = Size.zero;
  int _nextId = 1;
  int _bestChain = 0;
  int _totalCleared = 0;
  int _score = 0;
  int _comboStreak = 0;
  DateTime? _lastClearAt;
  bool _busy = false;
  bool _physicsKick = false;
  bool _initialized = false;
  Timer? _physicsTimer;
  int _impactKind = 0;
  int _impactStrength = 0;
  bool _impactFlash = false;
  double _boardScale = 1.0;
  bool _keySpawned = false;
  bool _keyDragging = false;
  bool _treasureOpened = false;
  double _keyX = 0;
  double _keyY = -80;
  double _keyVy = 0;
  Offset? _keyPointer;

  void _impact(int kind, int strength) {
    if (!mounted) return;
    setState(() {
      _impactKind = kind;
      _impactStrength = strength;
      _impactFlash = true;
      _boardScale = strength >= 4 ? .975 : .988;
    });
    Future.delayed(const Duration(milliseconds: 70), () { if (mounted) setState(() => _boardScale = 1.0); });
    Future.delayed(Duration(milliseconds: strength >= 9 ? 1900 : (strength >= 4 ? 620 : 320)), () { if (mounted) setState(() => _impactFlash = false); });
  }

  @override
  void initState() {
    super.initState();
    _random = math.Random(widget.stageId * 7919 + 181);
    WidgetsBinding.instance.addObserver(this);
    SfxManager.instance.startPuzzleBgm();
    _physicsTimer = Timer.periodic(const Duration(milliseconds: 16), (_) {
      if (!mounted || !_initialized || _boardSize == Size.zero) return;
      _physicsStep(_boardSize);
      _keyPhysicsStep(_boardSize);
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _physicsTimer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    SfxManager.instance.stopBgm();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      SfxManager.instance.resumeBgm();
    } else if (state == AppLifecycleState.inactive ||
        state == AppLifecycleState.paused ||
        state == AppLifecycleState.detached ||
        state == AppLifecycleState.hidden) {
      SfxManager.instance.pauseBgm();
    }
  }

  @override
  void didUpdateWidget(covariant FreePilePuzzle oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (!oldWidget.keyAvailable && widget.keyAvailable && _initialized) {
      _spawnKey();
    }
    if (oldWidget.stageId != widget.stageId) {
      _random = math.Random(widget.stageId * 7919 + 181);
      _pieces.clear();
      _traceIds.clear();
      _burstIds.clear();
      _tracePointer = null;
      _nextId = 1;
      _bestChain = 0;
      _totalCleared = 0;
      _score = 0;
      _comboStreak = 0;
      _lastClearAt = null;
      _initialized = false;
      _keySpawned = false;
      _keyDragging = false;
      _treasureOpened = false;
      _keyY = -80;
      _keyVy = 0;
    }
  }

  double _radius(Size size) {
    // V16.20.10: keep the character size while reducing the total
    // number of pieces. Radius is width-driven so shortening the playfield
    // does not make the characters tiny again.
    final byWidth = size.width / 13.6;
    return (byWidth * .96).clamp(17.0, 26.0).toDouble();
  }

  _PilePiece _newPiece(Size size, {bool fromTop = false}) {
    final r = _radius(size);
    return _PilePiece(
      id: _nextId++,
      type: _random.nextInt(_pieceTypes),
      x: r + _random.nextDouble() * math.max(1.0, size.width - r * 2),
      y: fromTop
          ? -r * (1.0 + _random.nextDouble() * 4.0)
          : r + _random.nextDouble() * math.max(1.0, size.height * .90 - r),
      rotation: (_random.nextDouble() - .5) * .24,
      vx: (_random.nextDouble() - .5) * 1.4,
      vy: fromTop ? 0 : _random.nextDouble() * 1.6,
    );
  }

  void _initialize(Size size) {
    _boardSize = size;
    _pieces
      ..clear()
      ..addAll(List.generate(_targetPieceCount, (_) => _newPiece(size)));
    for (var i = 0; i < 130; i++) {
      _physicsStep(size, settleOnly: true);
    }
    if (widget.startingSpecials > 0 && _pieces.isNotEmpty) {
      final candidates = List<_PilePiece>.from(_pieces)..shuffle(_random);
      final count = math.min(widget.startingSpecials, candidates.length);
      for (var i = 0; i < count; i++) {
        candidates[i].special = 1 + (i % 3);
      }
    }
    _initialized = true;
    if (widget.keyAvailable && !_keySpawned) _spawnKey();
  }

  void _spawnKey() {
    if (_boardSize == Size.zero || _keySpawned) return;
    _keySpawned = true;
    _keyX = _boardSize.width * (.46 + _random.nextDouble() * .08);
    _keyY = -36 * webUiScale;
    _keyVy = 0;
    SfxManager.instance.spawn();
    _impact(3, 3);
  }

  Rect _chestRect(Size size) {
    // V16.26.2: make the treasure a clear focal point and reserve real
    // physical space for it instead of drawing a tiny label under pieces.
    final w = math.min(184.0 * webUiScale, size.width * .48);
    final h = math.min(112.0 * webUiScale, size.height * .21);
    return Rect.fromCenter(
      center: Offset(size.width * .5, size.height - h * .48),
      width: w,
      height: h,
    );
  }

  Rect _chestPhysicsRect(Size size) => _chestRect(size).inflate(6.0 * webUiScale);

  Offset _pushCircleOutOfChest(Offset center, double radius, Size size) {
    final rect = _chestPhysicsRect(size);
    final nearest = Offset(
      center.dx.clamp(rect.left, rect.right).toDouble(),
      center.dy.clamp(rect.top, rect.bottom).toDouble(),
    );
    var delta = center - nearest;
    var distance = delta.distance;

    if (distance >= radius) return center;

    if (distance < .001) {
      // Center is inside the chest rectangle. Push it through the nearest
      // edge, preferring the top so falling pieces naturally pile over it.
      final top = (center.dy - rect.top).abs();
      final left = (center.dx - rect.left).abs();
      final right = (rect.right - center.dx).abs();
      final bottom = (rect.bottom - center.dy).abs();
      final minimum = math.min(math.min(top, bottom), math.min(left, right));
      if (minimum == top) return Offset(center.dx, rect.top - radius);
      if (minimum == left) return Offset(rect.left - radius, center.dy);
      if (minimum == right) return Offset(rect.right + radius, center.dy);
      return Offset(center.dx, rect.bottom + radius);
    }

    delta = delta / distance;
    return nearest + delta * radius;
  }

  Offset get _keyCenter => Offset(_keyX, _keyY);

  bool _keyNearChest() {
    if (!_keySpawned || _boardSize == Size.zero) return false;
    final chest = _chestRect(_boardSize);
    final nearestX = _keyX.clamp(chest.left, chest.right).toDouble();
    final nearestY = _keyY.clamp(chest.top, chest.bottom).toDouble();
    return (Offset(nearestX, nearestY) - _keyCenter).distance <= _radius(_boardSize) * 1.35;
  }

  void _keyPhysicsStep(Size size) {
    if (!_keySpawned || _treasureOpened || _keyDragging) return;

    // V16.26.2: the key now owns almost the same collision radius as a
    // character. Previously its collision body was much smaller than its
    // visual size, so it could slip into tiny gaps and jitter between pieces.
    final pieceRadius = _radius(size);
    final kr = pieceRadius * .92;
    _keyVy = math.min(_keyVy + .58, 9.2);
    _keyY += _keyVy;
    _keyX = _keyX.clamp(kr + 10, size.width - kr - 10).toDouble();

    // Resolve key <-> character collisions using the same circle rule as the
    // pile. Give a small part of the correction to the character so the key
    // feels like a real object rather than a ghost that only pushes itself.
    for (var pass = 0; pass < 3; pass++) {
      for (final p in _pieces) {
        var dx = _keyX - p.x;
        var dy = _keyY - p.y;
        var dist = math.sqrt(dx * dx + dy * dy);
        final minD = pieceRadius + kr;
        if (dist >= minD) continue;
        if (dist < .001) {
          dx = (_random.nextDouble() - .5) * .2;
          dy = -1;
          dist = math.sqrt(dx * dx + dy * dy);
        }
        final nx = dx / dist;
        final ny = dy / dist;
        final overlap = minD - dist;
        _keyX += nx * overlap * .72;
        _keyY += ny * overlap * .72;
        p.x -= nx * overlap * .18;
        p.y -= ny * overlap * .18;
        p.vx -= nx * overlap * .012;
        if (ny < 0) _keyVy = math.min(0, _keyVy * -.06);
      }

      // The enlarged chest is a true obstacle for the key too.
      final corrected = _pushCircleOutOfChest(_keyCenter, kr, size);
      if ((corrected - _keyCenter).distance > .01) {
        if (corrected.dy < _keyY) _keyVy = 0;
        _keyX = corrected.dx;
        _keyY = corrected.dy;
      }

      _keyX = _keyX.clamp(kr + 10, size.width - kr - 10).toDouble();
      _keyY = _keyY.clamp(-kr * 4, size.height - kr - 10).toDouble();
    }
  }


  double _roundedSideInset(double y, Size size, double r) {
    final radius = math.min(size.width * .16, 58.0 * webUiScale);
    final innerTop = r + 10.0 * webUiScale;
    final innerBottom = size.height - r - 10.0 * webUiScale;
    if (y < innerTop + radius) {
      final dy = (innerTop + radius - y).clamp(0.0, radius).toDouble();
      return radius - math.sqrt(math.max(0.0, radius * radius - dy * dy));
    }
    if (y > innerBottom - radius) {
      final dy = (y - (innerBottom - radius)).clamp(0.0, radius).toDouble();
      return radius - math.sqrt(math.max(0.0, radius * radius - dy * dy));
    }
    return 0;
  }

  void _physicsStep(Size size, {bool settleOnly = false}) {
    final r = _radius(size);
    // Slight visual overlap removes the artificial gaps between pieces.
    final minDistance = r * 1.72;

    for (final p in _pieces) {
      if (!settleOnly) {
        // Keep the collision body firm and predictable, while the drawing
        // stretches softly with falling speed like a stuffed plush toy.
        final fallT = (p.vy.abs() / 10.5).clamp(0.0, 1.0);
        final targetX = 1.0 - fallT * .035;
        final targetY = 1.0 + fallT * .065;
        p.plushX += (targetX - p.plushX) * .16;
        p.plushY += (targetY - p.plushY) * .16;
        p.vy = math.min(p.vy + .58, 10.0);
        p.x += p.vx;
        p.y += p.vy;
      } else {
        p.y += 4.2;
      }

      // V16.21: rounded physical walls match the visible arena and keep
      // every character safely inside the rim.
      final sideInset = _roundedSideInset(p.y, size, r);
      final wallPadding = 9.0 * webUiScale;
      final minX = r + sideInset + wallPadding;
      final maxX = size.width - r - sideInset - wallPadding;
      if (p.x < minX) {
        p.x = minX;
        p.vx = p.vx.abs() * .24;
      } else if (p.x > maxX) {
        p.x = maxX;
        p.vx = -p.vx.abs() * .24;
      }
      final bottomPadding = 10.0 * webUiScale;
      if (p.y > size.height - r - bottomPadding) {
        final landingSpeed = p.vy.abs();
        p.y = size.height - r - bottomPadding;
        if (landingSpeed > 1.8) {
          final squash = (landingSpeed / 10.0).clamp(0.0, 1.0);
          p.plushX = 1.0 + .10 * squash;
          p.plushY = 1.0 - .10 * squash;
        }
        p.vy *= -.11;
        if (p.vy.abs() < .22) p.vy = 0;
        p.vx *= .94;
      }


      // The treasure chest is part of the physical board. Characters can
      // rest on top of it or roll around its sides, but never overlap it.
      final chestCorrected = _pushCircleOutOfChest(Offset(p.x, p.y), r, size);
      if ((chestCorrected - Offset(p.x, p.y)).distance > .01) {
        if (chestCorrected.dy < p.y) p.vy = math.min(0, p.vy * -.10);
        p.x = chestCorrected.dx;
        p.y = chestCorrected.dy;
      }
    }

    // Extra relaxed collision passes keep the pile dense without turning it
    // into a grid.
    for (var pass = 0; pass < 4; pass++) {
      for (var i = 0; i < _pieces.length; i++) {
        final a = _pieces[i];
        for (var j = i + 1; j < _pieces.length; j++) {
          final b = _pieces[j];
          var dx = b.x - a.x;
          var dy = b.y - a.y;
          var distance = math.sqrt(dx * dx + dy * dy);
          final chest = _chestPhysicsRect(size);
          final nearChest = (a.y > chest.top - r * 2.2 || b.y > chest.top - r * 2.2) &&
              (a.x > chest.left - r * 2.5 || b.x > chest.left - r * 2.5) &&
              (a.x < chest.right + r * 2.5 || b.x < chest.right + r * 2.5);
          final requiredDistance = nearChest ? r * 1.78 : minDistance;
          if (distance >= requiredDistance) continue;
          if (distance < .001) {
            dx = (_random.nextDouble() - .5) * .4;
            dy = -.4;
            distance = math.sqrt(dx * dx + dy * dy);
          }
          final overlap = (requiredDistance - distance) * .52;
          final nx = dx / distance;
          final ny = dy / distance;
          a.x -= nx * overlap;
          a.y -= ny * overlap;
          b.x += nx * overlap;
          b.y += ny * overlap;
          final push = overlap * .055;
          a.vx -= nx * push;
          b.vx += nx * push;
          a.vy -= ny * push * .18;
          b.vy += ny * push * .18;
          // A tiny visual compression on contact gives the pile a soft
          // stuffed-toy feel without changing collision geometry.
          final press = (overlap / (r * .28)).clamp(0.0, 1.0);
          a.plushX += (1.0 + .035 * press - a.plushX) * .22;
          a.plushY += (1.0 - .030 * press - a.plushY) * .22;
          b.plushX += (1.0 + .035 * press - b.plushX) * .22;
          b.plushY += (1.0 - .030 * press - b.plushY) * .22;
          a.vx *= .91;
          b.vx *= .91;
          a.vy *= .90;
          b.vy *= .90;
        }
      }
      for (final p in _pieces) {
        final sideInset = _roundedSideInset(p.y, size, r);
        final wallPadding = 9.0 * webUiScale;
        p.x = p.x.clamp(r + sideInset + wallPadding, size.width - r - sideInset - wallPadding).toDouble();
        p.y = p.y.clamp(-r * 6, size.height - r - 10.0 * webUiScale).toDouble();
        final chestCorrected = _pushCircleOutOfChest(Offset(p.x, p.y), r, size);
        p.x = chestCorrected.dx;
        p.y = chestCorrected.dy;
      }
    }

    // Let squash/stretch settle gently instead of snapping back.
    for (final p in _pieces) {
      p.plushX += (1.0 - p.plushX) * .075;
      p.plushY += (1.0 - p.plushY) * .075;
    }

    // V16.27: identical special items automatically fuse when they settle
    // next to each other. The physics body never changes size; only level,
    // appearance and technique become stronger.
    if (!settleOnly) _autoMergeSpecials(size);
  }

  void _autoMergeSpecials(Size size) {
    if (_busy || _pieces.length < 2) return;
    final r = _radius(size);
    final mergeDistance = r * 2.02;
    for (var i = 0; i < _pieces.length; i++) {
      final a = _pieces[i];
      if (a.special < 1 || a.special > 3 || a.specialLevel >= 3) continue;
      for (var j = i + 1; j < _pieces.length; j++) {
        final b = _pieces[j];
        if (b.special != a.special || b.specialLevel >= 3) continue;
        // V16.27.1: levels add together up to Lv3.
        // Lv1+Lv1 -> Lv2, Lv2+Lv1 -> Lv3, Lv2+Lv2 -> Lv3.
        final mergedLevel = math.min(3, a.specialLevel + b.specialLevel);
        final dx = b.x - a.x;
        final dy = b.y - a.y;
        if (math.sqrt(dx * dx + dy * dy) > mergeDistance) continue;
        final newX = (a.x + b.x) / 2;
        final newY = (a.y + b.y) / 2;
        a.x = newX;
        a.y = newY;
        a.vx = (a.vx + b.vx) * .18;
        a.vy = math.min(a.vy, b.vy) * .12;
        a.specialLevel = mergedLevel;
        _pieces.removeAt(j);
        _traceIds.remove(b.id);
        SfxManager.instance.specialMerge(a.specialLevel);
        _impact(a.special, a.specialLevel + 1);
        return; // one fusion per frame keeps cascaded Lv1→Lv2→Lv3 readable
      }
    }
  }

  Future<void> _animateSettle(Size size) async {
    // V16.19.4: physics is now driven continuously by a 60fps timer instead
    // of a finite settle loop. The previous loop could hit its frame cap or
    // incorrectly decide the pile was calm while pieces were still airborne,
    // leaving isolated pieces frozen in mid-air.
    _physicsKick = true;
    if (mounted) setState(() {});
    await Future<void>.delayed(const Duration(milliseconds: 16));
    _physicsKick = false;
  }

  _PilePiece? _nearestPiece(Offset point, {double? maxDistance}) {
    if (_pieces.isEmpty) return null;
    final radius = _radius(_boardSize);
    final limit = maxDistance ?? radius * 1.62;
    _PilePiece? best;
    var bestD = double.infinity;
    for (final p in _pieces) {
      final dx = p.x - point.dx;
      final dy = p.y - point.dy;
      final d = math.sqrt(dx * dx + dy * dy);
      if (d <= limit && d < bestD) {
        best = p;
        bestD = d;
      }
    }
    return best;
  }

  _PilePiece? _pieceById(int id) {
    for (final piece in _pieces) {
      if (piece.id == id) return piece;
    }
    return null;
  }

  void _startTrace(Offset local) {
    if (!_initialized) return;
    if (_keySpawned && !_treasureOpened && (local - _keyCenter).distance <= _radius(_boardSize) * 1.15) {
      _keyDragging = true;
      _keyPointer = local;
      SfxManager.instance.traceStep(4);
      if (mounted) setState(() {});
      return;
    }
    final piece = _nearestPiece(local);
    if (piece == null) return;
    setState(() {
      _tracePointer = local;
      _traceIds
        ..clear()
        ..add(piece.id);
      SfxManager.instance.traceStep(1);
    });
  }

  void _updateTrace(Offset local) {
    if (_keyDragging) {
      _keyPointer = local;
      if (mounted) setState(() {});
      return;
    }
    if (_traceIds.isEmpty) return;
    _tracePointer = local;
    final last = _pieceById(_traceIds.last);
    if (last == null) return;
    final candidate = _nearestPiece(local, maxDistance: _radius(_boardSize) * 1.95);
    if (candidate == null) {
      if (mounted) setState(() {});
      return;
    }
    // V16.26.5: specials are wildcard connectors, but they do NOT allow
    // switching the normal-character colour in the middle of a trace.
    // Example: yellow -> rainbow -> yellow is valid, while
    // yellow -> rainbow -> blue is rejected. This makes one rainbow mean
    // "clear every character of THIS traced type". Two rainbows can still
    // be included anywhere along the same valid trace to trigger SURUSURU.
    int? traceNormalType;
    for (final id in _traceIds) {
      final tracedPiece = _pieceById(id);
      if (tracedPiece != null && tracedPiece.special == 0) {
        traceNormalType = tracedPiece.type;
        break;
      }
    }
    if (candidate.special == 0 &&
        traceNormalType != null &&
        candidate.type != traceNormalType) {
      if (mounted) setState(() {});
      return;
    }
    final wildcardLink = last.special > 0 || candidate.special > 0;
    if (!wildcardLink && candidate.type != last.type) {
      if (mounted) setState(() {});
      return;
    }

    if (_traceIds.length >= 2 && candidate.id == _traceIds[_traceIds.length - 2]) {
      setState(() => _traceIds.removeLast());
      return;
    }
    if (_traceIds.contains(candidate.id)) return;

    final dx = candidate.x - last.x;
    final dy = candidate.y - last.y;
    final distance = math.sqrt(dx * dx + dy * dy);
    if (distance > _radius(_boardSize) * 2.78) return;
    setState(() => _traceIds.add(candidate.id));
    SfxManager.instance.traceStep(_traceIds.length);
  }

  bool _traceContainsRainbowPair() {
    // V16.26.4: the two rainbows only need to be part of the same trace.
    // They no longer have to touch each other directly.
    var count = 0;
    for (final id in _traceIds) {
      if (_pieceById(id)?.special == 4 && ++count >= 2) return true;
    }
    return false;
  }

  int? _rainbowTargetType(List<_PilePiece> tracedPieces) {
    // One rainbow adopts the colour being cleared. Use the first normal
    // character in the trace as the clear colour; standalone specials do not
    // define a colour.
    for (final piece in tracedPieces) {
      if (piece.special == 0) return piece.type;
    }
    return null;
  }

  Future<void> _triggerSurusuruFullClear() async {
    if (_busy || _pieces.isEmpty) return;
    _busy = true;
    final clearIds = _pieces.map((p) => p.id).toSet();
    final clearedCount = clearIds.length;
    final tracedCount = _traceIds.length;

    SfxManager.instance.surusuru();
    _impact(4, 10);
    setState(() {
      _burstIds
        ..clear()
        ..addAll(clearIds);
      _bestChain = math.max(_bestChain, tracedCount);
      _totalCleared += clearedCount;
      _score += clearedCount * 25 + 1000;
      _traceIds.clear();
      _tracePointer = null;
    });

    widget.onClear?.call(clearedCount);
    widget.onMoveDetailed?.call(PuzzleMoveResult(
      tracedCount: tracedCount,
      clearedCount: clearedCount,
      createdSpecial: 0,
      reactionCount: 10,
      activatedSpecialKinds: const [4, 4],
    ));

    // Deliberately longer than a normal clear: the whole board flashes,
    // then the pieces pop away together before the fresh pile rains in.
    await Future<void>.delayed(const Duration(milliseconds: 1250));
    if (!mounted) return;
    setState(() {
      _pieces.removeWhere((p) => clearIds.contains(p.id));
      _burstIds.clear();
      for (var i = 0; i < clearedCount; i++) {
        _pieces.add(_newPiece(_boardSize, fromTop: true));
      }
    });
    _physicsKick = true;
    await _animateSettle(_boardSize);
    _busy = false;
  }

  Future<void> _finishTrace() async {
    if (_keyDragging) {
      final chest = _chestRect(_boardSize).inflate(24 * webUiScale);
      final success = _keyNearChest() && _keyPointer != null && chest.contains(_keyPointer!);
      _keyDragging = false;
      _keyPointer = null;
      if (success) {
        _treasureOpened = true;
        SfxManager.instance.unlock();
        _impact(4, 8);
        if (mounted) setState(() {});
        await Future<void>.delayed(const Duration(milliseconds: 520));
        SfxManager.instance.reward();
        widget.onTreasureOpened?.call();
      } else if (mounted) {
        setState(() {});
      }
      return;
    }
    // Two rainbows anywhere inside one continuous trace are the jackpot move.
    // A normal character or another wildcard may sit between them.
    if (!_busy && _traceContainsRainbowPair()) {
      await _triggerSurusuruFullClear();
      return;
    }
    if (_traceIds.length < 3 || _busy) {
      if (mounted) {
        setState(() {
          _traceIds.clear();
          _tracePointer = null;
        });
      }
      return;
    }

    _busy = true;
    final traced = List<int>.from(_traceIds);
    final tracedPieces = traced.map(_pieceById).whereType<_PilePiece>().toList();
    final now = DateTime.now();
    if (_lastClearAt != null && now.difference(_lastClearAt!).inMilliseconds < 2600) {
      _comboStreak++;
    } else {
      _comboStreak = 1;
    }
    _lastClearAt = now;

    final clearIds = <int>{...traced};

    // V16.26.5 rainbow rule:
    // - 1 rainbow inside a trace = erase every normal character of the one
    //   normal type used by that trace (frog + rainbow => all frogs, etc.).
    // - 2 rainbows are handled above as SURUSURU full clear, even when they
    //   are not adjacent.
    final rainbowCount = tracedPieces.where((p) => p.special == 4).length;
    if (rainbowCount == 1) {
      final targetType = _rainbowTargetType(tracedPieces);
      if (targetType != null) {
        clearIds.addAll(_pieces
            .where((p) => p.special == 0 && p.type == targetType)
            .map((p) => p.id));
        SfxManager.instance.core();
        _impact(4, 5);
      }
    }

    final activatedKinds = <int>[];
    final queued = <int>[];
    final queuedSet = <int>{};
    final triggered = <int>{};

    void enqueueSpecial(_PilePiece piece) {
      // Rainbow is resolved by the wildcard rules above; bomb / line /
      // lightning are standalone wildcard items whose own techniques fire
      // whenever they are included in the trace.
      if (piece.special == 4) return;
      if (piece.special <= 0 || triggered.contains(piece.id) || queuedSet.contains(piece.id)) return;
      queued.add(piece.id);
      queuedSet.add(piece.id);
    }

    for (final piece in tracedPieces) {
      enqueueSpecial(piece);
    }

    // Chain reaction: any special caught by another special is activated too.
    while (queued.isNotEmpty) {
      final id = queued.removeAt(0);
      queuedSet.remove(id);
      final piece = _pieceById(id);
      if (piece == null || triggered.contains(id) || piece.special <= 0) continue;
      triggered.add(id);
      activatedKinds.add(piece.special);
      clearIds.add(id);

      final newlyHit = <_PilePiece>[];
      if (piece.special == 1) {
        // BOMB Lv1/Lv2/Lv3: increasingly wide circular blast.
        final blast = _radius(_boardSize) * (piece.specialLevel == 1 ? 2.65 : piece.specialLevel == 2 ? 3.75 : 5.05);
        for (final other in _pieces) {
          final dx = other.x - piece.x;
          final dy = other.y - piece.y;
          if (math.sqrt(dx * dx + dy * dy) <= blast) newlyHit.add(other);
        }
      } else if (piece.special == 2) {
        // LINE appearance and technique match: Lv1 horizontal, Lv2 cross,
        // Lv3 eight directions (horizontal + vertical + both diagonals).
        final lane = _radius(_boardSize) * .92;
        for (final other in _pieces) {
          final dx = other.x - piece.x;
          final dy = other.y - piece.y;
          final horizontal = dy.abs() <= lane;
          final vertical = dx.abs() <= lane;
          final diagonal = (dx - dy).abs() <= lane * 1.25 || (dx + dy).abs() <= lane * 1.25;
          if (horizontal || (piece.specialLevel >= 2 && vertical) || (piece.specialLevel >= 3 && diagonal)) {
            newlyHit.add(other);
          }
        }
      } else if (piece.special == 3) {
        // LIGHTNING Lv1/Lv2/Lv3: jump to 3 / 6 / 12 nearby pieces.
        final sorted = List<_PilePiece>.from(_pieces)
          ..sort((a, b) {
            final da = (a.x - piece.x) * (a.x - piece.x) + (a.y - piece.y) * (a.y - piece.y);
            final db = (b.x - piece.x) * (b.x - piece.x) + (b.y - piece.y) * (b.y - piece.y);
            return da.compareTo(db);
          });
        final targets = piece.specialLevel == 1 ? 3 : piece.specialLevel == 2 ? 6 : 12;
        newlyHit.addAll(sorted.take(math.min(targets, sorted.length)));
      }

      for (final other in newlyHit) {
        clearIds.add(other.id);
        enqueueSpecial(other);
      }
    }

    final clearedCount = clearIds.length;
    final reactionCount = math.max(0, activatedKinds.length - 1);
    final chainBonus = math.max(0, traced.length - 3) * 15;
    final reactionBonus = reactionCount * reactionCount * 55;
    final comboBonus = math.max(0, _comboStreak - 1) * 20;
    final gained = clearedCount * 10 + chainBonus + reactionBonus + comboBonus;

    // Exact lengths matter: longer is not always better.
    final specialType = traced.length >= 7
        ? 4
        : traced.length == 6
            ? 3
            : traced.length == 5
                ? 2
                : traced.length == 4
                    ? 1
                    : 0;
    final anchor = tracedPieces.isEmpty ? null : tracedPieces.last;

    if (activatedKinds.isEmpty) {
      SfxManager.instance.clear();
      _impact(0, math.min(3, traced.length ~/ 3));
    } else {
      for (final kind in activatedKinds) {
        if (kind == 1) SfxManager.instance.bomb();
        if (kind == 2) SfxManager.instance.line();
        if (kind == 3) SfxManager.instance.lightning();
        if (kind == 4) SfxManager.instance.core();
      }
      if (reactionCount > 0) SfxManager.instance.reaction();
      _impact(activatedKinds.last, math.min(8, 2 + reactionCount));
    }

    setState(() {
      _burstIds
        ..clear()
        ..addAll(clearIds);
      _bestChain = math.max(_bestChain, traced.length);
      _totalCleared += clearedCount;
      _score += gained;
      _traceIds.clear();
      _tracePointer = null;
    });

    widget.onClear?.call(clearedCount);
    widget.onMoveDetailed?.call(PuzzleMoveResult(
      tracedCount: traced.length,
      clearedCount: clearedCount,
      createdSpecial: specialType,
      reactionCount: reactionCount,
      activatedSpecialKinds: List<int>.unmodifiable(activatedKinds),
    ));

    await Future<void>.delayed(Duration(milliseconds: reactionCount > 0 ? 260 : 180));
    if (!mounted) return;
    setState(() {
      _pieces.removeWhere((p) => clearIds.contains(p.id));
      _burstIds.clear();
      var spawnCount = clearedCount * widget.refillMultiplier;
      if (specialType > 0 && anchor != null) {
        _pieces.add(_PilePiece(
          id: _nextId++,
          type: anchor.type,
          x: anchor.x,
          y: anchor.y,
          rotation: 0,
          special: specialType,
        ));
        spawnCount = math.max(0, spawnCount - 1);
      }
      for (var i = 0; i < spawnCount; i++) {
        _pieces.add(_newPiece(_boardSize, fromTop: true));
      }
      if (widget.bombEveryMove && _pieces.isNotEmpty) {
        final normal = _pieces.where((p) => p.special == 0).toList();
        if (normal.isNotEmpty) normal[_random.nextInt(normal.length)].special = 1;
      }
    });
    _physicsKick = true;
    await _animateSettle(_boardSize);
    _busy = false;
  }



  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth * .96;
        final hudHeight = 62.0 * webUiScale;
        final boardHeight = math.min(
          math.max(260.0, constraints.maxHeight - hudHeight - 4 * webUiScale),
          width * 1.03,
        );
        final size = Size(width, boardHeight);
        if (!_initialized ||
            (_boardSize.width - width).abs() > 2 ||
            (_boardSize.height - boardHeight).abs() > 2) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (!mounted) return;
            setState(() => _initialize(size));
          });
        }

        return Align(
          alignment: Alignment.topCenter,
          child: SizedBox(
            width: width,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  width: width,
                  height: boardHeight,
                  child: AnimatedScale(
                    scale: _boardScale,
                    duration: const Duration(milliseconds: 90),
                    curve: Curves.easeOutBack,
                    child: CustomPaint(
                    painter: _ArenaFramePainter(fever: false),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(58 * webUiScale),
                      child: GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onPanStart: (d) => _startTrace(d.localPosition),
                        onPanUpdate: (d) => _updateTrace(d.localPosition),
                        onPanEnd: (_) => _finishTrace(),
                        onPanCancel: () {
                          if (mounted) {
                            setState(() {
                              _traceIds.clear();
                              _tracePointer = null;
                              _keyDragging = false;
                              _keyPointer = null;
                            });
                          }
                        },
                        child: Stack(
                          children: [
                            Positioned.fill(
                              child: IgnorePointer(
                                child: CustomPaint(
                                  painter: _NeonBackdropPainter(fever: false),
                                ),
                              ),
                            ),
                            _buildChest(size),
                            for (final p in _pieces) _buildPiece(p, size),
                            if (_keySpawned) _buildKey(size),
                            if (_keyDragging && _keyPointer != null)
                              Positioned.fill(
                                child: IgnorePointer(
                                  child: CustomPaint(painter: _KeyLinkPainter(from: _keyCenter, to: _keyPointer!)),
                                ),
                              ),
                            Positioned.fill(
                              child: IgnorePointer(
                                child: CustomPaint(
                                  painter: _TracePainter(
                                    points: _traceIds
                                        .map(_pieceById)
                                        .whereType<_PilePiece>()
                                        .map((p) => Offset(p.x, p.y))
                                        .toList(),
                                    color: _traceIds.isEmpty
                                        ? Colors.transparent
                                        : _edge[_pieceById(_traceIds.first)?.type ?? 0],
                                    rainbow: _traceIds
                                        .map(_pieceById)
                                        .whereType<_PilePiece>()
                                        .any((p) => p.special == 4),
                                    pointer: _tracePointer,
                                  ),
                                ),
                              ),
                            ),
                            if (_impactFlash)
                              Positioned.fill(
                                child: IgnorePointer(
                                  child: CustomPaint(
                                    painter: _ImpactOverlayPainter(kind: _impactKind, strength: _impactStrength),
                                  ),
                                ),
                              ),
                            if (_impactFlash && _impactStrength >= 3)
                              Center(
                                child: _impactKind == 4 && _impactStrength >= 9
                                    ? const _SurusuruText()
                                    : _ImpactText(kind: _impactKind, strength: _impactStrength),
                              ),
                            if (_comboStreak >= 2)
                              Positioned(
                                left: 16 * webUiScale,
                                top: 16 * webUiScale,
                                child: _ComboBadge(combo: _comboStreak),
                              ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  ),
                ),
                const SizedBox(height: 6 * webUiScale),
                _buildGameHud(width),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildChest(Size size) {
    final r = _chestRect(size);
    return Positioned(
      left: r.left,
      top: r.top,
      width: r.width,
      height: r.height,
      child: IgnorePointer(
        child: AnimatedScale(
          scale: _treasureOpened ? 1.10 : 1,
          duration: const Duration(milliseconds: 320),
          curve: Curves.easeOutBack,
          child: CustomPaint(
            painter: _TreasureChestPainter(opened: _treasureOpened),
            child: _treasureOpened
                ? Center(
                    child: Text(
                      '✨',
                      style: TextStyle(fontSize: 34 * webUiScale),
                    ),
                  )
                : null,
          ),
        ),
      ),
    );
  }

  Widget _buildKey(Size size) {
    // No circular badge: the key itself is the game object. Keep a soft glow
    // only so it remains readable among the characters.
    final d = _radius(size) * 1.70;
    return Positioned(
      left: _keyX - d / 2,
      top: _keyY - d / 2,
      width: d,
      height: d,
      child: IgnorePointer(
        child: Center(
          child: Text(
            '🔑',
            style: TextStyle(
              fontSize: d * .78,
              shadows: const [
                Shadow(color: Color(0xDDFFE66D), blurRadius: 14),
                Shadow(color: Color(0x88000000), blurRadius: 5, offset: Offset(0, 2)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildGameHud(double width) {
    final mission = math.min(_totalCleared, 40);
    return SizedBox(height: 54 * webUiScale, child: Row(children:[
      Expanded(child: _hudBox('4💣  5➕  6⚡  7+🌈')),
      const SizedBox(width: 7 * webUiScale),
      Expanded(child: _hudBox('SURUSURU CHAIN  BEST $_bestChain')),
      const SizedBox(width: 7 * webUiScale),
      _hudBox('SCORE $_score'),
    ]));
  }

  Widget _hudBox(String text) => Container(
    height: 48 * webUiScale, padding: const EdgeInsets.symmetric(horizontal: 10 * webUiScale),
    decoration: BoxDecoration(color: const Color(0xCC0C245D), borderRadius: BorderRadius.circular(18 * webUiScale), border: Border.all(color: const Color(0x6656B9FF))),
    alignment: Alignment.center, child: Text(text, maxLines:1, overflow:TextOverflow.ellipsis, style: const TextStyle(color:Colors.white,fontSize:12 * webUiScale,fontWeight:FontWeight.w900)),
  );

  Widget _buildPiece(_PilePiece p, Size size) {
    final r = _radius(size);
    final selected = _traceIds.contains(p.id);
    final bursting = _burstIds.contains(p.id);
    final diameter = r * 2;
    return Positioned(
      left: p.x - r,
      top: p.y - r,
      width: diameter,
      height: diameter,
      child: IgnorePointer(
        child: AnimatedScale(
          scale: bursting ? .18 : (selected ? 1.21 : 1),
          duration: Duration(milliseconds: bursting ? 150 : 90),
          curve: bursting ? Curves.easeInBack : Curves.easeOutBack,
          child: AnimatedOpacity(
            opacity: bursting ? 0 : 1,
            duration: const Duration(milliseconds: 150),
            child: Transform.rotate(
              angle: p.rotation,
              child: Transform.scale(
                scaleX: selected ? p.plushX * 1.015 : p.plushX,
                scaleY: selected ? p.plushY * .985 : p.plushY,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                  // V16.20.4: stop using emoji silhouettes. Each puzzle
                  // piece is drawn as a soft, round character body, so the
                  // character itself is circular/plush-like rather than an
                  // icon placed inside a circular tile.
                  if (selected)
                    Container(
                      width: diameter * .96,
                      height: diameter * .96,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: _edge[p.type].withValues(alpha: .60),
                            blurRadius: 13 * webUiScale,
                            spreadRadius: 4 * webUiScale,
                          ),
                        ],
                      ),
                    ),
                  SizedBox(
                    width: diameter * .96,
                    height: diameter * .96,
                    child: CustomPaint(
                      // V16.26.4: bomb / line / lightning are no longer
                      // character overlays. They are independent board items
                      // with the same physics body and wildcard trace rules.
                      painter: p.special == 4
                          ? _RainbowCharacterPainter(selected: selected)
                          : p.special > 0
                              ? _StandaloneSpecialPainter(
                                  kind: p.special,
                                  level: p.specialLevel,
                                  selected: selected,
                                )
                              : _RoundCharacterPainter(
                                  type: p.type,
                                  selected: selected,
                                ),
                    ),
                  ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}



class _KeyLinkPainter extends CustomPainter {
  final Offset from;
  final Offset to;
  const _KeyLinkPainter({required this.from, required this.to});
  @override
  void paint(Canvas canvas, Size size) {
    final glow = Paint()..color = const Color(0x99FFE76A)..strokeWidth = 16 * webUiScale..strokeCap = StrokeCap.round..maskFilter = MaskFilter.blur(BlurStyle.normal, 8 * webUiScale);
    final line = Paint()..color = const Color(0xFFFFF4A8)..strokeWidth = 6 * webUiScale..strokeCap = StrokeCap.round;
    canvas.drawLine(from, to, glow);
    canvas.drawLine(from, to, line);
  }
  @override
  bool shouldRepaint(covariant _KeyLinkPainter oldDelegate) => oldDelegate.from != from || oldDelegate.to != to;
}

class _SoftCapsuleRimPainter extends CustomPainter {
  const _SoftCapsuleRimPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Rect.fromLTWH(
      7 * webUiScale,
      7 * webUiScale,
      size.width - 14 * webUiScale,
      size.height - 14 * webUiScale,
    );
    final rrect = RRect.fromRectAndCorners(
      rect,
      topLeft: Radius.circular(76 * webUiScale),
      topRight: Radius.circular(76 * webUiScale),
      bottomLeft: Radius.circular(62 * webUiScale),
      bottomRight: Radius.circular(62 * webUiScale),
    );
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4 * webUiScale
      ..color = Colors.white.withValues(alpha: .13);
    canvas.drawRRect(rrect, paint);
  }

  @override
  bool shouldRepaint(covariant _SoftCapsuleRimPainter oldDelegate) => false;
}


class _PouchClipper extends CustomClipper<Path> {
  const _PouchClipper();

  Path _path(Size size) {
    final topDepth = math.min(54 * webUiScale, size.height * .085);
    final bottomDepth = math.min(46 * webUiScale, size.height * .075);
    final side = 5 * webUiScale;
    return Path()
      ..moveTo(side, topDepth)
      ..quadraticBezierTo(size.width * .5, -topDepth * .34, size.width - side, topDepth)
      ..lineTo(size.width - side, size.height - bottomDepth)
      ..quadraticBezierTo(size.width * .5, size.height + bottomDepth * .30, side, size.height - bottomDepth)
      ..close();
  }

  @override
  Path getClip(Size size) => _path(size);

  @override
  bool shouldReclip(covariant _PouchClipper oldClipper) => false;
}

class _PouchFramePainter extends CustomPainter {
  const _PouchFramePainter();

  Path _path(Size size) => const _PouchClipper()._path(size);

  @override
  void paint(Canvas canvas, Size size) {
    final path = _path(size);
    final bg = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Color(0xFF315B49), Color(0xFF24483E), Color(0xFF173833)],
      ).createShader(Offset.zero & size);
    canvas.drawPath(path, bg);

    final glow = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 8 * webUiScale
      ..color = const Color(0x556FD37B)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, 8 * webUiScale);
    canvas.drawPath(path, glow);

    final rim = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.2 * webUiScale
      ..color = const Color(0xCCF7E4A0);
    canvas.drawPath(path, rim);
  }

  @override
  bool shouldRepaint(covariant _PouchFramePainter oldDelegate) => false;
}

class _NeonBackdropPainter extends CustomPainter {
  final bool fever;
  const _NeonBackdropPainter({this.fever = false});

  @override
  void paint(Canvas canvas, Size size) {
    final glow = Paint()..color = fever ? const Color(0x33FF4CCB) : const Color(0x2238C8FF);
    final star = Paint()..color = const Color(0xA8FFFFFF);
    const seeds = <Offset>[
      Offset(.10, .15), Offset(.28, .09), Offset(.46, .18), Offset(.71, .12),
      Offset(.88, .23), Offset(.18, .38), Offset(.57, .34), Offset(.80, .44),
      Offset(.36, .54), Offset(.68, .60), Offset(.13, .68), Offset(.91, .72),
    ];
    for (final s in seeds) {
      final p = Offset(size.width * s.dx, size.height * s.dy);
      canvas.drawCircle(p, 7 * webUiScale, glow);
      canvas.drawCircle(p, 1.4 * webUiScale, star);
      canvas.drawLine(p - Offset(5 * webUiScale, 0), p + Offset(5 * webUiScale, 0), star..strokeWidth = .8 * webUiScale);
      canvas.drawLine(p - Offset(0, 5 * webUiScale), p + Offset(0, 5 * webUiScale), star);
    }
  }

  @override
  bool shouldRepaint(covariant _NeonBackdropPainter oldDelegate) => false;
}

class _TracePainter extends CustomPainter {
  final List<Offset> points;
  final Color color;
  final bool rainbow;
  final Offset? pointer;

  const _TracePainter({
    required this.points,
    required this.color,
    this.rainbow = false,
    this.pointer,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (points.isEmpty) return;

    final path = Path()..moveTo(points.first.dx, points.first.dy);
    for (final point in points.skip(1)) {
      path.lineTo(point.dx, point.dy);
    }
    if (pointer != null && points.isNotEmpty) {
      path.lineTo(pointer!.dx, pointer!.dy);
    }

    final traceShader = rainbow
        ? const LinearGradient(colors: [
            Color(0xFFFF5E7A), Color(0xFFFFD84A), Color(0xFF56E27A),
            Color(0xFF4FC3FF), Color(0xFFB77BFF), Color(0xFFFF5E7A),
          ]).createShader(Offset.zero & size)
        : null;

    final glowPaint = Paint()
      ..color = color.withValues(alpha: .40)
      ..shader = traceShader
      ..strokeWidth = 28 * webUiScale
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..style = PaintingStyle.stroke
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, 10 * webUiScale);
    canvas.drawPath(path, glowPaint);

    final mainPaint = Paint()
      ..color = color.withValues(alpha: .95)
      ..shader = traceShader
      ..strokeWidth = 14 * webUiScale
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..style = PaintingStyle.stroke;
    canvas.drawPath(path, mainPaint);

    final corePaint = Paint()
      ..color = Colors.white.withValues(alpha: .92)
      ..strokeWidth = 4.6 * webUiScale
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..style = PaintingStyle.stroke;
    canvas.drawPath(path, corePaint);

    // Bright nodes make each selected piece in the route unmistakable.
    final nodePaint = Paint()
      ..color = Colors.white.withValues(alpha: .96)
      ..style = PaintingStyle.fill;
    final nodeEdge = Paint()
      ..color = color.withValues(alpha: .98)
      ..shader = traceShader
      ..strokeWidth = 3 * webUiScale
      ..style = PaintingStyle.stroke;
    for (final point in points) {
      canvas.drawCircle(point, 6.5 * webUiScale, nodePaint);
      canvas.drawCircle(point, 6.5 * webUiScale, nodeEdge);
    }
  }

  @override
  bool shouldRepaint(covariant _TracePainter oldDelegate) =>
      oldDelegate.points != points ||
      oldDelegate.color != color ||
      oldDelegate.rainbow != rainbow ||
      oldDelegate.pointer != pointer;
}

class _ArenaFramePainter extends CustomPainter {
  final bool fever;
  const _ArenaFramePainter({required this.fever});

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Rect.fromLTWH(3 * webUiScale, 3 * webUiScale, size.width - 6 * webUiScale, size.height - 6 * webUiScale);
    final rr = RRect.fromRectAndRadius(rect, Radius.circular(58 * webUiScale));
    final bg = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: fever
            ? const [Color(0xFF4A5D3B), Color(0xFF31563D), Color(0xFF16352F)]
            : const [Color(0xFF3E7453), Color(0xFF285A46), Color(0xFF173A35)],
      ).createShader(rect);
    canvas.drawRRect(rr, bg);
    final glow = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 8 * webUiScale
      ..color = fever ? const Color(0x88FFD85A) : const Color(0x557FE071)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, 8 * webUiScale);
    canvas.drawRRect(rr, glow);
    final rim = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.1 * webUiScale
      ..color = fever ? const Color(0xFFFFD85A) : const Color(0xCCF7E4A0);
    canvas.drawRRect(rr, rim);
  }

  @override
  bool shouldRepaint(covariant _ArenaFramePainter oldDelegate) => oldDelegate.fever != fever;
}

class _ComboBadge extends StatelessWidget {
  final int combo;
  const _ComboBadge({required this.combo});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11 * webUiScale, vertical: 6 * webUiScale),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFFFFD54A), Color(0xFFFF7B39)]),
        borderRadius: BorderRadius.circular(16 * webUiScale),
        boxShadow: const [BoxShadow(color: Color(0x88FFB62B), blurRadius: 10, spreadRadius: 1)],
      ),
      child: Text('$combo COMBO!', style: const TextStyle(color: Color(0xFF4A2500), fontSize: 15 * webUiScale, fontWeight: FontWeight.w900)),
    );
  }
}

class _StandaloneSpecialPainter extends CustomPainter {
  final int kind;
  final int level;
  final bool selected;
  const _StandaloneSpecialPainter({required this.kind, required this.level, required this.selected});

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = math.min(size.width, size.height) / 2;

    final shadow = Paint()
      ..color = Colors.black.withValues(alpha: .22)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, r * .12);
    canvas.drawCircle(c + Offset(0, r * .10), r * .70, shadow);

    if (kind == 1) {
      // Cute standalone bomb: dark plum body, golden fuse and tiny sparkle.
      final body = Paint()
        ..shader = RadialGradient(
          center: const Alignment(-.28, -.32),
          colors: level == 1
              ? [Color(0xFF725A82), Color(0xFF392B49), Color(0xFF20182C)]
              : level == 2
                  ? [Color(0xFFFFA34A), Color(0xFFD94B35), Color(0xFF4A2027)]
                  : [Color(0xFFFFF4A3), Color(0xFFFFA51F), Color(0xFF7D2B18)],
        ).createShader(Rect.fromCircle(center: c, radius: r * .74));
      canvas.drawCircle(c + Offset(-r * .04, r * .05), r * .62, body);
      canvas.drawCircle(c + Offset(-r * .24, -r * .23), r * .12,
          Paint()..color = Colors.white.withValues(alpha: .24));
      final fuse = Paint()
        ..color = const Color(0xFFFFD65A)
        ..strokeWidth = r * .11
        ..strokeCap = StrokeCap.round;
      canvas.drawLine(c + Offset(r * .20, -r * .43), c + Offset(r * .43, -r * .66), fuse);
      canvas.drawCircle(c + Offset(r * .49, -r * .71), r * .11,
          Paint()..color = const Color(0xFFFFF19A));
    } else if (kind == 2) {
      // Standalone line item: candy-like cyan capsule with a bright cross beam.
      final rect = RRect.fromRectAndRadius(
        Rect.fromCenter(center: c, width: r * 1.38, height: r * 1.02),
        Radius.circular(r * .42),
      );
      final fill = Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF77F2FF), Color(0xFF349EDB), Color(0xFF5166FF)],
        ).createShader(rect.outerRect);
      canvas.drawRRect(rect, fill);
      final beam = Paint()
        ..color = Colors.white.withValues(alpha: .96)
        ..strokeWidth = r * .12
        ..strokeCap = StrokeCap.round;
      canvas.drawLine(c + Offset(-r * .48, 0), c + Offset(r * .48, 0), beam);
      if (level >= 2) canvas.drawLine(c + Offset(0, -r * .42), c + Offset(0, r * .42), beam);
      if (level >= 3) {
        canvas.drawLine(c + Offset(-r * .34, -r * .34), c + Offset(r * .34, r * .34), beam);
        canvas.drawLine(c + Offset(r * .34, -r * .34), c + Offset(-r * .34, r * .34), beam);
      }
    } else if (kind == 3) {
      // Standalone lightning crystal.
      final orb = Paint()
        ..shader = RadialGradient(
          center: const Alignment(-.25, -.25),
          colors: level == 1
              ? [Color(0xFFFFFFA8), Color(0xFFFFD84A), Color(0xFFFF8A35)]
              : level == 2
                  ? [Color(0xFFFFFFFF), Color(0xFF7FE7FF), Color(0xFF3979FF)]
                  : [Color(0xFFFFFFFF), Color(0xFFC99BFF), Color(0xFF713CDE)],
        ).createShader(Rect.fromCircle(center: c, radius: r * .72));
      canvas.drawCircle(c, r * .67, orb);
      final bolt = Path()
        ..moveTo(c.dx + r * .05, c.dy - r * .49)
        ..lineTo(c.dx - r * .23, c.dy - r * .03)
        ..lineTo(c.dx + r * .02, c.dy - r * .03)
        ..lineTo(c.dx - r * .10, c.dy + r * .52)
        ..lineTo(c.dx + r * .36, c.dy - r * .13)
        ..lineTo(c.dx + r * .10, c.dy - r * .13)
        ..close();
      canvas.drawPath(bolt, Paint()..color = Colors.white);
    }


    if (selected) {
      canvas.drawCircle(
        c,
        r * .78,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = r * .08
          ..color = Colors.white.withValues(alpha: .95),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _StandaloneSpecialPainter oldDelegate) =>
      oldDelegate.kind != kind || oldDelegate.level != level || oldDelegate.selected != selected;
}

class _ImpactText extends StatelessWidget {
  final int kind;
  final int strength;
  const _ImpactText({required this.kind, required this.strength});
  @override Widget build(BuildContext context) {
    final label = strength >= 6 ? 'SURUSURU!!' : (strength >= 4 ? 'REACTION!!' : 'NICE!');
    return IgnorePointer(child: Text(label,
      style: TextStyle(fontSize: (30 + strength * 3) * webUiScale, fontWeight: FontWeight.w900,
        color: Colors.white, shadows: const [Shadow(color: Color(0xFFFF4FD8), blurRadius: 18), Shadow(color: Color(0xFF47D9FF), blurRadius: 28)])));
  }
}

class _ImpactOverlayPainter extends CustomPainter {
  final int kind;
  final int strength;
  const _ImpactOverlayPainter({required this.kind, required this.strength});
  @override void paint(Canvas canvas, Size size) {
    final c=Offset(size.width/2,size.height/2);
    final color = kind==1 ? const Color(0xFFFFD34E) : kind==2 ? const Color(0xFF55E8FF) : kind==3 ? const Color(0xFFFFFF72) : kind==4 ? const Color(0xFFFF64E5) : const Color(0xFF73D8FF);
    final flash=Paint()..color=color.withValues(alpha:.08 + math.min(.18,strength*.025));
    canvas.drawRect(Offset.zero & size, flash);
    final ray=Paint()..color=color.withValues(alpha:.75)..strokeWidth=(2+strength*.55)*webUiScale..strokeCap=StrokeCap.round..maskFilter=MaskFilter.blur(BlurStyle.normal,4*webUiScale);
    final count=10+strength*4;
    for(var i=0;i<count;i++){
      final a=(math.pi*2*i/count)+(kind*.23);
      final inner=24.0*webUiScale;
      final outer=(80+strength*18+(i%3)*12)*webUiScale;
      canvas.drawLine(c+Offset(math.cos(a)*inner,math.sin(a)*inner),c+Offset(math.cos(a)*outer,math.sin(a)*outer),ray);
    }
    final ring=Paint()..style=PaintingStyle.stroke..strokeWidth=(4+strength)*webUiScale..color=Colors.white.withValues(alpha:.75)..maskFilter=MaskFilter.blur(BlurStyle.normal,6*webUiScale);
    canvas.drawCircle(c,(42+strength*12)*webUiScale,ring);
    if(kind==3 || strength>=5){
      final bolt=Paint()..color=Colors.white.withValues(alpha:.9)..strokeWidth=3.5*webUiScale..strokeCap=StrokeCap.round;
      for(var i=0;i<5;i++){
        final x=size.width*(.12+i*.19);
        final path=Path()..moveTo(x,0)..lineTo(x-12*webUiScale,size.height*.30)..lineTo(x+8*webUiScale,size.height*.48)..lineTo(x-5*webUiScale,size.height*.72);
        canvas.drawPath(path,bolt);
      }
    }
    if (kind == 4 && strength >= 9) {
      final rainbowShader = const SweepGradient(colors: [
        Color(0xFFFF4F77), Color(0xFFFFD74A), Color(0xFF51E57A),
        Color(0xFF48C7FF), Color(0xFFB675FF), Color(0xFFFF4F77),
      ]).createShader(Rect.fromCircle(center: c, radius: size.shortestSide * .48));
      for (var i = 0; i < 5; i++) {
        final rr = (55 + i * 34) * webUiScale;
        final rp = Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = (10 - i * 1.2) * webUiScale
          ..shader = rainbowShader
          ..maskFilter = MaskFilter.blur(BlurStyle.normal, (8 + i * 2) * webUiScale);
        canvas.drawCircle(c, rr, rp);
      }
    }
  }
  @override bool shouldRepaint(covariant _ImpactOverlayPainter old)=>old.kind!=kind||old.strength!=strength;
}

class _SurusuruText extends StatelessWidget {
  const _SurusuruText();

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: TweenAnimationBuilder<double>(
        tween: Tween(begin: .35, end: 1.0),
        duration: const Duration(milliseconds: 900),
        curve: Curves.elasticOut,
        builder: (context, value, child) => Transform.scale(
          scale: value,
          child: Opacity(opacity: value.clamp(0.0, 1.0), child: child),
        ),
        child: ShaderMask(
          shaderCallback: (rect) => const LinearGradient(colors: [
            Color(0xFFFF5B78), Color(0xFFFFD84B), Color(0xFF53E27B),
            Color(0xFF50C4FF), Color(0xFFB77AFF), Color(0xFFFF5B78),
          ]).createShader(rect),
          child: Text(
            'SURUSURU!!',
            style: TextStyle(
              color: Colors.white,
              fontSize: 58 * webUiScale,
              fontWeight: FontWeight.w900,
              letterSpacing: 2 * webUiScale,
              shadows: const [
                Shadow(color: Colors.white, blurRadius: 12),
                Shadow(color: Color(0xFFFF5AD9), blurRadius: 32),
                Shadow(color: Color(0xFF42C8FF), blurRadius: 48),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _TreasureChestPainter extends CustomPainter {
  final bool opened;
  const _TreasureChestPainter({required this.opened});

  @override
  void paint(Canvas canvas, Size size) {
    final scale = webUiScale;
    final shadow = Paint()
      ..color = const Color(0x66000000)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, 8 * scale);
    canvas.drawOval(
      Rect.fromCenter(center: Offset(size.width / 2, size.height * .91), width: size.width * .88, height: size.height * .16),
      shadow,
    );

    final gold = Paint()..color = const Color(0xFFFFC738);
    final goldDark = Paint()..color = const Color(0xFFC87513);
    final wood = Paint()..color = const Color(0xFF9C4F22);
    final woodLight = Paint()..color = const Color(0xFFC66A2C);
    final outline = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3 * scale
      ..color = const Color(0xFFFFE27A);

    final bodyTop = size.height * .43;
    final bodyRect = RRect.fromRectAndRadius(
      Rect.fromLTWH(size.width * .07, bodyTop, size.width * .86, size.height * .49),
      Radius.circular(14 * scale),
    );
    canvas.drawRRect(bodyRect, wood);
    canvas.drawRRect(bodyRect, outline);

    if (!opened) {
      final lidRect = Rect.fromLTWH(size.width * .07, size.height * .10, size.width * .86, size.height * .45);
      final lidPath = Path()
        ..moveTo(lidRect.left, lidRect.bottom)
        ..lineTo(lidRect.left, lidRect.top + lidRect.height * .45)
        ..quadraticBezierTo(size.width * .15, lidRect.top, size.width * .31, lidRect.top)
        ..lineTo(size.width * .69, lidRect.top)
        ..quadraticBezierTo(size.width * .85, lidRect.top, lidRect.right, lidRect.top + lidRect.height * .45)
        ..lineTo(lidRect.right, lidRect.bottom)
        ..close();
      canvas.drawPath(lidPath, woodLight);
      canvas.drawPath(lidPath, outline);
    } else {
      final lid = RRect.fromRectAndRadius(
        Rect.fromLTWH(size.width * .07, -size.height * .02, size.width * .86, size.height * .27),
        Radius.circular(18 * scale),
      );
      canvas.drawRRect(lid, woodLight);
      canvas.drawRRect(lid, outline);
      final glow = Paint()
        ..color = const Color(0xAAFFF5A8)
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, 18 * scale);
      canvas.drawOval(Rect.fromLTWH(size.width * .18, size.height * .25, size.width * .64, size.height * .30), glow);
    }

    // Gold bands make the silhouette read immediately as a treasure chest.
    for (final x in [size.width * .18, size.width * .76]) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(x, size.height * .54), width: size.width * .09, height: size.height * .75), Radius.circular(5 * scale)),
        gold,
      );
    }
    canvas.drawRect(Rect.fromLTWH(size.width * .07, size.height * .51, size.width * .86, size.height * .10), gold);

    final lockCenter = Offset(size.width / 2, size.height * .60);
    canvas.drawCircle(lockCenter, size.height * .15, goldDark);
    canvas.drawCircle(lockCenter, size.height * .12, gold);
    final keyhole = Path()
      ..addOval(Rect.fromCircle(center: Offset(lockCenter.dx, lockCenter.dy - size.height * .025), radius: size.height * .035))
      ..addRect(Rect.fromCenter(center: Offset(lockCenter.dx, lockCenter.dy + size.height * .035), width: size.height * .035, height: size.height * .085));
    canvas.drawPath(keyhole, Paint()..color = const Color(0xFF4E2A12));
  }

  @override
  bool shouldRepaint(covariant _TreasureChestPainter oldDelegate) => oldDelegate.opened != opened;
}

class _RainbowCharacterPainter extends CustomPainter {
  final bool selected;
  const _RainbowCharacterPainter({required this.selected});

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = size.shortestSide / 2;
    final rect = Rect.fromCircle(center: c, radius: r * .84);
    final body = Paint()
      ..shader = const SweepGradient(colors: [
        Color(0xFFFF5B78), Color(0xFFFFD84B), Color(0xFF52E37B),
        Color(0xFF4DC5FF), Color(0xFFB87BFF), Color(0xFFFF5B78),
      ]).createShader(rect);
    final glow = Paint()
      ..color = Colors.white.withValues(alpha: .32)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, 8 * webUiScale);
    canvas.drawCircle(c, r * .88, glow);
    canvas.drawCircle(c, r * .80, body);
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(-r * .23, -r * .32), width: r * .48, height: r * .24),
      Paint()..color = Colors.white.withValues(alpha: .46),
    );
    final eye = Paint()..color = const Color(0xFF2D2440);
    canvas.drawCircle(c + Offset(-r * .24, -r * .05), r * .07, eye);
    canvas.drawCircle(c + Offset(r * .24, -r * .05), r * .07, eye);
    final smile = Paint()
      ..color = const Color(0xFF49375A)
      ..style = PaintingStyle.stroke
      ..strokeWidth = r * .055
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(Rect.fromCenter(center: c + Offset(0, r * .12), width: r * .40, height: r * .24), .15, math.pi - .30, false, smile);
    final star = Paint()..color = Colors.white.withValues(alpha: .94);
    for (final o in const [Offset(-.58, -.12), Offset(.55, -.30), Offset(.42, .46)]) {
      canvas.drawCircle(c + Offset(o.dx * r, o.dy * r), r * .045, star);
    }
    if (selected) {
      canvas.drawCircle(c, r * .84, Paint()
        ..color = Colors.white.withValues(alpha: .88)
        ..style = PaintingStyle.stroke
        ..strokeWidth = r * .08);
    }
  }

  @override
  bool shouldRepaint(covariant _RainbowCharacterPainter oldDelegate) => oldDelegate.selected != selected;
}

class _RoundCharacterPainter extends CustomPainter {
  final int type;
  final bool selected;

  const _RoundCharacterPainter({required this.type, required this.selected});

  Paint _gloss(Color light, Color base, Color dark, Offset c, double r) {
    return Paint()
      ..shader = RadialGradient(
        center: const Alignment(-.34, -.42),
        radius: 1.05,
        colors: [light, base, dark],
        stops: const [0, .55, 1],
      ).createShader(Rect.fromCircle(center: c, radius: r));
  }

  void _bodyShine(Canvas canvas, Offset c, double r) {
    final shine = Paint()..color = Colors.white.withValues(alpha: .34);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(-r * .28, -r * .38), width: r * .48, height: r * .25), shine);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = math.min(size.width, size.height) / 2;
    final shadow = Paint()
      ..color = const Color(0x33000000)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3);
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(0, r * .12), width: r * 1.62, height: r * 1.58),
      shadow,
    );

    switch (type) {
      case 0:
        _drawChick(canvas, c, r);
        break;
      case 1:
        _drawFrog(canvas, c, r);
        break;
      case 2:
        _drawPenguin(canvas, c, r);
        break;
      case 3:
        _drawDog(canvas, c, r);
        break;
      default:
        _drawBunny(canvas, c, r);
    }

    if (selected) {
      final shine = Paint()
        ..color = Colors.white.withValues(alpha: .42)
        ..style = PaintingStyle.stroke
        ..strokeWidth = math.max(2, r * .08);
      canvas.drawCircle(c, r * .82, shine);
    }
  }

  void _eyes(Canvas canvas, Offset c, double r, {double y = -.10}) {
    final p = Paint()..color = const Color(0xFF252525);
    canvas.drawCircle(c + Offset(-r * .25, r * y), r * .075, p);
    canvas.drawCircle(c + Offset(r * .25, r * y), r * .075, p);
    final hi = Paint()..color = Colors.white.withValues(alpha: .9);
    canvas.drawCircle(c + Offset(-r * .225, r * (y - .025)), r * .018, hi);
    canvas.drawCircle(c + Offset(r * .275, r * (y - .025)), r * .018, hi);
  }

  void _blush(Canvas canvas, Offset c, double r) {
    final p = Paint()..color = const Color(0x55F38E9E);
    canvas.drawCircle(c + Offset(-r * .48, r * .13), r * .11, p);
    canvas.drawCircle(c + Offset(r * .48, r * .13), r * .11, p);
  }

  void _drawChick(Canvas canvas, Offset c, double r) {
    final body = _gloss(const Color(0xFFFFF08A), const Color(0xFFFFC928), const Color(0xFFE79A00), c, r);
    canvas.drawCircle(c, r * .82, body);
    _bodyShine(canvas, c, r);
    final wing = Paint()..color = const Color(0xFFFFB51E);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(-r * .66, r * .12), width: r * .28, height: r * .48), wing);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(r * .66, r * .12), width: r * .28, height: r * .48), wing);
    _eyes(canvas, c, r);
    _blush(canvas, c, r);
    final beak = Path()
      ..moveTo(c.dx - r * .10, c.dy + r * .08)
      ..lineTo(c.dx + r * .12, c.dy + r * .08)
      ..lineTo(c.dx, c.dy + r * .20)
      ..close();
    canvas.drawPath(beak, Paint()..color = const Color(0xFFF18A18));
  }

  void _drawFrog(Canvas canvas, Offset c, double r) {
    final body = _gloss(const Color(0xFFA6F3A9), const Color(0xFF63D46B), const Color(0xFF2C9A42), c, r);
    final deep = Paint()..color = const Color(0xFF25873A);
    canvas.drawCircle(c, r * .82, body);
    _bodyShine(canvas, c, r);
    canvas.drawCircle(c + Offset(-r * .42, -r * .55), r * .25, body);
    canvas.drawCircle(c + Offset(r * .42, -r * .55), r * .25, body);
    canvas.drawCircle(c + Offset(-r * .42, -r * .55), r * .11, Paint()..color = Colors.white);
    canvas.drawCircle(c + Offset(r * .42, -r * .55), r * .11, Paint()..color = Colors.white);
    canvas.drawCircle(c + Offset(-r * .42, -r * .55), r * .055, Paint()..color = const Color(0xFF1E2A25));
    canvas.drawCircle(c + Offset(r * .42, -r * .55), r * .055, Paint()..color = const Color(0xFF1E2A25));
    _blush(canvas, c, r);
    final smile = Paint()
      ..color = deep.color
      ..style = PaintingStyle.stroke
      ..strokeWidth = math.max(1.8, r * .07)
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(
      Rect.fromCenter(center: c + Offset(0, r * .12), width: r * .60, height: r * .36),
      .15,
      math.pi - .30,
      false,
      smile,
    );
  }

  void _drawPenguin(Canvas canvas, Offset c, double r) {
    // V16.20.5: changed from black/white to saturated blue so it can never
    // be confused with the panda in a crowded pile.
    final blue = _gloss(const Color(0xFF9DE1FF), const Color(0xFF4F9ED8), const Color(0xFF2464A8), c, r);
    final deepBlue = Paint()..color = const Color(0xFF2E6F9F);
    final belly = Paint()..color = const Color(0xFFEAF6FF);
    canvas.drawCircle(c, r * .82, blue);
    _bodyShine(canvas, c, r);
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(0, r * .19), width: r * 1.00, height: r * 1.10),
      belly,
    );
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(-r * .62, r * .08), width: r * .22, height: r * .56),
      deepBlue,
    );
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(r * .62, r * .08), width: r * .22, height: r * .56),
      deepBlue,
    );
    _eyes(canvas, c + Offset(0, -r * .10), r, y: 0);
    final beak = Path()
      ..moveTo(c.dx - r * .10, c.dy + r * .01)
      ..lineTo(c.dx + r * .10, c.dy + r * .01)
      ..lineTo(c.dx, c.dy + r * .15)
      ..close();
    canvas.drawPath(beak, Paint()..color = const Color(0xFFFF9B2F));
  }

  void _drawDog(Canvas canvas, Offset c, double r) {
    final ear = Paint()..color = const Color(0xFF7453B7);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(-r * .62, -r * .18), width: r * .42, height: r * .72), ear);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(r * .62, -r * .18), width: r * .42, height: r * .72), ear);
    canvas.drawCircle(c, r * .82, _gloss(const Color(0xFFE4D7FF), const Color(0xFFBFA8F2), const Color(0xFF8060C7), c, r));
    _bodyShine(canvas, c, r);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(r * .26, -r * .18), width: r * .36, height: r * .46), ear);
    _eyes(canvas, c, r);
    _blush(canvas, c, r);
    canvas.drawCircle(c + Offset(0, r * .16), r * .09, Paint()..color = const Color(0xFF3E315A));
  }

  void _drawBunny(Canvas canvas, Offset c, double r) {
    final body = _gloss(const Color(0xFFFFE2EE), const Color(0xFFFFA7C7), const Color(0xFFE66B9B), c, r);
    final inner = Paint()..color = const Color(0xFFFF6F9F);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(-r * .28, -r * .86), width: r * .32, height: r * .88), body);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(r * .28, -r * .86), width: r * .32, height: r * .88), body);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(-r * .28, -r * .86), width: r * .11, height: r * .55), inner);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(r * .28, -r * .86), width: r * .11, height: r * .55), inner);
    canvas.drawCircle(c + Offset(0, r * .04), r * .76, body);
    _bodyShine(canvas, c + Offset(0, r * .04), r * .92);
    _eyes(canvas, c + Offset(0, r * .02), r);
    _blush(canvas, c, r);
    canvas.drawCircle(c + Offset(0, r * .16), r * .06, Paint()..color = const Color(0xFF8C3F61));
  }

  @override
  bool shouldRepaint(covariant _RoundCharacterPainter oldDelegate) =>
      oldDelegate.type != type || oldDelegate.selected != selected;
}
