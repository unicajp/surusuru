import 'package:flutter/material.dart';

import '../web_ui_scale.dart';

class MergeItem extends StatelessWidget {
  final int level;
  final bool dragging;
  final bool emphasized;

  const MergeItem({
    super.key,
    required this.level,
    this.dragging = false,
    this.emphasized = false,
  });

  // V16.18.4 slide-chain prototype: five standalone piece types.
  // There are no merge levels in this ruleset.
  static const Map<int, String> icons = {
    1: '🍓',
    2: '🥛',
    3: '🍪',
    4: '🍋',
    5: '🍇',
  };

  static Color seriesColor(int level) {
    switch (level) {
      case 1: return const Color(0xFFE97CA7);
      case 2: return const Color(0xFF64AEE8);
      case 3: return const Color(0xFFE3A93F);
      case 4: return const Color(0xFF65B985);
      case 5: return const Color(0xFF9A79D1);
      default: return const Color(0xFF8FA2AC);
    }
  }

  static Color seriesSoftColor(int level) {
    switch (level) {
      case 1: return const Color(0xFFFFE8F1);
      case 2: return const Color(0xFFE6F3FF);
      case 3: return const Color(0xFFFFF3D2);
      case 4: return const Color(0xFFE7F7EC);
      case 5: return const Color(0xFFF0E8FF);
      default: return const Color(0xFFF0F2F3);
    }
  }

  static int tier(int level) => 1;

  @override
  Widget build(BuildContext context) {
    Widget item({double scale = 1.0}) {
      return Transform.scale(
        scale: scale,
        child: Container(
          alignment: Alignment.center,
          padding: const EdgeInsets.all(3 * webUiScale),
          decoration: BoxDecoration(
            color: seriesSoftColor(level).withValues(alpha: .72),
            borderRadius: BorderRadius.circular(11 * webUiScale),
            border: Border.all(
              color: seriesColor(level),
              width: emphasized ? 2.2 * webUiScale : 1.35 * webUiScale,
            ),
            boxShadow: [
              BoxShadow(
                color: seriesColor(level).withValues(alpha: emphasized ? .34 : .15),
                blurRadius: emphasized ? 9 * webUiScale : 4 * webUiScale,
                spreadRadius: emphasized ? 1 : 0,
              ),
            ],
          ),
          child: FittedBox(
            fit: BoxFit.contain,
            child: Text(
              icons[level] ?? '⭐',
              style: const TextStyle(
                fontSize: 104 * webUiScale,
                height: 1,
                // Keep board pieces visually dominant even in the compact Web UI.
                shadows: [
                  Shadow(color: Color(0x24000000), blurRadius: 2, offset: Offset(0, 1)),
                ],
              ),
            ),
          ),
        ),
      );
    }

    if (dragging) {
      return AnimatedScale(
        scale: 1.14,
        duration: const Duration(milliseconds: 100),
        curve: Curves.easeOutBack,
        child: item(),
      );
    }

    if (!emphasized) {
      return item();
    }

    // Fresh merge effect: soft pop + tiny hearts / flowers / sparkles.
    // Kept lightweight so it can run on every merge without blocking input.
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0, end: 1),
      duration: const Duration(milliseconds: 680),
      curve: Curves.easeOutCubic,
      builder: (context, t, child) {
        final pop = t < 0.42
            ? 0.78 + (t / 0.42) * 0.40
            : 1.18 - ((t - 0.42) / 0.58) * 0.18;
        final fade = (1 - t).clamp(0.0, 1.0).toDouble();
        final travel = 8 + (27 * t);

        Widget particle(
          String text,
          double dx,
          double dy, {
          double rotate = 0,
          double size = 17,
        }) {
          return Opacity(
            opacity: fade,
            child: Transform.translate(
              offset: Offset(dx * travel, dy * travel),
              child: Transform.rotate(
                angle: rotate * t,
                child: Text(text, style: TextStyle(fontSize: size)),
              ),
            ),
          );
        }

        return Stack(
          clipBehavior: Clip.none,
          alignment: Alignment.center,
          children: [
            // A pale pink halo gives the merge a soft "puff" rather than a flash.
            Opacity(
              opacity: fade * 0.72,
              child: Transform.scale(
                scale: 0.72 + (t * 0.85),
                child: Container(
                  width: 68 * webUiScale,
                  height: 68 * webUiScale,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0xFFFFDCE8),
                    border: Border.all(
                      color: const Color(0xFFFFB8D0),
                      width: 1.2,
                    ),
                  ),
                ),
              ),
            ),
            particle('♡', -1.0, -0.75, rotate: -0.35, size: 20 * webUiScale),
            particle('✦', 0.92, -0.72, rotate: 0.55, size: 19 * webUiScale),
            particle('✿', -0.92, 0.58, rotate: -0.45, size: 18 * webUiScale),
            particle('♡', 0.95, 0.62, rotate: 0.35, size: 19 * webUiScale),
            particle('✧', 0.10, -1.12, rotate: 0.25, size: 17 * webUiScale),
            particle('·', -1.18, -0.05, size: 24 * webUiScale),
            item(scale: pop),
          ],
        );
      },
    );
  }
}
