import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../game/game_controller.dart';
import '../sfx_manager.dart';
import '../screens/home_room_screen.dart';
import '../screens/game_screen.dart';
import '../screens/daily_reward_screen.dart';
import '../screens/mission_screen.dart';
import '../screens/collection_screen.dart';

class AppBottomNav extends StatelessWidget {
  final GameController controller;
  final String active;

  const AppBottomNav({
    super.key,
    required this.controller,
    this.active = '',
  });

  void _replace(BuildContext context, Widget page) {
    SfxManager.instance.tap();
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => page),
    );
  }

  Future<void> _settings(BuildContext context) async {
    SfxManager.instance.tap();
    bool requestReset = false;

    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) {
          return AlertDialog(
            title: const Text(
              '⚙️ 設定',
              style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900),
            ),
            content: SizedBox(
              width: 420,
              child: AnimatedBuilder(
                animation: SfxManager.instance,
                builder: (context, _) => Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      '効果音  ${SfxManager.instance.volumePercent.round()}%',
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    Slider(
                      min: 0,
                      max: 300,
                      divisions: 30,
                      value: SfxManager.instance.volumePercent,
                      onChanged: (value) {
                        SfxManager.instance.setVolumePercent(value);
                        setDialogState(() {});
                      },
                      onChangeEnd: (_) => SfxManager.instance.tap(),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'BGM  ${SfxManager.instance.bgmPercent.round()}%',
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
                    ),
                    Slider(
                      min: 0,
                      max: 100,
                      divisions: 20,
                      value: SfxManager.instance.bgmPercent,
                      onChanged: (value) {
                        SfxManager.instance.setBgmPercent(value);
                        setDialogState(() {});
                      },
                    ),
                    SizedBox(
                      height: 52,
                      child: FilledButton.icon(
                        onPressed: () => SfxManager.instance.test(),
                        icon: const Icon(Icons.volume_up_rounded),
                        label: const Text(
                          '効果音をテスト',
                          style: TextStyle(fontWeight: FontWeight.w900),
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                    const Divider(),
                    const SizedBox(height: 8),
                    FilledButton.tonal(
                      onPressed: () {
                        requestReset = true;
                        Navigator.pop(dialogContext);
                      },
                      child: const Text(
                        'プレイデータを完全初期化',
                        style: TextStyle(fontWeight: FontWeight.w900),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            actions: [
              FilledButton(
                onPressed: () {
                  SfxManager.instance.tap();
                  Navigator.pop(dialogContext);
                },
                child: const Text('閉じる'),
              ),
            ],
          );
        },
      ),
    );

    if (!requestReset || !context.mounted) return;

    final reset = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text(
          '本当に初期化しますか？',
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
        content: const Text('Lv.1から最初の状態に戻します。'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('キャンセル'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('完全初期化'),
          ),
        ],
      ),
    );

    if (reset != true || !context.mounted) return;
    await controller.resetAllProgress();
    if (!context.mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('プレイデータを初期化しました。')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final barHeight = kIsWeb ? 58.0 : 76.0;
    final iconSize = kIsWeb ? 22.0 : 28.0;
    final labelSize = kIsWeb ? 10.0 : 12.5;

    Widget item({
      required IconData icon,
      required String label,
      required String keyName,
      required VoidCallback onTap,
      bool center = false,
      bool attention = false,
    }) {
      final selected = active == keyName;
      return Expanded(
        child: InkWell(
          onTap: selected ? null : onTap,
          child: SizedBox(
            height: barHeight,
            child: Stack(
              alignment: Alignment.center,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: center ? (kIsWeb ? 46 : 56) : null,
                      height: center ? (kIsWeb ? 46 : 56) : null,
                      alignment: Alignment.center,
                      decoration: center
                          ? const BoxDecoration(
                              color: Color(0xFF36B5C3),
                              shape: BoxShape.circle,
                            )
                          : null,
                      child: Icon(
                        icon,
                        size: center ? iconSize * 1.35 : iconSize,
                        color: center
                            ? Colors.white
                            : selected
                                ? const Color(0xFF2C9DAA)
                                : const Color(0xFF41636B),
                      ),
                    ),
                    SizedBox(height: center ? 0 : 2),
                    Text(
                      label,
                      style: TextStyle(
                        fontSize: center ? labelSize * 1.08 : labelSize,
                        fontWeight: FontWeight.w900,
                        color: const Color(0xFF41636B),
                      ),
                    ),
                  ],
                ),
                if (attention)
                  Positioned(
                    top: kIsWeb ? 6 : 8,
                    right: kIsWeb ? 13 : 17,
                    child: Container(
                      width: kIsWeb ? 8 : 10,
                      height: kIsWeb ? 8 : 10,
                      decoration: const BoxDecoration(
                        color: Color(0xFFE96D72),
                        shape: BoxShape.circle,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      );
    }

    return SafeArea(
      top: false,
      child: Material(
        color: const Color(0xFFFDFEFE),
        elevation: 12,
        child: Row(
          children: [
            item(
              icon: Icons.card_giftcard_rounded,
              label: 'デイリー',
              keyName: 'daily',
              onTap: () => _replace(
                context,
                DailyRewardScreen(controller: controller),
              ),
            ),
            item(
              icon: Icons.assignment_rounded,
              label: 'ミッション',
              keyName: 'mission',
              attention: controller.hasClaimableMission,
              onTap: () => _replace(
                context,
                MissionScreen(controller: controller),
              ),
            ),
            item(
              icon: Icons.home_rounded,
              label: '部屋',
              keyName: 'home',
              center: true,
              onTap: () => _replace(
                context,
                HomeRoomScreen(controller: controller),
              ),
            ),
            item(
              icon: Icons.menu_book_rounded,
              label: '図鑑',
              keyName: 'collection',
              onTap: () => _replace(
                context,
                CollectionScreen(controller: controller),
              ),
            ),
            item(
              icon: Icons.auto_awesome_rounded,
              label: 'パズル',
              keyName: 'puzzle',
              onTap: () => _replace(
                context,
                GameScreen(controller: controller),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
