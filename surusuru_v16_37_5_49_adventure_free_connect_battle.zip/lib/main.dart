import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import 'screens/title_screen.dart';
import 'sfx_manager.dart';
import 'web_ui_scale.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SfxManager.instance.load();
  runApp(const YuruMergeWorldApp());
}

class YuruMergeWorldApp extends StatelessWidget {
  const YuruMergeWorldApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Web compacts every UI component itself; the viewport remains full-size.
    // Native keeps the existing app appearance.
    final ui = webUiScale;
    final textScale = kIsWeb ? 1.0 : 1.24;

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'surusuru',
      theme: ThemeData(
        useMaterial3: true,
        visualDensity: kIsWeb ? const VisualDensity(horizontal: -2, vertical: -2) : VisualDensity.standard,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFC7778E)),
        appBarTheme: AppBarTheme(
          toolbarHeight: 92 * ui,
          titleTextStyle: TextStyle(fontSize: 36 * ui, fontWeight: FontWeight.w900, color: const Color(0xFF674F49)),
          iconTheme: IconThemeData(size: 46 * ui, color: const Color(0xFF674F49)),
        ),
        iconButtonTheme: IconButtonThemeData(
          style: ButtonStyle(
            minimumSize: WidgetStatePropertyAll(Size(72 * ui, 72 * ui)),
            iconSize: WidgetStatePropertyAll(44 * ui),
          ),
        ),
        filledButtonTheme: FilledButtonThemeData(
          style: ButtonStyle(minimumSize: WidgetStatePropertyAll(Size(108 * ui, 76 * ui))),
        ),
        textButtonTheme: TextButtonThemeData(
          style: ButtonStyle(minimumSize: WidgetStatePropertyAll(Size(90 * ui, 68 * ui))),
        ),
      ),
      builder: (context, child) {
        final mq = MediaQuery.of(context);
        return MediaQuery(
          data: mq.copyWith(textScaler: TextScaler.linear(textScale)),
          child: child!,
        );
      },
      home: const TitleScreen(),
    );
  }
}
