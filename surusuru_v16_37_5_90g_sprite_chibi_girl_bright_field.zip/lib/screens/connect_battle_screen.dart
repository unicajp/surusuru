import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../game/game_controller.dart';

class ConnectBattleScreen extends StatefulWidget {
  final GameController controller;
  final int stageId;

  const ConnectBattleScreen({
    super.key,
    required this.controller,
    required this.stageId,
  });

  @override
  State<ConnectBattleScreen> createState() => _ConnectBattleScreenState();
}

class _DummyEnemy {
  _DummyEnemy(this.pos, this.phase);
  Offset pos;
  final double phase;
}

class _ConnectBattleScreenState extends State<ConnectBattleScreen> {
  Timer? _timer;
  DateTime _last = DateTime.now();
  Size _field = Size.zero;

  Offset _hero = const Offset(190, 360);
  Offset _velocity = Offset.zero;
  Offset _target = const Offset(190, 360);
  bool _holding = false;
  double _time = 0;
  double _tilt = 0;
  final List<_DummyEnemy> _enemies = <_DummyEnemy>[];

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(milliseconds: 16), (_) => _tick());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _seed(Size size) {
    if (_field != Size.zero) return;
    _field = size;
    _hero = Offset(size.width * .50, size.height * .74);
    _target = _hero;
    _enemies.addAll(<_DummyEnemy>[
      _DummyEnemy(Offset(size.width * .22, size.height * .29), .2),
      _DummyEnemy(Offset(size.width * .50, size.height * .20), 1.5),
      _DummyEnemy(Offset(size.width * .78, size.height * .31), 2.8),
    ]);
  }

  void _tick() {
    if (!mounted || _field == Size.zero) return;
    final now = DateTime.now();
    double dt = now.difference(_last).inMicroseconds / 1000000;
    _last = now;
    dt = dt.clamp(0.0, .035);
    _time += dt;

    final delta = _target - _hero;
    final spring = _holding ? 28.0 : 12.0;
    final damping = _holding ? 8.2 : 6.8;
    _velocity += delta * spring * dt;
    _velocity *= math.exp(-damping * dt);

    final speed = _velocity.distance;
    if (speed > 1050) _velocity = _velocity / speed * 1050;
    _hero += _velocity * dt;
    _hero = Offset(
      _hero.dx.clamp(44.0, _field.width - 44.0),
      _hero.dy.clamp(58.0, _field.height - 52.0),
    );

    final wantedTilt = (_velocity.dx / 650).clamp(-.15, .15);
    _tilt += (wantedTilt - _tilt) * math.min(1, dt * 10);
    setState(() {});
  }

  void _down(Offset p) {
    setState(() {
      _holding = true;
      _target = p;
    });
  }

  void _move(Offset p) {
    _holding = true;
    _target = p;
  }

  void _up() {
    _holding = false;
    _target = _hero;
  }

  String get _heroFacing {
    if (_velocity.dx > 75) return 'right';
    if (_velocity.dx < -75) return 'left';
    return 'back';
  }

  int get _walkFrame {
    if (_velocity.distance < 65) return 0;
    return ((_time * 7).floor() & 1);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF142536),
      body: SafeArea(
        child: Column(
          children: <Widget>[
            SizedBox(
              height: 64,
              child: Row(
                children: <Widget>[
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    '冒険  STAGE ${widget.stageId}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const Spacer(),
                  const Padding(
                    padding: EdgeInsets.only(right: 18),
                    child: Text(
                      '操作テスト',
                      style: TextStyle(
                        color: Color(0xFFFFD978),
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: LayoutBuilder(
                builder: (context, c) {
                  final size = Size(c.maxWidth, c.maxHeight);
                  _seed(size);
                  return Listener(
                    behavior: HitTestBehavior.opaque,
                    onPointerDown: (e) => _down(e.localPosition),
                    onPointerMove: (e) => _move(e.localPosition),
                    onPointerUp: (_) => _up(),
                    onPointerCancel: (_) => _up(),
                    child: Stack(
                      fit: StackFit.expand,
                      children: <Widget>[
                        const CustomPaint(painter: _BrightFieldPainter()),
                        ..._buildEnemies(),
                        if (_holding)
                          Positioned(
                            left: _target.dx - 14,
                            top: _target.dy - 14,
                            child: IgnorePointer(
                              child: Container(
                                width: 28,
                                height: 28,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: Colors.white.withValues(alpha: .28),
                                    width: 2,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        _buildHero(),
                      ],
                    ),
                  );
                },
              ),
            ),
            Container(
              height: 58,
              alignment: Alignment.center,
              color: const Color(0xFF0D1C28),
              child: const Text(
                '指で動かして、ちび剣士の追従感を確認',
                style: TextStyle(
                  color: Colors.white70,
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildEnemies() {
    return _enemies.map((e) {
      final bounce = math.sin(_time * 2.4 + e.phase) * 3;
      final frame = (((_time * 3 + e.phase).floor()) & 1);
      const w = 64.0;
      const h = 64.0;
      return Positioned(
        left: e.pos.dx - w / 2,
        top: e.pos.dy - h / 2 + bounce,
        child: IgnorePointer(
          child: Image.asset(
            'assets/sprites/enemy_forest_$frame.png',
            width: w,
            height: h,
            fit: BoxFit.contain,
            filterQuality: FilterQuality.none,
          ),
        ),
      );
    }).toList();
  }

  Widget _buildHero() {
    const w = 92.0;
    const h = 110.0;
    final speedRatio = (_velocity.distance / 430).clamp(0.0, 1.0);
    final bob = _velocity.distance < 65
        ? math.sin(_time * 2.2) * 1.0
        : math.sin(_time * 13) * 2.0 * speedRatio;

    return Positioned(
      left: _hero.dx - w / 2,
      top: _hero.dy - h * .66 + bob,
      child: IgnorePointer(
        child: Transform.rotate(
          angle: _tilt,
          alignment: Alignment.bottomCenter,
          child: Image.asset(
            'assets/sprites/hero_${_heroFacing}_$_walkFrame.png',
            width: w,
            height: h,
            fit: BoxFit.contain,
            filterQuality: FilterQuality.none,
          ),
        ),
      ),
    );
  }
}

class _BrightFieldPainter extends CustomPainter {
  const _BrightFieldPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final shader = const LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: <Color>[
        Color(0xFFDDEEC8),
        Color(0xFFCBE3AF),
        Color(0xFFBBD89D),
      ],
    ).createShader(rect);
    canvas.drawRect(rect, Paint()..shader = shader);

    // A soft earth path gives a JRPG-field feeling without puzzle-board rings.
    final path = Path()
      ..moveTo(size.width * .37, size.height)
      ..cubicTo(
        size.width * .33,
        size.height * .72,
        size.width * .58,
        size.height * .57,
        size.width * .54,
        size.height * .35,
      )
      ..cubicTo(
        size.width * .50,
        size.height * .18,
        size.width * .45,
        size.height * .10,
        size.width * .48,
        0,
      )
      ..lineTo(size.width * .67, 0)
      ..cubicTo(
        size.width * .66,
        size.height * .16,
        size.width * .70,
        size.height * .28,
        size.width * .66,
        size.height * .42,
      )
      ..cubicTo(
        size.width * .61,
        size.height * .63,
        size.width * .45,
        size.height * .75,
        size.width * .55,
        size.height,
      )
      ..close();
    canvas.drawPath(
      path,
      Paint()..color = const Color(0xFFE8D7A7).withValues(alpha: .42),
    );

    void patch(double x, double y, double rx, double ry, Color color) {
      canvas.drawOval(
        Rect.fromCenter(center: Offset(x, y), width: rx, height: ry),
        Paint()..color = color,
      );
    }

    final softGreen = const Color(0xFF8FBE75).withValues(alpha: .24);
    patch(size.width * .12, size.height * .18, 92, 46, softGreen);
    patch(size.width * .86, size.height * .24, 104, 52, softGreen);
    patch(size.width * .18, size.height * .58, 120, 58, softGreen);
    patch(size.width * .80, size.height * .70, 110, 56, softGreen);

    // Tiny flowers and stones are deliberately sparse so combat stays readable.
    final flower = Paint()..color = const Color(0xFFFFF7E9).withValues(alpha: .92);
    final center = Paint()..color = const Color(0xFFE8B85E).withValues(alpha: .92);
    final stone = Paint()..color = const Color(0xFF9BAF8C).withValues(alpha: .32);
    const points = <Offset>[
      Offset(.10, .39),
      Offset(.16, .76),
      Offset(.83, .46),
      Offset(.89, .80),
      Offset(.29, .15),
      Offset(.73, .12),
    ];
    for (var i = 0; i < points.length; i++) {
      final p = Offset(points[i].dx * size.width, points[i].dy * size.height);
      if (i.isEven) {
        canvas.drawCircle(p + const Offset(-3, 0), 2.4, flower);
        canvas.drawCircle(p + const Offset(3, 0), 2.4, flower);
        canvas.drawCircle(p + const Offset(0, -3), 2.4, flower);
        canvas.drawCircle(p, 1.5, center);
      } else {
        canvas.drawOval(
          Rect.fromCenter(center: p, width: 16, height: 8),
          stone,
        );
      }
    }

    // Gentle vignette only at the very edge; no dark arena mood.
    final vignette = RadialGradient(
      colors: <Color>[
        Colors.transparent,
        const Color(0xFF6E8F63).withValues(alpha: .08),
      ],
      stops: const <double>[.70, 1.0],
    ).createShader(rect);
    canvas.drawRect(rect, Paint()..shader = vignette);
  }

  @override
  bool shouldRepaint(covariant _BrightFieldPainter oldDelegate) => false;
}
