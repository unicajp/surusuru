import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../game/game_controller.dart';

class ConnectBattleScreen extends StatefulWidget {
  final GameController controller;
  final int stageId;

  const ConnectBattleScreen({
    super.key,
    required this.controller,
    required this.stageId,
  });

  @override
  State<ConnectBattleScreen> createState() => _ConnectBattleScreenState();
}

class _Enemy {
  _Enemy({required this.x, required this.y, required this.phase});
  double x;
  double y;
  final double phase;
}

class _ConnectBattleScreenState extends State<ConnectBattleScreen> {
  Timer? _timer;
  DateTime _last = DateTime.now();
  Size _field = Size.zero;

  Offset _hero = const Offset(160, 420);
  Offset _target = const Offset(160, 420);
  Offset _velocity = Offset.zero;
  Offset _downPoint = Offset.zero;
  bool _holding = false;
  bool _attack = false;
  double _attackTime = 0;
  double _time = 0;
  double _scroll = 0;
  double _tilt = 0;
  bool _faceRight = true;

  final List<_Enemy> _enemies = <_Enemy>[];

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(milliseconds: 16), (_) => _tick());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _seed(Size size) {
    if (_field != Size.zero) return;
    _field = size;
    _hero = Offset(size.width * .36, size.height * .70);
    _target = _hero;
    _enemies.addAll(<_Enemy>[
      _Enemy(x: size.width * .82, y: size.height * .70, phase: .3),
      _Enemy(x: size.width * 1.22, y: size.height * .66, phase: 1.5),
      _Enemy(x: size.width * 1.58, y: size.height * .72, phase: 2.8),
    ]);
  }

  void _tick() {
    if (!mounted || _field == Size.zero) return;
    final now = DateTime.now();
    double dt = now.difference(_last).inMicroseconds / 1000000;
    _last = now;
    dt = dt.clamp(0.0, .035);
    _time += dt;

    if (_attack) {
      _attackTime += dt;
      if (_attackTime >= .54) {
        _attack = false;
        _attackTime = 0;
      }
    }

    final delta = _target - _hero;
    final spring = _holding ? 30.0 : 12.0;
    final damping = _holding ? 8.0 : 7.2;
    _velocity += delta * spring * dt;
    _velocity *= math.exp(-damping * dt);

    final speed = _velocity.distance;
    if (speed > 980) _velocity = _velocity / speed * 980;
    _hero += _velocity * dt;

    final minY = _field.height * .57;
    final maxY = _field.height * .80;
    _hero = Offset(
      _hero.dx.clamp(58.0, _field.width - 58.0),
      _hero.dy.clamp(minY, maxY),
    );

    if (_velocity.dx.abs() > 45) _faceRight = _velocity.dx >= 0;

    // The hero stays in the portrait play area while the world moves sideways.
    final forward = math.max(0.0, _velocity.dx);
    _scroll += (forward * .58 + (_holding ? 12 : 0)) * dt;
    for (final enemy in _enemies) {
      enemy.x -= (forward * .34 + 18) * dt;
      if (enemy.x < -80) {
        enemy.x = _field.width + 220 + math.Random().nextDouble() * 260;
        enemy.y = _field.height * (.64 + math.Random().nextDouble() * .10);
      }
    }

    final wantedTilt = (_velocity.dx / 850).clamp(-.09, .09);
    _tilt += (wantedTilt - _tilt) * math.min(1, dt * 10);
    setState(() {});
  }

  void _down(Offset p) {
    _holding = true;
    _downPoint = p;
    _target = Offset(p.dx, p.dy.clamp(_field.height * .57, _field.height * .80));
  }

  void _move(Offset p) {
    _holding = true;
    _target = Offset(p.dx, p.dy.clamp(_field.height * .57, _field.height * .80));
  }

  void _up(Offset p) {
    final tap = (p - _downPoint).distance < 18;
    _holding = false;
    _target = _hero;
    if (tap) {
      _attack = true;
      _attackTime = 0;
    }
  }

  int get _idleFrame => ((_time * 2.2).floor() % 2) + 1;
  int get _runFrame => ((_time * 9.0).floor() % 5) + 1;
  int get _attackFrame => (((_attackTime / .54) * 6).floor().clamp(0, 5) as int) + 1;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF10233A),
      body: SafeArea(
        child: Column(
          children: <Widget>[
            SizedBox(
              height: 58,
              child: Row(
                children: <Widget>[
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                  ),
                  Text(
                    '冒険  STAGE ${widget.stageId}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 19,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const Spacer(),
                  const Padding(
                    padding: EdgeInsets.only(right: 14),
                    child: Text(
                      '横スクロール試作',
                      style: TextStyle(
                        color: Color(0xFFFFD978),
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: LayoutBuilder(
                builder: (context, c) {
                  final size = Size(c.maxWidth, c.maxHeight);
                  _seed(size);
                  return Listener(
                    behavior: HitTestBehavior.opaque,
                    onPointerDown: (e) => _down(e.localPosition),
                    onPointerMove: (e) => _move(e.localPosition),
                    onPointerUp: (e) => _up(e.localPosition),
                    onPointerCancel: (_) {
                      _holding = false;
                      _target = _hero;
                    },
                    child: Stack(
                      fit: StackFit.expand,
                      children: <Widget>[
                        CustomPaint(
                          painter: _SideScrollFieldPainter(scroll: _scroll),
                        ),
                        ..._buildEnemies(),
                        _buildHero(),
                        Positioned(
                          left: 14,
                          top: 14,
                          child: _hintChip('ドラッグ：移動  /  タップ：斬撃'),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
            Container(
              height: 50,
              alignment: Alignment.center,
              color: const Color(0xFF0D1C28),
              child: const Text(
                '縦画面のまま、背景と敵が横へ流れるアクション試作',
                style: TextStyle(
                  color: Colors.white70,
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _hintChip(String text) {
    return IgnorePointer(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
        decoration: BoxDecoration(
          color: const Color(0xFF17314A).withValues(alpha: .76),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Colors.white.withValues(alpha: .20)),
        ),
        child: Text(
          text,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 11,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
    );
  }

  List<Widget> _buildEnemies() {
    return _enemies.map((e) {
      final bounce = math.sin(_time * 3 + e.phase) * 3;
      final frame = (((_time * 3 + e.phase).floor()) & 1);
      const s = 66.0;
      return Positioned(
        left: e.x - s / 2,
        top: e.y - s + bounce,
        child: IgnorePointer(
          child: Image.asset(
            'assets/sprites/enemy_forest_$frame.png',
            width: s,
            height: s,
            fit: BoxFit.contain,
            filterQuality: FilterQuality.medium,
          ),
        ),
      );
    }).toList();
  }

  Widget _buildHero() {
    final speed = _velocity.distance;
    final moving = !_attack && speed > 55;
    final path = _attack
        ? 'assets/sprites/hero_swordswoman/attack_${_attackFrame.toString().padLeft(2, '0')}.png'
        : moving
            ? 'assets/sprites/hero_swordswoman/run_${_runFrame.toString().padLeft(2, '0')}.png'
            : 'assets/sprites/hero_swordswoman/idle_${_idleFrame.toString().padLeft(2, '0')}.png';

    final bob = moving ? math.sin(_time * 13) * 2.2 : math.sin(_time * 2.5) * .8;
    const boxW = 190.0;
    const boxH = 142.5;

    Widget sprite = Image.asset(
      path,
      width: boxW,
      height: boxH,
      fit: BoxFit.contain,
      alignment: Alignment.bottomCenter,
      filterQuality: FilterQuality.high,
      gaplessPlayback: true,
    );

    if (!_faceRight) {
      sprite = Transform(
        alignment: Alignment.center,
        transform: Matrix4.diagonal3Values(-1, 1, 1),
        child: sprite,
      );
    }

    return Positioned(
      left: _hero.dx - boxW / 2,
      top: _hero.dy - boxH + bob,
      child: IgnorePointer(
        child: Transform.rotate(
          angle: _tilt,
          alignment: Alignment.bottomCenter,
          child: sprite,
        ),
      ),
    );
  }
}

class _SideScrollFieldPainter extends CustomPainter {
  const _SideScrollFieldPainter({required this.scroll});
  final double scroll;

  @override
  void paint(Canvas canvas, Size size) {
    final sky = Paint()..color = const Color(0xFFBFE8FF);
    canvas.drawRect(Offset.zero & size, sky);

    // distant sky glow
    canvas.drawRect(
      Rect.fromLTWH(0, size.height * .30, size.width, size.height * .28),
      Paint()..color = const Color(0xFFDDF5FF),
    );

    _hills(canvas, size, .10, const Color(0xFF8ECF91), size.height * .43, 54);
    _hills(canvas, size, .24, const Color(0xFF62B975), size.height * .50, 72);

    final grassTop = size.height * .54;
    canvas.drawRect(
      Rect.fromLTWH(0, grassTop, size.width, size.height - grassTop),
      Paint()..color = const Color(0xFF7ED45E),
    );

    // dirt road where the action happens
    final road = Path()
      ..moveTo(0, size.height * .63)
      ..quadraticBezierTo(size.width * .45, size.height * .59, size.width, size.height * .64)
      ..lineTo(size.width, size.height * .86)
      ..quadraticBezierTo(size.width * .50, size.height * .82, 0, size.height * .88)
      ..close();
    canvas.drawPath(road, Paint()..color = const Color(0xFFEBC889));

    final offset = -(scroll % 180);
    for (double x = offset - 180; x < size.width + 180; x += 180) {
      _tree(canvas, Offset(x + 34, grassTop - 8), .88);
      _bush(canvas, Offset(x + 118, grassTop + 6), .82);
      _rock(canvas, Offset(x + 146, size.height * .83), .75);
      _flowers(canvas, Offset(x + 84, size.height * .89));
    }

    final nearOffset = -((scroll * 1.45) % 130);
    for (double x = nearOffset - 130; x < size.width + 130; x += 130) {
      _grassTuft(canvas, Offset(x + 20, size.height * .91));
      _grassTuft(canvas, Offset(x + 86, size.height * .58));
    }
  }

  void _hills(Canvas canvas, Size size, double parallax, Color color, double y, double amp) {
    final phase = -((scroll * parallax) % 240);
    final path = Path()..moveTo(0, size.height);
    path.lineTo(0, y);
    for (double x = phase - 240; x <= size.width + 240; x += 120) {
      path.quadraticBezierTo(x + 60, y - amp, x + 120, y);
    }
    path.lineTo(size.width, size.height);
    path.close();
    canvas.drawPath(path, Paint()..color = color);
  }

  void _tree(Canvas canvas, Offset p, double s) {
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(center: Offset(p.dx, p.dy + 19 * s), width: 12 * s, height: 48 * s),
        Radius.circular(5 * s),
      ),
      Paint()..color = const Color(0xFF875F3D),
    );
    final leaf = Paint()..color = const Color(0xFF3E9C58);
    canvas.drawCircle(Offset(p.dx - 14 * s, p.dy - 4 * s), 22 * s, leaf);
    canvas.drawCircle(Offset(p.dx + 11 * s, p.dy - 8 * s), 25 * s, leaf);
    canvas.drawCircle(Offset(p.dx, p.dy - 25 * s), 25 * s, Paint()..color = const Color(0xFF51B967));
  }

  void _bush(Canvas canvas, Offset p, double s) {
    final paint = Paint()..color = const Color(0xFF49AE5C);
    canvas.drawCircle(Offset(p.dx - 13 * s, p.dy), 16 * s, paint);
    canvas.drawCircle(Offset(p.dx + 2 * s, p.dy - 7 * s), 20 * s, paint);
    canvas.drawCircle(Offset(p.dx + 18 * s, p.dy), 15 * s, paint);
  }

  void _rock(Canvas canvas, Offset p, double s) {
    canvas.drawOval(
      Rect.fromCenter(center: p, width: 28 * s, height: 17 * s),
      Paint()..color = const Color(0xFF8E9A95),
    );
  }

  void _flowers(Canvas canvas, Offset p) {
    for (int i = 0; i < 4; i++) {
      final x = p.dx + i * 9;
      canvas.drawCircle(Offset(x, p.dy), 3.2, Paint()..color = Colors.white);
      canvas.drawCircle(Offset(x, p.dy), 1.2, Paint()..color = const Color(0xFFFFC84A));
    }
  }

  void _grassTuft(Canvas canvas, Offset p) {
    final paint = Paint()
      ..color = const Color(0xFF3F9E4F)
      ..strokeWidth = 2.2
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(p, p.translate(-5, -10), paint);
    canvas.drawLine(p, p.translate(0, -12), paint);
    canvas.drawLine(p, p.translate(6, -9), paint);
  }

  @override
  bool shouldRepaint(covariant _SideScrollFieldPainter oldDelegate) => oldDelegate.scroll != scroll;
}
