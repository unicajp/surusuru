
import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../game/game_controller.dart';
import '../sfx_manager.dart';
import '../widgets/game_bottom_nav.dart';
import 'rpg_home_screen.dart';
import 'shop_screen.dart';
import 'stage_map_screen.dart';
import 'training_screen.dart';

/// V16.37.5.59 CHANCE_MODE_MINIGAME
///
/// New visual/physics prototype:
/// - 3000 Surusuru for test play.
/// - Manual connect from the upper hub.
/// - Auto connect up to 30 in one hold.
/// - Smaller, staggered pachinko-style pin field.
/// - Three small branch bumpers near the top.
/// - Central special star bumper.
/// - Five bottom pockets with real separator collisions.
/// - Strong pocket/branch/star flashes and trails.
class SurusuruPlayScreen extends StatefulWidget {
  final GameController controller;

  const SurusuruPlayScreen({
    super.key,
    required this.controller,
  });

  @override
  State<SurusuruPlayScreen> createState() => _SurusuruPlayScreenState();
}

class _DropPiece {
  _DropPiece({
    required this.id,
    required this.type,
    required this.x,
    required this.y,
    required this.vx,
    required this.vy,
  });

  final int id;
  final int type;
  double x;
  double y;
  double vx;
  double vy;
  double angle = 0;
  double spin = 0;
  bool scored = false;
  bool branchTriggered = false;
  int branchCooldown = 0;
  bool starTriggered = false;
  int slowCenterFrames = 0;
  final Set<int> hitUPockets = <int>{};
  final List<Offset> trail = <Offset>[];
}

class _RewardToken {
  _RewardToken({
    required this.amount,
    required this.origin,
    required this.startedAt,
  });

  final int amount;
  final Offset origin;
  final DateTime startedAt;
  bool arrived = false;
}

class _ConnectionFlash {
  _ConnectionFlash(this.port, this.startedAt);
  final int port;
  final DateTime startedAt;
}

class _PocketBurst {
  _PocketBurst({
    required this.center,
    required this.text,
    required this.startedAt,
    required this.kind,
  });

  final Offset center;
  final String text;
  final DateTime startedAt;
  final int kind;
}

class _SurusuruPlayScreenState extends State<SurusuruPlayScreen> {
  final math.Random _random = math.Random();

  final List<_DropPiece> _pieces = <_DropPiece>[];
  final List<_ConnectionFlash> _flashes = <_ConnectionFlash>[];
  final List<_PocketBurst> _bursts = <_PocketBurst>[];
  final List<_RewardToken> _rewardTokens = <_RewardToken>[];

  int _rewardCounter = 0;
  DateTime? _lastCounterAddAt;
  DateTime? _expBeamStartedAt;
  DateTime? _expCountStartedAt;
  static const int _expBeamTravelDurationMs = 720;
  int _expBeamAmount = 0;
  int _expTransferApplied = 0;
  int _expTransferDurationMs = 0;
  DateTime? _lastExpTickSfxAt;

  Timer? _physicsTimer;
  Timer? _autoTimer;

  Size _boardSize = Size.zero;
  int _nextPieceId = 1;

  int get _surusuru => widget.controller.surusuruBalance;
  int _monsterExp = 0;
  int _monsterLevel = 1;

  int _autoUsed = 0;
  bool _autoRunning = false;

  bool _manualDragging = false;
  Offset? _manualFinger;
  int? _manualHoverPort;

  bool _miniGameOpen = false;
  bool _batchActive = false;
  bool _batchSettlementStarted = false;
  bool _holdCounterForBatch = false;
  int _centerPocketHits = 0;

  DateTime? _lastPegSfxAt;
  DateTime? _lastWallSfxAt;
  DateTime? _lastPieceSfxAt;

  bool get _dropBusy =>
      _autoRunning ||
      _pieces.isNotEmpty ||
      _miniGameOpen ||
      _batchSettlementStarted ||
      _rewardTokens.isNotEmpty ||
      _rewardCounter > 0 ||
      _expBeamStartedAt != null;

  static const int _portCount = 5;
  static const int _autoMax = 30;

  @override
  void initState() {
    super.initState();
    _physicsTimer = Timer.periodic(
      const Duration(milliseconds: 16),
      (_) => _tick(),
    );
  }

  @override
  void dispose() {
    _physicsTimer?.cancel();
    _autoTimer?.cancel();
    super.dispose();
  }

  double _pieceRadius(Size size) =>
      (size.width / 68).clamp(4.5, 6.0).toDouble();

  double _pegRadius(Size size) =>
      (size.width / 104).clamp(3.0, 4.2).toDouble();

  Rect _playRect(Size size) {
    // Restore the original vertical height, while narrowing the board width.
    final top = math.max(112.0, size.height * .205);
    final bottom = size.height - 122.0;
    final side = math.max(42.0, size.width * .16);
    return Rect.fromLTRB(side, top, size.width - side, bottom);
  }

  Offset _hub(Size size) =>
      Offset(size.width / 2, math.max(52.0, size.height * .085));

  List<Offset> _ports(Size size) {
    final y = math.max(88.0, size.height * .145);
    final side = math.max(48.0, size.width * .18);
    final left = side;
    final right = size.width - side;
    return List<Offset>.generate(
      _portCount,
      (i) => Offset(
        left + (right - left) * i / (_portCount - 1),
        y,
      ),
    );
  }

  List<({String label, Offset center})> _letterBumpers(Size size) {
    final r = _playRect(size);
    final topY = r.top + r.height * .31;
    final bottomY = r.top + r.height * .62;

    // Upper row:  S   U   R   U
    // Lower row:  S   U   ★   R   U
    return <({String label, Offset center})>[
      (label: 'S', center: Offset(r.left + r.width * .14, topY + 6)),
      (label: 'U', center: Offset(r.left + r.width * .38, topY - 8)),
      (label: 'R', center: Offset(r.left + r.width * .62, topY + 5)),
      (label: 'U', center: Offset(r.left + r.width * .86, topY - 4)),

      (label: 'S', center: Offset(r.left + r.width * .10, bottomY - 6)),
      (label: 'U', center: Offset(r.left + r.width * .27, bottomY + 10)),
      (label: 'R', center: Offset(r.left + r.width * .74, bottomY + 10)),
      (label: 'U', center: Offset(r.left + r.width * .90, bottomY - 6)),
    ];
  }

  Offset _starBumper(Size size) {
    final r = _playRect(size);
    // Move the ★ slightly upward so it is visually distinct from the
    // mini-game entrance mechanism below.
    return Offset(r.center.dx, r.top + r.height * .615);
  }

  List<Offset> _pegs(Size size) {
    final r = _playRect(size);
    if (r.height < 250) return const <Offset>[];
    return <Offset>[
      Offset(r.left + r.width * .23, r.top + r.height * .47),
      Offset(r.left + r.width * .50, r.top + r.height * .43),
      Offset(r.left + r.width * .77, r.top + r.height * .47),
      Offset(r.left + r.width * .20, r.top + r.height * .78),
      Offset(r.left + r.width * .80, r.top + r.height * .78),
    ];
  }

  List<Offset> _bottomPockets(Size size) {
    final r = _playRect(size);
    final y = r.bottom - 25;
    return List<Offset>.generate(
      5,
      (i) => Offset(r.left + r.width * (i + .5) / 5, y),
    );
  }

  List<double> _separatorXs(Size size) {
    final r = _playRect(size);
    return List<double>.generate(
      4,
      (i) => r.left + r.width * (i + 1) / 5,
    );
  }

  List<({Offset a, Offset b})> _miniGameGuards(Size size) {
    final r = _playRect(size);
    final cx = r.center.dx;

    // Final stage is deliberately simple and readable:
    // one straight-drop blocker and two side rails. The visible purple hole
    // itself is the only scoring trigger; there are no hidden qualifications.
    return <({Offset a, Offset b})>[
      (
        a: Offset(cx - 58, r.bottom - 108),
        b: Offset(cx - 27, r.bottom - 88),
      ),
      (
        a: Offset(cx + 58, r.bottom - 108),
        b: Offset(cx + 27, r.bottom - 88),
      ),
    ];
  }

  Offset _miniGameBlocker(Size size) {
    final r = _playRect(size);
    return Offset(r.center.dx, r.bottom - 112);
  }

  bool _allowSfx(DateTime? last, int milliseconds) {
    if (last == null) return true;
    return DateTime.now().difference(last).inMilliseconds >= milliseconds;
  }

  void _pegSfx() {
    if (!_allowSfx(_lastPegSfxAt, 55)) return;
    _lastPegSfxAt = DateTime.now();
    SfxManager.instance.traceStep(1 + _random.nextInt(3));
  }

  void _wallSfx() {
    if (!_allowSfx(_lastWallSfxAt, 90)) return;
    _lastWallSfxAt = DateTime.now();
    SfxManager.instance.tap();
  }

  void _pieceSfx() {
    if (!_allowSfx(_lastPieceSfxAt, 70)) return;
    _lastPieceSfxAt = DateTime.now();
    SfxManager.instance.spawn();
  }

  void _tick() {
    if (!mounted || _boardSize == Size.zero) return;

    _tickRewardFlow();
    if (_miniGameOpen) {
      if (_rewardTokens.isNotEmpty ||
          _rewardCounter > 0 ||
          _expBeamStartedAt != null) {
        setState(() {});
      }
      return;
    }

    final size = _boardSize;
    final rect = _playRect(size);
    final radius = _pieceRadius(size);
    final pegR = _pegRadius(size);
    final pegs = _pegs(size);
    final letterBumpers = _letterBumpers(size);
    final star = _starBumper(size);
    final pockets = _bottomPockets(size);
    final separators = _separatorXs(size);

    for (var index = 0; index < _pieces.length; index++) {
      final p = _pieces[index];
      if (p.scored) continue;
      if (p.branchCooldown > 0) p.branchCooldown--;

      final previousPosition = Offset(p.x, p.y);

      p.vy = math.min(p.vy + .17, 7.8);
      p.vx += (_random.nextDouble() - .5) * .025;
      p.vx *= .998;
      p.x += p.vx;
      p.y += p.vy;
      p.angle += p.spin;

      p.trail.add(Offset(p.x, p.y));
      if (p.trail.length > 8) p.trail.removeAt(0);

      // Swept side walls: even if a fast piece crosses beyond the wall
      // between frames, force it back inside and reflect the velocity.
      final leftLimit = rect.left + radius;
      final rightLimit = rect.right - radius;
      if (p.x < leftLimit ||
          (previousPosition.dx >= leftLimit && p.x < leftLimit)) {
        p.x = leftLimit + .35;
        p.vx = math.max(.9, p.vx.abs() * (.86 + _random.nextDouble() * .10));
        p.spin += .025;
        _wallSfx();
      } else if (p.x > rightLimit ||
          (previousPosition.dx <= rightLimit && p.x > rightLimit)) {
        p.x = rightLimit - .35;
        p.vx = -math.max(.9, p.vx.abs() * (.86 + _random.nextDouble() * .10));
        p.spin -= .025;
        _wallSfx();
      }

      // Small metallic pins.
      for (final peg in pegs) {
        final pegHit = _bounceCircle(
          p,
          peg,
          pegR,
          radius,
          restitution: .82 + _random.nextDouble() * .13,
          randomKick: .7,
        );
        if (pegHit) _pegSfx();
      }

      // Round SURUSURU letter bumpers.
      // Swept collision prevents tunnelling. Every valid hit gives EXP.
      for (var bumperIndex = 0;
          bumperIndex < letterBumpers.length;
          bumperIndex++) {
        final bumper = letterBumpers[bumperIndex];
        final hit = _bounceCircleSwept(
          p,
          previousPosition,
          bumper.center,
          13,
          radius,
          restitution: .88,
          randomKick: .72,
        );

        if (hit) {
          final gain = bumper.label == 'U' ? 1 : 2;
          if (bumper.label == 'U') {
            SfxManager.instance.traceStep(4);
          } else {
            SfxManager.instance.reaction();
          }
          _queueReward(gain, bumper.center);
          _bursts.add(
            _PocketBurst(
              center: bumper.center,
              text: '$gain',
              startedAt: DateTime.now(),
              kind: bumper.label == 'U' ? 0 : 1,
            ),
          );
        }
      }

      // Central star. Physical collision and EXP reward are active every hit.


      final starHit = _bounceCircleSwept(
        p,
        previousPosition,
        star,
        24,
        radius,
        restitution: .96,
        randomKick: 1.15,
      );
      if (starHit) {
        SfxManager.instance.lightning();
        _queueReward(2, star);
        _bursts.add(
          _PocketBurst(
            center: star,
            text: '2',
            startedAt: DateTime.now(),
            kind: 2,
          ),
        );
      }

      // Tiny character-to-character bounce.
      for (final q in _pieces) {
        if (identical(p, q) || q.id <= p.id || q.scored) continue;
        var dx = q.x - p.x;
        var dy = q.y - p.y;
        final minD = radius * 2;
        final d2 = dx * dx + dy * dy;
        if (d2 <= .0001 || d2 >= minD * minD) continue;
        final d = math.sqrt(d2);
        final nx = dx / d;
        final ny = dy / d;
        final overlap = minD - d;
        p.x -= nx * overlap * .5;
        p.y -= ny * overlap * .5;
        q.x += nx * overlap * .5;
        q.y += ny * overlap * .5;

        final rv = (q.vx - p.vx) * nx + (q.vy - p.vy) * ny;
        if (rv < 0) {
          _pieceSfx();
          final impulse = -rv * .60;
          p.vx -= nx * impulse;
          p.vy -= ny * impulse;
          q.vx += nx * impulse;
          q.vy += ny * impulse;
        }
      }

      // Real collision on the four vertical pocket separators.
      final separatorTop = rect.bottom - 86;
      final separatorBottom = rect.bottom + 6;
      if (p.y + radius >= separatorTop &&
          p.y - radius <= separatorBottom) {
        for (final sx in separators) {
          final dx = p.x - sx;
          final halfThickness = 4.5;
          if (dx.abs() <= radius + halfThickness) {
            p.x = sx +
                (dx >= 0 ? 1 : -1) * (radius + halfThickness + .2);
            p.vx = (dx >= 0 ? 1 : -1) *
                math.max(.85, p.vx.abs() * .78);
            p.spin += (dx >= 0 ? 1 : -1) * .03;
            _wallSfx();
          }
        }
      }

      // Pocket entry. The ball must actually descend below the lip.
      if (!p.scored && p.y >= rect.bottom - 40) {
        final pocketWidth = rect.width / 5;
        var pocketIndex =
            ((p.x - rect.left) / pocketWidth).floor().clamp(0, 4).toInt();

        final left = rect.left + pocketWidth * pocketIndex;
        final right = left + pocketWidth;
        if (p.x > left + radius + 4 &&
            p.x < right - radius - 4 &&
            p.y >= rect.bottom - 20) {
          p.scored = true;

          {
            const rewards = <int>[10, 20, 0, 20, 10];
            const labels = <String>[
              '10',
              '20',
              '',
              '20',
              '10',
            ];
            if (pocketIndex == 2) {
              // The center RED pocket is the mini-game pocket. It only counts
              // hits now; the mini-game opens later, after the whole batch has
              // finished, exactly like the existing settlement flow.
              _centerPocketHits++;
              SfxManager.instance.reward();
              _bursts.add(
                _PocketBurst(
                  center: pockets[pocketIndex] - const Offset(0, 18),
                  text: '×$_centerPocketHits',
                  startedAt: DateTime.now(),
                  kind: 5,
                ),
              );
            } else {
              SfxManager.instance.clear();
              _queueReward(rewards[pocketIndex], pockets[pocketIndex]);
              _bursts.add(
                _PocketBurst(
                  center: pockets[pocketIndex] - const Offset(0, 18),
                  text: labels[pocketIndex],
                  startedAt: DateTime.now(),
                  kind: 0,
                ),
              );
            }

            p.y = rect.bottom + 100;
            p.vx = 0;
            p.vy = 0;
          }
        }
      }
    }

    final hadPieces = _pieces.isNotEmpty;
    _pieces.removeWhere(
      (p) =>
          p.scored ||
          p.y > rect.bottom + 90 ||
          p.x < -100 ||
          p.x > size.width + 100,
    );
    if (hadPieces && _pieces.isEmpty && !_autoRunning) {
      SfxManager.instance.unlock();
      if (_batchActive && !_batchSettlementStarted) {
        _batchSettlementStarted = true;
        Future<void>.delayed(
          const Duration(milliseconds: 700),
          _settleBatch,
        );
      }
    }

    final now = DateTime.now();
    _flashes.removeWhere(
      (f) => now.difference(f.startedAt).inMilliseconds > 450,
    );
    _bursts.removeWhere(
      (b) =>
          now.difference(b.startedAt).inMilliseconds >
          (b.kind == 4 ? 1400 : b.kind == 5 ? 950 : 720),
    );

    if (mounted &&
        (_pieces.isNotEmpty ||
            _flashes.isNotEmpty ||
            _bursts.isNotEmpty ||
            _rewardTokens.isNotEmpty ||
            _rewardCounter > 0 ||
            _expBeamStartedAt != null)) {
      setState(() {});
    }
  }

  bool _bounceSegment(
    _DropPiece p,
    Offset a,
    Offset b,
    double obstacleRadius,
    double pieceRadius, {
    required double restitution,
    required double randomKick,
  }) {
    final ab = b - a;
    final len2 = ab.dx * ab.dx + ab.dy * ab.dy;
    if (len2 <= .0001) return false;

    final ap = Offset(p.x, p.y) - a;
    final t = ((ap.dx * ab.dx + ap.dy * ab.dy) / len2)
        .clamp(0.0, 1.0)
        .toDouble();
    final closest = a + ab * t;

    var dx = p.x - closest.dx;
    var dy = p.y - closest.dy;
    final minD = obstacleRadius + pieceRadius;
    final d2 = dx * dx + dy * dy;
    if (d2 >= minD * minD) return false;

    var d = math.sqrt(math.max(.0001, d2));
    if (d < .01) {
      dx = -ab.dy;
      dy = ab.dx;
      d = math.sqrt(dx * dx + dy * dy);
    }

    final nx = dx / d;
    final ny = dy / d;
    final overlap = minD - d;
    p.x += nx * (overlap + .25);
    p.y += ny * (overlap + .25);

    final dot = p.vx * nx + p.vy * ny;
    if (dot < 0) {
      p.vx -= (1 + restitution) * dot * nx;
      p.vy -= (1 + restitution) * dot * ny;
    }

    final kick = (_random.nextDouble() - .5) * randomKick;
    p.vx += -ny * kick;
    p.vy += nx * kick * .25;
    p.spin += kick * .018;
    return true;
  }

  Future<void> _settleBatch() async {
    if (!mounted) return;

    // Wait until all normal reward stars from this 30-ball batch have reached
    // the big counter. The counter is intentionally held and cannot beam yet.
    while (mounted && _rewardTokens.any((t) => !t.arrived)) {
      await Future<void>.delayed(const Duration(milliseconds: 80));
    }
    if (!mounted) return;

    final hits = _centerPocketHits;
    if (hits > 0) {
      setState(() {
        _miniGameOpen = true;
      });

      final miniReward = await Navigator.of(context).push<int>(
        MaterialPageRoute<int>(
          builder: (_) => _ConnectMiniGameScreen(multiplier: hits),
          fullscreenDialog: true,
        ),
      );

      if (!mounted) return;

      if (miniReward != null && miniReward > 0) {
        final bonus = miniReward * hits;
        setState(() {
          _miniGameOpen = false;
          _queueReward(
            bonus,
            _bottomPockets(_boardSize)[2],
          );
          _bursts.add(
            _PocketBurst(
              center: _playRect(_boardSize).center,
              text: hits > 1 ? '$miniReward ×$hits = $bonus' : '$bonus',
              startedAt: DateTime.now(),
              kind: 4,
            ),
          );
        });
        SfxManager.instance.unlock();
        SfxManager.instance.reward();

        // Wait for the mini-game bonus star to enter the big counter too.
        while (mounted && _rewardTokens.any((t) => !t.arrived)) {
          await Future<void>.delayed(const Duration(milliseconds: 80));
        }
      } else {
        setState(() {
          _miniGameOpen = false;
        });
      }
    }

    if (!mounted) return;
    setState(() {
      _centerPocketHits = 0;
      _batchActive = false;
      _batchSettlementStarted = false;
      _holdCounterForBatch = false;
      _lastCounterAddAt = DateTime.now();
    });
  }


  bool _bounceCircleSwept(
    _DropPiece p,
    Offset previous,
    Offset center,
    double obstacleRadius,
    double pieceRadius, {
    required double restitution,
    required double randomKick,
  }) {
    final current = Offset(p.x, p.y);
    final segment = current - previous;
    final segmentLen2 =
        segment.dx * segment.dx + segment.dy * segment.dy;
    final minD = obstacleRadius + pieceRadius;

    double t = 0.0;
    if (segmentLen2 > .000001) {
      final toCenter = center - previous;
      t = ((toCenter.dx * segment.dx + toCenter.dy * segment.dy) /
              segmentLen2)
          .clamp(0.0, 1.0)
          .toDouble();
    }

    final closest = previous + segment * t;
    var delta = closest - center;
    var distance = delta.distance;

    // Also catch ordinary overlap at the current position.
    final currentDelta = current - center;
    final currentDistance = currentDelta.distance;
    if (distance > minD && currentDistance > minD) return false;

    if (currentDistance <= minD) {
      delta = currentDelta;
      distance = currentDistance;
    }

    if (distance < .001) {
      final speed = Offset(p.vx, p.vy);
      if (speed.distance > .001) {
        delta = -speed / speed.distance;
      } else {
        delta = const Offset(0, -1);
      }
      distance = 1;
    }

    final normal = delta / distance;

    // Force the character back to the outside edge. This is the key part
    // that prevents tunnelling straight through on later contacts.
    p.x = center.dx + normal.dx * (minD + .35);
    p.y = center.dy + normal.dy * (minD + .35);

    final dot = p.vx * normal.dx + p.vy * normal.dy;
    if (dot < 0) {
      p.vx -= (1 + restitution) * dot * normal.dx;
      p.vy -= (1 + restitution) * dot * normal.dy;
    } else {
      // A swept crossing can finish on the far side with dot >= 0.
      // Give it a guaranteed outward push instead of allowing a pass-through.
      final outward = math.max(1.1, math.sqrt(p.vx * p.vx + p.vy * p.vy) * .72);
      p.vx = normal.dx * outward;
      p.vy = normal.dy * outward;
    }

    final tangentKick =
        (_random.nextDouble() - .5) * randomKick;
    p.vx += -normal.dy * tangentKick;
    p.vy += normal.dx * tangentKick * .22;
    p.spin += tangentKick * .02;
    return true;
  }

  bool _bounceCircle(
    _DropPiece p,
    Offset center,
    double obstacleRadius,
    double pieceRadius, {
    required double restitution,
    required double randomKick,
  }) {
    var dx = p.x - center.dx;
    var dy = p.y - center.dy;
    final minD = obstacleRadius + pieceRadius;
    var d2 = dx * dx + dy * dy;
    if (d2 >= minD * minD) return false;

    var d = math.sqrt(math.max(.0001, d2));
    if (d < .01) {
      dx = (_random.nextDouble() - .5) * .2;
      dy = -1;
      d = math.sqrt(dx * dx + dy * dy);
    }

    final nx = dx / d;
    final ny = dy / d;
    final overlap = minD - d;
    p.x += nx * overlap;
    p.y += ny * overlap;

    final dot = p.vx * nx + p.vy * ny;
    if (dot < 0) {
      p.vx -= (1 + restitution) * dot * nx;
      p.vy -= (1 + restitution) * dot * ny;
    }

    final tangentKick = (_random.nextDouble() - .5) * randomKick;
    p.vx += -ny * tangentKick;
    p.vy += nx * tangentKick * .22;
    p.spin += tangentKick * .02;
    return true;
  }

  Offset _rewardCounterCenter(Size size) {
    final r = _playRect(size);
    return Offset(r.center.dx, r.top + 34);
  }

  void _queueReward(int amount, Offset origin) {
    if (amount <= 0 || _boardSize == Size.zero) return;
    _rewardTokens.add(
      _RewardToken(
        amount: amount,
        origin: origin,
        startedAt: DateTime.now(),
      ),
    );
  }

  void _applyExp(int amount) {
    _monsterExp += amount;
    var leveledUp = false;
    while (true) {
      final need = _expNeed(_monsterLevel);
      if (_monsterExp < need) break;
      _monsterExp -= need;
      _monsterLevel++;
      leveledUp = true;
    }
    if (leveledUp) SfxManager.instance.unlock();
  }

  void _tickRewardFlow() {
    if (_boardSize == Size.zero) return;
    final now = DateTime.now();
    var addedToCounter = false;

    for (final token in _rewardTokens) {
      if (token.arrived) continue;
      if (now.difference(token.startedAt).inMilliseconds >= 430) {
        token.arrived = true;
        _rewardCounter += token.amount;
        _lastCounterAddAt = now;
        addedToCounter = true;
      }
    }

    _rewardTokens.removeWhere(
      (t) =>
          t.arrived &&
          now.difference(t.startedAt).inMilliseconds > 560,
    );

    if (addedToCounter) {
      SfxManager.instance.traceStep(
        (_rewardCounter ~/ 100 + 3).clamp(3, 8).toInt(),
      );
    }

    final waitingToken = _rewardTokens.any((t) => !t.arrived);

    // Start the counter -> EXP transfer automatically when settlement ends.
    if (!_holdCounterForBatch &&
        _expBeamStartedAt == null &&
        _rewardCounter > 0 &&
        !waitingToken &&
        _lastCounterAddAt != null &&
        now.difference(_lastCounterAddAt!).inMilliseconds >= 320) {
      _expBeamAmount = _rewardCounter;
      _rewardCounter = 0;
      _expTransferApplied = 0;

      // Bigger totals deliberately take longer to count up.
      // 100 ~= 0.9s, 1000 ~= 1.5s, 8000 ~= 3.0s.
      _expTransferDurationMs =
          (700 + math.sqrt(_expBeamAmount.toDouble()) * 25)
              .round()
              .clamp(850, 3600)
              .toInt();
      _expBeamStartedAt = now;
      _expCountStartedAt = null;
      _lastExpTickSfxAt = null;
      SfxManager.instance.core();

      // The counter becomes 0 immediately. First, the total itself flies
      // to the EXP gauge as light. EXP must not increase until it arrives.
      if (mounted) setState(() {});
    }

    if (_expBeamStartedAt != null && _expBeamAmount > 0) {
      if (_expCountStartedAt == null) {
        final beamElapsed =
            now.difference(_expBeamStartedAt!).inMilliseconds;
        if (beamElapsed >= _expBeamTravelDurationMs) {
          _expCountStartedAt = now;
          _lastExpTickSfxAt = null;
          SfxManager.instance.traceStep(1);
          if (mounted) setState(() {});
        }
      } else {
        final elapsed =
            now.difference(_expCountStartedAt!).inMilliseconds;
        final duration = math.max(1, _expTransferDurationMs);
        final progress =
            (elapsed / duration).clamp(0.0, 1.0).toDouble();

        // Only after the light reaches the gauge: "turururururun" EXP count-up.
        final eased = Curves.easeOutCubic.transform(progress);
        final targetApplied =
            (_expBeamAmount * eased).round().clamp(0, _expBeamAmount);
        final delta = targetApplied - _expTransferApplied;

        if (delta > 0) {
          _applyExp(delta);
          _expTransferApplied += delta;

          if (_lastExpTickSfxAt == null ||
              now.difference(_lastExpTickSfxAt!).inMilliseconds >= 55) {
            _lastExpTickSfxAt = now;
            final step =
                1 + (progress * 7).floor().clamp(0, 7).toInt();
            SfxManager.instance.traceStep(step);
          }

          if (mounted) setState(() {});
        }

        if (progress >= 1.0) {
          final remaining = _expBeamAmount - _expTransferApplied;
          if (remaining > 0) {
            _applyExp(remaining);
            _expTransferApplied += remaining;
          }

          _expBeamAmount = 0;
          _expTransferApplied = 0;
          _expTransferDurationMs = 0;
          _expBeamStartedAt = null;
          _expCountStartedAt = null;
          _lastExpTickSfxAt = null;
          SfxManager.instance.reward();

          if (mounted) setState(() {});
        }
      }
    }
  }

  int _expNeed(int level) {
    final n = level - 1;
    // Numeric rewards from the five bottom pockets are now large, so leveling needs
    // a much larger curve. Lv1=8,000, Lv2=13,000, Lv3=20,000, Lv4=29,000...
    return 8000 + n * 4000 + n * n * 1000;
  }

  bool _consumeOneAndConnect(int port, {bool automatic = false}) {
    if (_surusuru <= 0 || _boardSize == Size.zero) return false;

    final ports = _ports(_boardSize);
    if (port < 0 || port >= ports.length) return false;

    setState(() {
      widget.controller.consumeSurusuru();
      SfxManager.instance.spawn();
      _flashes.add(_ConnectionFlash(port, DateTime.now()));

      final start = ports[port];
      final r = _pieceRadius(_boardSize);
      _pieces.add(
        _DropPiece(
          id: _nextPieceId++,
          type: _random.nextInt(5),
          x: start.dx + (_random.nextDouble() - .5) * r * 1.2,
          y: math.min(start.dy + r * 1.25, _playRect(_boardSize).top - r - 2),
          vx: (_random.nextDouble() - .5) * (automatic ? 2.0 : 1.2),
          vy: .45 + _random.nextDouble() * .75,
        ),
      );
    });
    return true;
  }

  void _startAuto() {
    if (_dropBusy || _surusuru <= 0) {
      SfxManager.instance.error();
      return;
    }
    _autoUsed = 0;
    _autoRunning = true;
    _batchActive = true;
    _batchSettlementStarted = false;
    _holdCounterForBatch = true;
    _centerPocketHits = 0;
    SfxManager.instance.surusuru();

    void fire() {
      if (!_autoRunning ||
          _autoUsed >= _autoMax ||
          _surusuru <= 0 ||
          !mounted) {
        _stopAuto();
        return;
      }

      if (_consumeOneAndConnect(
        _random.nextInt(_portCount),
        automatic: true,
      )) {
        _autoUsed++;
      }
    }

    fire();
    _autoTimer?.cancel();
    _autoTimer = Timer.periodic(
      const Duration(milliseconds: 118),
      (_) => fire(),
    );
    setState(() {});
  }

  void _stopAuto() {
    _autoTimer?.cancel();
    _autoTimer = null;
    if (!_autoRunning) return;
    _autoRunning = false;
    if (mounted) setState(() {});
  }

  void _manualStart(DragStartDetails details) {
    if (_autoRunning || _surusuru <= 0) return;
    final hub = _hub(_boardSize);
    if ((details.localPosition - hub).distance > 42) return;

    SfxManager.instance.tap();
    setState(() {
      _manualDragging = true;
      _manualFinger = details.localPosition;
      _manualHoverPort = null;
    });
  }

  void _manualUpdate(DragUpdateDetails details) {
    if (!_manualDragging) return;
    final finger = details.localPosition;
    final ports = _ports(_boardSize);

    int? hover;
    var best = 38.0;
    for (var i = 0; i < ports.length; i++) {
      final d = (finger - ports[i]).distance;
      if (d < best) {
        best = d;
        hover = i;
      }
    }

    setState(() {
      _manualFinger = finger;
      _manualHoverPort = hover;
    });
  }

  void _manualEnd(DragEndDetails details) {
    if (!_manualDragging) return;
    final port = _manualHoverPort;

    setState(() {
      _manualDragging = false;
      _manualFinger = null;
      _manualHoverPort = null;
    });

    if (port != null) {
      if (!_batchActive) {
        _batchActive = true;
        _batchSettlementStarted = false;
        _holdCounterForBatch = true;
        _centerPocketHits = 0;
      }
      _consumeOneAndConnect(port);
    }
  }

  void _manualCancel() {
    if (!_manualDragging) return;
    setState(() {
      _manualDragging = false;
      _manualFinger = null;
      _manualHoverPort = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final expNeed = _expNeed(_monsterLevel);

    // V57: The SURUSURU machine now lives on a fixed logical canvas.
    // Its internal coordinates never depend on the phone height or on the
    // bottom navigation bar.  Different devices only scale this canvas as a
    // whole, so bumper/pin/pocket positions and physics stay identical.
    const logicalBoardSize = Size(390, 525);
    const topBarHeight = 74.0;

    return Scaffold(
      backgroundColor: const Color(0xFFF5F1EA),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, outer) {
            final scale = outer.maxWidth / logicalBoardSize.width;
            final renderedBoardHeight = logicalBoardSize.height * scale;

            return Stack(
              clipBehavior: Clip.hardEdge,
              children: [
                Positioned.fill(
                  child: Container(color: const Color(0xFFF5F1EA)),
                ),
                Positioned(
                  top: 0,
                  left: 0,
                  right: 0,
                  height: topBarHeight,
                  child: _TopBar(
                    level: _monsterLevel,
                    exp: _monsterExp,
                    expNeed: expNeed,
                    onBack: () => Navigator.pop(context),
                  ),
                ),
                Positioned(
                  top: topBarHeight,
                  left: 0,
                  right: 0,
                  height: renderedBoardHeight,
                  child: FittedBox(
                    fit: BoxFit.fill,
                    alignment: Alignment.topCenter,
                    child: SizedBox(
                      width: logicalBoardSize.width,
                      height: logicalBoardSize.height,
                      child: Builder(
                        builder: (context) {
                          _boardSize = logicalBoardSize;
                          return GestureDetector(
                            behavior: HitTestBehavior.opaque,
                            onPanStart: _manualStart,
                            onPanUpdate: _manualUpdate,
                            onPanEnd: _manualEnd,
                            onPanCancel: _manualCancel,
                            child: Stack(
                              children: [
                                Positioned.fill(
                                  child: CustomPaint(
                                    painter: _SuruBoardPainter(
                                      pieces: _pieces,
                                      flashes: _flashes,
                                      bursts: _bursts,
                                      hub: _hub(_boardSize),
                                      ports: _ports(_boardSize),
                                      pegs: _pegs(_boardSize),
                                      letterBumpers: _letterBumpers(_boardSize),
                                      starBumper: _starBumper(_boardSize),
                                      pockets: _bottomPockets(_boardSize),
                                      separators: _separatorXs(_boardSize),
                                      playRect: _playRect(_boardSize),
                                      pieceRadius: _pieceRadius(_boardSize),
                                      pegRadius: _pegRadius(_boardSize),
                                      manualFinger: _manualFinger,
                                      manualHoverPort: _manualHoverPort,
                                      rewardTokens: _rewardTokens,
                                      rewardCounter: _rewardCounter,
                                      expBeamStartedAt: _expBeamStartedAt,
                                      expCountStartedAt: _expCountStartedAt,
                                      expBeamAmount: _expBeamAmount,
                                      expTransferApplied: _expTransferApplied,
                                      expTransferDurationMs: _expTransferDurationMs,
                                      centerPocketHits: _centerPocketHits,
                                    ),
                                  ),
                                ),
                                Positioned(
                                  top: 6,
                                  left: 0,
                                  right: 0,
                                  child: IgnorePointer(
                                    child: Center(
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 12,
                                          vertical: 4,
                                        ),
                                        decoration: BoxDecoration(
                                          color: const Color(0xEEFDFBF8),
                                          borderRadius: BorderRadius.circular(15),
                                          border: Border.all(
                                            color: const Color(0x66A9BFB8),
                                          ),
                                        ),
                                        child: Text(
                                          _manualDragging
                                              ? '好きな入口へつないで離す'
                                              : '手動つなぎ  •  1スルスル',
                                          style: const TextStyle(
                                            color: const Color(0xFF6F6A64),
                                            fontSize: 10,
                                            fontWeight: FontWeight.w700,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  left: 0,
                                  right: 0,
                                  bottom: 2,
                                  child: Center(
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        GestureDetector(
                                          onTap: () {
                                            if (_dropBusy || _surusuru <= 0) {
                                              SfxManager.instance.error();
                                              return;
                                            }
                                            SfxManager.instance.tap();
                                            _consumeOneAndConnect(
                                              _random.nextInt(_portCount),
                                              automatic: true,
                                            );
                                          },
                                          onLongPressStart: (_) => _startAuto(),
                                          onLongPressEnd: (_) {},
                                          child: AnimatedScale(
                                            duration: const Duration(milliseconds: 90),
                                            scale: _autoRunning ? .93 : 1,
                                            child: Container(
                                              width: 116,
                                              height: 116,
                                              decoration: BoxDecoration(
                                                shape: BoxShape.circle,
                                                gradient: const RadialGradient(
                                                  colors: [
                                                    Color(0xFFFFF5D8),
                                                    Color(0xFFF8D690),
                                                    Color(0xFFE9B567),
                                                  ],
                                                ),
                                                border: Border.all(
                                                  color: Color(0xFFFFFAF2),
                                                  width: 2,
                                                ),
                                                boxShadow: const [
                                                  BoxShadow(
                                                    color: Color(0x33C58C52),
                                                    blurRadius: 20,
                                                    spreadRadius: 1,
                                                  ),
                                                  BoxShadow(
                                                    color: Color(0x77000000),
                                                    blurRadius: 10,
                                                    offset: Offset(0, 6),
                                                  ),
                                                ],
                                              ),
                                              child: Column(
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                children: [
                                                  const Text(
                                                    'スルスル',
                                                    style: TextStyle(
                                                      color: Color(0xFF432416),
                                                      fontSize: 18,
                                                      fontWeight: FontWeight.w900,
                                                    ),
                                                  ),
                                                  Text(
                                                    _autoRunning
                                                        ? '$_autoUsed / $_autoMax'
                                                        : _pieces.isNotEmpty
                                                            ? '落下中 ${_pieces.length}'
                                                            : 'MAX $_autoMax',
                                                    style: const TextStyle(
                                                      color: Color(0xFF432416),
                                                      fontSize: 15,
                                                      fontWeight: FontWeight.w900,
                                                    ),
                                                  ),
                                                  const Text(
                                                    '連打',
                                                    style: TextStyle(
                                                      color: Color(0xAA432416),
                                                      fontSize: 9,
                                                      fontWeight: FontWeight.w900,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(height: 5),
                                        Container(
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 13,
                                            vertical: 4,
                                          ),
                                          decoration: BoxDecoration(
                                            color: const Color(0xDD0E1120),
                                            borderRadius: BorderRadius.circular(13),
                                            border: Border.all(
                                              color: const Color(0x99FFD76A),
                                            ),
                                          ),
                                          child: Text(
                                            '所持スルスル  $_surusuru',
                                            style: const TextStyle(
                                              color: Colors.white,
                                              fontSize: 11,
                                              fontWeight: FontWeight.w900,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ),
                // Navigation is an overlay sibling, not part of the machine's
                // layout. Adding/removing/changing this bar can no longer move
                // any pin, bumper, pocket or physics coordinate.
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: GameBottomNav(
                    active: 'surusuru',
                    onAdventure: () {
                      SfxManager.instance.tap();
                      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => StageMapScreen(controller: widget.controller)));
                    },
                    onShop: () {
                      SfxManager.instance.tap();
                      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => ShopScreen(controller: widget.controller)));
                    },
                    onSurusuru: () {},
                    onTraining: () {
                      SfxManager.instance.tap();
                      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => TrainingScreen(controller: widget.controller)));
                    },
                    onMap: () {
                      SfxManager.instance.tap();
                      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => RpgHomeScreen(controller: widget.controller)));
                    },
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _TopBar extends StatelessWidget {
  const _TopBar({
    required this.level,
    required this.exp,
    required this.expNeed,
    required this.onBack,
  });

  final int level;
  final int exp;
  final int expNeed;
  final VoidCallback onBack;

  @override
  Widget build(BuildContext context) {
    final ratio =
        expNeed <= 0 ? 0.0 : (exp / expNeed).clamp(0.0, 1.0);

    return Container(
      height: 74,
      padding: const EdgeInsets.fromLTRB(7, 6, 9, 7),
      decoration: const BoxDecoration(
        color: Color(0xFFFDFBF8),
        boxShadow: [
          BoxShadow(
            color: Color(0x164A3E35),
            blurRadius: 14,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Row(
        children: [
          IconButton(
            onPressed: onBack,
            icon: const Icon(Icons.arrow_back_rounded, color: Color(0xFF625C56)),
          ),
          Expanded(
            child: Container(
              padding: const EdgeInsets.fromLTRB(10, 6, 10, 7),
              decoration: BoxDecoration(
                color: const Color(0xFFF6F1EA),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFFE8E0D7)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      const Text(
                        '育成モンスター',
                        style: TextStyle(
                          color: Color(0xFF625C56),
                          fontWeight: FontWeight.w700,
                          fontSize: 12,
                        ),
                      ),
                      const Spacer(),
                      Text(
                        'Lv.$level',
                        style: const TextStyle(
                          color: Color(0xFFB68545),
                          fontWeight: FontWeight.w800,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 5),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(7),
                    child: Stack(
                      children: [
                        Container(
                          height: 14,
                          color: const Color(0xFFE5DED6),
                        ),
                        FractionallySizedBox(
                          widthFactor: ratio,
                          child: Container(
                            height: 14,
                            decoration: const BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Color(0xFF85C7B0),
                                  Color(0xFFB9D9A0),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Positioned.fill(
                          child: Center(
                            child: Text(
                              '$exp / $expNeed',
                              style: const TextStyle(
                                color: Color(0xFF5A5550),
                                fontSize: 9,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}


enum _ChanceMode { instant, stepUp, battle, bubble }

class _ConnectMiniGameScreen extends StatefulWidget {
  const _ConnectMiniGameScreen({required this.multiplier});
  final int multiplier;

  @override
  State<_ConnectMiniGameScreen> createState() => _ConnectMiniGameScreenState();
}

class _ConnectMiniGameScreenState extends State<_ConnectMiniGameScreen> {
  final math.Random _rng = math.Random();
  late final int _result;
  _ChanceMode? _mode;
  int _step = 0;
  bool _revealed = false;
  bool _holding = false;
  int _battleHits = 0;
  int _defeated = 0;
  int _battleTarget = 0;
  final List<Offset> _battlePush = List<Offset>.filled(4, Offset.zero);
  int _battleBurstIndex = -1;
  double _battleBurstPhase = 1.0;
  String _message = '演出モードを選んでください';
  Timer? _holdTimer;
  Timer? _fxTimer;
  bool _screenFlash = false;
  bool _shake = false;
  bool _battleImpact = false;
  bool _sequenceLocked = false;
  bool _stepRevival = false;
  bool _battleReversal = false;
  bool _perfectFxPlayed = false;
  bool _missionReady = false;
  String? _cutIn;
  int _instantTaps = 0;
  double _charge = 0;
  Timer? _chargeTimer;
  int _stepTaps = 0;
  late final _ChanceMode _rouletteTarget;
  Timer? _rouletteTimer;
  int _rouletteIndex = 0;
  bool _rouletteSpinning = false;
  bool _rouletteCanStop = false;
  final List<_TreasureBubble> _bubbles = [];
  final List<_BubbleBurst> _bubbleBursts = [];
  Timer? _bubbleTimer;
  Timer? _ambientTimer;
  double _ambientT = 0;
  Size _bubbleFieldSize = Size.zero;
  int _bubblePopped = 0;
  bool _bubbleTreasureRising = false;
  bool _bubbleFinished = false;
  double _bubbleChestLift = 0;

  @override
  void initState() {
    super.initState();
    final r = _rng.nextInt(100);
    _result = r < 40 ? 4000 : r < 70 ? 3000 : r < 90 ? 2000 : 1000;
    _rouletteTarget = _ChanceMode.values[_rng.nextInt(_ChanceMode.values.length)];
  }

  @override
  void dispose() {
    _holdTimer?.cancel();
    _fxTimer?.cancel();
    _chargeTimer?.cancel();
    _rouletteTimer?.cancel();
    _bubbleTimer?.cancel();
    _ambientTimer?.cancel();
    super.dispose();
  }

  int get _resultLevel => (_result ~/ 1000).clamp(1, 4);
  Color get _heatColor => _result >= 4000 ? const Color(0xFFFFD54F) : _result >= 3000 ? const Color(0xFFFF405F) : _result >= 2000 ? const Color(0xFFFFA726) : const Color(0xFF42A5F5);
  String get _heatText => _result >= 4000 ? '激アツ' : _result >= 3000 ? '大チャンス' : _result >= 2000 ? 'チャンス' : 'ノーマル';

  void _flash({String? cutIn, bool strong = false}) {
    if (!mounted) return;
    _fxTimer?.cancel();
    setState(() {
      _screenFlash = true;
      _shake = strong;
      if (cutIn != null) _cutIn = cutIn;
    });
    _fxTimer = Timer(Duration(milliseconds: strong ? 420 : 260), () {
      if (!mounted) return;
      setState(() {
        _screenFlash = false;
        _shake = false;
        _battleImpact = false;
      });
      if (cutIn != null) {
        Future<void>.delayed(const Duration(milliseconds: 850), () {
          if (mounted && _cutIn == cutIn) setState(() => _cutIn = null);
        });
      }
    });
  }

  void _fxTap() { SfxManager.instance.tap(); }
  void _fxRise(int n) { SfxManager.instance.chanceStepUp(); SfxManager.instance.traceStep(n.clamp(1, 8)); if (n >= 4) SfxManager.instance.reaction(); }
  void _fxImpact() { SfxManager.instance.bomb(); SfxManager.instance.lightning(); }
  void _fxKyuiin() {
    _perfectFxPlayed = true;
    // V63: audio and screen flash are intentionally synchronized.
    SfxManager.instance.chanceKyuiin();
    SfxManager.instance.chanceFlash();
    _flash(cutIn: '激アツ!!', strong: true);
    Future<void>.delayed(const Duration(milliseconds: 850), () {
      if (!mounted) return;
      _flash(cutIn: 'キュイン!!', strong: true);
      SfxManager.instance.lightning();
    });
    Future<void>.delayed(const Duration(milliseconds: 1030), () {
      if (!mounted) return;
      _flash(cutIn: 'キュイーーーン!!', strong: true);
      SfxManager.instance.reaction();
    });
    Future<void>.delayed(const Duration(milliseconds: 1450), () {
      if (mounted) SfxManager.instance.chanceRewardBurst();
    });
  }

  void _choose(_ChanceMode mode) {
    _fxImpact();
    setState(() {
      _mode = mode; _step = 0; _battleHits = 0; _defeated = 0; _battleTarget = 0;
      for (var i = 0; i < _battlePush.length; i++) _battlePush[i] = Offset.zero;
      _battleBurstIndex = -1; _battleBurstPhase = 1.0;
      _screenFlash = false; _shake = false; _battleImpact = false; _cutIn = null;
      _sequenceLocked = false; _stepRevival = false; _battleReversal = false; _perfectFxPlayed = false;
      _missionReady = false; _instantTaps = 0; _charge = 0; _stepTaps = 0;
      _message = switch (mode) {
        _ChanceMode.instant => 'MISSION：光のコアを操作して\nキュインを鳴らせ！',
        _ChanceMode.stepUp => 'MISSION：4つの試練を突破して\n宝箱を開けろ！',
        _ChanceMode.battle => 'MISSION：敵を攻撃して\n4体撃破を目指せ！',
        _ChanceMode.bubble => 'MISSION：湧き続けるバブルを\n全部PAN!して宝箱を出せ！',
      };
    });
  }

  void _startAmbientMotion() {
    _ambientTimer?.cancel();
    _ambientTimer = Timer.periodic(const Duration(milliseconds: 40), (_) {
      if (!mounted || !_missionReady || _revealed) return;
      setState(() {
        _ambientT += .055;
        for (var i = 0; i < _battlePush.length; i++) {
          _battlePush[i] = _battlePush[i] * .82;
        }
        if (_battleBurstPhase < 1) {
          _battleBurstPhase = (_battleBurstPhase + .075).clamp(0.0, 1.0);
        }
      });
    });
  }

  void _stopAmbientMotion() {
    _ambientTimer?.cancel();
    _ambientTimer = null;
  }

  void _startMission() {
    _fxImpact();
    setState(() {
      _missionReady = true;
      _message = switch (_mode!) {
        _ChanceMode.instant => '光のコアを10回たたこう！',
        _ChanceMode.stepUp => 'STEP 1：3つの鍵から好きな鍵を選べ！',
        _ChanceMode.battle => 'モンスター1を追いかけてタップ！',
        _ChanceMode.bubble => '画面をなぞって、すべてのバブルをPAN！',
      };
    });
    _startAmbientMotion();
    if (_mode == _ChanceMode.bubble) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _ensureBubbleGameStarted());
    }
  }

  static const List<String> _rouletteNames = [
    'キュインチャレンジ',
    'トレジャーアンロック',
    'モンスターブレイク4',
    'バブルトレジャー',
  ];

  void _startRoulette() {
    if (_rouletteSpinning || _mode != null) return;
    _fxImpact();
    _rouletteTimer?.cancel();
    setState(() {
      _rouletteSpinning = true;
      _rouletteCanStop = false;
      _message = 'ルーレット START！';
    });
    var ticks = 0;
    _rouletteTimer = Timer.periodic(const Duration(milliseconds: 115), (timer) {
      if (!mounted) { timer.cancel(); return; }
      ticks++;
      setState(() => _rouletteIndex = (_rouletteIndex + 1) % _ChanceMode.values.length);
      SfxManager.instance.tap();
      if (ticks >= 9 && !_rouletteCanStop) setState(() => _rouletteCanStop = true);
    });
  }

  void _stopRoulette() {
    if (!_rouletteSpinning || !_rouletteCanStop) return;
    _rouletteTimer?.cancel();
    _rouletteSpinning = false;
    _rouletteCanStop = false;
    final target = _ChanceMode.values.indexOf(_rouletteTarget);
    var steps = (target - _rouletteIndex) % _ChanceMode.values.length;
    if (steps < 3) steps += _ChanceMode.values.length;
    var i = 0;
    Timer.periodic(const Duration(milliseconds: 170), (timer) {
      if (!mounted) { timer.cancel(); return; }
      i++;
      setState(() => _rouletteIndex = (_rouletteIndex + 1) % _ChanceMode.values.length);
      SfxManager.instance.chanceStepUp();
      if (i >= steps) {
        timer.cancel();
        _fxImpact();
        _flash(cutIn: '決定!!', strong: true);
        Future<void>.delayed(const Duration(milliseconds: 850), () {
          if (mounted) _choose(_rouletteTarget);
        });
      }
    });
  }

  int get _bubbleTotal => 72;

  void _ensureBubbleGameStarted([int retry = 0]) {
    if (!mounted || _mode != _ChanceMode.bubble || !_missionReady || _bubbles.isNotEmpty) return;
    if (_bubbleFieldSize == Size.zero || !_bubbleFieldSize.width.isFinite || !_bubbleFieldSize.height.isFinite || _bubbleFieldSize.width <= 1 || _bubbleFieldSize.height <= 1) {
      if (retry < 12) {
        Future<void>.delayed(const Duration(milliseconds: 80), () => _ensureBubbleGameStarted(retry + 1));
      }
      return;
    }
    _startBubbleGame();
  }

  void _startBubbleGame() {
    if (!mounted || _mode != _ChanceMode.bubble || !_missionReady || _bubbleFieldSize == Size.zero || _bubbles.isNotEmpty) return;
    _bubblePopped = 0;
    _bubbleFinished = false;
    _bubbleTreasureRising = false;
    _bubbleChestLift = 0;
    _bubbles.clear();
    _bubbleBursts.clear();
    for (var i = 0; i < _bubbleTotal; i++) {
      final radius = 10.0 + _rng.nextDouble() * 8.0;
      final specialChance = _resultLevel == 4 ? .22 : _resultLevel == 3 ? .12 : _resultLevel == 2 ? .06 : .025;
      // V69: show the first wave immediately after START instead of making
      // every bubble wait below the play field. Later bubbles remain staggered.
      final firstWave = i < 18;
      final spawnY = firstWave
          ? _bubbleFieldSize.height * (.58 + _rng.nextDouble() * .38)
          : _bubbleFieldSize.height + 10 + _rng.nextDouble() * (_bubbleFieldSize.height * 1.35);
      _bubbles.add(_TreasureBubble(
        x: radius + _rng.nextDouble() * math.max(1, _bubbleFieldSize.width - radius * 2),
        y: spawnY,
        radius: radius,
        speed: 1.65 + _rng.nextDouble() * 1.35,
        phase: _rng.nextDouble() * math.pi * 2,
        kind: _rng.nextInt(5),
        special: _rng.nextDouble() < specialChance,
      ));
    }
    _bubbleTimer?.cancel();
    _bubbleTimer = Timer.periodic(const Duration(milliseconds: 33), (_) => _tickBubbles());
    setState(() {});
  }

  void _tickBubbles() {
    if (!mounted || _mode != _ChanceMode.bubble || !_missionReady) return;
    if (_bubbleFinished) return;
    for (final b in _bubbles) {
      if (b.popped) continue;
      b.phase += .065;
      b.y -= b.speed;
      b.x += math.sin(b.phase) * .46;
      if (b.y < -b.radius - 4) {
        b.y = _bubbleFieldSize.height + b.radius + 6 + _rng.nextDouble() * 120;
        b.x = b.radius + _rng.nextDouble() * math.max(1, _bubbleFieldSize.width - b.radius * 2);
      }
    }
    for (final burst in _bubbleBursts) burst.life -= .07;
    _bubbleBursts.removeWhere((e) => e.life <= 0);
    setState(() {});
  }

  void _popBubblesAt(Offset p) {
    if (!_missionReady || _bubbleFinished || _mode != _ChanceMode.bubble) return;
    var hit = 0;
    for (final b in _bubbles) {
      if (b.popped) continue;
      final dx = b.x - p.dx;
      final dy = b.y - p.dy;
      if (dx * dx + dy * dy <= math.pow(b.radius + 13, 2)) {
        b.popped = true;
        hit++;
        _bubblePopped++;
        _bubbleBursts.add(_BubbleBurst(Offset(b.x, b.y), b.special ? 1.35 : 1));
        SfxManager.instance.tap();
      }
    }
    if (hit == 0) return;
    if (_bubblePopped == 20 || _bubblePopped == 45) {
      SfxManager.instance.chanceStepUp();
      _flash(cutIn: _bubblePopped == 45 ? 'あと少し!!' : 'PAN! COMBO!', strong: false);
    }
    if (_bubblePopped >= _bubbleTotal) _finishBubbleTreasure();
    setState(() => _message = 'PAN!  $_bubblePopped / $_bubbleTotal');
  }

  void _finishBubbleTreasure() {
    if (_bubbleFinished) return;
    _bubbleFinished = true;
    _bubbleTimer?.cancel();
    setState(() {
      _bubbleTreasureRising = true;
      _message = 'ALL CLEAR！……何か出てくる！';
    });
    SfxManager.instance.chanceFlash();
    _flash(cutIn: 'ALL CLEAR!!', strong: true);
    var lift = 0;
    Timer.periodic(const Duration(milliseconds: 45), (timer) {
      if (!mounted) { timer.cancel(); return; }
      lift++;
      setState(() => _bubbleChestLift = (lift / 18).clamp(0.0, 1.0));
      if (lift >= 18) {
        timer.cancel();
        Future<void>.delayed(const Duration(milliseconds: 600), () {
          if (!mounted) return;
          if (_result == 4000) {
            _fxKyuiin();
            setState(() => _message = '虹の宝箱！！ キュイーーーン！！');
          } else if (_result == 3000) {
            SfxManager.instance.chanceRevival();
            _flash(cutIn: 'GOLD TREASURE!!', strong: true);
            setState(() => _message = '金の宝箱が出現！！');
          } else if (_result == 2000) {
            SfxManager.instance.reaction();
            _flash(cutIn: 'SILVER TREASURE!', strong: true);
            setState(() => _message = '銀の宝箱が出現！');
          } else {
            SfxManager.instance.unlock();
            _flash(cutIn: 'TREASURE!', strong: false);
            setState(() => _message = '宝箱を発見！');
          }
          Future<void>.delayed(Duration(milliseconds: _result == 4000 ? 2800 : 1700), _reveal);
        });
      }
    });
  }

  void _instantTap() {
    if (_revealed || _sequenceLocked || !_missionReady) return;
    _fxTap();
    if (_instantTaps < 10) {
      setState(() {
        _instantTaps++;
        _step = 1;
        _message = _instantTaps >= 10 ? 'チャージ開始！ さらにランプを連打！' : 'ランプが育つ！ $_instantTaps / 10';
      });
      if (_instantTaps == 5) _flash(cutIn: 'CHANCE ×5!', strong: false);
      if (_instantTaps == 10) { SfxManager.instance.chanceStepUp(); _flash(cutIn: 'CHARGE READY!', strong: true); }
      return;
    }
    setState(() {
      _instantTaps++;
      _charge = (_charge + .10).clamp(0.0, 1.0);
      _message = '連打でチャージ！ ${(100 * _charge).round()}%';
    });
    if (_charge < 1) return;
    _sequenceLocked = true;
    SfxManager.instance.chanceFlash();
    _flash(cutIn: 'JUDGE!!', strong: true);
    setState(() => _message = 'MAX！ 判定！！');
    Future<void>.delayed(const Duration(milliseconds: 800), () {
      if (!mounted || _revealed) return;
      if (_resultLevel >= 3) {
        _fxKyuiin();
        setState(() { _step = 6; _message = _result == 4000 ? 'キュイン！キュイン！キュイーーーン！！' : 'キュイン！ キュイン！！'; });
      } else if (_result == 2000) {
        SfxManager.instance.reaction(); _flash(cutIn: 'CHANCE!', strong: true);
        setState(() => _message = 'ピキーン！ CHANCE！');
      } else {
        SfxManager.instance.tap(); setState(() => _message = '……ポンッ！');
      }
      Future<void>.delayed(Duration(milliseconds: _resultLevel >= 3 ? 2700 : 1650), _reveal);
    });
  }

  static const _missions = ['鍵を発見！', 'タイミング成功！', '連打突破！', '封印チャージ完了！'];

  void _stepAdvance(String cut) {
    if (_revealed || _sequenceLocked) return;
    _fxRise(_step + 2);
    setState(() { _step++; _stepTaps = 0; _charge = 0; _message = _step < 4 ? _missions[_step - 1] : '最終ジャッジ……'; });
    _flash(cutIn: cut, strong: _step >= 4);
    if (_step < 4) return;
    _sequenceLocked = true;
    SfxManager.instance.chanceFlash();
    Future<void>.delayed(const Duration(milliseconds: 900), () {
      if (!mounted || _revealed) return;
      if (_resultLevel >= 3) {
        SfxManager.instance.chanceFake(); SfxManager.instance.error();
        setState(() { _message = '……開かない！？'; }); _flash(cutIn: 'STOP!?', strong: false);
        Future<void>.delayed(const Duration(milliseconds: 1200), () {
          if (!mounted || _revealed) return;
          _stepRevival = true; SfxManager.instance.chanceRevival(); _fxImpact();
          _flash(cutIn: _result == 4000 ? '虹昇格!!' : '復活!!', strong: true);
          setState(() { _message = _result == 4000 ? '復活！ 虹の宝箱へ昇格！！' : '復活！ 宝箱が覚醒！！'; });
          Future<void>.delayed(const Duration(milliseconds: 1600), _reveal);
        });
      } else {
        _fxImpact(); _flash(cutIn: 'TREASURE OPEN!', strong: true); setState(() { _message = '宝箱OPEN！'; });
        Future<void>.delayed(const Duration(milliseconds: 1450), _reveal);
      }
    });
  }

  void _stepKey(int key) { if (_step == 0) _stepAdvance('KEY ${key + 1} GET!'); }
  void _stepTiming() { if (_step == 1) _stepAdvance('NICE STOP!'); }
  void _stepMash() {
    if (_step != 2 || _sequenceLocked) return;
    _fxTap(); setState(() { _stepTaps++; _message = '連打！ $_stepTaps / 12'; });
    if (_stepTaps >= 12) _stepAdvance('BREAK!!');
  }
  void _stepSealTap() {
    if (_step != 3 || _sequenceLocked) return;
    _fxTap();
    setState(() {
      _stepTaps++;
      _charge = (_stepTaps / 8).clamp(0.0, 1.0);
      _message = '封印を連打！ $_stepTaps / 8';
    });
    if (_stepTaps >= 8) _stepAdvance('SEAL BREAK!!');
  }

  // V80: moving targets use taps only; long-press chase controls were removed.

  void _battleTap() {
    if (_revealed || _sequenceLocked || !_missionReady || _battleTarget >= 4) return;
    _battleHits++;
    SfxManager.instance.chanceBattleHit();
    const hitTable = <int>[8, 10, 12, 15];
    final hitsNeeded = hitTable[_battleTarget];
    final angle = _rng.nextDouble() * math.pi * 2;
    final force = 18.0 + _rng.nextDouble() * 10.0;
    _battlePush[_battleTarget] = Offset(math.cos(angle) * force, math.sin(angle) * force);
    setState(() {
      _step++;
      _battleImpact = true;
      _message = _battleHits >= hitsNeeded ? '必殺！' : 'HIT！ 連打！';
    });
    _flash(
      cutIn: _battleHits >= hitsNeeded ? 'CRITICAL!!' : 'HIT!',
      strong: _battleHits >= hitsNeeded,
    );
    if (_battleHits < hitsNeeded) return;

    _battleHits = 0;
    final canDefeat = _defeated < _resultLevel;
    if (!canDefeat) {
      _battleFailureSequence();
      return;
    }

    // V64: later enemies can counter just before defeat, then the player revives
    // with a finishing blow. The final result itself is still predetermined.
    final dramaticReversal = _battleTarget >= 2;
    if (dramaticReversal) {
      _sequenceLocked = true;
      _battleReversal = true;
      SfxManager.instance.chanceFake();
      SfxManager.instance.error();
      setState(() { _message = '敵の反撃！！ 危ない！！'; });
      _flash(cutIn: 'DANGER!!', strong: true);
      Future<void>.delayed(const Duration(milliseconds: 1100), () {
        if (!mounted || _revealed) return;
        SfxManager.instance.chanceBattleReversal();
        SfxManager.instance.chanceRevival();
        setState(() { _message = 'まだ終わらない！！'; });
        _flash(cutIn: '逆転必殺!!', strong: true);
        Future<void>.delayed(const Duration(milliseconds: 850), () {
          if (!mounted || _revealed) return;
          _finishBattleEnemy();
        });
      });
    } else {
      _finishBattleEnemy();
    }
  }

  void _finishBattleEnemy() {
    if (!mounted || _revealed) return;
    _fxImpact();
    SfxManager.instance.chanceEnemyDown();
    setState(() {
      _battleBurstIndex = _battleTarget;
      _battleBurstPhase = 0;
      _defeated++;
      _battleTarget++;
      _battleReversal = false;
      _message = '撃破！！  $_defeated / 4';
    });
    _flash(
      cutIn: _defeated == 4 ? 'PERFECT K.O.!!' : 'ENEMY DOWN!!',
      strong: true,
    );

    if (_defeated < _resultLevel) {
      _sequenceLocked = false;
      return;
    }
    if (_defeated == 4) {
      setState(() => _message = '全滅！！ PERFECT！！');
      Future<void>.delayed(const Duration(milliseconds: 1450), _reveal);
      return;
    }

    // Show the next enemy surviving and counterattacking, so the defeated count
    // itself becomes the visible reward rank.
    Future<void>.delayed(const Duration(milliseconds: 950), () {
      if (!mounted || _revealed) return;
      _battleFailureSequence();
    });
  }

  void _battleFailureSequence() {
    if (!mounted || _revealed) return;
    _sequenceLocked = true;
    SfxManager.instance.chanceFake();
    setState(() { _message = '次の敵が立ちはだかる……'; });
    _flash(cutIn: 'NEXT ENEMY...', strong: false);
    Future<void>.delayed(const Duration(milliseconds: 1000), () {
      if (!mounted || _revealed) return;
      SfxManager.instance.error();
      SfxManager.instance.bomb();
      setState(() { _message = '強烈な反撃！！ ここまで！'; });
      _flash(cutIn: 'COUNTER!!', strong: true);
      Future<void>.delayed(const Duration(milliseconds: 1450), _reveal);
    });
  }

  void _reveal() {
    if (!mounted || _revealed) return;
    _stopAmbientMotion();
    setState(() { _revealed = true; _message = _result == 4000 ? 'PERFECT BONUS！！' : '報酬 GET！'; });
    if (_result == 4000) {
      if (!_perfectFxPlayed) _fxKyuiin();
    } else {
      SfxManager.instance.unlock();
      SfxManager.instance.chanceRewardBurst();
    }
  }

  @override
  Widget build(BuildContext context) {
    final content = SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: _mode == null ? _modeSelect() : _modePlay(),
      ),
    );
    return Scaffold(
      backgroundColor: const Color(0xFFF7F3ED),
      body: Stack(
        fit: StackFit.expand,
        children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 75),
            transform: Matrix4.translationValues(_shake ? 7 : 0, _shake ? -4 : 0, 0),
            child: content,
          ),
          IgnorePointer(
            child: AnimatedOpacity(
              duration: const Duration(milliseconds: 80),
              opacity: _screenFlash ? .88 : 0,
              child: Container(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    colors: [Colors.white, _heatColor.withOpacity(.88), Colors.transparent],
                    stops: const [0, .32, 1],
                  ),
                ),
              ),
            ),
          ),
          if (_cutIn != null)
            IgnorePointer(
              child: Center(
                child: AnimatedScale(
                  duration: const Duration(milliseconds: 120),
                  scale: _screenFlash ? 1.08 : .92,
                  child: Transform.rotate(
                    angle: -.045,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [const Color(0xFFFDFBF8).withOpacity(.96), _heatColor.withOpacity(.22), const Color(0xFFFDFBF8).withOpacity(.96)],
                        ),
                        border: Border.all(color: _heatColor.withOpacity(.45), width: 1.5),
                        boxShadow: [BoxShadow(color: _heatColor.withOpacity(.8), blurRadius: 28, spreadRadius: 4)],
                      ),
                      child: Text(
                        _cutIn!,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: const Color(0xFF4F4A45),
                          fontSize: 30,
                          fontWeight: FontWeight.w900,
                          letterSpacing: .2,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _modeSelect() => Column(children: [
    const SizedBox(height: 8),
    const Text('ミニゲームを選んでテスト', style: TextStyle(color: Color(0xFF514C47), fontSize: 24, fontWeight: FontWeight.w800)),
    const SizedBox(height: 6),
    const Text('ルーレットは一時停止中です', style: TextStyle(color: Color(0xFF98918A), fontWeight: FontWeight.w600)),
    const SizedBox(height: 18),
    Expanded(child: GridView.count(
      crossAxisCount: 2,
      mainAxisSpacing: 12,
      crossAxisSpacing: 12,
      childAspectRatio: 1.18,
      children: [
        _testModeTile(_ChanceMode.instant, Icons.notifications_active_rounded, 'キュイン\nチャレンジ', const Color(0xFFE6B84D)),
        _testModeTile(_ChanceMode.stepUp, Icons.inventory_2_rounded, 'トレジャー\nアンロック', const Color(0xFFE79B70)),
        _testModeTile(_ChanceMode.battle, Icons.sports_mma_rounded, 'モンスター\nブレイク4', const Color(0xFFB58AC8)),
        _testModeTile(_ChanceMode.bubble, Icons.bubble_chart_rounded, 'バブル\nトレジャー', const Color(0xFF65BFC8)),
      ],
    )),
    Text('ごほうび倍率  ×${widget.multiplier}', style: const TextStyle(color: Color(0xFFB88643), fontWeight: FontWeight.w700)),
  ]);

  Widget _testModeTile(_ChanceMode mode, IconData icon, String label, Color accent) => Material(
    color: Colors.transparent,
    child: InkWell(
      onTap: () => _choose(mode),
      borderRadius: BorderRadius.circular(24),
      child: Ink(
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(.94),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: accent.withOpacity(.42), width: 1.4),
          boxShadow: const [BoxShadow(color: Color(0x124A3E35), blurRadius: 14, offset: Offset(0, 6))],
        ),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Container(width: 62, height: 62, decoration: BoxDecoration(color: accent.withOpacity(.16), shape: BoxShape.circle), child: Icon(icon, color: accent, size: 34)),
          const SizedBox(height: 12),
          Text(label, textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFF514C47), fontSize: 17, height: 1.18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 7),
          const Text('タップして遊ぶ', style: TextStyle(color: Color(0xFF9A938C), fontSize: 11, fontWeight: FontWeight.w600)),
        ]),
      ),
    ),
  );

  Widget _modeCard(_ChanceMode mode, IconData icon, String title, String sub, Color accent) => Expanded(child: InkWell(onTap: () => _choose(mode), borderRadius: BorderRadius.circular(24), child: Ink(decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), gradient: LinearGradient(colors: [accent.withOpacity(.30), const Color(0xFF21113F)]), border: Border.all(color: accent.withOpacity(.75), width: 2), boxShadow: [BoxShadow(color: accent.withOpacity(.16), blurRadius: 18)]), child: Padding(padding: const EdgeInsets.symmetric(horizontal: 17), child: Row(children: [Container(width: 62, height: 62, decoration: BoxDecoration(shape: BoxShape.circle, color: accent.withOpacity(.18), border: Border.all(color: accent, width: 2)), child: Icon(icon, color: accent, size: 36)), const SizedBox(width: 15), Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)), const SizedBox(height: 5), Text(sub, style: TextStyle(color: Colors.white.withOpacity(.72), fontSize: 12.5))])), const Icon(Icons.chevron_right_rounded, color: Colors.white70)])))));

  Widget _modePlay() {
    final title = switch (_mode!) { _ChanceMode.instant => '⚡ キュインチャレンジ', _ChanceMode.stepUp => '🔑 トレジャーアンロック', _ChanceMode.battle => '⚔️ モンスターブレイク4', _ChanceMode.bubble => '🫧 バブルトレジャー' };
    final accent = _mode == _ChanceMode.instant ? const Color(0xFFFFD740) : _mode == _ChanceMode.stepUp ? const Color(0xFFFF7043) : _mode == _ChanceMode.battle ? const Color(0xFFE040FB) : const Color(0xFF26C6DA);
    return Column(children: [
      Row(children: [IconButton(onPressed: _revealed ? null : () { _bubbleTimer?.cancel(); _stopAmbientMotion(); _bubbles.clear(); setState(() { _mode = null; _missionReady = false; }); }, icon: const Icon(Icons.arrow_back_rounded, color: Color(0xFF625C56))), Expanded(child: Text(title, textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFF514C47), fontSize: 21, fontWeight: FontWeight.w800))), const SizedBox(width: 48)]),
      const SizedBox(height: 8),
      Expanded(
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          width: double.infinity,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(28),
            gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.white.withOpacity(.98), accent.withOpacity(.08)]),
            border: Border.all(color: (_step >= 3 ? _heatColor : accent).withOpacity(.28), width: 1.2),
            boxShadow: const [BoxShadow(color: Color(0x164A3E35), blurRadius: 24, offset: Offset(0, 10))],
          ),
          child: _revealed ? _resultView() : (_missionReady ? _playBody() : _missionIntro()),
        ),
      ),
      if (!_missionReady && !_revealed) ...[
        const SizedBox(height: 14),
        // V75: START is a true sibling of the game panel. Nothing is stacked over
        // this area, so its painted position and hit-test position stay identical.
        SizedBox(
          width: double.infinity,
          height: 68,
          child: FilledButton.icon(
            onPressed: _startMission,
            icon: const Icon(Icons.play_arrow_rounded, size: 28),
            label: const Text('はじめる', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            style: FilledButton.styleFrom(
              backgroundColor: const Color(0xFFE2A964),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
              elevation: 4,
            ),
          ),
        ),
      ],
    ]);
  }

  Widget _playBody() {
    if (!_missionReady) return _missionIntro();
    if (_mode == _ChanceMode.battle) return _battleBody();
    if (_mode == _ChanceMode.stepUp) return _stepBody();
    if (_mode == _ChanceMode.bubble) return _bubbleBody();
    return _instantBody();
  }

  Widget _missionIntro() {
    final icon = switch (_mode!) {
      _ChanceMode.instant => Icons.notifications_active_rounded,
      _ChanceMode.stepUp => Icons.inventory_2_rounded,
      _ChanceMode.battle => Icons.sports_mma_rounded,
      _ChanceMode.bubble => Icons.bubble_chart_rounded,
    };
    final hint = switch (_mode!) {
      _ChanceMode.instant => '中央のパトランプを10回タップ\nそのあと連打で光をためよう',
      _ChanceMode.stepUp => '動いているものを直接タップ\n選ぶ・止める・連打・連打で宝箱へ',
      _ChanceMode.battle => '画面を動き回るモンスターを追いかけてタップ\n3体目は連打で力をためよう',
      _ChanceMode.bubble => '泡をタップ、または指でなぞって弾けさせる\n全部なくなると宝箱が現れるよ',
    };
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Text('あそびかた', style: TextStyle(color: Color(0xFFB78A4E), fontSize: 16, fontWeight: FontWeight.w800)),
        const SizedBox(height: 18),
        Container(width: 94, height: 94, decoration: BoxDecoration(color: const Color(0xFFF5EBDD), borderRadius: BorderRadius.circular(30)), child: Icon(icon, color: const Color(0xFFB78A4E), size: 52)),
        const SizedBox(height: 22),
        Text(_message, textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFF514C47), fontSize: 24, height: 1.45, fontWeight: FontWeight.w800)),
        const SizedBox(height: 20),
        Container(padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14), decoration: BoxDecoration(color: const Color(0xFFF7F2EC), borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFE8DFD6))), child: Text(hint, textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFF7E7770), fontSize: 15, height: 1.6, fontWeight: FontWeight.w600))),
      ]),
    );
  }

  Widget _instantBody() {
    final tapRatio = (_instantTaps.clamp(0, 10) / 10).clamp(0.0, 1.0);
    final pulse = (math.sin(_ambientT * 2.2) + 1) * .5;
    final scale = .92 + tapRatio * .12 + _charge * .18 + pulse * .025;
    final lampOpacity = (.18 + tapRatio * .42 + _charge * .35).clamp(0.0, .95);
    return Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      const Text('中央のパトランプを直接たたこう', style: TextStyle(color: Color(0xFF8C7A57), fontWeight: FontWeight.w800)),
      const SizedBox(height: 10),
      Text(_instantTaps < 10 ? '$_instantTaps / 10' : 'チャージ  ${(100 * _charge).round()}%', style: const TextStyle(color: Color(0xFF625C56), fontSize: 20, fontWeight: FontWeight.w800)),
      const SizedBox(height: 16),
      GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: _instantTap,
        child: Transform.scale(
          scale: scale,
          child: SizedBox(
            width: 190,
            height: 205,
            child: Stack(alignment: Alignment.bottomCenter, children: [
              Container(
                width: 180, height: 112,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(34),
                  color: const Color(0xFFF6EFE7),
                  border: Border.all(color: const Color(0xFFCDBFAF), width: 2),
                  boxShadow: const [BoxShadow(color: Color(0x254A3E35), blurRadius: 18, offset: Offset(0, 9))],
                ),
              ),
              Positioned(
                top: 16,
                child: Container(
                  width: 126, height: 112,
                  decoration: BoxDecoration(
                    borderRadius: const BorderRadius.vertical(top: Radius.circular(64), bottom: Radius.circular(28)),
                    gradient: RadialGradient(center: const Alignment(0, -.35), colors: [Colors.white.withOpacity(.98), Color.lerp(const Color(0xFFFFCDD2), const Color(0xFFFF1744), tapRatio)!, const Color(0xFFD50000)]),
                    border: Border.all(color: const Color(0xFFB71C1C), width: 3),
                    boxShadow: [BoxShadow(color: const Color(0xFFFF1744).withOpacity(lampOpacity), blurRadius: 24 + 34 * tapRatio + 24 * _charge, spreadRadius: 2 + 7 * _charge)],
                  ),
                  child: Stack(alignment: Alignment.center, children: [
                    Transform.rotate(angle: _ambientT * (1.2 + tapRatio * 2.4), child: Container(width: 92, height: 8, decoration: BoxDecoration(color: Colors.white.withOpacity(.76), borderRadius: BorderRadius.circular(8)))),
                    Icon(Icons.notifications_active_rounded, color: Colors.white.withOpacity(.94), size: 48 + 12 * tapRatio),
                  ]),
                ),
              ),
              Positioned(bottom: 18, child: Text(_instantTaps < 10 ? 'TAP' : 'HOLD', style: const TextStyle(color: Color(0xFF6E6257), fontSize: 16, fontWeight: FontWeight.w900, letterSpacing: 1.4))),
            ]),
          ),
        ),
      ),
      const SizedBox(height: 16),
      Text(_instantTaps < 10 ? '押すたびにランプが大きく・強く光る' : (_holding ? 'そのまま連打…' : '同じランプを連打'), style: const TextStyle(color: Color(0xFF625C56), fontSize: 16, fontWeight: FontWeight.w800)),
      const SizedBox(height: 8),
      Text(_message, textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFF8A837C), fontSize: 14, fontWeight: FontWeight.w600)),
    ]);
  }

  Widget _stepBody() => Column(mainAxisAlignment: MainAxisAlignment.center, children: [
    Text('宝箱まで  ${(_step + 1).clamp(1,4)}/4', style: const TextStyle(color: Color(0xFFB78A4E), fontWeight: FontWeight.w800)),
    const SizedBox(height: 8),
    Text(_message, textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFF625C56), fontSize: 17, fontWeight: FontWeight.w800)),
    const SizedBox(height: 14),
    if (_step == 0) ...[
      const Text('動き回る鍵を追いかけてタップ', style: TextStyle(color: Color(0xFF93877C), fontSize: 13)),
      const SizedBox(height: 8),
      SizedBox(
        height: 220,
        child: LayoutBuilder(builder: (context, c) {
          final w = c.maxWidth;
          final h = c.maxHeight;
          return Stack(children: List.generate(3, (i) {
            final t = _ambientT + i * 2.1;
            final x = 18 + (w - 92) * (.5 + .5 * math.sin(t * (.85 + i * .06)));
            final y = 12 + (h - 112) * (.5 + .5 * math.cos(t * (1.07 + i * .05)));
            return Positioned(
              left: x.clamp(6.0, math.max(6.0, w - 88)),
              top: y.clamp(4.0, math.max(4.0, h - 108)),
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => _stepKey(i),
                child: Transform.rotate(
                  angle: math.sin(t * 1.7) * .10,
                  child: Container(width: 82, height: 104, decoration: BoxDecoration(color: const Color(0xFFFFF7E8), borderRadius: BorderRadius.circular(24), border: Border.all(color: const Color(0xFFE7C98C), width: 1.5), boxShadow: const [BoxShadow(color: Color(0x1A8B6E42), blurRadius: 12, offset: Offset(0, 5))]), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [const Icon(Icons.key_rounded, size: 42, color: Color(0xFFD5A449)), const SizedBox(height: 7), Text('${i+1}', style: const TextStyle(color: Color(0xFF7A6955), fontWeight: FontWeight.w800))])),
                ),
              ),
            );
          }));
        }),
      ),
    ],
    if (_step == 1) ...[
      const Text('流れる光が中央に来た瞬間にタップ', textAlign: TextAlign.center, style: TextStyle(color: Color(0xFF93877C), fontSize: 13)),
      const SizedBox(height: 18),
      GestureDetector(
        behavior: HitTestBehavior.opaque, onTap: _stepTiming,
        child: Container(width: 300, height: 88, padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: const Color(0xFFF4EEE7), borderRadius: BorderRadius.circular(22)), child: Stack(children: [
          Center(child: Container(width: 52, height: 58, decoration: BoxDecoration(color: const Color(0xFFFFD978).withOpacity(.38), borderRadius: BorderRadius.circular(16)))),
          Align(alignment: Alignment(math.sin(_ambientT * 2.3), 0), child: Container(width: 28, height: 58, decoration: BoxDecoration(color: const Color(0xFFE29B67), borderRadius: BorderRadius.circular(14), boxShadow: const [BoxShadow(color: Color(0x55E29B67), blurRadius: 14)]))),
        ])),
      ),
    ],
    if (_step == 2) ...[
      Text('$_stepTaps / 12', style: const TextStyle(color: Color(0xFFB78A4E), fontSize: 24, fontWeight: FontWeight.w900)),
      const SizedBox(height: 8),
      GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: _stepMash,
        child: Transform.translate(
          offset: Offset(math.sin(_ambientT * 1.9) * 46, math.cos(_ambientT * 2.4) * 18),
          child: Transform.rotate(
            angle: math.sin(_ambientT * 2.1) * .08,
            child: Container(width: 160, height: 140, decoration: BoxDecoration(color: const Color(0xFFF7E9D5), borderRadius: BorderRadius.circular(30), boxShadow: const [BoxShadow(color: Color(0x1A6D5743), blurRadius: 18, offset: Offset(0, 8))]), child: const Icon(Icons.inventory_2_rounded, size: 88, color: Color(0xFF9B7555))),
          ),
        ),
      ),
      const SizedBox(height: 8), const Text('動く宝箱を追いかけて連打！', style: TextStyle(color: Color(0xFF93877C), fontWeight: FontWeight.w700)),
    ],
    if (_step == 3) ...[
      SizedBox(width: 240, child: LinearProgressIndicator(value: _charge, minHeight: 12, borderRadius: BorderRadius.circular(8), backgroundColor: const Color(0xFFEDE5DD), valueColor: const AlwaysStoppedAnimation(Color(0xFFC49BD3)))),
      const SizedBox(height: 12),
      GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: _stepSealTap,
        child: Transform.translate(
          offset: Offset(math.sin(_ambientT * 1.45) * 36, math.cos(_ambientT * 1.8) * 10),
          child: Transform.scale(
            scale: (1 + .035 * math.sin(_ambientT * 2.8)),
            child: Container(width: 170, height: 150, decoration: BoxDecoration(color: const Color(0xFFF0E7F4), borderRadius: BorderRadius.circular(32), border: Border.all(color: const Color(0xFFC49BD3), width: 2), boxShadow: [BoxShadow(color: const Color(0xFFC49BD3).withOpacity(.16 + _charge * .35), blurRadius: 18 + _charge * 22)]), child: const Icon(Icons.lock_open_rounded, size: 84, color: Color(0xFF9A72AA))),
          ),
        ),
      ),
      const SizedBox(height: 8), Text('動く封印を追いかけて8回タップ', style: const TextStyle(color: Color(0xFF93877C), fontWeight: FontWeight.w700)),
    ],
  ]);

  Widget _battleBody() => Column(mainAxisAlignment: MainAxisAlignment.center, children: [
    Text('モンスター  $_defeated / 4', style: const TextStyle(color: Color(0xFFB78A4E), fontWeight: FontWeight.w800)),
    const SizedBox(height: 6),
    const Text('動き回るモンスターを追いかけよう', style: TextStyle(color: Color(0xFF8A837C), fontWeight: FontWeight.w700)),
    const SizedBox(height: 8),
    SizedBox(
      height: 250,
      child: LayoutBuilder(builder: (context, c) {
        final w = c.maxWidth;
        final h = c.maxHeight;
        return Stack(children: List.generate(4, (i) {
          final dead = i < _defeated;
          final active = i == _battleTarget;
          const hitTable = <int>[8, 10, 12, 15];
          final maxHits = hitTable[i];
          final remain = active ? (1 - (_battleHits / maxHits)).clamp(0.0, 1.0) : (dead ? 0.0 : 1.0);
          final t = _ambientT + i * 1.55;
          final speed = 1.0 + i * .07;
          final x = 6 + (w - 92) * (.5 + .5 * math.sin(t * speed + i * .8));
          final y = 6 + (h - 102) * (.5 + .5 * math.cos(t * (1.18 + i * .05) + i));
          final bob = dead ? 0.0 : math.sin(t * 3.1) * 4.0;
          final pulse = active ? 1.0 + .055 * math.sin(t * 4.2) : 1.0;
          final size = active ? 72.0 : 64.0;
          return Positioned(
            left: (x + _battlePush[i].dx).clamp(2.0, math.max(2.0, w - 92)),
            top: (y + _battlePush[i].dy).clamp(2.0, math.max(2.0, h - 102)),
            child: GestureDetector(
              behavior: HitTestBehavior.translucent,
              onTap: active ? _battleTap : null,
              child: SizedBox(
                width: 92,
                height: 102,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    if (active && !dead)
                      Container(
                        width: 82,
                        height: 82,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFFC79AC2).withOpacity(.20 + .08 * (math.sin(t * 3.8) + 1)),
                              blurRadius: 24,
                              spreadRadius: 5,
                            ),
                          ],
                        ),
                      ),
                    if (active && !dead)
                      Transform.scale(
                        scale: 1 + .08 * math.sin(t * 3.5),
                        child: Container(
                          width: 78,
                          height: 78,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: const Color(0xFFC79AC2).withOpacity(.72), width: 2),
                          ),
                        ),
                      ),
                    Transform.translate(
                      offset: Offset(active && _battleImpact ? 5 : 0, bob + (active && _battleImpact ? -4 : 0)),
                      child: Transform.rotate(
                        angle: dead ? 0 : math.sin(t * 2.0) * .12,
                        child: Transform.scale(
                          scale: dead ? .72 : pulse,
                          child: Opacity(
                            opacity: dead ? .30 : 1,
                            child: SizedBox(
                              width: size,
                              height: size,
                              child: dead
                                  ? const Center(child: Text('💥', style: TextStyle(fontSize: 42)))
                                  : CustomPaint(painter: _BattleTsumPainter(type: i, selected: active)),
                            ),
                          ),
                        ),
                      ),
                    ),
                    if (_battleBurstIndex == i && _battleBurstPhase < 1)
                      IgnorePointer(
                        child: SizedBox(
                          width: 92,
                          height: 92,
                          child: CustomPaint(painter: _BattlePopPainter(progress: _battleBurstPhase)),
                        ),
                      ),
                    Positioned(
                      bottom: 2,
                      child: Column(
                        children: [
                          Text(
                            dead ? '撃破' : (active ? 'TARGET' : ''),
                            style: TextStyle(
                              color: dead ? const Color(0xFFAAA39C) : const Color(0xFF9A72AA),
                              fontSize: 9,
                              fontWeight: FontWeight.w900,
                              letterSpacing: .6,
                            ),
                          ),
                          const SizedBox(height: 2),
                          SizedBox(
                            width: 58,
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(6),
                              child: LinearProgressIndicator(
                                value: remain,
                                minHeight: 6,
                                backgroundColor: const Color(0x66D8D1CB),
                                valueColor: AlwaysStoppedAnimation<Color>(dead ? Colors.transparent : const Color(0xFFFF6B7A)),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }));
      }),
    ),
    if (_battleReversal) const Text('…まだ何か起こりそう！', style: TextStyle(color: Color(0xFFB78A4E), fontSize: 13, fontWeight: FontWeight.w900)),
    Text('${_battleHits + _defeated * 5} コンボ   ・   $_defeated / 4', style: TextStyle(color: _defeated >= 3 ? const Color(0xFFB78A4E) : const Color(0xFF625C56), fontSize: 22, fontWeight: FontWeight.w800)),
    const SizedBox(height: 6),
    Text(_message, textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFF625C56), fontSize: 16, fontWeight: FontWeight.w800)),
    const SizedBox(height: 8),
    Text(_battleTarget == 3 ? 'ボスを追いかけて連打！' : '動くモンスターを追いかけてタップ！', style: const TextStyle(color: Color(0xFF8A6B91), fontWeight: FontWeight.w800)),
  ]);

  Widget _bubbleBody() => Column(children: [
    const Text('泡をぜんぶ弾けさせよう', style: TextStyle(color: Color(0xFF5D9E9B), fontWeight: FontWeight.w800)),
    const SizedBox(height: 8),
    Row(mainAxisAlignment: MainAxisAlignment.center, children: [
      Text('あと ${_bubbleTotal - _bubblePopped}', style: const TextStyle(color: Color(0xFF5C5752), fontSize: 20, fontWeight: FontWeight.w800)),
      const SizedBox(width: 12),
      SizedBox(width: 130, child: LinearProgressIndicator(value: _bubblePopped / _bubbleTotal, minHeight: 10, borderRadius: BorderRadius.circular(8), backgroundColor: Colors.white12, valueColor: AlwaysStoppedAnimation(_heatColor))),
    ]),
    const SizedBox(height: 8),
    Expanded(
      child: LayoutBuilder(builder: (context, constraints) {
        final next = Size(constraints.maxWidth, constraints.maxHeight);
        if (next != _bubbleFieldSize) {
          _bubbleFieldSize = next;
          if (_missionReady && _bubbles.isEmpty) WidgetsBinding.instance.addPostFrameCallback((_) => _ensureBubbleGameStarted());
        }
        return ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: Listener(
            behavior: HitTestBehavior.opaque,
            onPointerDown: (e) => _popBubblesAt(e.localPosition),
            onPointerMove: (e) => _popBubblesAt(e.localPosition),
            child: Container(
              decoration: BoxDecoration(
                gradient: const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFFEAF7F4), Color(0xFFD7EFEC), Color(0xFFBFDCD9)]),
                border: Border.all(color: const Color(0x6699C8C2), width: 1),
              ),
              child: Stack(fit: StackFit.expand, children: [
                CustomPaint(painter: _BubbleTreasurePainter(bubbles: _bubbles, bursts: _bubbleBursts, resultLevel: _resultLevel)),
                if (_bubbleTreasureRising)
                  Align(
                    alignment: Alignment(0, 1.15 - .85 * _bubbleChestLift),
                    child: Transform.scale(
                      scale: .75 + .25 * _bubbleChestLift,
                      child: Container(
                        width: 150,
                        height: 105,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(22),
                          gradient: LinearGradient(colors: _resultLevel == 4 ? const [Color(0xFFE040FB), Color(0xFFFFD740), Color(0xFF00E5FF)] : _resultLevel == 3 ? const [Color(0xFFFF8F00), Color(0xFFFFD740)] : _resultLevel == 2 ? const [Color(0xFF78909C), Color(0xFFECEFF1)] : const [Color(0xFF6D4C41), Color(0xFFBCAAA4)]),
                          border: Border.all(color: Colors.white, width: 4),
                          boxShadow: [BoxShadow(color: _heatColor.withOpacity(.75), blurRadius: 28, spreadRadius: 4)],
                        ),
                        child: const Icon(Icons.inventory_2_rounded, color: Colors.white, size: 64),
                      ),
                    ),
                  ),
                Positioned(left: 12, right: 12, top: 10, child: Text(_message, textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFF514C47), fontSize: 16, fontWeight: FontWeight.w800))),
              ]),
            ),
          ),
        );
      }),
    ),
    const SizedBox(height: 7),
    const Text('指でサーッとなぞるだけでもOK', style: TextStyle(color: Color(0xFF9A938C), fontSize: 12, fontWeight: FontWeight.w600)),
  ]);

  Widget _pushButton(String text, Color color, {bool wide = false}) => Container(width: wide ? 210 : 160, height: wide ? 64 : 78, decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), color: color, border: Border.all(color: Colors.white.withOpacity(.82), width: 1.2), boxShadow: [BoxShadow(color: color.withOpacity(.24), blurRadius: 18, offset: const Offset(0, 8))]), alignment: Alignment.center, child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w800)));

  Widget _resultView() => Column(mainAxisAlignment: MainAxisAlignment.center, children: [
    if (_mode == _ChanceMode.battle) Text('$_defeated / 4 クリア', style: TextStyle(color: _heatColor, fontSize: 24, fontWeight: FontWeight.w900)),
    Text(_result == 4000 ? '✨ すごい！ ✨' : _heatText, style: TextStyle(color: _heatColor, fontSize: 30, fontWeight: FontWeight.w900)),
    const SizedBox(height: 16),
    Text('$_result', style: const TextStyle(color: Color(0xFF514C47), fontSize: 72, fontWeight: FontWeight.w800)),
    const Text('EXP', style: TextStyle(color: Color(0xFF918A83), fontSize: 18, fontWeight: FontWeight.w700)),
    if (widget.multiplier > 1) Padding(padding: const EdgeInsets.only(top: 10), child: Text('× ${widget.multiplier}  →  ${_result * widget.multiplier}', style: const TextStyle(color: Color(0xFFFFD54F), fontSize: 22, fontWeight: FontWeight.w900))),
    const SizedBox(height: 30),
    FilledButton(onPressed: () => Navigator.of(context).pop(_result), style: FilledButton.styleFrom(backgroundColor: const Color(0xFF7DB9A6), foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(horizontal: 44, vertical: 16)), child: const Text('受け取る', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
  ]);
}


class _SuruBoardPainter extends CustomPainter {
  const _SuruBoardPainter({
    required this.pieces,
    required this.flashes,
    required this.bursts,
    required this.hub,
    required this.ports,
    required this.pegs,
    required this.letterBumpers,
    required this.starBumper,
    required this.pockets,
    required this.separators,
    required this.playRect,
    required this.pieceRadius,
    required this.pegRadius,
    required this.manualFinger,
    required this.manualHoverPort,
    required this.rewardTokens,
    required this.rewardCounter,
    required this.expBeamStartedAt,
    required this.expCountStartedAt,
    required this.expBeamAmount,
    required this.expTransferApplied,
    required this.expTransferDurationMs,
    required this.centerPocketHits,
  });

  final List<_DropPiece> pieces;
  final List<_ConnectionFlash> flashes;
  final List<_PocketBurst> bursts;
  final Offset hub;
  final List<Offset> ports;
  final List<Offset> pegs;
  final List<({String label, Offset center})> letterBumpers;
  final Offset starBumper;
  final List<Offset> pockets;
  final List<double> separators;
  final Rect playRect;
  final double pieceRadius;
  final double pegRadius;
  final Offset? manualFinger;
  final int? manualHoverPort;
  final List<_RewardToken> rewardTokens;
  final int rewardCounter;
  final DateTime? expBeamStartedAt;
  final DateTime? expCountStartedAt;
  final int expBeamAmount;
  final int expTransferApplied;
  final int expTransferDurationMs;
  final int centerPocketHits;

  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          Color(0xFF243747),
          Color(0xFF2D4652),
          Color(0xFF31525A),
          Color(0xFF243C48),
        ],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, bg);

    // Decorative stars / light speckles.
    final sparkle = Paint()..color = const Color(0x338FC4B2);
    for (var i = 0; i < 34; i++) {
      final x = (i * 71.0) % size.width;
      final y =
          (28 + ((i * 137.0) % math.max(50.0, size.height - 80))).toDouble();
      canvas.drawCircle(Offset(x, y), i % 5 == 0 ? 1.8 : .8, sparkle);
    }

    final machineRect = Rect.fromLTRB(
      playRect.left,
      math.max(8.0, hub.dy - 34),
      playRect.right,
      math.min(size.height - 4, playRect.bottom + 155),
    );
    final arena = RRect.fromRectAndRadius(
      machineRect,
      const Radius.circular(28),
    );
    canvas.drawRRect(
      arena,
      Paint()..color = const Color(0xE82A414D),
    );
    canvas.drawRRect(
      arena,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = const Color(0xFF6F9297),
    );
    canvas.drawRRect(
      arena.deflate(6),
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..color = const Color(0xFFFFFFFF),
    );

    _drawRewardCounter(canvas);
    _drawConnectionArea(canvas);
    _drawPegs(canvas);
    _drawLetterBumpers(canvas);
    _drawStar(canvas);
    _drawPocketArea(canvas);
    _drawCenterPocketCount(canvas);
    _drawTrails(canvas);
    _drawPieces(canvas);
    _drawBursts(canvas);
    _drawRewardTransfers(canvas, size);
  }

  Offset get _counterCenter =>
      Offset(playRect.center.dx, playRect.top + 34);

  void _drawRewardCounter(Canvas canvas) {
    final center = _counterCenter;
    final rect = RRect.fromRectAndRadius(
      Rect.fromCenter(
        center: center,
        width: math.min(220.0, playRect.width * .72),
        height: 54,
      ),
      const Radius.circular(16),
    );

    canvas.drawRRect(
      rect.inflate(7),
      Paint()
        ..color = const Color(0x44FFBF32)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12),
    );
    canvas.drawRRect(
      rect,
      Paint()
        ..shader = const LinearGradient(
          colors: [
            Color(0xFF5B210B),
            Color(0xFF1B101C),
            Color(0xFF5B210B),
          ],
        ).createShader(rect.outerRect),
    );
    canvas.drawRRect(
      rect,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 4
        ..color = const Color(0xFFFFB733),
    );

    // LED dots.
    final dotPaint = Paint()..color = const Color(0x44FFB432);
    for (var row = 0; row < 4; row++) {
      for (var col = 0; col < 21; col++) {
        canvas.drawCircle(
          Offset(
            rect.left + 10 + col * (rect.width - 20) / 20,
            rect.top + 9 + row * 12,
          ),
          1.1,
          dotPaint,
        );
      }
    }

    // As soon as transfer begins the big counter visually becomes 0.
    final shown = rewardCounter;
    final tp = TextPainter(
      text: TextSpan(
        text: '$shown',
        style: const TextStyle(
          color: Color(0xFFFFF4BA),
          fontSize: 29,
          fontWeight: FontWeight.w900,
          shadows: [
            Shadow(color: Color(0xFFFF8B1F), blurRadius: 9),
            Shadow(color: Colors.black, blurRadius: 3),
          ],
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(
      canvas,
      center - Offset(tp.width / 2, tp.height / 2),
    );
  }

  void _drawRewardTransfers(Canvas canvas, Size size) {
    final now = DateTime.now();
    final counter = _counterCenter;

    // Reward stars fly from the hit/pocket location into the counter.
    for (final token in rewardTokens) {
      if (token.arrived) continue;
      final elapsed = now.difference(token.startedAt).inMilliseconds;
      final t = (elapsed / 430).clamp(0.0, 1.0);
      final eased = Curves.easeOutCubic.transform(t);
      final control = Offset(
        (token.origin.dx + counter.dx) / 2,
        math.min(token.origin.dy, counter.dy) - 55,
      );
      final oneMinus = 1 - eased;
      final pos =
          token.origin * (oneMinus * oneMinus) +
          control * (2 * oneMinus * eased) +
          counter * (eased * eased);

      canvas.drawCircle(
        pos,
        18,
        Paint()
          ..color = const Color(0x55FFE15A)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10),
      );

      final star = TextPainter(
        text: const TextSpan(
          text: '★',
          style: TextStyle(
            color: Color(0xFFFFE55C),
            fontSize: 19,
            fontWeight: FontWeight.w900,
            shadows: [
              Shadow(color: Color(0xFFFF8E1A), blurRadius: 6),
            ],
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      star.paint(canvas, pos - Offset(star.width / 2, star.height / 2));

      final number = TextPainter(
        text: TextSpan(
          text: '${token.amount}',
          style: const TextStyle(
            color: Colors.white,
            fontSize: 9,
            fontWeight: FontWeight.w900,
            shadows: [
              Shadow(color: Colors.black, blurRadius: 3),
            ],
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      number.paint(
        canvas,
        pos + Offset(10, -number.height / 2),
      );
    }

    // The counter total itself becomes light and flies to the EXP gauge.
    // During this travel phase the EXP value is still unchanged.
    if (expBeamStartedAt != null &&
        expBeamAmount > 0 &&
        expCountStartedAt == null) {
      final elapsed = now.difference(expBeamStartedAt!).inMilliseconds;
      const duration = 720;
      final t = (elapsed / duration).clamp(0.0, 1.0);
      final eased = Curves.easeInOutCubic.transform(t);
      final target = Offset(size.width * .58, -18);
      final pos = Offset.lerp(counter, target, eased)!;

      canvas.drawLine(
        counter,
        pos,
        Paint()
          ..color = const Color(0x66FFF29A)
          ..strokeWidth = 15 * (1 - t) + 4
          ..strokeCap = StrokeCap.round
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12),
      );
      canvas.drawLine(
        counter,
        pos,
        Paint()
          ..color = const Color(0xFFFFF8CB)
          ..strokeWidth = 3.5
          ..strokeCap = StrokeCap.round,
      );
      canvas.drawCircle(
        pos,
        16,
        Paint()
          ..color = const Color(0x99FFF1A8)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8),
      );

      final flyingNumber = TextPainter(
        text: TextSpan(
          text: '$expBeamAmount',
          style: const TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.w900,
            shadows: [
              Shadow(color: Color(0xFFFFB52E), blurRadius: 10),
              Shadow(color: Colors.black, blurRadius: 3),
            ],
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      flyingNumber.paint(
        canvas,
        pos - Offset(flyingNumber.width / 2, flyingNumber.height / 2),
      );
    }
  }

  void _drawConnectionArea(Canvas canvas) {
    canvas.drawCircle(
      hub,
      22,
      Paint()
        ..color = const Color(0x5546B5FF)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 14),
    );
    canvas.drawCircle(
      hub,
      17,
      Paint()..color = const Color(0xFF2C1C65),
    );
    canvas.drawCircle(
      hub,
      17,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.4
        ..color = const Color(0xFFA3E7FF),
    );

    final hubText = TextPainter(
      text: const TextSpan(
        text: '手動',
        style: TextStyle(
          color: Colors.white,
          fontSize: 7,
          fontWeight: FontWeight.w900,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    hubText.paint(
      canvas,
      hub - Offset(hubText.width / 2, hubText.height / 2),
    );

    final guide = Paint()
      ..color = const Color(0x3358BFFF)
      ..strokeWidth = 1.2;
    for (final port in ports) {
      canvas.drawLine(hub, port, guide);
    }

    final now = DateTime.now();
    for (final flash in flashes) {
      if (flash.port < 0 || flash.port >= ports.length) continue;
      final elapsed = now.difference(flash.startedAt).inMilliseconds;
      final t = (elapsed / 450).clamp(0.0, 1.0);
      final a = ((1 - t) * 255).round().clamp(0, 255);

      canvas.drawLine(
        hub,
        ports[flash.port],
        Paint()
          ..color = Color.fromARGB(a ~/ 2, 81, 206, 255)
          ..strokeWidth = 12
          ..strokeCap = StrokeCap.round
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8),
      );
      canvas.drawLine(
        hub,
        ports[flash.port],
        Paint()
          ..color = Color.fromARGB(a, 214, 250, 255)
          ..strokeWidth = 3.2
          ..strokeCap = StrokeCap.round,
      );
    }

    if (manualFinger != null) {
      final to = manualHoverPort == null
          ? manualFinger!
          : ports[manualHoverPort!];
      canvas.drawLine(
        hub,
        to,
        Paint()
          ..color = const Color(0xFFFFE25C)
          ..strokeWidth = 5
          ..strokeCap = StrokeCap.round,
      );
    }

    for (var i = 0; i < ports.length; i++) {
      final selected = i == manualHoverPort;
      final p = ports[i];

      canvas.drawCircle(
        p,
        selected ? 5.5 : 3.2,
        Paint()
          ..color = const Color(0x5526AFFF)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
      );
      canvas.drawCircle(
        p,
        selected ? 4.5 : 2.5,
        Paint()..color = const Color(0xFF0E1021),
      );
      canvas.drawCircle(
        p,
        selected ? 4.5 : 2.5,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = selected ? 2.0 : 1.2
          ..color = selected
              ? const Color(0xFFFFE86A)
              : const Color(0xFF8FDAFF),
      );
    }
  }

  void _drawPegs(Canvas canvas) {
    for (final p in pegs) {
      canvas.drawCircle(
        p + const Offset(0, 1.2),
        pegRadius + 1.2,
        Paint()..color = const Color(0x55000000),
      );
      canvas.drawCircle(
        p,
        pegRadius + 1.4,
        Paint()
          ..shader = const RadialGradient(
            center: Alignment(-.35, -.35),
            colors: [
              Color(0xFFFFF2C2),
              Color(0xFFFFC247),
              Color(0xFF9A5A12),
            ],
          ).createShader(
            Rect.fromCircle(center: p, radius: pegRadius + 1.4),
          ),
      );
      canvas.drawCircle(
        p,
        pegRadius + 1.4,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = .8
          ..color = const Color(0xFFFFE89A),
      );
    }
  }

  void _drawLetterBumpers(Canvas canvas) {
    for (final bumper in letterBumpers) {
      final p = bumper.center;
      final isU = bumper.label == 'U';
      final ringColor =
          isU ? const Color(0xFF64DFFF) : const Color(0xFFFF63C8);

      canvas.drawCircle(
        p,
        16,
        Paint()
          ..color = ringColor.withOpacity(.18)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5),
      );
      canvas.drawCircle(
        p,
        13,
        Paint()
          ..shader = const RadialGradient(
            colors: [
              Color(0xFF432A79),
              Color(0xFF171226),
            ],
          ).createShader(
            Rect.fromCircle(center: p, radius: 13),
          ),
      );
      canvas.drawCircle(
        p,
        13,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.6
          ..color = ringColor,
      );

      final tp = TextPainter(
        text: TextSpan(
          text: bumper.label,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 14,
            fontWeight: FontWeight.w900,
            shadows: [
              Shadow(color: Colors.black, blurRadius: 3),
            ],
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();

      tp.paint(
        canvas,
        p - Offset(tp.width / 2, tp.height / 2),
      );
    }
  }

  void _drawStar(Canvas canvas) {
    canvas.drawCircle(
      starBumper,
      35,
      Paint()
        ..color = const Color(0x55FF4CE3)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12),
    );
    canvas.drawCircle(
      starBumper,
      25,
      Paint()
        ..shader = const RadialGradient(
          colors: [
            Color(0xFFFF89ED),
            Color(0xFF8F42D9),
            Color(0xFF46247C),
          ],
        ).createShader(
          Rect.fromCircle(center: starBumper, radius: 25),
        ),
    );
    canvas.drawCircle(
      starBumper,
      25,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 4
        ..color = const Color(0xFFFFDF63),
    );

    final tp = TextPainter(
      text: const TextSpan(
        text: '★',
        style: TextStyle(
          color: Colors.white,
          fontSize: 27,
          fontWeight: FontWeight.w900,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(
      canvas,
      starBumper - Offset(tp.width / 2, tp.height / 2),
    );
  }

  void _drawMiniGameGuards(Canvas canvas) {
    final cx = playRect.center.dx;
    final hole = Offset(cx, playRect.bottom - 82);

    // Exact scoring marker: the BRIGHT INNER OVAL is the suction hit area.
    // Outside glow is intentionally faint so the player reads the inner ring
    // as the only target.
    final hitRect = Rect.fromCenter(center: hole, width: 22, height: 12);
    canvas.drawOval(
      Rect.fromCenter(center: hole, width: 27, height: 17),
      Paint()
        ..color = const Color(0x335C27D9)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 7),
    );
    canvas.drawOval(
      hitRect,
      Paint()
        ..shader = const RadialGradient(
          colors: [
            Color(0xFF47107E),
            Color(0xFF160329),
            Color(0xFF020106),
          ],
        ).createShader(hitRect),
    );
    canvas.drawOval(
      hitRect,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.6
        ..color = const Color(0xFFF0D6FF),
    );

    // Straight-drop blocker. Clearly separate from the hole.
    final blockerY = playRect.bottom - 112;
    final blockerA = Offset(cx - 20, blockerY);
    final blockerB = Offset(cx + 20, blockerY);
    canvas.drawLine(
      blockerA,
      blockerB,
      Paint()
        ..color = const Color(0x5546C8FF)
        ..strokeWidth = 11
        ..strokeCap = StrokeCap.round
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5),
    );
    canvas.drawLine(
      blockerA,
      blockerB,
      Paint()
        ..color = const Color(0xFFFFE7B0)
        ..strokeWidth = 6
        ..strokeCap = StrokeCap.round,
    );
    canvas.drawLine(
      blockerA,
      blockerB,
      Paint()
        ..color = const Color(0xFF7A5260)
        ..strokeWidth = 3
        ..strokeCap = StrokeCap.round,
    );

    // Only two side rails. No lower rails overlapping the hole.
    final guards = <({Offset a, Offset b})>[
      (
        a: Offset(cx - 58, playRect.bottom - 108),
        b: Offset(cx - 27, playRect.bottom - 88),
      ),
      (
        a: Offset(cx + 58, playRect.bottom - 108),
        b: Offset(cx + 27, playRect.bottom - 88),
      ),
    ];
    for (final g in guards) {
      canvas.drawLine(
        g.a,
        g.b,
        Paint()
          ..color = const Color(0x5546C8FF)
          ..strokeWidth = 11
          ..strokeCap = StrokeCap.round
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5),
      );
      canvas.drawLine(
        g.a,
        g.b,
        Paint()
          ..color = const Color(0xFFFFE7B0)
          ..strokeWidth = 6
          ..strokeCap = StrokeCap.round,
      );
      canvas.drawLine(
        g.a,
        g.b,
        Paint()
          ..color = const Color(0xFF7A5260)
          ..strokeWidth = 3
          ..strokeCap = StrokeCap.round,
      );
    }

  }

  void _drawPocketArea(Canvas canvas) {
    final pocketWidth = playRect.width / 5;
    final top = playRect.bottom - 76;
    final bottom = playRect.bottom + 2;

    // Separator walls.
    for (final x in separators) {
      final wall = RRect.fromRectAndRadius(
        Rect.fromLTWH(x - 4, top, 8, bottom - top),
        const Radius.circular(4),
      );
      canvas.drawRRect(
        wall,
        Paint()..color = const Color(0xFFFFC14D),
      );
      canvas.drawRRect(
        wall,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5
          ..color = Colors.white,
      );
    }

    const labels = <String>[
      '10',
      '20',
      '',
      '20',
      '10',
    ];
    const baseColors = <Color>[
      Color(0xFF1D7DDF),
      Color(0xFF3AAA57),
      Color(0xFFD63C72),
      Color(0xFF3AAA57),
      Color(0xFF1D7DDF),
    ];

    for (var i = 0; i < 5; i++) {
      final left = playRect.left + i * pocketWidth + 4;
      final rect = RRect.fromRectAndRadius(
        Rect.fromLTWH(
          left,
          playRect.bottom - 64,
          pocketWidth - 8,
          58,
        ),
        const Radius.circular(10),
      );

      canvas.drawRRect(rect, Paint()..color = baseColors[i]);
      canvas.drawRRect(
        rect,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.5
          ..color = const Color(0xFFFFE06E),
      );

      final tp = TextPainter(
        text: TextSpan(
          text: labels[i],
          style: const TextStyle(
            color: Colors.white,
            fontSize: 10,
            height: 1.0,
            fontWeight: FontWeight.w900,
            shadows: [
              Shadow(
                color: Colors.black,
                blurRadius: 3,
              ),
            ],
          ),
        ),
        textAlign: TextAlign.center,
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(
        canvas,
        Offset(
          left + (pocketWidth - 8 - tp.width) / 2,
          playRect.bottom - 52,
        ),
      );
    }
  }

  void _drawCenterPocketCount(Canvas canvas) {
    final pocketWidth = playRect.width / 5;
    final center = Offset(
      playRect.left + pocketWidth * 2.5,
      playRect.bottom - 35,
    );

    final tp = TextPainter(
      text: TextSpan(
        text: centerPocketHits > 0 ? '×$centerPocketHits' : '×0',
        style: TextStyle(
          color: centerPocketHits > 0
              ? const Color(0xFFFFF06B)
              : const Color(0x99FFFFFF),
          fontSize: centerPocketHits > 0 ? 18 : 16,
          fontWeight: FontWeight.w900,
          shadows: const [
            Shadow(color: Colors.black, blurRadius: 5),
          ],
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();

    tp.paint(
      canvas,
      center - Offset(tp.width / 2, tp.height / 2),
    );
  }

  void _drawTrails(Canvas canvas) {
    for (final p in pieces) {
      if (p.trail.length < 2) continue;

      for (var i = 1; i < p.trail.length; i++) {
        final t = i / p.trail.length;
        canvas.drawLine(
          p.trail[i - 1],
          p.trail[i],
          Paint()
            ..color = Color.fromARGB(
              (38 + 90 * t).round(),
              103,
              214,
              255,
            )
            ..strokeWidth = 1.2 + t * 2
            ..strokeCap = StrokeCap.round,
        );
      }
    }
  }

  void _drawPieces(Canvas canvas) {
    for (final p in pieces) {
      canvas.save();
      canvas.translate(p.x, p.y);
      canvas.rotate(p.angle);

      canvas.drawCircle(
        Offset.zero,
        pieceRadius * 1.75,
        Paint()
          ..color = const Color(0x4468D8FF)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5),
      );

      final s = pieceRadius * 2;
      canvas.translate(-pieceRadius, -pieceRadius);
      _MiniCharacterPainter(type: p.type).paint(
        canvas,
        Size(s, s),
      );
      canvas.restore();
    }
  }

  void _drawBursts(Canvas canvas) {
    final now = DateTime.now();

    for (final b in bursts) {
      final elapsed = now.difference(b.startedAt).inMilliseconds;
      final duration = b.kind == 4 ? 1400.0 : b.kind == 5 ? 950.0 : 720.0;
      final t = (elapsed / duration).clamp(0.0, 1.0);
      final alpha = ((1 - t) * 255).round().clamp(0, 255);
      final radius = b.kind == 4 ? 24 + 72 * t : b.kind == 5 ? 18 + 50 * t : 12 + 34 * t;

      canvas.drawCircle(
        b.center,
        radius,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 4 * (1 - t) + 1
          ..color = Color.fromARGB(
            alpha,
            b.kind == 5 ? 255 : b.kind == 3 ? 255 : 118,
            b.kind == 5 ? 225 : b.kind == 3 ? 108 : 221,
            b.kind == 5 ? 75 : 255,
          ),
      );

      for (var i = 0; i < 8; i++) {
        final a = i * math.pi / 4 + t * .8;
        final p = b.center +
            Offset(math.cos(a), math.sin(a)) * (10 + 38 * t);
        canvas.drawCircle(
          p,
          2.5 * (1 - t) + .8,
          Paint()
            ..color = Color.fromARGB(
              alpha,
              255,
              b.kind == 2 ? 226 : 185,
              82,
            ),
        );
      }

      final tp = TextPainter(
        text: TextSpan(
          text: b.text,
          style: TextStyle(
            color: Color.fromARGB(alpha, 255, 255, 255),
            fontSize: b.kind == 4
                ? 18 + 7 * (1 - t)
                : b.kind == 5
                    ? 20 + 8 * (1 - t)
                    : 11 + 5 * (1 - t),
            fontWeight: FontWeight.w900,
            shadows: [
              Shadow(
                color: Color.fromARGB(
                  (alpha * .78).round().clamp(0, 255),
                  0,
                  0,
                  0,
                ),
                blurRadius: 4,
              ),
            ],
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();

      tp.paint(
        canvas,
        b.center +
            Offset(
              -tp.width / 2,
              b.kind == 4 ? -48 - t * 30 : -34 - t * 24,
            ),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _SuruBoardPainter oldDelegate) => true;
}

class _MiniCharacterPainter extends CustomPainter {
  const _MiniCharacterPainter({required this.type});

  final int type;

  Paint _gloss(
    Color light,
    Color base,
    Color dark,
    Offset c,
    double r,
  ) {
    return Paint()
      ..shader = RadialGradient(
        center: const Alignment(-.34, -.42),
        radius: 1.05,
        colors: [light, base, dark],
        stops: const [0, .55, 1],
      ).createShader(Rect.fromCircle(center: c, radius: r));
  }

  void _eyes(Canvas canvas, Offset c, double r) {
    final p = Paint()..color = const Color(0xFF202020);
    canvas.drawCircle(c + Offset(-r * .25, -r * .08), r * .085, p);
    canvas.drawCircle(c + Offset(r * .25, -r * .08), r * .085, p);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = math.min(size.width, size.height) / 2;

    switch (type % 5) {
      case 0:
        canvas.drawCircle(
          c,
          r * .82,
          _gloss(
            const Color(0xFFFFF08A),
            const Color(0xFFFFC928),
            const Color(0xFFE79A00),
            c,
            r,
          ),
        );
        _eyes(canvas, c, r);
        break;
      case 1:
        final body = _gloss(
          const Color(0xFFA6F3A9),
          const Color(0xFF63D46B),
          const Color(0xFF2C9A42),
          c,
          r,
        );
        canvas.drawCircle(c, r * .82, body);
        canvas.drawCircle(
          c + Offset(-r * .42, -r * .54),
          r * .22,
          body,
        );
        canvas.drawCircle(
          c + Offset(r * .42, -r * .54),
          r * .22,
          body,
        );
        _eyes(canvas, c, r);
        break;
      case 2:
        canvas.drawCircle(
          c,
          r * .82,
          _gloss(
            const Color(0xFF9DE1FF),
            const Color(0xFF4F9ED8),
            const Color(0xFF2464A8),
            c,
            r,
          ),
        );
        canvas.drawOval(
          Rect.fromCenter(
            center: c + Offset(0, r * .18),
            width: r * .98,
            height: r * 1.05,
          ),
          Paint()..color = const Color(0xFFEAF6FF),
        );
        _eyes(canvas, c, r);
        break;
      case 3:
        final ear = Paint()..color = const Color(0xFF7453B7);
        canvas.drawOval(
          Rect.fromCenter(
            center: c + Offset(-r * .63, -r * .12),
            width: r * .36,
            height: r * .65,
          ),
          ear,
        );
        canvas.drawOval(
          Rect.fromCenter(
            center: c + Offset(r * .63, -r * .12),
            width: r * .36,
            height: r * .65,
          ),
          ear,
        );
        canvas.drawCircle(
          c,
          r * .82,
          _gloss(
            const Color(0xFFE4D7FF),
            const Color(0xFFBFA8F2),
            const Color(0xFF8060C7),
            c,
            r,
          ),
        );
        _eyes(canvas, c, r);
        break;
      default:
        final body = _gloss(
          const Color(0xFFFFE2EE),
          const Color(0xFFFFA7C7),
          const Color(0xFFE66B9B),
          c,
          r,
        );
        canvas.drawOval(
          Rect.fromCenter(
            center: c + Offset(-r * .27, -r * .72),
            width: r * .28,
            height: r * .72,
          ),
          body,
        );
        canvas.drawOval(
          Rect.fromCenter(
            center: c + Offset(r * .27, -r * .72),
            width: r * .28,
            height: r * .72,
          ),
          body,
        );
        canvas.drawCircle(
          c + Offset(0, r * .06),
          r * .76,
          body,
        );
        _eyes(canvas, c + Offset(0, r * .04), r);
        break;
    }
  }

  @override
  bool shouldRepaint(covariant _MiniCharacterPainter oldDelegate) =>
      oldDelegate.type != type;
}


class _TreasureBubble {
  _TreasureBubble({required this.x, required this.y, required this.radius, required this.speed, required this.phase, required this.kind, required this.special});
  double x;
  double y;
  final double radius;
  final double speed;
  double phase;
  final int kind;
  final bool special;
  bool popped = false;
}

class _BubbleBurst {
  _BubbleBurst(this.position, this.power);
  final Offset position;
  final double power;
  double life = 1;
}

class _BubbleTreasurePainter extends CustomPainter {
  const _BubbleTreasurePainter({required this.bubbles, required this.bursts, required this.resultLevel});
  final List<_TreasureBubble> bubbles;
  final List<_BubbleBurst> bursts;
  final int resultLevel;

  @override
  void paint(Canvas canvas, Size size) {
    const palette = [Color(0xFF64B5F6), Color(0xFF80CBC4), Color(0xFFFFB74D), Color(0xFFF48FB1), Color(0xFFB39DDB)];
    for (final b in bubbles) {
      if (b.popped) continue;
      final c = b.special ? (resultLevel >= 4 ? const Color(0xFFFFD740) : const Color(0xFFFFF176)) : palette[b.kind % palette.length];
      final center = Offset(b.x, b.y);
      final fill = Paint()..color = c.withOpacity(.86);
      final edge = Paint()..color = Colors.white.withOpacity(.82)..style = PaintingStyle.stroke..strokeWidth = b.special ? 3 : 1.7;
      canvas.drawCircle(center, b.radius, fill);
      canvas.drawCircle(center, b.radius, edge);
      canvas.drawCircle(center + Offset(-b.radius * .32, -b.radius * .30), b.radius * .22, Paint()..color = Colors.white.withOpacity(.72));
      final eye = Paint()..color = const Color(0xFF102027);
      canvas.drawCircle(center + Offset(-b.radius * .26, b.radius * .04), 1.3, eye);
      canvas.drawCircle(center + Offset(b.radius * .26, b.radius * .04), 1.3, eye);
      if (b.special) {
        final star = TextPainter(text: const TextSpan(text: '★', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w900)), textDirection: TextDirection.ltr)..layout();
        star.paint(canvas, center + Offset(-star.width / 2, -b.radius * .92));
      }
    }
    for (final burst in bursts) {
      final p = burst.position;
      final r = (1 - burst.life) * 24 * burst.power + 5;
      final paint = Paint()..color = Colors.white.withOpacity(burst.life.clamp(0, 1))..style = PaintingStyle.stroke..strokeWidth = 3;
      canvas.drawCircle(p, r, paint);
      for (var i = 0; i < 7; i++) {
        final a = i * math.pi * 2 / 7;
        final a0 = p + Offset(math.cos(a), math.sin(a)) * r * .65;
        final a1 = p + Offset(math.cos(a), math.sin(a)) * r * 1.15;
        canvas.drawLine(a0, a1, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _BubbleTreasurePainter oldDelegate) => true;
}

class _BattleTsumPainter extends CustomPainter {
  final int type;
  final bool selected;

  const _BattleTsumPainter({required this.type, required this.selected});

  Paint _gloss(Color light, Color base, Color dark, Offset c, double r) {
    return Paint()
      ..shader = RadialGradient(
        center: const Alignment(-.34, -.42),
        radius: 1.05,
        colors: [light, base, dark],
        stops: const [0, .55, 1],
      ).createShader(Rect.fromCircle(center: c, radius: r));
  }

  void _bodyShine(Canvas canvas, Offset c, double r) {
    final shine = Paint()..color = Colors.white.withValues(alpha: .34);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(-r * .28, -r * .38), width: r * .48, height: r * .25), shine);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = math.min(size.width, size.height) / 2;
    final shadow = Paint()
      ..color = const Color(0x33000000)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3);
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(0, r * .12), width: r * 1.62, height: r * 1.58),
      shadow,
    );

    switch (type) {
      case 0:
        _drawChick(canvas, c, r);
        break;
      case 1:
        _drawFrog(canvas, c, r);
        break;
      case 2:
        _drawPenguin(canvas, c, r);
        break;
      case 3:
        _drawDog(canvas, c, r);
        break;
      default:
        _drawBunny(canvas, c, r);
    }

    if (selected) {
      final shine = Paint()
        ..color = Colors.white.withValues(alpha: .42)
        ..style = PaintingStyle.stroke
        ..strokeWidth = math.max(2, r * .08);
      canvas.drawCircle(c, r * .82, shine);
    }
  }

  void _eyes(Canvas canvas, Offset c, double r, {double y = -.10}) {
    final p = Paint()..color = const Color(0xFF252525);
    canvas.drawCircle(c + Offset(-r * .25, r * y), r * .075, p);
    canvas.drawCircle(c + Offset(r * .25, r * y), r * .075, p);
    final hi = Paint()..color = Colors.white.withValues(alpha: .9);
    canvas.drawCircle(c + Offset(-r * .225, r * (y - .025)), r * .018, hi);
    canvas.drawCircle(c + Offset(r * .275, r * (y - .025)), r * .018, hi);
  }

  void _blush(Canvas canvas, Offset c, double r) {
    final p = Paint()..color = const Color(0x55F38E9E);
    canvas.drawCircle(c + Offset(-r * .48, r * .13), r * .11, p);
    canvas.drawCircle(c + Offset(r * .48, r * .13), r * .11, p);
  }

  void _drawChick(Canvas canvas, Offset c, double r) {
    final body = _gloss(const Color(0xFFFFF08A), const Color(0xFFFFC928), const Color(0xFFE79A00), c, r);
    canvas.drawCircle(c, r * .82, body);
    _bodyShine(canvas, c, r);
    final wing = Paint()..color = const Color(0xFFFFB51E);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(-r * .66, r * .12), width: r * .28, height: r * .48), wing);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(r * .66, r * .12), width: r * .28, height: r * .48), wing);
    _eyes(canvas, c, r);
    _blush(canvas, c, r);
    final beak = Path()
      ..moveTo(c.dx - r * .10, c.dy + r * .08)
      ..lineTo(c.dx + r * .12, c.dy + r * .08)
      ..lineTo(c.dx, c.dy + r * .20)
      ..close();
    canvas.drawPath(beak, Paint()..color = const Color(0xFFF18A18));
  }

  void _drawFrog(Canvas canvas, Offset c, double r) {
    final body = _gloss(const Color(0xFFA6F3A9), const Color(0xFF63D46B), const Color(0xFF2C9A42), c, r);
    final deep = Paint()..color = const Color(0xFF25873A);
    canvas.drawCircle(c, r * .82, body);
    _bodyShine(canvas, c, r);
    canvas.drawCircle(c + Offset(-r * .42, -r * .55), r * .25, body);
    canvas.drawCircle(c + Offset(r * .42, -r * .55), r * .25, body);
    canvas.drawCircle(c + Offset(-r * .42, -r * .55), r * .11, Paint()..color = Colors.white);
    canvas.drawCircle(c + Offset(r * .42, -r * .55), r * .11, Paint()..color = Colors.white);
    canvas.drawCircle(c + Offset(-r * .42, -r * .55), r * .055, Paint()..color = const Color(0xFF1E2A25));
    canvas.drawCircle(c + Offset(r * .42, -r * .55), r * .055, Paint()..color = const Color(0xFF1E2A25));
    _blush(canvas, c, r);
    final smile = Paint()
      ..color = deep.color
      ..style = PaintingStyle.stroke
      ..strokeWidth = math.max(1.8, r * .07)
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(
      Rect.fromCenter(center: c + Offset(0, r * .12), width: r * .60, height: r * .36),
      .15,
      math.pi - .30,
      false,
      smile,
    );
  }

  void _drawPenguin(Canvas canvas, Offset c, double r) {
    // V16.20.5: changed from black/white to saturated blue so it can never
    // be confused with the panda in a crowded pile.
    final blue = _gloss(const Color(0xFF9DE1FF), const Color(0xFF4F9ED8), const Color(0xFF2464A8), c, r);
    final deepBlue = Paint()..color = const Color(0xFF2E6F9F);
    final belly = Paint()..color = const Color(0xFFEAF6FF);
    canvas.drawCircle(c, r * .82, blue);
    _bodyShine(canvas, c, r);
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(0, r * .19), width: r * 1.00, height: r * 1.10),
      belly,
    );
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(-r * .62, r * .08), width: r * .22, height: r * .56),
      deepBlue,
    );
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(r * .62, r * .08), width: r * .22, height: r * .56),
      deepBlue,
    );
    _eyes(canvas, c + Offset(0, -r * .10), r, y: 0);
    final beak = Path()
      ..moveTo(c.dx - r * .10, c.dy + r * .01)
      ..lineTo(c.dx + r * .10, c.dy + r * .01)
      ..lineTo(c.dx, c.dy + r * .15)
      ..close();
    canvas.drawPath(beak, Paint()..color = const Color(0xFFFF9B2F));
  }

  void _drawDog(Canvas canvas, Offset c, double r) {
    final ear = Paint()..color = const Color(0xFF7453B7);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(-r * .62, -r * .18), width: r * .42, height: r * .72), ear);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(r * .62, -r * .18), width: r * .42, height: r * .72), ear);
    canvas.drawCircle(c, r * .82, _gloss(const Color(0xFFE4D7FF), const Color(0xFFBFA8F2), const Color(0xFF8060C7), c, r));
    _bodyShine(canvas, c, r);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(r * .26, -r * .18), width: r * .36, height: r * .46), ear);
    _eyes(canvas, c, r);
    _blush(canvas, c, r);
    canvas.drawCircle(c + Offset(0, r * .16), r * .09, Paint()..color = const Color(0xFF3E315A));
  }

  void _drawBunny(Canvas canvas, Offset c, double r) {
    final body = _gloss(const Color(0xFFFFE2EE), const Color(0xFFFFA7C7), const Color(0xFFE66B9B), c, r);
    final inner = Paint()..color = const Color(0xFFFF6F9F);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(-r * .28, -r * .86), width: r * .32, height: r * .88), body);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(r * .28, -r * .86), width: r * .32, height: r * .88), body);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(-r * .28, -r * .86), width: r * .11, height: r * .55), inner);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(r * .28, -r * .86), width: r * .11, height: r * .55), inner);
    canvas.drawCircle(c + Offset(0, r * .04), r * .76, body);
    _bodyShine(canvas, c + Offset(0, r * .04), r * .92);
    _eyes(canvas, c + Offset(0, r * .02), r);
    _blush(canvas, c, r);
    canvas.drawCircle(c + Offset(0, r * .16), r * .06, Paint()..color = const Color(0xFF8C3F61));
  }

  @override
  bool shouldRepaint(covariant _BattleTsumPainter oldDelegate) =>
      oldDelegate.type != type || oldDelegate.selected != selected;
}


class _BattlePopPainter extends CustomPainter {
  const _BattlePopPainter({required this.progress});
  final double progress;
  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final fade = (1 - progress).clamp(0.0, 1.0);
    final ring = Paint()..color = const Color(0xFFFFC857).withOpacity(fade)..style = PaintingStyle.stroke..strokeWidth = 5 * fade + 1;
    canvas.drawCircle(c, 12 + progress * 34, ring);
    const colors = [Color(0xFFFFC857), Color(0xFFFF7B8B), Color(0xFF7FD8C9), Color(0xFFFFFFFF)];
    for (var i = 0; i < 12; i++) {
      final a = i * math.pi * 2 / 12;
      final d = 10 + progress * (34 + (i % 3) * 5);
      final p = c + Offset(math.cos(a) * d, math.sin(a) * d);
      canvas.drawCircle(p, (5 - progress * 3).clamp(1.5, 5.0), Paint()..color = colors[i % colors.length].withOpacity(fade));
    }
  }
  @override
  bool shouldRepaint(covariant _BattlePopPainter oldDelegate) => oldDelegate.progress != progress;
}
