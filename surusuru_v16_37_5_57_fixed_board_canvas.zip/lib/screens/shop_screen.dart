import 'package:flutter/material.dart';

import '../widgets/game_bottom_nav.dart';
import 'rpg_home_screen.dart';
import 'stage_map_screen.dart';
import 'surusuru_play_screen.dart';
import 'training_screen.dart';

import '../web_ui_scale.dart';

import '../game/game_controller.dart';
import '../sfx_manager.dart';

class ShopScreen extends StatelessWidget {
  final GameController controller;

  const ShopScreen({super.key, required this.controller});

  Future<void> _buy(
    BuildContext context, {
    required Future<bool> Function() action,
    required String successText,
  }) async {
    SfxManager.instance.tap();
    final ok = await action();

    if (!context.mounted) return;
    if (ok) { SfxManager.instance.reward(); } else { SfxManager.instance.error(); }

    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          duration: const Duration(milliseconds: 1600),
          content: Text(ok ? successText : _failureText()),
        ),
      );
  }

  String _failureText() {
    if (controller.state.energy >= controller.state.maxEnergy) {
      return 'エネルギーは満タンです';
    }

    return 'コインが足りません';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF9F5),
      appBar: AppBar(
        leadingWidth: 72 * webUiScale,
        leading: IconButton(
          tooltip: '戻る',
          onPressed: () { SfxManager.instance.tap(); Navigator.of(context).maybePop(); },
          icon: const Icon(Icons.arrow_back_rounded, size: 40 * webUiScale),
        ),
        backgroundColor: const Color(0xFFFFF9F5),
        foregroundColor: const Color(0xFF674F49),
        elevation: 0,
        centerTitle: true,
        title: const Text(
          'ショップ',
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
      ),
      bottomNavigationBar: GameBottomNav(
        active: 'shop',
        onAdventure: () => Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => StageMapScreen(controller: controller))),
        onShop: () {},
        onSurusuru: () => Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => SurusuruPlayScreen(controller: controller))),
        onTraining: () => Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => TrainingScreen(controller: controller))),
        onMap: () => Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => RpgHomeScreen(controller: controller))),
      ),
      body: AnimatedBuilder(
        animation: controller,
        builder: (context, _) {
          final state = controller.state;

          return SafeArea(
            top: false,
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16 * webUiScale, 8 * webUiScale, 16 * webUiScale, 28 * webUiScale),
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14 * webUiScale,
                    vertical: 12 * webUiScale,
                  ),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFECE5),
                    borderRadius: BorderRadius.circular(18 * webUiScale),
                    border: Border.all(color: const Color(0xFFF0D6CC)),
                  ),
                  child: Row(
                    children: [
                      const Text(
                        'MY WALLET',
                        style: TextStyle(
                          fontSize: 18 * webUiScale,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.4 * webUiScale,
                          color: Color(0xFFA36F65),
                        ),
                      ),
                      const Spacer(),
                      Text(
                        '🪙 ${state.coins}',
                        style: const TextStyle(
                          fontSize: 20 * webUiScale,
                          fontWeight: FontWeight.w900,
                          color: Color(0xFF654D48),
                        ),
                      ),
                      const SizedBox(width: 12 * webUiScale),
                      Text(
                        '💎 ${state.gems}',
                        style: const TextStyle(
                          fontSize: 20 * webUiScale,
                          fontWeight: FontWeight.w900,
                          color: Color(0xFF654D48),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 18 * webUiScale),

                Text(
                  '⚡ ${state.energy} / ${state.maxEnergy}',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 22 * webUiScale,
                    fontWeight: FontWeight.w900,
                    color: Color(0xFF654D48),
                  ),
                ),

                const SizedBox(height: 18 * webUiScale),

                _ShopCard(
                  icon: '⚡',
                  title: 'エネルギー 20',
                  subtitle: 'ちょっとだけ遊びたいときに',
                  price: 30,
                  enabled:
                      controller.canBuyWithCoins(30) &&
                      state.energy < state.maxEnergy,
                  onTap: () => _buy(
                    context,
                    action: controller.buyEnergySmall,
                    successText: 'エネルギーを20回復しました！',
                  ),
                ),

                const SizedBox(height: 12 * webUiScale),

                _ShopCard(
                  icon: '⚡',
                  title: 'エネルギー 50',
                  subtitle: 'たっぷり遊びたいときに',
                  price: 70,
                  enabled:
                      controller.canBuyWithCoins(70) &&
                      state.energy < state.maxEnergy,
                  recommended: true,
                  onTap: () => _buy(
                    context,
                    action: controller.buyEnergyLarge,
                    successText: 'エネルギーを50回復しました！',
                  ),
                ),

                const SizedBox(height: 22 * webUiScale),

                Container(
                  padding: const EdgeInsets.all(14 * webUiScale),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFFDFB),
                    borderRadius: BorderRadius.circular(16 * webUiScale),
                    border: Border.all(color: const Color(0xFFF0E2DC)),
                  ),
                  child: const Text(
                    'アイテムや特別な商品は、今後ここに追加できます。',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 19 * webUiScale,
                      height: 1.5,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF9A817A),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _ShopCard extends StatelessWidget {
  final String icon;
  final String title;
  final String subtitle;
  final int price;
  final bool enabled;
  final bool recommended;
  final VoidCallback onTap;

  const _ShopCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.price,
    required this.enabled,
    required this.onTap,
    this.recommended = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFFFFF0E9),
        borderRadius: BorderRadius.circular(20 * webUiScale),
        border: Border.all(
          color: recommended
              ? const Color(0xFFE9AC9F)
              : const Color(0xFFF0D8CE),
          width: recommended ? 1.7 : 1,
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0D000000),
            blurRadius: 10,
            offset: Offset(0, 4 * webUiScale),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(20 * webUiScale),
          onTap: enabled ? onTap : null,
          child: Padding(
            padding: const EdgeInsets.all(16 * webUiScale),
            child: Row(
              children: [
                Container(
                  width: 58 * webUiScale,
                  height: 58 * webUiScale,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFE1D5),
                    borderRadius: BorderRadius.circular(18 * webUiScale),
                  ),
                  child: Text(icon, style: const TextStyle(fontSize: 30 * webUiScale)),
                ),
                const SizedBox(width: 14 * webUiScale),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Flexible(
                            child: Text(
                              title,
                              style: const TextStyle(
                                fontSize: 20 * webUiScale,
                                fontWeight: FontWeight.w900,
                                color: Color(0xFF654D48),
                              ),
                            ),
                          ),
                          if (recommended) ...[
                            const SizedBox(width: 7),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 6 * webUiScale,
                                vertical: 3 * webUiScale,
                              ),
                              decoration: BoxDecoration(
                                color: const Color(0xFFEBA99A),
                                borderRadius: BorderRadius.circular(999 * webUiScale),
                              ),
                              child: const Text(
                                'おすすめ',
                                style: TextStyle(
                                  fontSize: 18 * webUiScale,
                                  fontWeight: FontWeight.w900,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        subtitle,
                        style: const TextStyle(
                          fontSize: 19 * webUiScale,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF9A7D76),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8 * webUiScale),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 11 * webUiScale,
                    vertical: 8 * webUiScale,
                  ),
                  decoration: BoxDecoration(
                    color: enabled
                        ? const Color(0xFFFFD86E)
                        : const Color(0xFFE4DAD6),
                    borderRadius: BorderRadius.circular(14 * webUiScale),
                  ),
                  child: Text(
                    '🪙 $price',
                    style: TextStyle(
                      fontSize: 19 * webUiScale,
                      fontWeight: FontWeight.w900,
                      color: enabled
                          ? const Color(0xFF6D5548)
                          : const Color(0xFFA89A94),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
