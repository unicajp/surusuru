import 'package:flutter/material.dart';

class GameBottomNav extends StatelessWidget {
  final String active;
  final VoidCallback onAdventure;
  final VoidCallback onShop;
  final VoidCallback onSurusuru;
  final VoidCallback onTraining;
  final VoidCallback onMap;

  const GameBottomNav({
    super.key,
    required this.active,
    required this.onAdventure,
    required this.onShop,
    required this.onSurusuru,
    required this.onTraining,
    required this.onMap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 66,
      margin: const EdgeInsets.fromLTRB(7, 0, 7, 7),
      padding: const EdgeInsets.fromLTRB(4, 4, 4, 3),
      decoration: BoxDecoration(
        color: const Color(0xF122292F),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFFFD775), width: 2),
        boxShadow: const [
          BoxShadow(color: Colors.black45, blurRadius: 8, offset: Offset(0, 4)),
        ],
      ),
      child: Row(
        children: [
          Expanded(child: _Item(icon: '⚔️', label: '冒険', active: active == 'adventure', onTap: onAdventure)),
          Expanded(child: _Item(icon: '🛒', label: 'SHOP', active: active == 'shop', onTap: onShop)),
          Expanded(child: _Item(icon: '✦', label: 'スルスル', active: active == 'surusuru', emphasized: true, onTap: onSurusuru)),
          Expanded(child: _Item(icon: '🌱', label: '育成', active: active == 'training', onTap: onTraining)),
          Expanded(child: _Item(icon: '🗺️', label: 'マップ', active: active == 'map', onTap: onMap)),
        ],
      ),
    );
  }
}

class _Item extends StatelessWidget {
  final String icon;
  final String label;
  final bool active;
  final bool emphasized;
  final VoidCallback onTap;

  const _Item({
    required this.icon,
    required this.label,
    required this.active,
    required this.onTap,
    this.emphasized = false,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 2),
        padding: const EdgeInsets.symmetric(vertical: 5),
        decoration: BoxDecoration(
          color: active
              ? const Color(0xFFE9B93E)
              : emphasized
                  ? const Color(0xFF43504C)
                  : const Color(0xFF303D43),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(icon, style: const TextStyle(fontSize: 19)),
            const SizedBox(height: 1),
            Text(
              label,
              maxLines: 1,
              style: TextStyle(
                color: active ? const Color(0xFF34220D) : Colors.white,
                fontSize: 9,
                fontWeight: FontWeight.w900,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
