import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../game/game_controller.dart';

class ConnectBattleScreen extends StatefulWidget {
  final GameController controller;
  final int stageId;
  const ConnectBattleScreen({super.key, required this.controller, required this.stageId});
  @override
  State<ConnectBattleScreen> createState() => _ConnectBattleScreenState();
}

class _ConnectBattleScreenState extends State<ConnectBattleScreen> {
  Timer? _timer;
  DateTime _last = DateTime.now();
  Size _field = Size.zero;
  Offset _hero = Offset.zero;
  Offset _velocity = Offset.zero;
  Offset _target = Offset.zero;
  Offset _finger = Offset.zero;
  bool _touching = false;
  double _lean = 0;
  double _phase = 0;
  final List<Offset> _trail = <Offset>[];

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(milliseconds: 16), (_) => _tick());
  }

  @override
  void dispose() { _timer?.cancel(); super.dispose(); }

  void _seed(Size s) {
    _field = s;
    if (_hero == Offset.zero) {
      _hero = Offset(s.width * .5, s.height * .62);
      _target = _hero;
      _finger = _hero;
    }
  }

  void _tick() {
    if (!mounted || _field == Size.zero) return;
    final now = DateTime.now();
    double dt = now.difference(_last).inMicroseconds / 1000000;
    _last = now;
    dt = dt.clamp(.001, .035);
    _phase += dt * 5.5;

    // Soft spring: intentionally not finger == character. It catches up,
    // overshoots a little, then settles smoothly.
    final Offset delta = _target - _hero;
    final Offset acceleration = delta * 30.0 - _velocity * 8.2;
    _velocity += acceleration * dt;
    final double speed = _velocity.distance;
    if (speed > 900) _velocity = _velocity / speed * 900;
    _hero += _velocity * dt;

    _hero = Offset(
      _hero.dx.clamp(30.0, math.max(30.0, _field.width - 30.0)),
      _hero.dy.clamp(48.0, math.max(48.0, _field.height - 40.0)),
    );
    _lean += ((_velocity.dx / 700).clamp(-.30, .30) - _lean) * math.min(1, dt * 9);

    if (speed > 95) {
      _trail.insert(0, _hero);
      if (_trail.length > 9) _trail.removeLast();
    } else if (_trail.isNotEmpty && !_touching) {
      _trail.removeLast();
    }
    setState(() {});
  }

  void _down(Offset p) {
    setState(() { _touching = true; _finger = p; _target = p; });
  }
  void _move(Offset p) {
    setState(() { _finger = p; _target = p; });
  }
  void _up() {
    setState(() { _touching = false; _target = _hero; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF17253A),
      body: SafeArea(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(4, 4, 12, 4),
            child: Row(children: [
              IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back, color: Colors.white)),
              Text('冒険  TOUCH TEST ${widget.stageId}', style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w900)),
              const Spacer(),
              const Text('ちび剣士 追従テスト', style: TextStyle(color: Color(0xFFFFDF7A), fontWeight: FontWeight.w800, fontSize: 12)),
            ]),
          ),
          Expanded(child: LayoutBuilder(builder: (context, box) {
            final s = Size(box.maxWidth, box.maxHeight); _seed(s);
            return Listener(
              behavior: HitTestBehavior.opaque,
              onPointerDown: (e) => _down(e.localPosition),
              onPointerMove: (e) => _move(e.localPosition),
              onPointerUp: (_) => _up(),
              onPointerCancel: (_) => _up(),
              child: CustomPaint(size: s, painter: _ChibiTestPainter(hero: _hero, finger: _finger, touching: _touching, velocity: _velocity, lean: _lean, phase: _phase, trail: _trail)),
            );
          })),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 13),
            color: const Color(0xFF101B2A),
            child: const Text('画面をなぞって剣士を振り回す  •  急加速 / 急停止 / 円運動を試してください', textAlign: TextAlign.center, style: TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.w700)),
          )
        ]),
      ),
    );
  }
}

class _ChibiTestPainter extends CustomPainter {
  final Offset hero, finger, velocity;
  final bool touching;
  final double lean, phase;
  final List<Offset> trail;
  _ChibiTestPainter({required this.hero, required this.finger, required this.touching, required this.velocity, required this.lean, required this.phase, required this.trail});

  @override
  void paint(Canvas c, Size s) {
    final bg = Paint()..shader = const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF223A59), Color(0xFF132236)]).createShader(Offset.zero & s);
    c.drawRect(Offset.zero & s, bg);
    final grid = Paint()..color = Colors.white.withOpacity(.035)..strokeWidth = 1;
    for (double y=70; y<s.height; y+=54) c.drawLine(Offset(0,y), Offset(s.width,y), grid);

    if (touching) {
      c.drawCircle(finger, 22, Paint()..color = Colors.white.withOpacity(.06));
      c.drawCircle(finger, 8, Paint()..style=PaintingStyle.stroke..strokeWidth=2..color=const Color(0xFF8DEBFF).withOpacity(.7));
    }

    for (int i=trail.length-1; i>=0; i--) {
      final a = (1 - i / math.max(1, trail.length)) * .16;
      _drawWarrior(c, trail[i], lean, phase, opacity: a, ghost: true);
    }
    _drawWarrior(c, hero, lean, phase, opacity: 1);

    final speed = velocity.distance;
    final text = TextPainter(textDirection: TextDirection.ltr, text: TextSpan(text: '${speed.round()}  SPEED', style: const TextStyle(color: Colors.white54, fontWeight: FontWeight.w800, fontSize: 11)))..layout();
    text.paint(c, Offset(12, 12));
  }

  void _drawWarrior(Canvas c, Offset p, double lean, double phase, {required double opacity, bool ghost=false}) {
    c.save(); c.translate(p.dx, p.dy); c.rotate(lean);
    final moving = velocity.distance > 40;
    final bob = moving ? math.sin(phase * 2) * 1.8 : math.sin(phase) * 1.2;
    c.translate(0, bob);
    Color col(Color x) => x.withOpacity(opacity);
    if (!ghost) c.drawOval(const Rect.fromLTWH(-18, 23, 38, 10), Paint()..color=Colors.black.withOpacity(.25));

    // Back sword: oversized silhouette so this reads as a fighter, not a puzzle ball.
    final sword = Paint()..color=col(const Color(0xFFE8F2F6));
    final blade = Path()..moveTo(13,-3)..lineTo(37,-31)..lineTo(42,-34)..lineTo(40,-27)..lineTo(18,2)..close();
    c.drawPath(blade, sword);
    c.drawLine(const Offset(10,0), const Offset(22,10), Paint()..color=col(const Color(0xFFDAA43A))..strokeWidth=5..strokeCap=StrokeCap.round);

    // Legs / boots.
    final boot = Paint()..color=col(const Color(0xFF392D36));
    c.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-12,16,9,14), const Radius.circular(4)), boot);
    c.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(4,16,9,14), const Radius.circular(4)), boot);
    // Body armor / scarf.
    c.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-15,-2,30,24), const Radius.circular(8)), Paint()..color=col(const Color(0xFF4C73A8)));
    c.drawPath(Path()..moveTo(-15,3)..lineTo(-25,19)..lineTo(-9,15)..close(), Paint()..color=col(const Color(0xFFD94E55)));
    c.drawRect(const Rect.fromLTWH(-15,12,30,5), Paint()..color=col(const Color(0xFFCF9B3C)));
    // Head, hair and face: compact 2.5-head-ish JRPG fighter silhouette.
    c.drawCircle(const Offset(0,-16), 14, Paint()..color=col(const Color(0xFFF0C59B)));
    final hair = Path()..moveTo(-14,-18)..quadraticBezierTo(-10,-35,4,-31)..lineTo(10,-37)..lineTo(13,-27)..lineTo(18,-30)..lineTo(13,-14)..lineTo(7,-23)..lineTo(2,-17)..lineTo(-4,-25)..lineTo(-8,-16)..close();
    c.drawPath(hair, Paint()..color=col(const Color(0xFF2A2632)));
    c.drawCircle(const Offset(-5,-14), 1.5, Paint()..color=col(const Color(0xFF202331)));
    c.drawCircle(const Offset(5,-14), 1.5, Paint()..color=col(const Color(0xFF202331)));
    c.drawLine(const Offset(-4,-8), const Offset(5,-8), Paint()..color=col(const Color(0xFF9D5C55))..strokeWidth=1.5);
    c.restore();
  }

  @override
  bool shouldRepaint(covariant _ChibiTestPainter oldDelegate) => true;
}
