import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../game/game_controller.dart';
import '../sfx_manager.dart';

enum _Element { ice, fire, wind, thunder }
enum _ThingKind { grass, pot, crate, vine, rock, switchPad, torch }

class _Thing {
  _Thing(this.p, this.kind, {this.hp = 1, this.active = false});
  Offset p; final _ThingKind kind; int hp; bool active; double flash = 0;
  bool get solid => kind == _ThingKind.crate || kind == _ThingKind.pot || kind == _ThingKind.rock || kind == _ThingKind.vine;
  double get radius => switch (kind) { _ThingKind.crate => 35, _ThingKind.rock => 42, _ThingKind.vine => 34, _ThingKind.pot => 25, _ => 24 };
}
class _Ice { _Ice(this.p); Offset p; Offset v = Offset.zero; }
class _MagicFx { _MagicFx(this.from,this.to,this.e); final Offset from,to; final _Element e; double life=1; }

class ConnectBattleScreen extends StatefulWidget {
  final GameController controller; final int stageId;
  const ConnectBattleScreen({super.key,required this.controller,required this.stageId});
  @override State<ConnectBattleScreen> createState()=>_S();
}

class _S extends State<ConnectBattleScreen> {
  static const world = Size(2400,1900);
  Timer? timer; DateTime last=DateTime.now(); Size view=Size.zero;
  Offset hero=const Offset(330,1450), target=const Offset(330,1450), vel=Offset.zero, pointerV=Offset.zero,lastPointer=Offset.zero;
  int lastMs=0; bool holding=false, faceRight=true, vertical=false, up=false, attack=false; double attackT=0,t=0,shake=0;
  _Element selected=_Element.ice; bool castMode=false; _Ice? draggedIce;
  final things=< _Thing>[]; final ices=<_Ice>[]; final fx=<_MagicFx>[];

  @override void initState(){super.initState(); _seed(); timer=Timer.periodic(const Duration(milliseconds:16),(_)=>_tick());}
  @override void dispose(){timer?.cancel();super.dispose();}
  void _seed(){
    final data=<(_ThingKind,double,double,int)>[
      (_ThingKind.grass,430,1430,1),(_ThingKind.grass,470,1400,1),(_ThingKind.pot,610,1370,2),(_ThingKind.crate,760,1450,4),
      (_ThingKind.crate,820,1450,4),(_ThingKind.vine,1030,1370,3),(_ThingKind.vine,1030,1435,3),(_ThingKind.vine,1030,1500,3),
      (_ThingKind.rock,520,1060,99),(_ThingKind.rock,580,1010,99),(_ThingKind.torch,780,1040,1),(_ThingKind.switchPad,1190,1180,1),
      (_ThingKind.crate,1450,1040,4),(_ThingKind.pot,1530,980,2),(_ThingKind.grass,1640,920,1),(_ThingKind.vine,1740,790,3),
      (_ThingKind.rock,1350,620,99),(_ThingKind.rock,1420,610,99),(_ThingKind.torch,1760,520,1),(_ThingKind.switchPad,2030,420,1),
      (_ThingKind.crate,2020,900,4),(_ThingKind.pot,2150,1060,2),(_ThingKind.grass,2050,1420,1),(_ThingKind.crate,1800,1510,4)
    ];
    for(final d in data) things.add(_Thing(Offset(d.$2,d.$3),d.$1,hp:d.$4));
  }
  Offset get cam { if(view==Size.zero)return Offset.zero; return Offset((hero.dx-view.width/2).clamp(0.0,world.width-view.width),(hero.dy-view.height/2).clamp(0.0,world.height-view.height)); }
  Offset _w(Offset local)=>local+cam;

  void _tick(){if(!mounted||view==Size.zero)return; final n=DateTime.now(); var dt=n.difference(last).inMicroseconds/1e6;last=n;dt=dt.clamp(0,.035);t+=dt;shake=math.max(0,shake-dt*6);
    if(attack){attackT+=dt;if(attackT>.28){attack=false;attackT=0;}}
    for(final f in fx)f.life-=dt*2.8;fx.removeWhere((e)=>e.life<=0); for(final o in things)o.flash=math.max(0,o.flash-dt*5);
    if(draggedIce==null){final d=target-hero;final desired=d*(holding?12.0:4.0)+(holding?pointerV*.13:Offset.zero);vel+=(desired-vel)*(1-math.exp(-(holding?17:7)*dt));if(vel.distance>900)vel=vel/vel.distance*900; final old=hero;hero+=vel*dt;hero=Offset(hero.dx.clamp(45.0,world.width-45),hero.dy.clamp(55.0,world.height-45));_collide(old);}
    for(final i in ices){if(i==draggedIce)continue;i.p+=i.v*dt;i.v*=math.pow(.90,dt*60).toDouble();}
    if(vel.distance>40){if(vel.dy.abs()>vel.dx.abs()*.78){vertical=true;up=vel.dy<0;}else{vertical=false;faceRight=vel.dx>=0;}}
    setState((){});
  }
  void _collide(Offset old){final speed=math.max(vel.distance,pointerV.distance*.7);for(final o in things.toList()){if(!o.solid)continue;final d=hero-o.p;if(d.distance>o.radius+28)continue;
      if(o.kind==_ThingKind.rock){hero=old;vel*=.15;continue;}
      if(speed>390){o.flash=1;if(speed>720)o.hp-=2;else o.hp-=1;shake=.25;HapticFeedback.lightImpact();SfxManager.instance.chanceBattleHit();if(o.hp<=0){things.remove(o);HapticFeedback.mediumImpact();}}
      else {hero=old;vel*=.12;}
    }}
  void _down(Offset local){final p=_w(local); for(final i in ices.reversed){if((i.p-p).distance<48){draggedIce=i;holding=true;lastPointer=p;return;}}
    if(castMode){_cast(p);return;} holding=true;lastPointer=p;lastMs=DateTime.now().millisecondsSinceEpoch;pointerV=Offset.zero;target=p;}
  void _move(Offset local){final p=_w(local);if(draggedIce!=null){draggedIce!.p=p;return;}if(!holding)return;final n=DateTime.now().millisecondsSinceEpoch;final ms=math.max(1,n-lastMs);final instant=(p-lastPointer)*(1000/ms);pointerV+=(instant-pointerV)*.58;lastPointer=p;lastMs=n;target=p;if(pointerV.distance>430){attack=true;attackT=0;}}
  void _up(Offset local){if(draggedIce!=null){draggedIce!.v=pointerV*.35;draggedIce=null;}holding=false;target=hero;}
  void _cast(Offset p){castMode=false;final from=hero+const Offset(0,-22);fx.add(_MagicFx(from,p,selected));
    switch(selected){case _Element.ice: ices.add(_Ice(p));break;case _Element.fire: for(final o in things.toList()){if((o.p-p).distance<115&&(o.kind==_ThingKind.grass||o.kind==_ThingKind.vine)){things.remove(o);}} break;case _Element.wind: for(final i in ices){final d=i.p-p;if(d.distance<190&&d.distance>1)i.v+=d/d.distance*650;} break;case _Element.thunder: for(final o in things){if((o.p-p).distance<130&&(o.kind==_ThingKind.switchPad||o.kind==_ThingKind.torch))o.active=true;}break;}
    HapticFeedback.selectionClick();setState((){});
  }
  int get runFrame=>((t*11).floor()%5)+1, vrun=>((t*9).floor()%3)+1, af=>((attackT/.28*6).floor().clamp(0,5))+1, vaf=>((attackT/.28*2).floor().clamp(0,1))+1;

  @override Widget build(BuildContext context)=>Scaffold(backgroundColor:const Color(0xff173927),body:SafeArea(child:Column(children:[
    SizedBox(height:52,child:Row(children:[IconButton(onPressed:()=>Navigator.pop(context),icon:const Icon(Icons.arrow_back,color:Colors.white)),const Text('大冒険フィールド',style:TextStyle(color:Colors.white,fontSize:19,fontWeight:FontWeight.w900)),const Spacer(),const Padding(padding:EdgeInsets.only(right:12),child:Text('探索・破壊・4属性',style:TextStyle(color:Color(0xffffdc7b),fontWeight:FontWeight.bold)))])),
    Expanded(child:LayoutBuilder(builder:(context,c){view=Size(c.maxWidth,c.maxHeight);return Listener(behavior:HitTestBehavior.opaque,onPointerDown:(e)=>_down(e.localPosition),onPointerMove:(e)=>_move(e.localPosition),onPointerUp:(e)=>_up(e.localPosition),onPointerCancel:(_)=>_up(Offset.zero),child:Stack(children:[
      Positioned.fill(child:CustomPaint(painter:_WorldPainter(camera:cam))),
      ..._buildThings(),..._buildIce(),..._buildFx(),_heroWidget(),
      Positioned(left:10,top:10,child:IgnorePointer(child:Container(padding:const EdgeInsets.symmetric(horizontal:10,vertical:6),decoration:BoxDecoration(color:Colors.black54,borderRadius:BorderRadius.circular(14)),child:Text(castMode?'場所をタップして ${_name(selected)} を使う':'振って壊す / 氷は直接つかんで運べる',style:const TextStyle(color:Colors.white,fontSize:11,fontWeight:FontWeight.bold))))),
      Positioned(left:0,right:0,bottom:12,child:Center(child:_elementBar())),
    ]));})),
  ])));
  String _name(_Element e)=>switch(e){_Element.ice=>'氷',_Element.fire=>'炎',_Element.wind=>'風',_Element.thunder=>'雷'};
  Widget _elementBar()=>Container(padding:const EdgeInsets.all(6),decoration:BoxDecoration(color:const Color(0xdd102b22),borderRadius:BorderRadius.circular(25),border:Border.all(color:Colors.white24)),child:Row(mainAxisSize:MainAxisSize.min,children:[_eb(_Element.ice,'❄️'),_eb(_Element.fire,'🔥'),_eb(_Element.wind,'💨'),_eb(_Element.thunder,'⚡')]));
  Widget _eb(_Element e,String s)=>GestureDetector(onTap:(){setState((){selected=e;castMode=true;});},child:AnimatedContainer(duration:const Duration(milliseconds:120),margin:const EdgeInsets.symmetric(horizontal:3),width:49,height:42,alignment:Alignment.center,decoration:BoxDecoration(color:selected==e?Colors.white24:Colors.transparent,borderRadius:BorderRadius.circular(18),border:Border.all(color:selected==e?Colors.white70:Colors.transparent,width:2)),child:Text(s,style:const TextStyle(fontSize:23))));
  List<Widget> _buildThings()=>things.map((o){final q=o.p-cam;return Positioned(left:q.dx-48,top:q.dy-48,child:IgnorePointer(child:CustomPaint(size:const Size(96,96),painter:_ThingPainter(o.kind,o.flash,o.active))));}).toList();
  List<Widget> _buildIce()=>ices.map((i){final q=i.p-cam;return Positioned(left:q.dx-37,top:q.dy-42,child:IgnorePointer(child:CustomPaint(size:const Size(74,74),painter:const _IcePainter())));}).toList();
  List<Widget> _buildFx()=>fx.map((f){final a=f.from-cam,b=f.to-cam;return Positioned.fill(child:IgnorePointer(child:CustomPaint(painter:_MagicPainter(a,b,f.e,f.life))));}).toList();
  Widget _heroWidget(){final moving=!attack&&vel.distance>48;final pref=up?'up':'down';final path=attack&&vertical?'assets/sprites/hero_swordswoman/${pref}_attack_${vaf.toString().padLeft(2,'0')}.png':attack?'assets/sprites/hero_swordswoman/attack_${af.toString().padLeft(2,'0')}.png':moving&&vertical?'assets/sprites/hero_swordswoman/${pref}_run_${vrun.toString().padLeft(2,'0')}.png':moving?'assets/sprites/hero_swordswoman/run_${runFrame.toString().padLeft(2,'0')}.png':'assets/sprites/hero_swordswoman/idle_01.png';Widget im=Image.asset(path,width:156,height:117,fit:BoxFit.contain,gaplessPlayback:true);if(!vertical&&!faceRight)im=Transform(alignment:Alignment.center,transform:Matrix4.diagonal3Values(-1,1,1),child:im);final q=hero-cam;return Positioned(left:q.dx-78+math.sin(t*70)*shake*2,top:q.dy-84,child:IgnorePointer(child:im));}
}

class _WorldPainter extends CustomPainter{const _WorldPainter({required this.camera});final Offset camera;@override void paint(Canvas c,Size s){c.drawRect(Offset.zero&s,Paint()..color=const Color(0xff74b85a));c.save();c.translate(-camera.dx,-camera.dy);final path=Paint()..color=const Color(0xffd8bd7b);c.drawPath(Path()..moveTo(220,1510)..cubicTo(650,1300,850,1500,1100,1210)..cubicTo(1370,900,1640,1080,1850,700)..cubicTo(2000,520,2170,500,2260,350),path);final water=Paint()..color=const Color(0xff58aeda);c.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(1120,720,500,260),const Radius.circular(90)),water);c.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(1820,1120,420,250),const Radius.circular(80)),water);final dark=Paint()..color=const Color(0xff4b8d45);for(int x=80;x<2380;x+=180){c.drawCircle(Offset(x.toDouble(),90),55,dark);c.drawCircle(Offset(x.toDouble(),1810),55,dark);}for(int y=180;y<1780;y+=180){c.drawCircle(Offset(70,y.toDouble()),55,dark);c.drawCircle(Offset(2330,y.toDouble()),55,dark);}c.restore();}@override bool shouldRepaint(covariant _WorldPainter o)=>o.camera!=camera;}
class _ThingPainter extends CustomPainter{const _ThingPainter(this.k,this.flash,this.active);final _ThingKind k;final double flash;final bool active;@override void paint(Canvas c,Size s){final m=s.center(Offset.zero);switch(k){case _ThingKind.grass:c.drawOval(Rect.fromCenter(center:m,width:60,height:34),Paint()..color=const Color(0xff287b39));break;case _ThingKind.pot:c.drawOval(Rect.fromCenter(center:m,width:44,height:55),Paint()..color=const Color(0xffb86c3d));c.drawRect(Rect.fromCenter(center:m-const Offset(0,24),width:35,height:8),Paint()..color=const Color(0xffe09a60));break;case _ThingKind.crate:c.drawRect(Rect.fromCenter(center:m,width:62,height:62),Paint()..color=const Color(0xffa96d32));c.drawLine(m-const Offset(25,25),m+const Offset(25,25),Paint()..color=const Color(0xff71441f)..strokeWidth=7);c.drawLine(m+const Offset(25,-25),m+const Offset(-25,25),Paint()..color=const Color(0xff71441f)..strokeWidth=7);break;case _ThingKind.vine:c.drawCircle(m,35,Paint()..color=const Color(0xff236d35));for(int i=0;i<5;i++)c.drawCircle(m+Offset(math.cos(i*1.25)*25,math.sin(i*1.25)*25),12,Paint()..color=const Color(0xff4fa94d));break;case _ThingKind.rock:c.drawCircle(m,40,Paint()..color=const Color(0xff6f7a72));break;case _ThingKind.switchPad:c.drawCircle(m,31,Paint()..color=active?const Color(0xffffe65c):const Color(0xff5e6871));c.drawCircle(m,18,Paint()..color=active?Colors.white:const Color(0xff8c9aa4));break;case _ThingKind.torch:c.drawRect(Rect.fromCenter(center:m+const Offset(0,18),width:8,height:45),Paint()..color=const Color(0xff6f4224));c.drawCircle(m-const Offset(0,12),active?18:10,Paint()..color=active?const Color(0xffff8a2b):const Color(0xff6c6c6c));break;}if(flash>0)c.drawCircle(m,43,Paint()..color=Colors.white.withValues(alpha:flash*.45));}@override bool shouldRepaint(covariant _ThingPainter o)=>true;}
class _IcePainter extends CustomPainter{const _IcePainter();@override void paint(Canvas c,Size s){final m=s.center(Offset.zero);final p=Path()..moveTo(m.dx,m.dy-34)..lineTo(m.dx+31,m.dy-16)..lineTo(m.dx+27,m.dy+28)..lineTo(m.dx-27,m.dy+28)..lineTo(m.dx-31,m.dy-16)..close();c.drawPath(p,Paint()..color=const Color(0xff91e8ff));c.drawPath(p,Paint()..color=Colors.white70..style=PaintingStyle.stroke..strokeWidth=3);}@override bool shouldRepaint(covariant CustomPainter o)=>false;}
class _MagicPainter extends CustomPainter{const _MagicPainter(this.a,this.b,this.e,this.life);final Offset a,b;final _Element e;final double life;@override void paint(Canvas c,Size s){final col=switch(e){_Element.ice=>const Color(0xff8eeaff),_Element.fire=>const Color(0xffff7b32),_Element.wind=>const Color(0xffd9fff1),_Element.thunder=>const Color(0xffffe54d)};final p=Paint()..color=col.withValues(alpha:life.clamp(0,1))..strokeWidth=6..strokeCap=StrokeCap.round;c.drawLine(a,b,p);c.drawCircle(a,13+10*(1-life),Paint()..color=col.withValues(alpha:life*.7));c.drawCircle(b,22+20*(1-life),Paint()..color=col.withValues(alpha:life*.45));}@override bool shouldRepaint(covariant _MagicPainter o)=>true;}
