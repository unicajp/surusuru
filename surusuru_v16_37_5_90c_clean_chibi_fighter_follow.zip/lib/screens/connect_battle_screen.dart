import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../game/game_controller.dart';

class ConnectBattleScreen extends StatefulWidget {
  final GameController controller;
  final int stageId;

  const ConnectBattleScreen({
    super.key,
    required this.controller,
    required this.stageId,
  });

  @override
  State<ConnectBattleScreen> createState() => _ConnectBattleScreenState();
}

class _DummyEnemy {
  _DummyEnemy(this.pos, this.phase);
  Offset pos;
  final double phase;
}

class _ConnectBattleScreenState extends State<ConnectBattleScreen> {
  Timer? _timer;
  DateTime _last = DateTime.now();
  Size _field = Size.zero;

  Offset _hero = const Offset(190, 360);
  Offset _velocity = Offset.zero;
  Offset _target = const Offset(190, 360);
  bool _holding = false;
  double _time = 0;
  double _tilt = 0;
  final List<Offset> _trail = <Offset>[];
  final List<_DummyEnemy> _enemies = <_DummyEnemy>[];

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(milliseconds: 16), (_) => _tick());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _seed(Size size) {
    if (_field != Size.zero) return;
    _field = size;
    _hero = Offset(size.width * .5, size.height * .72);
    _target = _hero;
    _enemies.addAll(<_DummyEnemy>[
      _DummyEnemy(Offset(size.width * .22, size.height * .28), .2),
      _DummyEnemy(Offset(size.width * .50, size.height * .20), 1.5),
      _DummyEnemy(Offset(size.width * .78, size.height * .31), 2.8),
    ]);
  }

  void _tick() {
    if (!mounted || _field == Size.zero) return;
    final now = DateTime.now();
    double dt = now.difference(_last).inMicroseconds / 1000000;
    _last = now;
    dt = dt.clamp(0.0, .035);
    _time += dt;

    // Spring-like follow: the finger is a target, not the character position.
    final Offset delta = _target - _hero;
    final double spring = _holding ? 28.0 : 12.0;
    final double damping = _holding ? 8.2 : 6.8;
    _velocity += delta * spring * dt;
    _velocity *= math.exp(-damping * dt);

    // Keep enough inertia to overshoot on sudden stops, but cap extreme speed.
    final double speed = _velocity.distance;
    if (speed > 1050) _velocity = _velocity / speed * 1050;
    _hero += _velocity * dt;
    _hero = Offset(
      _hero.dx.clamp(38.0, _field.width - 38.0),
      _hero.dy.clamp(54.0, _field.height - 48.0),
    );

    final double wantedTilt = (_velocity.dx / 520).clamp(-.34, .34);
    _tilt += (wantedTilt - _tilt) * math.min(1, dt * 10);

    if (_velocity.distance > 90) {
      _trail.insert(0, _hero);
      if (_trail.length > 8) _trail.removeLast();
    } else if (_trail.isNotEmpty && (_time * 30).floor().isEven) {
      _trail.removeLast();
    }
    setState(() {});
  }

  void _down(Offset p) {
    setState(() {
      _holding = true;
      _target = p;
    });
  }

  void _move(Offset p) {
    _holding = true;
    _target = p;
  }

  void _up() {
    // On release, stop pulling. The target becomes the current position so
    // residual velocity produces a tiny natural overshoot before settling.
    _holding = false;
    _target = _hero;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF122433),
      body: SafeArea(
        child: Column(
          children: <Widget>[
            SizedBox(
              height: 64,
              child: Row(
                children: <Widget>[
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    '冒険  STAGE ${widget.stageId}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const Spacer(),
                  const Padding(
                    padding: EdgeInsets.only(right: 18),
                    child: Text(
                      '操作テスト',
                      style: TextStyle(
                        color: Color(0xFFFFD978),
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: LayoutBuilder(
                builder: (context, c) {
                  final size = Size(c.maxWidth, c.maxHeight);
                  _seed(size);
                  return Listener(
                    behavior: HitTestBehavior.opaque,
                    onPointerDown: (e) => _down(e.localPosition),
                    onPointerMove: (e) => _move(e.localPosition),
                    onPointerUp: (_) => _up(),
                    onPointerCancel: (_) => _up(),
                    child: CustomPaint(
                      size: Size.infinite,
                      painter: _BattlePrototypePainter(
                        hero: _hero,
                        velocity: _velocity,
                        tilt: _tilt,
                        time: _time,
                        holding: _holding,
                        target: _target,
                        trail: _trail,
                        enemies: _enemies,
                      ),
                    ),
                  );
                },
              ),
            ),
            Container(
              height: 58,
              alignment: Alignment.center,
              color: const Color(0xFF0D1C28),
              child: const Text(
                '指で動かして、剣士の重さと追従感を確認',
                style: TextStyle(
                  color: Colors.white70,
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BattlePrototypePainter extends CustomPainter {
  const _BattlePrototypePainter({
    required this.hero,
    required this.velocity,
    required this.tilt,
    required this.time,
    required this.holding,
    required this.target,
    required this.trail,
    required this.enemies,
  });

  final Offset hero;
  final Offset velocity;
  final double tilt;
  final double time;
  final bool holding;
  final Offset target;
  final List<Offset> trail;
  final List<_DummyEnemy> enemies;

  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()..color = const Color(0xFF173B3B);
    canvas.drawRect(Offset.zero & size, bg);

    // Subtle battlefield rings keep depth without looking like a puzzle board.
    final ring = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..color = Colors.white.withValues(alpha: .045);
    for (double r = 90; r < size.width * .85; r += 82) {
      canvas.drawCircle(Offset(size.width / 2, size.height * .48), r, ring);
    }

    for (final e in enemies) {
      _drawMonster(canvas, e.pos + Offset(0, math.sin(time * 2 + e.phase) * 3));
    }

    final speed = velocity.distance;
    if (speed > 220) {
      for (var i = trail.length - 1; i >= 0; i--) {
        final alpha = (1 - i / math.max(1, trail.length)) * .10;
        _drawHero(canvas, trail[i], tilt, time, alpha: alpha, ghost: true);
      }
    }

    if (holding) {
      canvas.drawCircle(
        target,
        16,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..color = Colors.white.withValues(alpha: .16),
      );
    }

    _drawHero(canvas, hero, tilt, time, alpha: 1);
  }

  void _drawHero(
    Canvas canvas,
    Offset p,
    double lean,
    double t, {
    required double alpha,
    bool ghost = false,
  }) {
    canvas.save();
    final bob = ghost ? 0.0 : math.sin(t * 9) * math.min(2.4, velocity.distance / 220);
    canvas.translate(p.dx, p.dy + bob);
    canvas.rotate(lean);

    Color c(Color color) => color.withValues(alpha: alpha);
    final shadow = Paint()..color = Colors.black.withValues(alpha: alpha * .20);
    canvas.drawOval(const Rect.fromLTWH(-23, 29, 46, 13), shadow);

    // Cape / scarf: gives direction and makes fast turns readable.
    final scarf = Path()
      ..moveTo(-8, -14)
      ..quadraticBezierTo(-28 - velocity.dx * .012, -8, -32 - velocity.dx * .018, 5)
      ..quadraticBezierTo(-18, 2, -7, 0)
      ..close();
    canvas.drawPath(scarf, Paint()..color = c(const Color(0xFFD84B55)));

    // Legs and boots.
    final dark = Paint()..color = c(const Color(0xFF273344));
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-13, 17, 10, 19), const Radius.circular(4)), dark);
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(3, 17, 10, 19), const Radius.circular(4)), dark);
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-17, 30, 15, 8), const Radius.circular(4)), Paint()..color = c(const Color(0xFF5A3C31)));
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(2, 30, 15, 8), const Radius.circular(4)), Paint()..color = c(const Color(0xFF5A3C31)));

    // Torso: compact JRPG fighter silhouette, clearly separate from puzzle balls.
    canvas.drawRRect(
      RRect.fromRectAndRadius(const Rect.fromLTWH(-18, -7, 36, 31), const Radius.circular(9)),
      Paint()..color = c(const Color(0xFF3E6FA7)),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(const Rect.fromLTWH(-15, -4, 30, 12), const Radius.circular(5)),
      Paint()..color = c(const Color(0xFFB9C9D8)),
    );
    canvas.drawRect(const Rect.fromLTWH(-18, 10, 36, 6), Paint()..color = c(const Color(0xFF6C432B)));
    canvas.drawCircle(const Offset(0, 13), 3, Paint()..color = c(const Color(0xFFFFD35C)));

    // Arms.
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-24, -2, 10, 23), const Radius.circular(5)), Paint()..color = c(const Color(0xFF3E6FA7)));
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(14, -2, 10, 23), const Radius.circular(5)), Paint()..color = c(const Color(0xFF3E6FA7)));

    // Sword, intentionally oversized so swinging the character reads as combat.
    canvas.save();
    canvas.translate(21, 7);
    canvas.rotate(-.55 - lean * .7);
    final blade = Path()
      ..moveTo(-3, 3)
      ..lineTo(3, 3)
      ..lineTo(4, -43)
      ..lineTo(0, -53)
      ..lineTo(-4, -43)
      ..close();
    canvas.drawPath(blade, Paint()..color = c(const Color(0xFFE9F2F7)));
    canvas.drawPath(blade, Paint()..style = PaintingStyle.stroke..strokeWidth = 1.5..color = c(const Color(0xFF7895A8)));
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-11, 1, 22, 5), const Radius.circular(2)), Paint()..color = c(const Color(0xFFFFC64B)));
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-3, 5, 6, 14), const Radius.circular(2)), Paint()..color = c(const Color(0xFF70442F)));
    canvas.restore();

    // Head and hair.
    canvas.drawCircle(const Offset(0, -25), 18, Paint()..color = c(const Color(0xFFFFD2A5)));
    final hair = Path()
      ..moveTo(-17, -28)
      ..quadraticBezierTo(-13, -47, 3, -45)
      ..quadraticBezierTo(19, -43, 18, -24)
      ..lineTo(10, -32)
      ..lineTo(5, -26)
      ..lineTo(-1, -34)
      ..lineTo(-8, -27)
      ..lineTo(-14, -31)
      ..close();
    canvas.drawPath(hair, Paint()..color = c(const Color(0xFF4A342D)));
    canvas.drawCircle(const Offset(-6, -24), 1.7, Paint()..color = c(const Color(0xFF26313B)));
    canvas.drawCircle(const Offset(6, -24), 1.7, Paint()..color = c(const Color(0xFF26313B)));
    canvas.drawLine(const Offset(-4, -17), const Offset(4, -17), Paint()..strokeWidth = 1.4..strokeCap = StrokeCap.round..color = c(const Color(0xFF9A5D52)));

    canvas.restore();
  }

  void _drawMonster(Canvas canvas, Offset p) {
    canvas.save();
    canvas.translate(p.dx, p.dy);
    canvas.drawOval(const Rect.fromLTWH(-22, 19, 44, 10), Paint()..color = Colors.black.withValues(alpha: .18));

    // Horned slime/beast hybrid: still simple, but no round puzzle-face sprite.
    final body = Path()
      ..moveTo(-24, 20)
      ..quadraticBezierTo(-27, -8, -13, -18)
      ..lineTo(-18, -31)
      ..lineTo(-4, -22)
      ..quadraticBezierTo(0, -25, 4, -22)
      ..lineTo(18, -31)
      ..lineTo(13, -17)
      ..quadraticBezierTo(28, -6, 24, 20)
      ..quadraticBezierTo(0, 31, -24, 20)
      ..close();
    canvas.drawPath(body, Paint()..color = const Color(0xFF7650A4));
    canvas.drawPath(body, Paint()..style = PaintingStyle.stroke..strokeWidth = 2..color = const Color(0xFF4C3473));
    canvas.drawCircle(const Offset(-8, -5), 3, Paint()..color = const Color(0xFFFFE65C));
    canvas.drawCircle(const Offset(8, -5), 3, Paint()..color = const Color(0xFFFFE65C));
    canvas.drawCircle(const Offset(-8, -5), 1.4, Paint()..color = const Color(0xFF241B31));
    canvas.drawCircle(const Offset(8, -5), 1.4, Paint()..color = const Color(0xFF241B31));
    canvas.drawLine(const Offset(-7, 8), const Offset(7, 8), Paint()..strokeWidth = 2..color = const Color(0xFF3A274E));
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _BattlePrototypePainter oldDelegate) => true;
}
