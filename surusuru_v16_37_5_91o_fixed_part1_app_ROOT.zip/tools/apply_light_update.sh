#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -ne 1 ]; then
  echo "Usage: bash tools/apply_light_update.sh /path/to/light_update.zip"
  exit 1
fi

ZIP="$1"
ROOT="$(pwd)"
FIXED="$ROOT/assets/sprites/hero_swordswoman"

if [ ! -d "$FIXED" ]; then
  echo "ERROR: fixed asset folder is missing: $FIXED"
  echo "Install the one-time V91c fixed-assets base first."
  exit 2
fi

required=(
  idle_01.png idle_02.png
  run_01.png run_02.png run_03.png run_04.png run_05.png
  attack_01.png attack_02.png attack_03.png attack_04.png attack_05.png attack_06.png
)
for f in "${required[@]}"; do
  if [ ! -f "$FIXED/$f" ]; then
    echo "ERROR: missing fixed asset: $FIXED/$f"
    exit 3
  fi
done

unzip -o "$ZIP" -d "$ROOT"

echo "Light update applied. Fixed character assets were preserved."
