import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../game/game_controller.dart';
import '../sfx_manager.dart';

class ConnectBattleScreen extends StatefulWidget {
  final GameController controller;
  final int stageId;

  const ConnectBattleScreen({
    super.key,
    required this.controller,
    required this.stageId,
  });

  @override
  State<ConnectBattleScreen> createState() => _ConnectBattleScreenState();
}

class _MapEnemy {
  _MapEnemy({
    required this.position,
    required this.type,
    required this.size,
    required int hp,
    required this.phase,
  })  : hp = hp,
        maxHp = hp;

  Offset position;
  Offset velocity = Offset.zero;
  final int type;
  final double size;
  final int maxHp;
  int hp;
  final double phase;
  double flash = 0;
  double pop = 0;
  int lastHitMs = 0;
}

class _SlashFx {
  _SlashFx({required this.position, required this.direction, required this.power});
  final Offset position;
  final Offset direction;
  final double power;
  double life = 1;
}

class _ConnectBattleScreenState extends State<ConnectBattleScreen> {
  Timer? _timer;
  DateTime _last = DateTime.now();
  Size _field = Size.zero;

  Offset _hero = Offset.zero;
  Offset _target = Offset.zero;
  Offset _velocity = Offset.zero;
  Offset _pointerVelocity = Offset.zero;
  Offset _lastPointer = Offset.zero;
  int _lastPointerMs = 0;
  bool _holding = false;

  bool _faceRight = true;
  bool _verticalFacing = false;
  bool _verticalFacingUp = false;
  bool _attack = false;
  double _attackTime = 0;
  double _time = 0;
  double _screenShake = 0;
  double _hitStop = 0;

  final List<_MapEnemy> _enemies = <_MapEnemy>[];
  final List<_SlashFx> _slashFx = <_SlashFx>[];

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(milliseconds: 16), (_) => _tick());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _seed(Size size) {
    if (_field != Size.zero) return;
    _field = size;
    _hero = Offset(size.width * .5, size.height * .56);
    _target = _hero;

    final spots = <Offset>[
      Offset(.18, .18),
      Offset(.48, .16),
      Offset(.78, .20),
      Offset(.27, .34),
      Offset(.69, .36),
      Offset(.14, .54),
      Offset(.84, .53),
      Offset(.28, .69),
      Offset(.67, .70),
      Offset(.13, .82),
      Offset(.48, .84),
      Offset(.84, .80),
    ];

    for (var i = 0; i < spots.length; i++) {
      final p = spots[i];
      final sizePx = i % 5 == 3 ? 72.0 : (i % 4 == 2 ? 58.0 : 48.0);
      final hp = sizePx >= 70 ? 6 : (sizePx >= 58 ? 3 : 2);
      _enemies.add(
        _MapEnemy(
          position: Offset(size.width * p.dx, size.height * p.dy),
          type: i % 5,
          size: sizePx,
          hp: hp,
          phase: i * 1.37,
        ),
      );
    }
  }

  void _tick() {
    if (!mounted || _field == Size.zero) return;
    final now = DateTime.now();
    var dt = now.difference(_last).inMicroseconds / 1000000.0;
    _last = now;
    dt = dt.clamp(0.0, .035);
    _time += dt;

    _screenShake = math.max(0, _screenShake - dt * 7.5);
    _hitStop = math.max(0, _hitStop - dt);

    if (_attack) {
      _attackTime += dt;
      if (_attackTime >= .30) {
        _attack = false;
        _attackTime = 0;
      }
    }

    for (final fx in _slashFx) {
      fx.life -= dt * 4.8;
    }
    _slashFx.removeWhere((fx) => fx.life <= 0);

    final delta = _target - _hero;
    final desired = delta * (_holding ? 14.0 : 4.5) + (_holding ? _pointerVelocity * .16 : Offset.zero);
    final follow = 1.0 - math.exp(-(_holding ? 18.0 : 8.0) * dt);
    _velocity += (desired - _velocity) * follow;

    final speed = _velocity.distance;
    if (speed > 980) {
      _velocity = _velocity / speed * 980;
    }

    final movementScale = _hitStop > 0 ? .25 : 1.0;
    _hero += _velocity * dt * movementScale;
    _hero = Offset(
      _hero.dx.clamp(34.0, _field.width - 34.0),
      _hero.dy.clamp(42.0, _field.height - 28.0),
    );

    if (_velocity.distance > 38) {
      if (_velocity.dy.abs() > _velocity.dx.abs() * .78) {
        _verticalFacing = true;
        _verticalFacingUp = _velocity.dy < 0;
      } else if (_velocity.dx.abs() > 38) {
        _verticalFacing = false;
        _faceRight = _velocity.dx >= 0;
      }
    }

    for (final enemy in _enemies) {
      if (enemy.hp <= 0) {
        enemy.pop = (enemy.pop + dt * 4.2).clamp(0.0, 1.0);
        continue;
      }
      enemy.flash = math.max(0, enemy.flash - dt * 7);

      final drift = Offset(
        math.sin(_time * .72 + enemy.phase),
        math.cos(_time * .83 + enemy.phase * 1.13),
      );
      enemy.velocity += drift * dt * 4.0;
      enemy.velocity *= math.pow(.92, dt * 60).toDouble();
      enemy.position += enemy.velocity * dt * 18;

      final margin = enemy.size * .55;
      if (enemy.position.dx < margin || enemy.position.dx > _field.width - margin) {
        enemy.position = Offset(enemy.position.dx.clamp(margin, _field.width - margin), enemy.position.dy);
        enemy.velocity = Offset(-enemy.velocity.dx * .7, enemy.velocity.dy);
      }
      if (enemy.position.dy < margin + 10 || enemy.position.dy > _field.height - margin) {
        enemy.position = Offset(enemy.position.dx, enemy.position.dy.clamp(margin + 10, _field.height - margin));
        enemy.velocity = Offset(enemy.velocity.dx, -enemy.velocity.dy * .7);
      }
    }

    _resolveContacts();
    setState(() {});
  }

  void _down(Offset p) {
    _holding = true;
    _lastPointer = p;
    _lastPointerMs = DateTime.now().millisecondsSinceEpoch;
    _pointerVelocity = Offset.zero;
    _target = p;
  }

  void _move(Offset p) {
    final now = DateTime.now().millisecondsSinceEpoch;
    final ms = math.max(1, now - _lastPointerMs);
    final step = p - _lastPointer;
    final instant = step * (1000.0 / ms);
    _pointerVelocity += (instant - _pointerVelocity) * .58;
    _lastPointer = p;
    _lastPointerMs = now;
    _target = p;

    if (_pointerVelocity.distance > 430) {
      _attack = true;
      _attackTime = 0;
      if (_pointerVelocity.dy.abs() > _pointerVelocity.dx.abs() * .72) {
        _verticalFacing = true;
        _verticalFacingUp = _pointerVelocity.dy < 0;
      } else {
        _verticalFacing = false;
        _faceRight = _pointerVelocity.dx >= 0;
      }
    }
  }

  void _up(Offset p) {
    _holding = false;
    final fling = _pointerVelocity.distance.clamp(0.0, 760.0);
    if (fling > 260) {
      _velocity += _pointerVelocity / math.max(1.0, _pointerVelocity.distance) * (fling * .22);
    }
    _target = _hero;
  }

  void _resolveContacts() {
    final now = DateTime.now().millisecondsSinceEpoch;
    final speed = math.max(_velocity.distance, _pointerVelocity.distance * .72);
    final attacking = _attack || (_holding && speed > 380);

    for (final enemy in _enemies) {
      if (enemy.hp <= 0) continue;
      final d = enemy.position - _hero;
      final hitRadius = enemy.size * .48 + 31;
      if (d.distance > hitRadius) continue;

      if (attacking && now - enemy.lastHitMs > 155) {
        enemy.lastHitMs = now;
        final damage = speed > 760 ? 2 : 1;
        enemy.hp = math.max(0, enemy.hp - damage);
        enemy.flash = 1;
        final dir = d.distance > 1 ? d / d.distance : const Offset(1, 0);
        enemy.velocity += dir * (speed > 760 ? 7.5 : 4.5);
        _slashFx.add(_SlashFx(position: enemy.position, direction: dir, power: damage.toDouble()));
        _screenShake = math.max(_screenShake, damage == 2 ? .42 : .22);
        _hitStop = math.max(_hitStop, damage == 2 ? .028 : .016);
        SfxManager.instance.chanceBattleHit();
        HapticFeedback.lightImpact();
        if (enemy.hp <= 0) {
          enemy.pop = 0;
          SfxManager.instance.chanceEnemyDown();
          HapticFeedback.mediumImpact();
        }
      } else if (!attacking) {
        final dir = d.distance > 1 ? d / d.distance : const Offset(1, 0);
        _hero -= dir * 2.0;
        _velocity -= dir * 28;
      }
    }
  }

  int get _runFrame => ((_time * 11).floor() % 5) + 1;
  int get _verticalRunFrame => ((_time * 9).floor() % 3) + 1;
  int get _attackFrame => ((_attackTime / .30 * 6).floor().clamp(0, 5)) + 1;
  int get _verticalAttackFrame => ((_attackTime / .30 * 2).floor().clamp(0, 1)) + 1;

  @override
  Widget build(BuildContext context) {
    final remaining = _enemies.where((e) => e.hp > 0).length;
    return Scaffold(
      backgroundColor: const Color(0xFF193B2A),
      body: SafeArea(
        child: Column(
          children: <Widget>[
            SizedBox(
              height: 56,
              child: Row(
                children: <Widget>[
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                  ),
                  const Text(
                    '冒険マップ',
                    style: TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w900),
                  ),
                  const Spacer(),
                  Padding(
                    padding: const EdgeInsets.only(right: 14),
                    child: Text(
                      '敵 $remaining体',
                      style: const TextStyle(color: Color(0xFFFFD978), fontWeight: FontWeight.w900),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: LayoutBuilder(
                builder: (context, c) {
                  final size = Size(c.maxWidth, c.maxHeight);
                  _seed(size);
                  return Listener(
                    behavior: HitTestBehavior.opaque,
                    onPointerDown: (e) => _down(e.localPosition),
                    onPointerMove: (e) => _move(e.localPosition),
                    onPointerUp: (e) => _up(e.localPosition),
                    onPointerCancel: (_) {
                      _holding = false;
                      _target = _hero;
                    },
                    child: Stack(
                      fit: StackFit.expand,
                      children: <Widget>[
                        const CustomPaint(painter: _TopDownMapPainter()),
                        ..._buildEnemies(),
                        ..._buildSlashEffects(),
                        _buildHero(),
                        Positioned(
                          left: 12,
                          top: 10,
                          child: _hintChip('自由に上下左右へ移動 ・ 速く振ると斬る'),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
            Container(
              height: 44,
              alignment: Alignment.center,
              color: const Color(0xFF102A20),
              child: const Text(
                '技・進行ゲージなし。マップを自由に動いて敵とぶつかって遊ぶ試作',
                style: TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.w700),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _hintChip(String text) {
    return IgnorePointer(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
        decoration: BoxDecoration(
          color: const Color(0xFF17314A).withValues(alpha: .72),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Colors.white.withValues(alpha: .20)),
        ),
        child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800)),
      ),
    );
  }

  List<Widget> _buildEnemies() {
    return _enemies.map((e) {
      final s = e.size;
      if (e.hp <= 0) {
        if (e.pop >= 1) return const SizedBox.shrink();
        return Positioned(
          left: e.position.dx - s * .65,
          top: e.position.dy - s * .65,
          child: IgnorePointer(
            child: SizedBox(width: s * 1.3, height: s * 1.3, child: CustomPaint(painter: _BattlePopPainter(progress: e.pop))),
          ),
        );
      }

      Widget monster = CustomPaint(
        size: Size.square(s),
        painter: _BattleTsumPainter(type: e.type, selected: e.size >= 70),
      );
      if (e.flash > 0) {
        monster = Stack(
          fit: StackFit.expand,
          children: <Widget>[
            monster,
            Opacity(
              opacity: (e.flash * .68).clamp(0.0, .68),
              child: Container(decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle)),
            ),
          ],
        );
      }

      final hpRatio = e.hp / e.maxHp;
      return Positioned(
        left: e.position.dx - s / 2 + math.sin(_time * 71) * _screenShake * 1.8,
        top: e.position.dy - s / 2 + math.cos(_time * 83) * _screenShake * 1.2,
        child: IgnorePointer(
          child: SizedBox(
            width: s,
            height: s + 9,
            child: Stack(
              clipBehavior: Clip.none,
              children: <Widget>[
                Positioned(left: 0, top: 0, width: s, height: s, child: monster),
                if (e.maxHp >= 3)
                  Positioned(
                    left: s * .10,
                    right: s * .10,
                    bottom: 0,
                    child: Container(
                      height: 4,
                      decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(99)),
                      alignment: Alignment.centerLeft,
                      child: FractionallySizedBox(
                        widthFactor: hpRatio.clamp(0.0, 1.0).toDouble(),
                        child: Container(
                          decoration: BoxDecoration(color: const Color(0xFFFFC857), borderRadius: BorderRadius.circular(99)),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      );
    }).toList();
  }

  List<Widget> _buildSlashEffects() {
    return _slashFx.map((fx) {
      return Positioned(
        left: fx.position.dx - 62,
        top: fx.position.dy - 62,
        child: IgnorePointer(
          child: SizedBox(
            width: 124,
            height: 124,
            child: CustomPaint(painter: _SimpleSlashPainter(life: fx.life, direction: fx.direction, power: fx.power)),
          ),
        ),
      );
    }).toList();
  }

  Widget _buildHero() {
    final moving = !_attack && _velocity.distance > 48;
    final verticalPrefix = _verticalFacingUp ? 'up' : 'down';
    final path = _attack && _verticalFacing
        ? 'assets/sprites/hero_swordswoman/${verticalPrefix}_attack_${_verticalAttackFrame.toString().padLeft(2, '0')}.png'
        : _attack
            ? 'assets/sprites/hero_swordswoman/attack_${_attackFrame.toString().padLeft(2, '0')}.png'
            : moving && _verticalFacing
                ? 'assets/sprites/hero_swordswoman/${verticalPrefix}_run_${_verticalRunFrame.toString().padLeft(2, '0')}.png'
                : moving
                    ? 'assets/sprites/hero_swordswoman/run_${_runFrame.toString().padLeft(2, '0')}.png'
                    : 'assets/sprites/hero_swordswoman/idle_01.png';

    const boxW = 156.0;
    const boxH = 117.0;
    Widget sprite = Image.asset(
      path,
      width: boxW,
      height: boxH,
      fit: BoxFit.contain,
      alignment: Alignment.bottomCenter,
      filterQuality: FilterQuality.high,
      gaplessPlayback: true,
    );
    if (!_verticalFacing && !_faceRight) {
      sprite = Transform(
        alignment: Alignment.center,
        transform: Matrix4.diagonal3Values(-1, 1, 1),
        child: sprite,
      );
    }

    final bob = moving ? math.sin(_time * 13) * 1.6 : math.sin(_time * 4.2) * .8;
    return Positioned(
      left: _hero.dx - boxW / 2 + math.sin(_time * 71) * _screenShake * 1.8,
      top: _hero.dy - boxH * .72 + bob + math.cos(_time * 83) * _screenShake * 1.2,
      child: IgnorePointer(child: sprite),
    );
  }
}

class _SimpleSlashPainter extends CustomPainter {
  const _SimpleSlashPainter({required this.life, required this.direction, required this.power});
  final double life;
  final Offset direction;
  final double power;

  @override
  void paint(Canvas canvas, Size size) {
    final alpha = life.clamp(0.0, 1.0);
    final center = Offset(size.width / 2, size.height / 2);
    final dir = direction.distance > 0 ? direction / direction.distance : const Offset(1, 0);
    final side = Offset(-dir.dy, dir.dx);
    final p0 = center - dir * 36 - side * 22;
    final p1 = center + dir * 34;
    final p2 = center + dir * 44 + side * 26;
    final path = Path()..moveTo(p0.dx, p0.dy)..quadraticBezierTo(p1.dx, p1.dy, p2.dx, p2.dy);
    canvas.drawPath(
      path,
      Paint()
        ..color = const Color(0xFF65D9FF).withValues(alpha: alpha * .62)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 8 + power * 2
        ..strokeCap = StrokeCap.round,
    );
    canvas.drawPath(
      path,
      Paint()
        ..color = Colors.white.withValues(alpha: alpha)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3.0
        ..strokeCap = StrokeCap.round,
    );
  }

  @override
  bool shouldRepaint(covariant _SimpleSlashPainter oldDelegate) => true;
}

class _BattleTsumPainter extends CustomPainter {
  const _BattleTsumPainter({required this.type, required this.selected});
  final int type;
  final bool selected;

  Paint _gloss(Color light, Color base, Color dark, Offset c, double r) => Paint()
    ..shader = RadialGradient(
      center: const Alignment(-.34, -.42),
      radius: 1.05,
      colors: [light, base, dark],
      stops: const [0, .55, 1],
    ).createShader(Rect.fromCircle(center: c, radius: r));

  void _shine(Canvas canvas, Offset c, double r) {
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(-r * .28, -r * .38), width: r * .48, height: r * .25),
      Paint()..color = Colors.white.withValues(alpha: .34),
    );
  }

  void _eyes(Canvas canvas, Offset c, double r, {double y = -.10}) {
    final p = Paint()..color = const Color(0xFF252525);
    canvas.drawCircle(c + Offset(-r * .25, r * y), r * .075, p);
    canvas.drawCircle(c + Offset(r * .25, r * y), r * .075, p);
    final hi = Paint()..color = Colors.white.withValues(alpha: .9);
    canvas.drawCircle(c + Offset(-r * .225, r * (y - .025)), r * .018, hi);
    canvas.drawCircle(c + Offset(r * .275, r * (y - .025)), r * .018, hi);
  }

  void _blush(Canvas canvas, Offset c, double r) {
    final p = Paint()..color = const Color(0x55F38E9E);
    canvas.drawCircle(c + Offset(-r * .48, r * .13), r * .11, p);
    canvas.drawCircle(c + Offset(r * .48, r * .13), r * .11, p);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = math.min(size.width, size.height) / 2;
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(0, r * .12), width: r * 1.62, height: r * 1.58),
      Paint()
        ..color = const Color(0x33000000)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3),
    );
    switch (type) {
      case 0:
        _drawChick(canvas, c, r);
        break;
      case 1:
        _drawFrog(canvas, c, r);
        break;
      case 2:
        _drawPenguin(canvas, c, r);
        break;
      case 3:
        _drawDog(canvas, c, r);
        break;
      default:
        _drawBunny(canvas, c, r);
    }
    if (selected) {
      canvas.drawCircle(
        c,
        r * .82,
        Paint()
          ..color = Colors.white.withValues(alpha: .38)
          ..style = PaintingStyle.stroke
          ..strokeWidth = math.max(2, r * .07),
      );
    }
  }

  void _drawChick(Canvas canvas, Offset c, double r) {
    final body = _gloss(const Color(0xFFFFF08A), const Color(0xFFFFC928), const Color(0xFFE79A00), c, r);
    canvas.drawCircle(c, r * .82, body);
    _shine(canvas, c, r);
    final wing = Paint()..color = const Color(0xFFFFB51E);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(-r * .66, r * .12), width: r * .28, height: r * .48), wing);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(r * .66, r * .12), width: r * .28, height: r * .48), wing);
    _eyes(canvas, c, r);
    _blush(canvas, c, r);
    final beak = Path()
      ..moveTo(c.dx - r * .10, c.dy + r * .08)
      ..lineTo(c.dx + r * .12, c.dy + r * .08)
      ..lineTo(c.dx, c.dy + r * .20)
      ..close();
    canvas.drawPath(beak, Paint()..color = const Color(0xFFF18A18));
  }

  void _drawFrog(Canvas canvas, Offset c, double r) {
    final body = _gloss(const Color(0xFFA6F3A9), const Color(0xFF63D46B), const Color(0xFF2C9A42), c, r);
    canvas.drawCircle(c, r * .82, body);
    _shine(canvas, c, r);
    canvas.drawCircle(c + Offset(-r * .42, -r * .55), r * .25, body);
    canvas.drawCircle(c + Offset(r * .42, -r * .55), r * .25, body);
    for (final x in [-.42, .42]) {
      canvas.drawCircle(c + Offset(r * x, -r * .55), r * .11, Paint()..color = Colors.white);
      canvas.drawCircle(c + Offset(r * x, -r * .55), r * .055, Paint()..color = const Color(0xFF1E2A25));
    }
    _blush(canvas, c, r);
    canvas.drawArc(
      Rect.fromCenter(center: c + Offset(0, r * .12), width: r * .60, height: r * .36),
      .15,
      math.pi - .30,
      false,
      Paint()
        ..color = const Color(0xFF25873A)
        ..style = PaintingStyle.stroke
        ..strokeWidth = math.max(1.8, r * .07)
        ..strokeCap = StrokeCap.round,
    );
  }

  void _drawPenguin(Canvas canvas, Offset c, double r) {
    final blue = _gloss(const Color(0xFF9DE1FF), const Color(0xFF4F9ED8), const Color(0xFF2464A8), c, r);
    canvas.drawCircle(c, r * .82, blue);
    _shine(canvas, c, r);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(0, r * .19), width: r, height: r * 1.10), Paint()..color = const Color(0xFFEAF6FF));
    final wing = Paint()..color = const Color(0xFF2E6F9F);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(-r * .62, r * .08), width: r * .22, height: r * .56), wing);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(r * .62, r * .08), width: r * .22, height: r * .56), wing);
    _eyes(canvas, c + Offset(0, -r * .10), r, y: 0);
    final beak = Path()
      ..moveTo(c.dx - r * .10, c.dy + r * .01)
      ..lineTo(c.dx + r * .10, c.dy + r * .01)
      ..lineTo(c.dx, c.dy + r * .15)
      ..close();
    canvas.drawPath(beak, Paint()..color = const Color(0xFFFF9B2F));
  }

  void _drawDog(Canvas canvas, Offset c, double r) {
    final ear = Paint()..color = const Color(0xFF7453B7);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(-r * .62, -r * .18), width: r * .42, height: r * .72), ear);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(r * .62, -r * .18), width: r * .42, height: r * .72), ear);
    canvas.drawCircle(c, r * .82, _gloss(const Color(0xFFE4D7FF), const Color(0xFFBFA8F2), const Color(0xFF8060C7), c, r));
    _shine(canvas, c, r);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(r * .26, -r * .18), width: r * .36, height: r * .46), ear);
    _eyes(canvas, c, r);
    _blush(canvas, c, r);
    canvas.drawCircle(c + Offset(0, r * .16), r * .09, Paint()..color = const Color(0xFF3E315A));
  }

  void _drawBunny(Canvas canvas, Offset c, double r) {
    final body = _gloss(const Color(0xFFFFE2EE), const Color(0xFFFFA7C7), const Color(0xFFE66B9B), c, r);
    final inner = Paint()..color = const Color(0xFFFF6F9F);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(-r * .28, -r * .86), width: r * .32, height: r * .88), body);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(r * .28, -r * .86), width: r * .32, height: r * .88), body);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(-r * .28, -r * .86), width: r * .11, height: r * .55), inner);
    canvas.drawOval(Rect.fromCenter(center: c + Offset(r * .28, -r * .86), width: r * .11, height: r * .55), inner);
    canvas.drawCircle(c + Offset(0, r * .04), r * .76, body);
    _shine(canvas, c + Offset(0, r * .04), r * .92);
    _eyes(canvas, c + Offset(0, r * .02), r);
    _blush(canvas, c, r);
    canvas.drawCircle(c + Offset(0, r * .16), r * .06, Paint()..color = const Color(0xFF8C3F61));
  }

  @override
  bool shouldRepaint(covariant _BattleTsumPainter oldDelegate) => oldDelegate.type != type || oldDelegate.selected != selected;
}

class _BattlePopPainter extends CustomPainter {
  const _BattlePopPainter({required this.progress});
  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    final life = (1 - progress).clamp(0.0, 1.0);
    final p = Offset(size.width / 2, size.height / 2);
    final r = (1 - life) * 24 + 5;
    final paint = Paint()
      ..color = Colors.white.withValues(alpha: life)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;
    canvas.drawCircle(p, r, paint);
    for (var i = 0; i < 7; i++) {
      final a = i * math.pi * 2 / 7;
      final a0 = p + Offset(math.cos(a), math.sin(a)) * r * .65;
      final a1 = p + Offset(math.cos(a), math.sin(a)) * r * 1.15;
      canvas.drawLine(a0, a1, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _BattlePopPainter oldDelegate) => oldDelegate.progress != progress;
}

class _TopDownMapPainter extends CustomPainter {
  const _TopDownMapPainter();

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Offset.zero & size, Paint()..color = const Color(0xFF79C95B));

    // Soft grass patches make the arena read as a field instead of a side-scroll lane.
    final patch = Paint()..color = const Color(0xFF67B94E).withValues(alpha: .45);
    canvas.drawOval(Rect.fromLTWH(size.width * .04, size.height * .08, size.width * .34, size.height * .22), patch);
    canvas.drawOval(Rect.fromLTWH(size.width * .61, size.height * .50, size.width * .34, size.height * .25), patch);
    canvas.drawOval(Rect.fromLTWH(size.width * .18, size.height * .72, size.width * .42, size.height * .20), patch);

    // A winding dirt path crossing in two directions evokes a small top-down adventure map.
    final roadPaint = Paint()
      ..color = const Color(0xFFE5C27E)
      ..style = PaintingStyle.stroke
      ..strokeWidth = math.max(46, size.width * .13)
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    final road = Path()
      ..moveTo(-18, size.height * .63)
      ..cubicTo(size.width * .23, size.height * .54, size.width * .45, size.height * .70, size.width * .66, size.height * .57)
      ..cubicTo(size.width * .80, size.height * .48, size.width * .90, size.height * .42, size.width + 20, size.height * .47);
    canvas.drawPath(road, roadPaint);

    final verticalRoad = Path()
      ..moveTo(size.width * .53, -18)
      ..cubicTo(size.width * .47, size.height * .24, size.width * .60, size.height * .39, size.width * .51, size.height + 22);
    canvas.drawPath(verticalRoad, roadPaint..strokeWidth = math.max(34, size.width * .10));

    // Pond in one corner.
    final pond = Rect.fromCenter(
      center: Offset(size.width * .16, size.height * .31),
      width: size.width * .24,
      height: size.height * .17,
    );
    canvas.drawOval(pond.inflate(5), Paint()..color = const Color(0xFFB9E5A3));
    canvas.drawOval(pond, Paint()..color = const Color(0xFF69C8E8));
    canvas.drawArc(
      pond.deflate(8),
      .2,
      math.pi * .8,
      false,
      Paint()
        ..color = Colors.white.withValues(alpha: .45)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.2,
    );

    // Trees around the perimeter leave the center open for direct movement.
    final trees = <Offset>[
      Offset(.05, .10), Offset(.20, .06), Offset(.38, .08), Offset(.76, .08), Offset(.93, .14),
      Offset(.94, .34), Offset(.07, .45), Offset(.93, .69), Offset(.08, .74), Offset(.18, .93),
      Offset(.42, .94), Offset(.72, .92), Offset(.91, .90),
    ];
    for (var i = 0; i < trees.length; i++) {
      _tree(canvas, Offset(size.width * trees[i].dx, size.height * trees[i].dy), i.isEven ? .72 : .60);
    }

    final rocks = <Offset>[
      Offset(.37, .25), Offset(.82, .30), Offset(.73, .78), Offset(.24, .61), Offset(.56, .37),
    ];
    for (final r in rocks) {
      _rock(canvas, Offset(size.width * r.dx, size.height * r.dy));
    }

    final flower = Paint()..color = const Color(0xFFFFF5D0);
    for (var i = 0; i < 24; i++) {
      final x = ((i * 83) % 97) / 97.0 * size.width;
      final y = ((i * 47 + 19) % 91) / 91.0 * size.height;
      canvas.drawCircle(Offset(x, y), 2.0, flower);
      canvas.drawCircle(Offset(x + 1.3, y), .8, Paint()..color = const Color(0xFFFFC857));
    }
  }

  void _tree(Canvas canvas, Offset p, double scale) {
    canvas.drawOval(
      Rect.fromCenter(center: p.translate(3, 17 * scale), width: 42 * scale, height: 15 * scale),
      Paint()..color = Colors.black.withValues(alpha: .13),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(center: p.translate(0, 10 * scale), width: 10 * scale, height: 32 * scale),
        Radius.circular(4 * scale),
      ),
      Paint()..color = const Color(0xFF8A613D),
    );
    canvas.drawCircle(p.translate(-10 * scale, -5 * scale), 18 * scale, Paint()..color = const Color(0xFF3B9851));
    canvas.drawCircle(p.translate(10 * scale, -8 * scale), 20 * scale, Paint()..color = const Color(0xFF46A95A));
    canvas.drawCircle(p.translate(0, -20 * scale), 19 * scale, Paint()..color = const Color(0xFF56B966));
  }

  void _rock(Canvas canvas, Offset p) {
    canvas.drawOval(
      Rect.fromCenter(center: p.translate(2, 4), width: 32, height: 17),
      Paint()..color = Colors.black.withValues(alpha: .12),
    );
    canvas.drawOval(Rect.fromCenter(center: p, width: 29, height: 18), Paint()..color = const Color(0xFF8D9A91));
    canvas.drawOval(Rect.fromCenter(center: p.translate(-5, -3), width: 12, height: 5), Paint()..color = Colors.white.withValues(alpha: .22));
  }

  @override
  bool shouldRepaint(covariant _TopDownMapPainter oldDelegate) => false;
}
