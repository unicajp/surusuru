import 'package:flutter/material.dart';

class GameBottomNav extends StatelessWidget {
  final String active;
  final VoidCallback onAdventure;
  final VoidCallback onShop;
  final VoidCallback onSurusuru;
  final VoidCallback onTraining;
  final VoidCallback onMap;

  const GameBottomNav({
    super.key,
    required this.active,
    required this.onAdventure,
    required this.onShop,
    required this.onSurusuru,
    required this.onTraining,
    required this.onMap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 68,
      margin: const EdgeInsets.fromLTRB(10, 0, 10, 9),
      padding: const EdgeInsets.fromLTRB(6, 5, 6, 5),
      decoration: BoxDecoration(
        color: const Color(0xFFFDFBF8).withOpacity(.96),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xFFEDE7DF)),
        boxShadow: const [
          BoxShadow(color: Color(0x1A4A3E35), blurRadius: 20, offset: Offset(0, 8)),
        ],
      ),
      child: Row(
        children: [
          Expanded(child: _Item(icon: '⚔️', label: '冒険', active: active == 'adventure', onTap: onAdventure)),
          Expanded(child: _Item(icon: '🛒', label: 'ショップ', active: active == 'shop', onTap: onShop)),
          Expanded(child: _Item(icon: '✦', label: 'スルスル', active: active == 'surusuru', emphasized: true, onTap: onSurusuru)),
          Expanded(child: _Item(icon: '🌱', label: '育成', active: active == 'training', onTap: onTraining)),
          Expanded(child: _Item(icon: '🗺️', label: 'マップ', active: active == 'map', onTap: onMap)),
        ],
      ),
    );
  }
}

class _Item extends StatelessWidget {
  final String icon;
  final String label;
  final bool active;
  final bool emphasized;
  final VoidCallback onTap;

  const _Item({
    required this.icon,
    required this.label,
    required this.active,
    required this.onTap,
    this.emphasized = false,
  });

  @override
  Widget build(BuildContext context) {
    final activeColor = emphasized ? const Color(0xFF7DB9A6) : const Color(0xFFF3C988);
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        margin: const EdgeInsets.symmetric(horizontal: 2),
        padding: const EdgeInsets.symmetric(vertical: 5),
        decoration: BoxDecoration(
          color: active ? activeColor.withOpacity(.24) : Colors.transparent,
          borderRadius: BorderRadius.circular(17),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimatedScale(
              duration: const Duration(milliseconds: 180),
              scale: active ? 1.08 : .94,
              child: Text(icon, style: const TextStyle(fontSize: 19)),
            ),
            const SizedBox(height: 1),
            Text(
              label,
              maxLines: 1,
              style: TextStyle(
                color: active ? const Color(0xFF4E4A45) : const Color(0xFF8B8580),
                fontSize: 9.5,
                fontWeight: active ? FontWeight.w800 : FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
