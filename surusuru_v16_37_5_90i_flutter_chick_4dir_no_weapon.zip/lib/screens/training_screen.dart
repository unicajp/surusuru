import 'package:flutter/material.dart';

import '../game/game_controller.dart';
import '../sfx_manager.dart';
import '../widgets/game_bottom_nav.dart';
import 'rpg_home_screen.dart';
import 'shop_screen.dart';
import 'stage_map_screen.dart';
import 'surusuru_play_screen.dart';

class TrainingScreen extends StatelessWidget {
  final GameController controller;
  const TrainingScreen({super.key, required this.controller});

  void _replace(BuildContext context, Widget screen) {
    SfxManager.instance.tap();
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => screen));
  }

  @override
  Widget build(BuildContext context) {
    const monsters = <({String icon, String name, String role, int level, double exp})>[
      (icon: '🐥', name: 'ひよこ', role: 'ATK', level: 1, exp: .18),
      (icon: '🐸', name: 'カエル', role: 'SUP', level: 1, exp: .42),
      (icon: '🐧', name: 'ペンギン', role: 'DEF', level: 1, exp: .27),
      (icon: '🐶', name: 'いぬ', role: 'ATK', level: 1, exp: .64),
      (icon: '🐰', name: 'うさぎ', role: 'SUP', level: 1, exp: .09),
    ];

    return Scaffold(
      backgroundColor: const Color(0xFFF5F0E6),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
              child: Row(
                children: [
                  const Text('🌱', style: TextStyle(fontSize: 28)),
                  const SizedBox(width: 8),
                  const Text(
                    '育成',
                    style: TextStyle(color: Color(0xFF3E3229), fontSize: 24, fontWeight: FontWeight.w900),
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)),
                    child: const Text('育成モンスター 5体', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900)),
                  ),
                ],
              ),
            ),
            Expanded(
              child: GridView.builder(
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 18),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  childAspectRatio: 1.12,
                ),
                itemCount: monsters.length,
                itemBuilder: (context, index) {
                  final m = monsters[index];
                  return _MonsterTile(
                    icon: m.icon,
                    name: m.name,
                    role: m.role,
                    level: m.level,
                    exp: m.exp,
                  );
                },
              ),
            ),
            GameBottomNav(
              active: 'training',
              onAdventure: () => _replace(context, StageMapScreen(controller: controller)),
              onShop: () => _replace(context, ShopScreen(controller: controller)),
              onSurusuru: () => _replace(context, SurusuruPlayScreen(controller: controller)),
              onTraining: () {},
              onMap: () => _replace(context, RpgHomeScreen(controller: controller)),
            ),
          ],
        ),
      ),
    );
  }
}

class _MonsterTile extends StatelessWidget {
  final String icon;
  final String name;
  final String role;
  final int level;
  final double exp;

  const _MonsterTile({
    required this.icon,
    required this.name,
    required this.role,
    required this.level,
    required this.exp,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      elevation: 2,
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: SfxManager.instance.tap,
        child: Padding(
          padding: const EdgeInsets.all(11),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 54,
                    height: 54,
                    alignment: Alignment.center,
                    decoration: const BoxDecoration(color: Color(0xFFFFE69B), shape: BoxShape.circle),
                    child: Text(icon, style: const TextStyle(fontSize: 34)),
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
                    decoration: BoxDecoration(color: const Color(0xFF27343A), borderRadius: BorderRadius.circular(10)),
                    child: Text(role, style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w900)),
                  ),
                ],
              ),
              const Spacer(),
              Text(name, style: const TextStyle(color: Color(0xFF3E3229), fontSize: 16, fontWeight: FontWeight.w900)),
              Text('Lv.$level', style: const TextStyle(color: Color(0xFF7C6E63), fontSize: 11, fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              ClipRRect(
                borderRadius: BorderRadius.circular(99),
                child: LinearProgressIndicator(
                  value: exp,
                  minHeight: 7,
                  backgroundColor: const Color(0xFFE8E1D8),
                  valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFF74B66A)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
