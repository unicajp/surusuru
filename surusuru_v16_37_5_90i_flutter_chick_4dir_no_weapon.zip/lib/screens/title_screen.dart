import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../web_ui_scale.dart';
import '../game/game_controller.dart';
import '../sfx_manager.dart';
import 'rpg_home_screen.dart';

class TitleScreen extends StatefulWidget { const TitleScreen({super.key}); @override State<TitleScreen> createState()=>_TitleScreenState(); }
class _TitleScreenState extends State<TitleScreen> {
  final GameController controller=GameController(); Future<void>? _loadFuture; Timer? _timer; bool loading=false; double progress=0, t=0;
  @override void initState(){super.initState();_loadFuture=controller.load();_timer=Timer.periodic(const Duration(milliseconds:40),(_){if(mounted)setState(()=>t+=.04);});}
  @override void dispose(){_timer?.cancel();super.dispose();}
  Future<void> startGame() async { if(loading)return; SfxManager.instance.tap(); setState((){loading=true;progress=.12;}); await Future<void>.delayed(const Duration(milliseconds:40)); if(!mounted)return;setState(()=>progress=.35);await(_loadFuture??=controller.load());if(!mounted)return;setState(()=>progress=.82);await Future<void>.delayed(const Duration(milliseconds:80));if(!mounted)return;setState(()=>progress=1);await Future<void>.delayed(const Duration(milliseconds:70));if(!mounted)return;Navigator.of(context).pushReplacement(PageRouteBuilder<void>(transitionDuration:const Duration(milliseconds:360),pageBuilder:(_,a,s)=>RpgHomeScreen(controller:controller),transitionsBuilder:(_,a,s,c)=>FadeTransition(opacity:a,child:c))); }
  @override Widget build(BuildContext context){
    final bob=math.sin(t)*7*webUiScale;
    return Scaffold(body:Container(decoration:const BoxDecoration(gradient:LinearGradient(begin:Alignment.topCenter,end:Alignment.bottomCenter,colors:[Color(0xFFFFFBF5),Color(0xFFFFEAF0),Color(0xFFEAF5EF)])),child:SafeArea(child:Stack(children:[
      ...List.generate(12,(i)=>Positioned(left:((i*83)%100)/100*MediaQuery.sizeOf(context).width,top:30+((i*137)%80)/100*MediaQuery.sizeOf(context).height*.75,child:Opacity(opacity:.18,child:Transform.rotate(angle:t*.08+i,child:const Icon(Icons.auto_awesome_rounded,color:Color(0xFFC995A6),size:18))))),
      Center(child:Padding(padding:const EdgeInsets.symmetric(horizontal:24*webUiScale),child:Column(mainAxisSize:MainAxisSize.min,children:[
        Transform.translate(offset:Offset(0,bob),child:Container(padding:const EdgeInsets.symmetric(horizontal:22*webUiScale,vertical:8*webUiScale),decoration:BoxDecoration(color:Colors.white.withOpacity(.62),borderRadius:BorderRadius.circular(99),border:Border.all(color:Colors.white.withOpacity(.9))),child:const Text('SURUSURU CAMP',style:TextStyle(color:Color(0xFF9A7180),fontSize:18*webUiScale,fontWeight:FontWeight.w800,letterSpacing:2.4*webUiScale)))),
        const SizedBox(height:18*webUiScale),
        FractionallySizedBox(widthFactor:.88,child:FittedBox(child:Text('surusuru',style:TextStyle(fontSize:150*webUiScale,height:.9,fontWeight:FontWeight.w900,letterSpacing:-4*webUiScale,color:const Color(0xFF4C3E45),shadows:[Shadow(color:Colors.white.withOpacity(.8),blurRadius:18)])))),
        const SizedBox(height:12*webUiScale),
        const Text('あつめて そだてて ぼうけんしよう',style:TextStyle(color:Color(0xFF9A7E86),fontSize:19*webUiScale,fontWeight:FontWeight.w700,letterSpacing:1.2*webUiScale)),
        const SizedBox(height:30*webUiScale),
        Transform.translate(offset:Offset(0,-bob*.45),child:Container(padding:const EdgeInsets.symmetric(horizontal:24*webUiScale,vertical:16*webUiScale),decoration:BoxDecoration(color:Colors.white.withOpacity(.52),borderRadius:BorderRadius.circular(34),boxShadow:const [BoxShadow(color:Color(0x164A3E35),blurRadius:24,offset:Offset(0,10))]),child:const Text('🐥   🐸   🐧   🐶   🐰',style:TextStyle(fontSize:54*webUiScale)))),
        const SizedBox(height:36*webUiScale),
        if(!loading) GestureDetector(behavior:HitTestBehavior.opaque,onTap:startGame,child:AnimatedContainer(duration:const Duration(milliseconds:200),padding:const EdgeInsets.symmetric(horizontal:64*webUiScale,vertical:22*webUiScale),decoration:BoxDecoration(gradient:const LinearGradient(colors:[Color(0xFFFFD5A8),Color(0xFFF3AFC4)]),borderRadius:BorderRadius.circular(99),boxShadow:const [BoxShadow(color:Color(0x33C98AA0),blurRadius:22,offset:Offset(0,9))]),child:const Row(mainAxisSize:MainAxisSize.min,children:[Icon(Icons.play_arrow_rounded,color:Colors.white,size:30*webUiScale),SizedBox(width:8*webUiScale),Text('はじめる',style:TextStyle(fontSize:26*webUiScale,fontWeight:FontWeight.w900,color:Colors.white,letterSpacing:1.5*webUiScale))]))) else SizedBox(width:330*webUiScale,child:Column(children:[ClipRRect(borderRadius:BorderRadius.circular(99),child:LinearProgressIndicator(value:progress,minHeight:14*webUiScale,backgroundColor:Colors.white.withOpacity(.7),color:const Color(0xFFD895AA))),const SizedBox(height:10*webUiScale),Text('準備中… ${(progress*100).round()}%',style:const TextStyle(color:Color(0xFF947982),fontSize:16*webUiScale,fontWeight:FontWeight.w700))])),
      ]))),
      const Positioned(bottom:12,left:0,right:0,child:Text('SURUSURU WORLD',textAlign:TextAlign.center,style:TextStyle(color:Color(0x669A7E86),fontSize:11,fontWeight:FontWeight.w700,letterSpacing:2))),
    ]))));
  }
}
