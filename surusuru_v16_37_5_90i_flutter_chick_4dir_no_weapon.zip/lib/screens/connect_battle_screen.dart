import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../game/game_controller.dart';

class ConnectBattleScreen extends StatefulWidget {
  final GameController controller;
  final int stageId;

  const ConnectBattleScreen({
    super.key,
    required this.controller,
    required this.stageId,
  });

  @override
  State<ConnectBattleScreen> createState() => _ConnectBattleScreenState();
}

class _DummyEnemy {
  _DummyEnemy(this.pos, this.phase);
  Offset pos;
  final double phase;
}

class _ConnectBattleScreenState extends State<ConnectBattleScreen> {
  Timer? _timer;
  DateTime _last = DateTime.now();
  Size _field = Size.zero;

  Offset _hero = const Offset(190, 360);
  Offset _velocity = Offset.zero;
  Offset _target = const Offset(190, 360);
  bool _holding = false;
  double _time = 0;
  double _tilt = 0;
  final List<_DummyEnemy> _enemies = <_DummyEnemy>[];

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(milliseconds: 16), (_) => _tick());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _seed(Size size) {
    if (_field != Size.zero) return;
    _field = size;
    _hero = Offset(size.width * .50, size.height * .74);
    _target = _hero;
    _enemies.addAll(<_DummyEnemy>[
      _DummyEnemy(Offset(size.width * .22, size.height * .29), .2),
      _DummyEnemy(Offset(size.width * .50, size.height * .20), 1.5),
      _DummyEnemy(Offset(size.width * .78, size.height * .31), 2.8),
    ]);
  }

  void _tick() {
    if (!mounted || _field == Size.zero) return;
    final now = DateTime.now();
    double dt = now.difference(_last).inMicroseconds / 1000000;
    _last = now;
    dt = dt.clamp(0.0, .035);
    _time += dt;

    final delta = _target - _hero;
    final spring = _holding ? 28.0 : 12.0;
    final damping = _holding ? 8.2 : 6.8;
    _velocity += delta * spring * dt;
    _velocity *= math.exp(-damping * dt);

    final speed = _velocity.distance;
    if (speed > 1050) _velocity = _velocity / speed * 1050;
    _hero += _velocity * dt;
    _hero = Offset(
      _hero.dx.clamp(44.0, _field.width - 44.0),
      _hero.dy.clamp(58.0, _field.height - 52.0),
    );

    final wantedTilt = (_velocity.dx / 650).clamp(-.15, .15);
    _tilt += (wantedTilt - _tilt) * math.min(1, dt * 10);
    setState(() {});
  }

  void _down(Offset p) {
    setState(() {
      _holding = true;
      _target = p;
    });
  }

  void _move(Offset p) {
    _holding = true;
    _target = p;
  }

  void _up() {
    _holding = false;
    _target = _hero;
  }

  String get _heroFacing {
    final speed = _velocity.distance;
    if (speed < 65) return 'back';

    final ax = _velocity.dx.abs();
    final ay = _velocity.dy.abs();
    if (ax > ay * .82) {
      return _velocity.dx >= 0 ? 'right' : 'left';
    }

    // Screen Y grows downward: moving toward the player shows her face,
    // moving toward the enemies keeps the rear view.
    return _velocity.dy > 0 ? 'front' : 'back';
  }

  int get _walkFrame {
    if (_velocity.distance < 65) return 0;
    return ((_time * 7).floor() & 1);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF142536),
      body: SafeArea(
        child: Column(
          children: <Widget>[
            SizedBox(
              height: 64,
              child: Row(
                children: <Widget>[
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    '冒険  STAGE ${widget.stageId}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const Spacer(),
                  const Padding(
                    padding: EdgeInsets.only(right: 18),
                    child: Text(
                      '操作テスト',
                      style: TextStyle(
                        color: Color(0xFFFFD978),
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: LayoutBuilder(
                builder: (context, c) {
                  final size = Size(c.maxWidth, c.maxHeight);
                  _seed(size);
                  return Listener(
                    behavior: HitTestBehavior.opaque,
                    onPointerDown: (e) => _down(e.localPosition),
                    onPointerMove: (e) => _move(e.localPosition),
                    onPointerUp: (_) => _up(),
                    onPointerCancel: (_) => _up(),
                    child: Stack(
                      fit: StackFit.expand,
                      children: <Widget>[
                        const CustomPaint(painter: _BrightFieldPainter()),
                        ..._buildEnemies(),
                        if (_holding)
                          Positioned(
                            left: _target.dx - 14,
                            top: _target.dy - 14,
                            child: IgnorePointer(
                              child: Container(
                                width: 28,
                                height: 28,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: Colors.white.withValues(alpha: .28),
                                    width: 2,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        _buildHero(),
                      ],
                    ),
                  );
                },
              ),
            ),
            Container(
              height: 58,
              alignment: Alignment.center,
              color: const Color(0xFF0D1C28),
              child: const Text(
                '指で動かして、ちびキャラの追従感を確認',
                style: TextStyle(
                  color: Colors.white70,
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildEnemies() {
    return _enemies.map((e) {
      final bounce = math.sin(_time * 2.4 + e.phase) * 3;
      final frame = (((_time * 3 + e.phase).floor()) & 1);
      const w = 64.0;
      const h = 64.0;
      return Positioned(
        left: e.pos.dx - w / 2,
        top: e.pos.dy - h / 2 + bounce,
        child: IgnorePointer(
          child: Image.asset(
            'assets/sprites/enemy_forest_$frame.png',
            width: w,
            height: h,
            fit: BoxFit.contain,
            filterQuality: FilterQuality.none,
          ),
        ),
      );
    }).toList();
  }

  Widget _buildHero() {
    const w = 104.0;
    const h = 122.0;
    final speedRatio = (_velocity.distance / 430).clamp(0.0, 1.0);
    final moving = _velocity.distance >= 65;
    final step = moving ? math.sin(_time * 13.0) : math.sin(_time * 2.4) * .18;
    final bob = moving
        ? math.sin(_time * 13.0) * 2.2 * speedRatio
        : math.sin(_time * 2.4) * .8;
    final squash = moving ? 1.0 + math.sin(_time * 13.0) * .022 : 1.0;

    return Positioned(
      left: _hero.dx - w / 2,
      top: _hero.dy - h * .70 + bob,
      child: IgnorePointer(
        child: Transform.rotate(
          angle: _tilt,
          alignment: Alignment.bottomCenter,
          child: Transform(
            alignment: Alignment.bottomCenter,
            transform: Matrix4.diagonal3Values(1 / squash, squash, 1),
            child: SizedBox(
              width: w,
              height: h,
              child: CustomPaint(
                painter: _ChickHeroPainter(
                  facing: _heroFacing,
                  step: step,
                  speedRatio: speedRatio,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _ChickHeroPainter extends CustomPainter {
  const _ChickHeroPainter({
    required this.facing,
    required this.step,
    required this.speedRatio,
  });

  final String facing;
  final double step;
  final double speedRatio;

  static const _outline = Color(0xFF2D170B);
  static const _white = Color(0xFFFFFEFA);
  static const _pink = Color(0xFFFF8790);
  static const _gold = Color(0xFFF5B52C);
  static const _dark = Color(0xFF281306);

  Paint _fill(Color color) => Paint()
    ..color = color
    ..style = PaintingStyle.fill;

  Paint _stroke([double width = 4.5]) => Paint()
    ..color = _outline
    ..style = PaintingStyle.stroke
    ..strokeWidth = width
    ..strokeCap = StrokeCap.round
    ..strokeJoin = StrokeJoin.round;

  @override
  void paint(Canvas canvas, Size size) {
    final shadow = Paint()..color = const Color(0xFF5A6B4A).withValues(alpha: .18);
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(size.width * .50, size.height * .91),
        width: size.width * .62,
        height: size.height * .10,
      ),
      shadow,
    );

    if (facing == 'left') {
      canvas.save();
      canvas.translate(size.width, 0);
      canvas.scale(-1, 1);
      _paintSide(canvas, size, right: true);
      canvas.restore();
      return;
    }
    if (facing == 'right') {
      _paintSide(canvas, size, right: true);
      return;
    }
    if (facing == 'front') {
      _paintFront(canvas, size);
      return;
    }
    _paintBack(canvas, size);
  }

  void _paintFront(Canvas canvas, Size size) {
    final cx = size.width * .50;
    final sway = step * 1.3 * speedRatio;

    final body = Path()
      ..moveTo(cx, 20)
      ..cubicTo(27, 20, 18, 42, 20, 65)
      ..cubicTo(21, 91, 33, 103, cx, 104)
      ..cubicTo(71, 103, 83, 91, 84, 65)
      ..cubicTo(86, 42, 77, 20, cx, 20)
      ..close();
    canvas.drawPath(body, _fill(_white));
    canvas.drawPath(body, _stroke());

    // wings
    _frontWing(canvas, Offset(24, 59), -1, -sway);
    _frontWing(canvas, Offset(80, 59), 1, sway);

    // feet alternate slightly while moving
    final leftLift = math.max(0.0, step) * 2.6 * speedRatio;
    final rightLift = math.max(0.0, -step) * 2.6 * speedRatio;
    _foot(canvas, Offset(39, 100 - leftLift));
    _foot(canvas, Offset(65, 100 - rightLift));

    // eyes
    for (final x in <double>[39, 65]) {
      canvas.drawOval(Rect.fromCenter(center: Offset(x, 53), width: 13, height: 18), _fill(_dark));
      canvas.drawCircle(Offset(x - 2.2, 49.2), 2.8, _fill(Colors.white));
    }
    canvas.drawCircle(const Offset(31, 62), 5.4, _fill(const Color(0xFFFFC0C3).withValues(alpha: .62)));
    canvas.drawCircle(const Offset(73, 62), 5.4, _fill(const Color(0xFFFFC0C3).withValues(alpha: .62)));

    final beak = Path()
      ..moveTo(cx - 8, 64)
      ..quadraticBezierTo(cx, 58, cx + 8, 64)
      ..quadraticBezierTo(cx, 72, cx - 8, 64)
      ..close();
    canvas.drawPath(beak, _fill(_pink));
    canvas.drawPath(beak, _stroke(3.2));
    canvas.drawLine(Offset(cx - 6, 64), Offset(cx + 6, 64), _stroke(2.2));

    _heart(canvas, const Offset(35, 38), 4.8, const Color(0xFFFF8B95));
    _heart(canvas, const Offset(69, 38), 4.8, const Color(0xFFFF8B95));
    _hat(canvas, size, side: false);
  }

  void _paintBack(Canvas canvas, Size size) {
    final cx = size.width * .50;
    final sway = step * 1.4 * speedRatio;

    final body = Path()
      ..moveTo(cx, 20)
      ..cubicTo(27, 20, 18, 42, 20, 66)
      ..cubicTo(21, 91, 33, 103, cx, 104)
      ..cubicTo(71, 103, 83, 91, 84, 66)
      ..cubicTo(86, 42, 77, 20, cx, 20)
      ..close();
    canvas.drawPath(body, _fill(_white));
    canvas.drawPath(body, _stroke());

    _frontWing(canvas, const Offset(24, 60), -1, -sway);
    _frontWing(canvas, const Offset(80, 60), 1, sway);

    final leftLift = math.max(0.0, step) * 2.6 * speedRatio;
    final rightLift = math.max(0.0, -step) * 2.6 * speedRatio;
    _foot(canvas, Offset(39, 100 - leftLift));
    _foot(canvas, Offset(65, 100 - rightLift));

    _heart(canvas, const Offset(52, 86), 4.4, _outline);
    _hat(canvas, size, side: false, back: true);
  }

  void _paintSide(Canvas canvas, Size size, {required bool right}) {
    final sway = step * 1.8 * speedRatio;
    final body = Path()
      ..moveTo(44, 22)
      ..cubicTo(24, 26, 19, 50, 25, 73)
      ..cubicTo(31, 98, 52, 105, 72, 97)
      ..cubicTo(84, 92, 88, 77, 85, 59)
      ..cubicTo(81, 36, 65, 20, 44, 22)
      ..close();
    canvas.drawPath(body, _fill(_white));
    canvas.drawPath(body, _stroke());

    // tail peeks out on the rear side
    final tail = Path()
      ..moveTo(28, 72)
      ..quadraticBezierTo(17, 70, 18, 80)
      ..quadraticBezierTo(25, 83, 30, 79)
      ..close();
    canvas.drawPath(tail, _fill(_white));
    canvas.drawPath(tail, _stroke(3.6));

    // visible wing
    canvas.save();
    canvas.translate(46, 62);
    canvas.rotate(-.10 + sway * .015);
    final wing = Path()
      ..moveTo(0, -12)
      ..cubicTo(16, -8, 19, 6, 12, 19)
      ..cubicTo(6, 17, 2, 13, 0, 8)
      ..cubicTo(-2, 13, -6, 11, -7, 5)
      ..cubicTo(-7, -2, -5, -8, 0, -12)
      ..close();
    canvas.drawPath(wing, _fill(_white));
    canvas.drawPath(wing, _stroke(3.8));
    canvas.restore();

    final leftLift = math.max(0.0, step) * 2.8 * speedRatio;
    final rightLift = math.max(0.0, -step) * 2.8 * speedRatio;
    _sideFoot(canvas, Offset(43 - sway * .7, 98 - leftLift));
    _sideFoot(canvas, Offset(65 + sway * .7, 98 - rightLift));

    // eye + cheek + beak
    canvas.drawOval(Rect.fromCenter(center: const Offset(69, 51), width: 13, height: 18), _fill(_dark));
    canvas.drawCircle(const Offset(67, 47), 2.8, _fill(Colors.white));
    canvas.drawCircle(const Offset(70, 63), 5.4, _fill(const Color(0xFFFFC0C3).withValues(alpha: .62)));
    final beak = Path()
      ..moveTo(82, 56)
      ..lineTo(94, 62)
      ..lineTo(82, 67)
      ..close();
    canvas.drawPath(beak, _fill(_pink));
    canvas.drawPath(beak, _stroke(3.2));

    _heart(canvas, const Offset(58, 37), 4.6, const Color(0xFFFF8B95));
    _hat(canvas, size, side: true);
  }

  void _frontWing(Canvas canvas, Offset origin, int dir, double sway) {
    canvas.save();
    canvas.translate(origin.dx, origin.dy);
    canvas.rotate(dir * (.06 + sway * .01));
    final wing = Path()
      ..moveTo(0, -13)
      ..cubicTo(dir * 12, -9, dir * 13, 7, dir * 7, 18)
      ..cubicTo(dir * 3, 17, dir * 1, 13, 0, 9)
      ..cubicTo(dir * 1, 14, -dir * 3, 13, -dir * 5, 8)
      ..cubicTo(-dir * 7, 2, -dir * 5, -8, 0, -13)
      ..close();
    canvas.drawPath(wing, _fill(_white));
    canvas.drawPath(wing, _stroke(3.8));
    canvas.restore();
  }

  void _foot(Canvas canvas, Offset c) {
    final path = Path()
      ..moveTo(c.dx - 9, c.dy)
      ..cubicTo(c.dx - 11, c.dy + 7, c.dx - 4, c.dy + 10, c.dx, c.dy + 6)
      ..cubicTo(c.dx + 4, c.dy + 10, c.dx + 11, c.dy + 7, c.dx + 9, c.dy)
      ..close();
    canvas.drawPath(path, _fill(const Color(0xFFFF9DA0)));
    canvas.drawPath(path, _stroke(3.2));
  }

  void _sideFoot(Canvas canvas, Offset c) {
    final rect = RRect.fromRectAndRadius(Rect.fromCenter(center: c, width: 20, height: 10), const Radius.circular(6));
    canvas.drawRRect(rect, _fill(const Color(0xFFFF9DA0)));
    canvas.drawRRect(rect, _stroke(3.0));
  }

  void _heart(Canvas canvas, Offset c, double r, Color color) {
    final path = Path()
      ..moveTo(c.dx, c.dy + r)
      ..cubicTo(c.dx - r * 1.3, c.dy + r * .15, c.dx - r * .9, c.dy - r, c.dx, c.dy - r * .25)
      ..cubicTo(c.dx + r * .9, c.dy - r, c.dx + r * 1.3, c.dy + r * .15, c.dx, c.dy + r)
      ..close();
    canvas.drawPath(path, _fill(color));
  }

  void _hat(Canvas canvas, Size size, {required bool side, bool back = false}) {
    if (!side) {
      final crown = Path()
        ..moveTo(23, 27)
        ..cubicTo(25, 11, 39, 6, 52, 10)
        ..cubicTo(65, 6, 79, 11, 81, 27)
        ..cubicTo(69, 23, 35, 23, 23, 27)
        ..close();
      canvas.drawPath(crown, _fill(_white));
      canvas.drawPath(crown, _stroke(4.2));
      final brim = Path()
        ..moveTo(25, 27)
        ..quadraticBezierTo(52, 21, 79, 27)
        ..lineTo(76, 34)
        ..quadraticBezierTo(52, 31, 28, 34)
        ..close();
      canvas.drawPath(brim, _fill(_dark));
      canvas.drawPath(brim, _stroke(3.4));
      final goldLine = Paint()
        ..color = _gold
        ..strokeWidth = 4
        ..strokeCap = StrokeCap.round;
      canvas.drawLine(const Offset(29, 28), const Offset(75, 28), goldLine);
      if (!back) {
        _heart(canvas, const Offset(52, 18), 6.0, _gold);
        canvas.drawCircle(const Offset(50, 15), 2.0, _fill(Colors.white));
      }
    } else {
      final crown = Path()
        ..moveTo(28, 28)
        ..cubicTo(31, 13, 47, 8, 62, 13)
        ..cubicTo(72, 16, 77, 22, 77, 28)
        ..quadraticBezierTo(52, 22, 28, 28)
        ..close();
      canvas.drawPath(crown, _fill(_white));
      canvas.drawPath(crown, _stroke(4.0));
      final brim = Path()
        ..moveTo(31, 29)
        ..quadraticBezierTo(60, 23, 84, 31)
        ..quadraticBezierTo(78, 38, 58, 35)
        ..lineTo(33, 35)
        ..close();
      canvas.drawPath(brim, _fill(_dark));
      canvas.drawPath(brim, _stroke(3.3));
      final goldLine = Paint()
        ..color = _gold
        ..strokeWidth = 4
        ..strokeCap = StrokeCap.round;
      canvas.drawLine(const Offset(32, 29), const Offset(75, 27), goldLine);
      _heart(canvas, const Offset(62, 19), 5.4, _gold);
      canvas.drawCircle(const Offset(60, 16), 1.8, _fill(Colors.white));
    }
  }

  @override
  bool shouldRepaint(covariant _ChickHeroPainter oldDelegate) =>
      oldDelegate.facing != facing ||
      oldDelegate.step != step ||
      oldDelegate.speedRatio != speedRatio;
}

class _BrightFieldPainter extends CustomPainter {
  const _BrightFieldPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final bg = const LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: <Color>[
        Color(0xFFEAF6D8),
        Color(0xFFD8EDBE),
        Color(0xFFC7E4AA),
      ],
    ).createShader(rect);
    canvas.drawRect(rect, Paint()..shader = bg);

    // Soft layered grass so the field reads as a place, not a flat board.
    final farGrass = Paint()..color = const Color(0xFFB6D998).withValues(alpha: .42);
    final nearGrass = Paint()..color = const Color(0xFF94C77B).withValues(alpha: .23);
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(size.width * .11, size.height * .16),
        width: size.width * .34,
        height: 76,
      ),
      farGrass,
    );
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(size.width * .88, size.height * .20),
        width: size.width * .38,
        height: 86,
      ),
      farGrass,
    );
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(size.width * .10, size.height * .77),
        width: size.width * .42,
        height: 110,
      ),
      nearGrass,
    );
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(size.width * .91, size.height * .71),
        width: size.width * .43,
        height: 104,
      ),
      nearGrass,
    );

    // A narrow winding path keeps the battlefield readable while giving depth.
    final path = Path()
      ..moveTo(size.width * .38, size.height)
      ..cubicTo(
        size.width * .36,
        size.height * .82,
        size.width * .52,
        size.height * .69,
        size.width * .50,
        size.height * .52,
      )
      ..cubicTo(
        size.width * .47,
        size.height * .36,
        size.width * .58,
        size.height * .22,
        size.width * .52,
        0,
      )
      ..lineTo(size.width * .64, 0)
      ..cubicTo(
        size.width * .69,
        size.height * .20,
        size.width * .57,
        size.height * .37,
        size.width * .61,
        size.height * .55,
      )
      ..cubicTo(
        size.width * .66,
        size.height * .73,
        size.width * .48,
        size.height * .84,
        size.width * .55,
        size.height,
      )
      ..close();
    canvas.drawPath(
      path,
      Paint()..color = const Color(0xFFF0DDAA).withValues(alpha: .62),
    );
    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3
        ..color = const Color(0xFFD4C58E).withValues(alpha: .18),
    );

    // Small grass blades around the edges. No giant circles/rings.
    final blade = Paint()
      ..color = const Color(0xFF79AF67).withValues(alpha: .43)
      ..strokeWidth = 1.6
      ..strokeCap = StrokeCap.round;
    const grassSeeds = <Offset>[
      Offset(.07, .09), Offset(.18, .24), Offset(.91, .10), Offset(.82, .32),
      Offset(.09, .53), Offset(.20, .67), Offset(.90, .57), Offset(.82, .84),
      Offset(.12, .90), Offset(.72, .91), Offset(.95, .38), Offset(.05, .36),
    ];
    for (final seed in grassSeeds) {
      final p = Offset(seed.dx * size.width, seed.dy * size.height);
      canvas.drawLine(p, p + const Offset(-4, -9), blade);
      canvas.drawLine(p, p + const Offset(1, -11), blade);
      canvas.drawLine(p, p + const Offset(5, -7), blade);
    }

    // Tiny flowers and stones add charm but stay away from combat silhouettes.
    final petal = Paint()..color = const Color(0xFFFFFAF3).withValues(alpha: .95);
    final flowerCenter = Paint()..color = const Color(0xFFF0BD59);
    final pinkPetal = Paint()..color = const Color(0xFFF7C2D5).withValues(alpha: .88);
    const flowerSeeds = <Offset>[
      Offset(.18, .14), Offset(.10, .43), Offset(.86, .13), Offset(.90, .45),
      Offset(.16, .83), Offset(.84, .79), Offset(.29, .61), Offset(.72, .62),
    ];
    for (var i = 0; i < flowerSeeds.length; i++) {
      final p = Offset(flowerSeeds[i].dx * size.width, flowerSeeds[i].dy * size.height);
      final pp = i.isOdd ? pinkPetal : petal;
      canvas.drawCircle(p + const Offset(-3, 0), 2.5, pp);
      canvas.drawCircle(p + const Offset(3, 0), 2.5, pp);
      canvas.drawCircle(p + const Offset(0, -3), 2.5, pp);
      canvas.drawCircle(p + const Offset(0, 3), 2.5, pp);
      canvas.drawCircle(p, 1.7, flowerCenter);
    }

    final stone = Paint()..color = const Color(0xFF91A98B).withValues(alpha: .30);
    const stones = <Offset>[Offset(.28, .35), Offset(.74, .27), Offset(.22, .74), Offset(.78, .88)];
    for (final seed in stones) {
      final p = Offset(seed.dx * size.width, seed.dy * size.height);
      canvas.drawOval(Rect.fromCenter(center: p, width: 15, height: 8), stone);
      canvas.drawOval(
        Rect.fromCenter(center: p + const Offset(-2, -2), width: 7, height: 3),
        Paint()..color = Colors.white.withValues(alpha: .18),
      );
    }

    // Gentle sunlight from the upper-right; kept very subtle for readability.
    final light = RadialGradient(
      center: const Alignment(.72, -.72),
      radius: .92,
      colors: <Color>[
        const Color(0xFFFFF6C9).withValues(alpha: .16),
        Colors.transparent,
      ],
    ).createShader(rect);
    canvas.drawRect(rect, Paint()..shader = light);
  }

  @override
  bool shouldRepaint(covariant _BrightFieldPainter oldDelegate) => false;
}
