import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../sfx_manager.dart';

class TouchLabScreen extends StatefulWidget {
  const TouchLabScreen({super.key});

  @override
  State<TouchLabScreen> createState() => _TouchLabScreenState();
}

enum _TouchLabMode { pop, roll }

class _LabPiece {
  _LabPiece({required this.id, required this.type, required this.p, required this.v});
  final int id;
  final int type;
  Offset p;
  Offset v;
  bool alive = true;
}

class _Burst {
  _Burst(this.p, this.type);
  final Offset p;
  final int type;
  double life = 1;
}

class _TouchLabScreenState extends State<TouchLabScreen> {
  final math.Random _random = math.Random();
  final List<_LabPiece> _pieces = <_LabPiece>[];
  final List<_Burst> _bursts = <_Burst>[];
  Timer? _timer;
  Size _size = Size.zero;
  _TouchLabMode _mode = _TouchLabMode.pop;
  int _nextId = 0;
  int _popped = 0;
  double _core = 0;
  bool _coreBurst = false;
  Offset? _lastPointer;

  static const int _popTarget = 65;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(milliseconds: 16), (_) => _tick());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _reset({bool keepMode = true}) {
    _pieces.clear();
    _bursts.clear();
    _nextId = 0;
    _popped = 0;
    _core = 0;
    _coreBurst = false;
    _lastPointer = null;
    if (_size != Size.zero) _spawn(_size);
    if (mounted) setState(() {});
  }

  void _spawn(Size size) {
    if (_pieces.isNotEmpty) return;
    final count = _mode == _TouchLabMode.pop ? 125 : 90;
    final r = _radius(size);
    for (var i = 0; i < count; i++) {
      _pieces.add(_LabPiece(
        id: _nextId++,
        type: _random.nextInt(5),
        p: Offset(
          r + _random.nextDouble() * math.max(1.0, size.width - r * 2),
          r + _random.nextDouble() * math.max(1.0, size.height - r * 2),
        ),
        v: Offset((_random.nextDouble() - .5) * .5, (_random.nextDouble() - .5) * .5),
      ));
    }
    if (_mode == _TouchLabMode.roll) {
      for (var i = 0; i < 120; i++) {
        _physicsStep(settle: true);
      }
    }
  }

  double _radius(Size size) => (size.width / 22).clamp(10.0, 16.0).toDouble();

  void _tick() {
    if (!mounted || _size == Size.zero) return;
    if (_mode == _TouchLabMode.roll) _physicsStep();
    for (final b in _bursts) {
      b.life -= .055;
    }
    _bursts.removeWhere((b) => b.life <= 0);
    if (_bursts.isNotEmpty || _mode == _TouchLabMode.roll) setState(() {});
  }

  void _physicsStep({bool settle = false}) {
    if (_pieces.isEmpty) return;
    final r = _radius(_size);
    final maxX = _size.width - r;
    final maxY = _size.height - r;
    for (final p in _pieces) {
      if (!p.alive) continue;
      p.p += p.v;
      p.v *= settle ? .84 : .965;
      if (p.p.dx < r) {
        p.p = Offset(r, p.p.dy);
        p.v = Offset(p.v.dx.abs() * .55, p.v.dy);
      } else if (p.p.dx > maxX) {
        p.p = Offset(maxX, p.p.dy);
        p.v = Offset(-p.v.dx.abs() * .55, p.v.dy);
      }
      if (p.p.dy < r) {
        p.p = Offset(p.p.dx, r);
        p.v = Offset(p.v.dx, p.v.dy.abs() * .55);
      } else if (p.p.dy > maxY) {
        p.p = Offset(p.p.dx, maxY);
        p.v = Offset(p.v.dx, -p.v.dy.abs() * .55);
      }
    }

    final minD = r * 1.7;
    for (var i = 0; i < _pieces.length; i++) {
      final a = _pieces[i];
      if (!a.alive) continue;
      for (var j = i + 1; j < _pieces.length; j++) {
        final b = _pieces[j];
        if (!b.alive) continue;
        final d = b.p - a.p;
        final dist = d.distance;
        if (dist <= .01 || dist >= minD) continue;
        final n = d / dist;
        final overlap = (minD - dist) * .5;
        a.p -= n * overlap;
        b.p += n * overlap;
        final rel = (b.v - a.v).dx * n.dx + (b.v - a.v).dy * n.dy;
        if (rel < 0) {
          final impulse = n * (-rel * .55);
          a.v -= impulse;
          b.v += impulse;
        }
      }
    }
  }

  void _popAt(Offset pos) {
    if (_mode != _TouchLabMode.pop || _size == Size.zero) return;
    final r = _radius(_size);
    var hit = 0;
    for (final p in _pieces) {
      if (!p.alive || (p.p - pos).distance > r * 1.35) continue;
      p.alive = false;
      _bursts.add(_Burst(p.p, p.type));
      hit++;
    }
    if (hit == 0) return;
    _popped += hit;
    SfxManager.instance.clear();
    if (_popped % 12 < hit) SfxManager.instance.bomb();
    if (_popped >= _popTarget) SfxManager.instance.reward();
    setState(() {});
  }

  void _pushAt(Offset pos, Offset delta) {
    if (_mode != _TouchLabMode.roll || _size == Size.zero) return;
    final r = _radius(_size);
    final reach = r * 4.4;
    var touched = 0;
    for (final p in _pieces) {
      if (!p.alive) continue;
      final d = p.p - pos;
      final dist = d.distance;
      if (dist >= reach) continue;
      final falloff = 1 - dist / reach;
      final radial = dist < .01 ? Offset.zero : d / dist;
      p.v += delta * (.38 + falloff * .95) + radial * (1.2 * falloff);
      touched++;
    }
    if (touched > 0) {
      _core = (_core + delta.distance * touched * .0024).clamp(0.0, 1.0).toDouble();
      if (_core >= 1 && !_coreBurst) {
        _coreBurst = true;
        SfxManager.instance.core();
        SfxManager.instance.chanceRewardBurst();
        final center = Offset(_size.width / 2, _size.height / 2);
        for (final p in _pieces) {
          final d = p.p - center;
          final dist = math.max(1.0, d.distance);
          p.v += d / dist * 8;
        }
        Future.delayed(const Duration(milliseconds: 1200), () {
          if (!mounted) return;
          setState(() {
            _core = 0;
            _coreBurst = false;
          });
        });
      } else {
        SfxManager.instance.traceStep((_core * 7).round().clamp(1, 8).toInt());
      }
      setState(() {});
    }
  }

  void _changeMode(_TouchLabMode mode) {
    if (_mode == mode) return;
    setState(() => _mode = mode);
    _reset();
    SfxManager.instance.tap();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F4EF),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back_rounded, color: Color(0xFF5E5954)),
                  ),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('実験場', style: TextStyle(color: Color(0xFF4F4A45), fontSize: 22, fontWeight: FontWeight.w800)),
                        Text('さわって、気持ちいい動きを試そう', style: TextStyle(color: Color(0xFF9A938C), fontSize: 12, fontWeight: FontWeight.w600)),
                      ],
                    ),
                  ),
                  TextButton.icon(
                    onPressed: () => _reset(),
                    icon: const Icon(Icons.refresh_rounded),
                    label: const Text('やり直す'),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(
                children: [
                  Expanded(child: _modeButton(_TouchLabMode.pop, 'ぱん！と消す', 'なぞって弾ける', Icons.auto_awesome_rounded)),
                  const SizedBox(width: 8),
                  Expanded(child: _modeButton(_TouchLabMode.roll, 'ころころ動かす', '押してかき分ける', Icons.sports_baseball_rounded)),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 8),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      _mode == _TouchLabMode.pop
                          ? (_popped >= _popTarget ? '発見！ キャラクターの下から何かが現れた！' : '指で好きなようになぞって、キャラをパン！と消そう')
                          : (_coreBurst ? 'CORE BURST!! キャラクターが一気にはじけ飛ぶ！' : '指でかき分けて転がすほど CORE がたまる'),
                      style: const TextStyle(color: Color(0xFF625C57), fontSize: 13, fontWeight: FontWeight.w700),
                    ),
                  ),
                  const SizedBox(width: 12),
                  if (_mode == _TouchLabMode.pop)
                    Text('$_popped / $_popTarget', style: const TextStyle(color: Color(0xFFD39A47), fontWeight: FontWeight.w800))
                  else
                    Text('${(_core * 100).round()}%', style: const TextStyle(color: Color(0xFF5F9C99), fontWeight: FontWeight.w800)),
                ],
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(24),
                  child: LayoutBuilder(
                    builder: (context, box) {
                      final size = Size(box.maxWidth, box.maxHeight);
                      if (_size != size) {
                        _size = size;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          if (!mounted) return;
                          if (_pieces.isEmpty) setState(() => _spawn(size));
                        });
                      }
                      return GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTapDown: (d) {
                          if (_mode == _TouchLabMode.pop) _popAt(d.localPosition);
                        },
                        onPanStart: (d) {
                          _lastPointer = d.localPosition;
                          if (_mode == _TouchLabMode.pop) _popAt(d.localPosition);
                        },
                        onPanUpdate: (d) {
                          final prev = _lastPointer ?? d.localPosition;
                          final delta = d.localPosition - prev;
                          _lastPointer = d.localPosition;
                          if (_mode == _TouchLabMode.pop) {
                            final distance = delta.distance;
                            final steps = math.max(1, (distance / 8).ceil());
                            for (var i = 1; i <= steps; i++) {
                              _popAt(prev + delta * (i / steps));
                            }
                          } else {
                            _pushAt(d.localPosition, delta);
                          }
                        },
                        onPanEnd: (_) => _lastPointer = null,
                        child: Stack(
                          fit: StackFit.expand,
                          children: [
                            const DecoratedBox(
                              decoration: BoxDecoration(
                                gradient: RadialGradient(
                                  center: Alignment(0, -.2),
                                  radius: 1.1,
                                  colors: [Color(0xFFF7EFE4), Color(0xFFE8F2EE), Color(0xFFDDE9E7)],
                                ),
                              ),
                            ),
                            if (_mode == _TouchLabMode.pop && _popped >= _popTarget)
                              Center(
                                child: AnimatedScale(
                                  scale: 1,
                                  duration: const Duration(milliseconds: 250),
                                  child: Container(
                                    width: 120,
                                    height: 120,
                                    alignment: Alignment.center,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: const Color(0xFFFFD54F).withOpacity(.18),
                                      border: Border.all(color: const Color(0xFFFFD54F), width: 4),
                                      boxShadow: const [BoxShadow(color: Color(0xAAFFD54F), blurRadius: 40, spreadRadius: 8)],
                                    ),
                                    child: const Text('✨\n???', textAlign: TextAlign.center, style: TextStyle(fontSize: 34, color: Colors.white, fontWeight: FontWeight.w900)),
                                  ),
                                ),
                              ),
                            if (_mode == _TouchLabMode.roll)
                              Center(
                                child: Container(
                                  width: 86,
                                  height: 86,
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: (_coreBurst ? const Color(0xFFFFD740) : const Color(0xFF26C6DA)).withOpacity(.20),
                                    border: Border.all(color: _coreBurst ? const Color(0xFFFFD740) : const Color(0xFF80DEEA), width: 3),
                                    boxShadow: [BoxShadow(color: (_coreBurst ? const Color(0xFFFFD740) : const Color(0xFF26C6DA)).withOpacity(.45), blurRadius: 30, spreadRadius: _coreBurst ? 12 : 2)],
                                  ),
                                  child: Text(_coreBurst ? 'BURST!' : 'CORE\n${(_core * 100).round()}%', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w900)),
                                ),
                              ),
                            Positioned.fill(
                              child: CustomPaint(
                                painter: _TouchLabPainter(
                                  pieces: _pieces,
                                  bursts: _bursts,
                                  radius: _radius(size),
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _modeButton(_TouchLabMode mode, String title, String sub, IconData icon) {
    final selected = _mode == mode;
    return GestureDetector(
      onTap: () => _changeMode(mode),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFDDEDE7) : const Color(0xFFFDFBF8),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: selected ? const Color(0xFF91BFB1) : const Color(0xFFE6DED6), width: selected ? 1.5 : 1),
          boxShadow: selected ? const [BoxShadow(color: Color(0x187DB9A6), blurRadius: 14, offset: Offset(0, 5))] : null,
        ),
        child: Row(
          children: [
            Icon(icon, color: selected ? const Color(0xFF5D9E8A) : const Color(0xFF9B948E), size: 26),
            const SizedBox(width: 9),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(color: Color(0xFF56514C), fontSize: 15, fontWeight: FontWeight.w800)),
                  Text(sub, style: const TextStyle(color: Color(0xFF9A938D), fontSize: 10, fontWeight: FontWeight.w600)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TouchLabPainter extends CustomPainter {
  const _TouchLabPainter({required this.pieces, required this.bursts, required this.radius});
  final List<_LabPiece> pieces;
  final List<_Burst> bursts;
  final double radius;

  static const List<Color> _colors = <Color>[
    Color(0xFFFFC928),
    Color(0xFF63D46B),
    Color(0xFF4F9ED8),
    Color(0xFFBFA8F2),
    Color(0xFFFFA7C7),
  ];

  @override
  void paint(Canvas canvas, Size size) {
    for (final p in pieces) {
      if (!p.alive) continue;
      _drawCharacter(canvas, p.p, radius, p.type);
    }
    for (final b in bursts) {
      final t = 1 - b.life;
      final paint = Paint()
        ..color = _colors[b.type].withOpacity(b.life.clamp(0.0, 1.0).toDouble())
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3 * b.life;
      canvas.drawCircle(b.p, radius * (1 + t * 2.3), paint);
      final dot = Paint()..color = Colors.white.withOpacity(b.life.clamp(0.0, 1.0).toDouble());
      for (var i = 0; i < 6; i++) {
        final a = math.pi * 2 * i / 6;
        final d = radius * (1.2 + t * 2.2);
        canvas.drawCircle(b.p + Offset(math.cos(a), math.sin(a)) * d, 2.4 * b.life, dot);
      }
    }
  }

  void _drawCharacter(Canvas canvas, Offset c, double r, int type) {
    final shadow = Paint()..color = const Color(0x33000000);
    canvas.drawCircle(c + Offset(0, r * .13), r * .86, shadow);
    final color = _colors[type];
    final body = Paint()..color = color;

    if (type == 4) {
      canvas.drawOval(Rect.fromCenter(center: c + Offset(-r * .26, -r * .72), width: r * .28, height: r * .78), body);
      canvas.drawOval(Rect.fromCenter(center: c + Offset(r * .26, -r * .72), width: r * .28, height: r * .78), body);
    }
    if (type == 3) {
      final ear = Paint()..color = const Color(0xFF8060C7);
      canvas.drawOval(Rect.fromCenter(center: c + Offset(-r * .64, -r * .08), width: r * .30, height: r * .65), ear);
      canvas.drawOval(Rect.fromCenter(center: c + Offset(r * .64, -r * .08), width: r * .30, height: r * .65), ear);
    }
    if (type == 1) {
      canvas.drawCircle(c + Offset(-r * .38, -r * .50), r * .25, body);
      canvas.drawCircle(c + Offset(r * .38, -r * .50), r * .25, body);
    }

    canvas.drawCircle(c, r * .82, body);
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(-r * .22, -r * .32), width: r * .38, height: r * .20),
      Paint()..color = Colors.white.withOpacity(.30),
    );
    final eye = Paint()..color = const Color(0xFF20232B);
    canvas.drawCircle(c + Offset(-r * .23, -r * .08), r * .075, eye);
    canvas.drawCircle(c + Offset(r * .23, -r * .08), r * .075, eye);

    if (type == 0 || type == 2) {
      final beak = Path()
        ..moveTo(c.dx - r * .10, c.dy + r * .07)
        ..lineTo(c.dx + r * .10, c.dy + r * .07)
        ..lineTo(c.dx, c.dy + r * .19)
        ..close();
      canvas.drawPath(beak, Paint()..color = const Color(0xFFFF8F00));
    } else {
      canvas.drawCircle(c + Offset(0, r * .15), r * .06, Paint()..color = const Color(0xFF5D425B));
    }
  }

  @override
  bool shouldRepaint(covariant _TouchLabPainter oldDelegate) => true;
}
