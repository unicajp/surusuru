// V16.37.5.45 TRUE_HOLE_FINAL_STAGE
// V16.37.5.44 CLEAR_CENTER_ENTRY
// V16.37.5.43 SETTLEMENT_COUNTUP_RARE_GATE
// V16.37.5.42 BATCH_MINIGAME_SETTLEMENT
// V16.37.5.41 OPEN_CENTER_FUNNEL
// V16.37.5.40 CENTER_ANTI_STUCK
// V16.37.5.39 REWARD_COUNTER_TRANSFER
// V16.37.5.38 PHYSICAL_MINIGAME_GATE
// V16.37.5.37 JACKPOT_CALIBRATED_1IN50
// V16.37.5.36 JACKPOT_1IN50_BURST_FADE_FIX
// V16.37.5.35 BATCH_LOCK_BIG_BUMPERS_RICH_SFX
// V16.37.5.34 NO_TOP_WALL_MATCHED_RINGS
// V16.37.5.33 INTEGRATED_MACHINE_TINY_RINGS
// V16.37.5.32 NARROW_BOARD_FULL_HEIGHT
// V16.37.5.31 COMPACT_BOARD_SMALL_RINGS
// V16.37.5.30 SMALL_LETTER_BUMPERS_SOFT_BOUNCE
// V16.37.5.29 SURUSURU_COUNT_BOTTOM_EXP_CURVE
// V16.37.5.28 WALL_SWEEP_REPEAT_REWARDS
// V16.37.5.27 SURU_TWO_ROW_SWEPT_COLLISION
// V16.37.5.26 SURU_ROUND_BUMPER_LAYOUT
// V16.37.5.25 SURU_LETTER_PINS_U_POCKETS
// V16.37.5.24 SURUSURU_NEON_PACHINKO_PROTOTYPE
// V16.37.5.23 SURUSURU_POCKETS_BRANCH_PROTOTYPE
// V16.37.5.22 SURUSURU_CONNECT_DROP_PROTOTYPE
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../game/game_controller.dart';
import '../sfx_manager.dart';
import 'area_build_screen.dart';
import 'daily_chest_screen.dart';
import 'stage_map_screen.dart';
import 'surusuru_play_screen.dart';
import 'sticker_collection_screen.dart';
import 'shop_screen.dart';
import 'training_screen.dart';
import '../widgets/game_bottom_nav.dart';

class RpgHomeScreen extends StatefulWidget {
  final GameController controller;
  const RpgHomeScreen({super.key, required this.controller});

  @override
  State<RpgHomeScreen> createState() => _RpgHomeScreenState();
}

class _RpgHomeScreenState extends State<RpgHomeScreen> {
  final GlobalKey<_CampWorldState> _campKey = GlobalKey<_CampWorldState>();
  CampTool _tool = CampTool.view;
  int _campWood = 30;

  void _open(Widget screen) {
    SfxManager.instance.tap();
    Navigator.push(context, MaterialPageRoute(builder: (_) => screen)).then((_) {
      if (mounted) setState(() {});
    });
  }

  Future<void> _settings() async {
    final reset = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: const Text('⚙️ 設定'),
        content: const Text('時間制限なし。ゆっくり遊べます。\nプレイデータとキャンプを初期化しますか？'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('閉じる')),
          TextButton(onPressed: () => Navigator.pop(d, true), child: const Text('初期化')),
        ],
      ),
    );
    if (reset == true) {
      await widget.controller.resetAllProgress();
      await _CampStorage.reset();
      await _campKey.currentState?.reload();
      if (mounted) setState(() {});
    }
  }

  void _inventory() {
    SfxManager.instance.tap();
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF20332B),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (context) => Padding(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('🎒 持ちもの', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 12),
            Text('🪵 木材  $_campWood', style: const TextStyle(color: Color(0xFFFFD56A), fontSize: 16, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            const Text('建築素材は「BUILD」から配置できます。\n木や岩を開拓すると素材が増え、フィールド拡張にも使えます。', style: TextStyle(color: Colors.white70, height: 1.5)),
          ],
        ),
      ),
    );
  }

  void _setTool(CampTool tool) {
    SfxManager.instance.tap();
    setState(() => _tool = tool);
    _campKey.currentState?.setTool(tool);
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.controller;
    return Scaffold(
      backgroundColor: const Color(0xFF173A2A),
      body: Stack(
        children: [
          Positioned.fill(
            child: _CampWorld(
              key: _campKey,
              controller: c,
              initialTool: _tool,
              onWoodChanged: (value) { if (mounted) setState(() => _campWood = value); },
              onToolChanged: (tool) {
                if (mounted && tool != _tool) setState(() => _tool = tool);
              },
            ),
          ),
          SafeArea(
            child: IgnorePointer(
              ignoring: _tool == CampTool.move || _tool == CampTool.build || _tool == CampTool.clear,
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(10, 8, 10, 0),
                    child: Row(
                      children: [
                        const _WoodLogo(),
                        const Spacer(),
                        _ResourceChip(icon: '🪙', text: '${c.state.coins}'),
                        const SizedBox(width: 6),
                        _ResourceChip(icon: '🪵', text: '$_campWood'),
                        const SizedBox(width: 6),
                        _ResourceChip(icon: '💎', text: '6'),
                        const SizedBox(width: 6),
                        _SquareGameButton(icon: Icons.settings, onTap: _settings),
                      ],
                    ),
                  ),
                  const Spacer(),
                ],
              ),
            ),
          ),
          SafeArea(
            child: Align(
              alignment: Alignment.topRight,
              child: Padding(
                padding: const EdgeInsets.only(top: 58, right: 10),
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => _setTool(
                    _tool == CampTool.build ? CampTool.view : CampTool.build,
                  ),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                    decoration: BoxDecoration(
                      color: _tool == CampTool.build
                          ? const Color(0xFFE9B93E)
                          : const Color(0xE829373B),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.white70, width: 1.5),
                      boxShadow: const [BoxShadow(color: Colors.black38, blurRadius: 5, offset: Offset(0, 2))],
                    ),
                    child: Text(
                      _tool == CampTool.build ? '✓ 配置中' : '＋ 配置',
                      style: TextStyle(
                        color: _tool == CampTool.build ? const Color(0xFF3B2B12) : Colors.white,
                        fontSize: 11,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          SafeArea(
            child: Align(
              alignment: Alignment.bottomCenter,
              child: GameBottomNav(
                active: 'map',
                onAdventure: () => _open(StageMapScreen(controller: c)),
                onShop: () => _open(ShopScreen(controller: c)),
                onSurusuru: () => _open(SurusuruPlayScreen(controller: c)),
                onTraining: () => _open(TrainingScreen(controller: c)),
                onMap: () => _setTool(CampTool.view),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// V16.37.5.21 PATH_TILE_EDIT_RECOVER
// Placed path tiles can be selected, dragged to another cell, and returned to inventory.
// V16.37.5.20 GHOST_PLACEMENT_RECOVER_BUTTON
// Only remaining inventory is shown. Object placement uses a draggable translucent preview.
// Existing objects show a recover/back button when selected.
// V16.37.5.19 COMPACT_PLACEMENT_MENU
// Placement nav is level with the other buttons; build catalogue is compact and auto-collapses after selection.
// V16.37.5.18 BOTTOM_GAME_NAV
// Five-button bottom navigation: Adventure / SHOP / Placement / Surusuru / Map.
// V16.37.5.16 PACKED_LOCKED_FOREST
// Forest clusters are tightly packed, fixed in place and ignore normal taps.
// A future consumable item can remove one forest cluster at a time.
// V16.37.5.15 DENSE_FOREST_NO_ROCKS
// Removed all rock/rock-field objects and increased the wilderness forest density.
// V16.37.5.14 BUILD_INVENTORY_PATH_SYSTEM
// Bottom build drawer with path/object tabs, inventory counts and recovery mode.
// V16.37.5.13 EMOJI_OBJECT_SHOWCASE
// Added a broad set of camp-friendly emoji objects around the tent for real-device selection.
// V16.37.5.12 TENT_CENTER_EMOJI_LAYOUT
// Cabin/flowers removed; tent is the start focus with camp-friendly angled emoji around it.
// V16.37.5.11 WIDER_START_SLOWER_CAMERA
// Initial camera is wider and one-finger camera movement is slowed for precise control.
// V16.37.5.10 EAST_WEST_FACING_AND_CAMERA_FIX
// All movable visuals use two facings only: east/west via horizontal mirroring.
enum CampTool { view, move, build, clear }

enum BuildPanelTab { path, object, recover }
enum GroundTileKind { dirt, stone }

enum CampKind {
  tree,
  rock,
  stump,
  forest,
  rockField,
  cabin,
  tent,
  campfire,
  bench,
  market,
  flower,
  hut,
  lantern,
  basket,
  bucket,
  toolbox,
  ladder,
  wheel,
  canoe,
  mushroom,
  pottedPlant,
  cactus,
  bicycle,
}

class CampObject {
  final int id;
  CampKind kind;
  int gx;
  int gy;
  int rotation;

  CampObject({required this.id, required this.kind, required this.gx, required this.gy, this.rotation = 0});

  int get w => switch (kind) {
        CampKind.cabin => 3,
        CampKind.tent => 2,
        CampKind.hut => 2,
        CampKind.canoe => 2,
        CampKind.bicycle => 2,
        CampKind.market => 2,
        CampKind.bench => 2,
        CampKind.forest || CampKind.rockField => 4,
        _ => 1,
      };

  int get h => switch (kind) {
        CampKind.cabin => 3,
        CampKind.tent => 2,
        CampKind.hut => 2,
        CampKind.canoe => 2,
        CampKind.bicycle => 2,
        CampKind.market => 2,
        CampKind.bench => 1,
        CampKind.forest || CampKind.rockField => 4,
        _ => 1,
      };

  // Forest is environmental terrain. It cannot be selected, moved or cleared
  // by the current tools. A later consumable-item action can target it.
  bool get movable => kind != CampKind.forest;
  bool get clearable => {CampKind.tree, CampKind.rock, CampKind.stump, CampKind.rockField}.contains(kind);
  bool get harvestableByItem => kind == CampKind.forest;

  Map<String, dynamic> toJson() => {'id': id, 'kind': kind.name, 'gx': gx, 'gy': gy, 'rotation': rotation};

  static CampObject fromJson(Map<String, dynamic> json) => CampObject(
        id: json['id'] as int,
        kind: CampKind.values.firstWhere((e) => e.name == json['kind'], orElse: () => CampKind.tree),
        gx: json['gx'] as int,
        gy: json['gy'] as int,
        rotation: (json['rotation'] as int?) ?? 0,
      );
}

class _CampStorage {
  static const _key = 'surusuru_camp_world_v4';
  static const _woodKey = 'surusuru_camp_wood_v4';
  static const _expansionKey = 'surusuru_camp_expansion_v4';

  static Future<Map<String, dynamic>?> load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_key);
    if (raw == null) return null;
    try {
      return jsonDecode(raw) as Map<String, dynamic>;
    } catch (_) {
      return null;
    }
  }

  static Future<void> save(
    List<CampObject> objects,
    int wood,
    int expansion, {
    Map<String, String> pathTiles = const <String, String>{},
    Map<String, int> inventory = const <String, int>{},
  }) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_key, jsonEncode({
      'objects': objects.map((e) => e.toJson()).toList(),
      'pathTiles': pathTiles,
      'inventory': inventory,
    }));
    await p.setInt(_woodKey, wood);
    await p.setInt(_expansionKey, expansion);
  }

  static Future<int> loadWood() async => (await SharedPreferences.getInstance()).getInt(_woodKey) ?? 30;
  static Future<int> loadExpansion() async => (await SharedPreferences.getInstance()).getInt(_expansionKey) ?? 0;

  static Future<void> reset() async {
    final p = await SharedPreferences.getInstance();
    await p.remove(_key);
    await p.remove(_woodKey);
    await p.remove(_expansionKey);
  }
}

class _CampWorld extends StatefulWidget {
  final GameController controller;
  final CampTool initialTool;
  final ValueChanged<CampTool> onToolChanged;
  final ValueChanged<int> onWoodChanged;
  const _CampWorld({super.key, required this.controller, required this.initialTool, required this.onToolChanged, required this.onWoodChanged});

  @override
  State<_CampWorld> createState() => _CampWorldState();
}

class _CampWorldState extends State<_CampWorld> {
  // V16.37.5.9 VISUAL_HITBOX_FIX: object taps follow the visible sprite instead of the whole footprint / oversized touch halo.
  // V16.37.5.8 DIRECT_EDIT_GESTURE_FIX: tap selected object to rotate, drag to move, tap anywhere else to confirm; editor buttons removed.
  // V16.37.5.7 TAP_EDIT_CONFIRM_FIX: tap-to-select, persistent edit mode, tap-empty-to-confirm; no oval selection halo.
  // V16.37.5.6 ISO_MAP_ALIGNMENT_FIX: half-size map with corrected clearing and isometric object anchors.
  static const int gridSize = 38;
  static const double tileW = 72;
  static const double tileH = 36;
  static const double worldW = 2850;
  static const double worldH = 1550;
  static const Offset origin = Offset(worldW / 2, 120);

  final TransformationController _camera = TransformationController();
  final List<CampObject> _objects = [];
  CampTool _tool = CampTool.view;
  CampObject? _selected;
  math.Point<int>? _dragCell;
  Offset? _dragGrabOffset;
  bool _draggingObject = false;
  final ValueNotifier<Offset?> _dragVisualAnchor = ValueNotifier<Offset?>(null);
  final ValueNotifier<math.Point<int>?> _dragCellNotifier = ValueNotifier<math.Point<int>?>(null);
  final ValueNotifier<int?> _activeDragObjectId = ValueNotifier<int?>(null);
  final Set<int> _activePointers = <int>{};
  final Map<int, Offset> _pointerPositions = <int, Offset>{};
  final Map<int, Offset> _pointerDownPositions = <int, Offset>{};
  int? _dragPointer;
  CampObject? _pendingDragObject;
  int? _pendingDragPointer;
  bool _pinchingDuringDrag = false;
  bool _multiTouchGesture = false;
  bool _suppressNextTap = false;
  int? _editObjectId;
  int? _editOriginalGx;
  int? _editOriginalGy;
  int? _editOriginalRotation;
  bool _cameraInitialized = false;
  CampKind _buildKind = CampKind.campfire;
  BuildPanelTab _buildTab = BuildPanelTab.object;
  bool _buildPanelCollapsed = false;
  CampObject? _placementGhost;
  String? _selectedPathKey;
  String? _selectedPathKind;
  int? _pendingPathDragPointer;
  int? _pathDragPointer;
  bool _draggingPath = false;
  GroundTileKind _groundTileKind = GroundTileKind.dirt;
  final Map<String, String> _pathTiles = <String, String>{};
  final Map<String, int> _inventory = <String, int>{};
  static const Map<String, int> _defaultInventory = <String, int>{
    'path:dirt': 60,
    'path:stone': 40,
    'campfire': 2,
    'tent': 1,
    'bench': 4,
    'hut': 1,
    'lantern': 4,
    'basket': 3,
    'bucket': 2,
    'toolbox': 2,
    'ladder': 2,
    'wheel': 2,
    'canoe': 1,
    'mushroom': 6,
    'pottedPlant': 4,
    'cactus': 3,
    'bicycle': 1,
    'stump': 4,
  };
  int wood = 30;
  int expansion = 0;
  bool _loaded = false;
  int _nextId = 1;
  String _toast = '1本指で高速移動・2本指でピンチズーム';

  @override
  void initState() {
    super.initState();
    _tool = widget.initialTool;
    _load();
  }

  @override
  void dispose() {
    _camera.dispose();
    _dragVisualAnchor.dispose();
    _dragCellNotifier.dispose();
    _activeDragObjectId.dispose();
    super.dispose();
  }

  Future<void> reload() async => _load(forceSeed: true);

  void setTool(CampTool tool) {
    if (!mounted) return;
    setState(() {
      _tool = tool;
      if (tool == CampTool.build) {
        _buildPanelCollapsed = false;
      } else {
        _placementGhost = null;
      }
      _selected = null;
      _selectedPathKey = null;
      _selectedPathKind = null;
      _draggingPath = false;
      _pendingPathDragPointer = null;
      _pathDragPointer = null;
      _toast = switch (tool) {
        CampTool.view => '1本指で高速移動・2本指でピンチズーム',
        CampTool.move => '施設をタップで選択・移動や回転後、地面タップで決定',
        CampTool.build => '下の素材を選び、置きたいマスをタップ',
        CampTool.clear => '森林をタップして開拓',
      };
    });
  }

  Future<void> _load({bool forceSeed = false}) async {
    final data = forceSeed ? null : await _CampStorage.load();
    wood = forceSeed ? 30 : await _CampStorage.loadWood();
    expansion = forceSeed ? 0 : await _CampStorage.loadExpansion();
    _objects.clear();
    if (data != null) {
      final list = (data['objects'] as List<dynamic>? ?? []);
      _objects.addAll(list.map((e) => CampObject.fromJson(Map<String, dynamic>.from(e as Map))));
      _nextId = _objects.fold<int>(0, (m, e) => math.max(m, e.id).toInt()) + 1;
      _pathTiles.clear();
      final savedPaths = data['pathTiles'];
      if (savedPaths is Map) {
        for (final entry in savedPaths.entries) {
          _pathTiles[entry.key.toString()] = entry.value.toString();
        }
      } else if (savedPaths is List) {
        // Compatibility with early path-test saves.
        for (final entry in savedPaths) {
          _pathTiles[entry.toString()] = GroundTileKind.dirt.name;
        }
      }
      _inventory
        ..clear()
        ..addAll(_defaultInventory);
      final savedInventory = data['inventory'];
      if (savedInventory is Map) {
        for (final entry in savedInventory.entries) {
          _inventory[entry.key.toString()] = (entry.value as num?)?.toInt() ?? 0;
        }
      }

      // V16.37.5.5 HALF_MAP_TEST: old 76x76 saves use coordinates
      // outside this temporary 38x38 performance-test map. Re-seed only
      // when such an old-map save is detected so the test opens centered.
      final incompatibleLargeMapSave = _objects.any((o) =>
          o.gx < 0 || o.gy < 0 || o.gx + o.w > gridSize || o.gy + o.h > gridSize);
      if (incompatibleLargeMapSave) {
        _objects.clear();
        _nextId = 1;
        _seedWorld();
        await _save();
      }

      // V16.37.5.4 FOREST_CLUSTER_OPTIMIZATION:
      // Old saves may contain hundreds of one-cell trees/rocks. Replace only
      // that wilderness layer while preserving the player's facilities.
      final hadLegacyWilderness = _objects.any((o) => o.kind == CampKind.tree || o.kind == CampKind.rock || o.kind == CampKind.stump);
      if (hadLegacyWilderness) {
        _objects.removeWhere((o) => o.kind == CampKind.tree || o.kind == CampKind.rock || o.kind == CampKind.stump || o.kind == CampKind.forest || o.kind == CampKind.rockField);
        _seedClusteredWilderness();
        await _save();
      }

      // V16.37.5.12: migrate the previous central layout without resetting
      // the clustered wilderness. The removed cabin/flowers act as the
      // one-time migration marker for existing test saves.
      final hadOldCenterLayout = _objects.any(
        (o) => o.kind == CampKind.cabin || o.kind == CampKind.flower,
      );
      if (hadOldCenterLayout) {
        _objects.removeWhere((o) =>
            o.kind == CampKind.cabin ||
            o.kind == CampKind.flower ||
            o.kind == CampKind.tent ||
            o.kind == CampKind.campfire ||
            o.kind == CampKind.bench ||
            o.kind == CampKind.market);
        _objects.addAll([
          CampObject(id: _nextId++, kind: CampKind.tent, gx: 18, gy: 18),
          CampObject(id: _nextId++, kind: CampKind.campfire, gx: 21, gy: 20),
          CampObject(id: _nextId++, kind: CampKind.bench, gx: 22, gy: 18),
          CampObject(id: _nextId++, kind: CampKind.stump, gx: 17, gy: 22),
            ]);
        await _save();
      }

      // V16.37.5.16: rebuild the wilderness once as a tightly packed,
      // forest-only wall around the campsite. Existing placed facilities and
      // paths are preserved.
      if ((_inventory['_forestPackedV16'] ?? 0) == 0) {
        _objects.removeWhere((o) =>
            o.kind == CampKind.forest ||
            o.kind == CampKind.rock ||
            o.kind == CampKind.rockField);
        _inventory.remove('rock');
        _inventory['_forestDenseV15'] = 1;
        _inventory['_forestPackedV16'] = 1;
        _seedClusteredWilderness();
        await _save();
      }

      // V16.37.5.15: one-time migration for existing saves.
      // Remove every rock/rock-field and rebuild only the wilderness layer
      // with the denser forest-only layout. The hidden inventory marker keeps
      // cleared forests from respawning on later loads.
      if ((_inventory['_forestDenseV15'] ?? 0) == 0) {
        _objects.removeWhere((o) =>
            o.kind == CampKind.rock ||
            o.kind == CampKind.rockField ||
            o.kind == CampKind.forest);
        _inventory.remove('rock');
        _inventory['_forestDenseV15'] = 1;
        _seedClusteredWilderness();
        await _save();
      }

      // V16.37.5.13: add the emoji showcase once to an existing V16.37.5.12 save.
      if (!_objects.any((o) => o.kind == CampKind.hut)) {
        final showcase = <CampObject>[
          CampObject(id: _nextId++, kind: CampKind.hut, gx: 14, gy: 16),
          CampObject(id: _nextId++, kind: CampKind.lantern, gx: 17, gy: 17),
          CampObject(id: _nextId++, kind: CampKind.basket, gx: 16, gy: 20),
          CampObject(id: _nextId++, kind: CampKind.bucket, gx: 23, gy: 21),
          CampObject(id: _nextId++, kind: CampKind.toolbox, gx: 24, gy: 19),
          CampObject(id: _nextId++, kind: CampKind.ladder, gx: 15, gy: 22),
          CampObject(id: _nextId++, kind: CampKind.wheel, gx: 24, gy: 22),
          CampObject(id: _nextId++, kind: CampKind.canoe, gx: 17, gy: 24),
          CampObject(id: _nextId++, kind: CampKind.mushroom, gx: 20, gy: 16),
          CampObject(id: _nextId++, kind: CampKind.pottedPlant, gx: 21, gy: 16),
          CampObject(id: _nextId++, kind: CampKind.cactus, gx: 22, gy: 16),
          CampObject(id: _nextId++, kind: CampKind.bicycle, gx: 13, gy: 20),
        ];
        for (final item in showcase) {
          if (_canPlace(item, item.gx, item.gy)) _objects.add(item);
        }
        await _save();
      }
    } else {
      _pathTiles.clear();
      _inventory
        ..clear()
        ..addAll(_defaultInventory);
      _inventory['_forestDenseV15'] = 1;
      _inventory['_forestPackedV16'] = 1;
      _seedWorld();
      await _save();
    }
    if (mounted) {
      setState(() => _loaded = true);
      widget.onWoodChanged(wood);
      if (!_cameraInitialized) {
        WidgetsBinding.instance.addPostFrameCallback((_) => _focusTent());
      }
    }
  }

  void _seedWorld() {
    // The playable camp is intentionally grouped at the exact center of the huge map.
    // The open clearing is large enough that furniture reads as a camp, not as objects lost in a forest.
    _objects.addAll([
      // Tent is the visual/start-position center.
      CampObject(id: _nextId++, kind: CampKind.tent, gx: 18, gy: 18),
      // Camp-friendly emoji that already read with some depth on the map.
      CampObject(id: _nextId++, kind: CampKind.campfire, gx: 21, gy: 20),
      CampObject(id: _nextId++, kind: CampKind.bench, gx: 22, gy: 18),
      CampObject(id: _nextId++, kind: CampKind.stump, gx: 17, gy: 22),
      CampObject(id: _nextId++, kind: CampKind.hut, gx: 14, gy: 16),
      CampObject(id: _nextId++, kind: CampKind.lantern, gx: 17, gy: 17),
      CampObject(id: _nextId++, kind: CampKind.basket, gx: 16, gy: 20),
      CampObject(id: _nextId++, kind: CampKind.bucket, gx: 23, gy: 21),
      CampObject(id: _nextId++, kind: CampKind.toolbox, gx: 24, gy: 19),
      CampObject(id: _nextId++, kind: CampKind.ladder, gx: 15, gy: 22),
      CampObject(id: _nextId++, kind: CampKind.wheel, gx: 24, gy: 22),
      CampObject(id: _nextId++, kind: CampKind.canoe, gx: 17, gy: 24),
      CampObject(id: _nextId++, kind: CampKind.mushroom, gx: 20, gy: 16),
      CampObject(id: _nextId++, kind: CampKind.pottedPlant, gx: 21, gy: 16),
      CampObject(id: _nextId++, kind: CampKind.cactus, gx: 22, gy: 16),
      CampObject(id: _nextId++, kind: CampKind.bicycle, gx: 13, gy: 20),
    ]);

    _seedClusteredWilderness();
  }

  void _seedClusteredWilderness() {
    // V16.37.5.16 PACKED_LOCKED_FOREST
    // 4x4 clusters tile the outer camp with no intentional gaps. Using one
    // object per 4x4 block keeps rendering far lighter than individual trees.
    const center = 19.0;

    for (var x = 1; x <= gridSize - 5; x += 4) {
      for (var y = 1; y <= gridSize - 5; y += 4) {
        final cx = x + 1.5;
        final cy = y + 1.5;
        final dx = cx - center;
        final dy = cy - center;

        // Keep only the central campsite open. Everything outside this circle
        // is packed with forest unless an existing facility already occupies it.
        if (dx * dx + dy * dy <= 8.0 * 8.0) continue;

        final cluster = CampObject(
          id: _nextId++,
          kind: CampKind.forest,
          gx: x,
          gy: y,
        );
        if (_canPlace(cluster, x, y)) {
          _objects.add(cluster);
        }
      }
    }
  }

  void _focusTent() {
    if (!mounted || _cameraInitialized) return;
    CampObject? tent;
    for (final o in _objects) {
      if (o.kind == CampKind.tent) {
        tent = o;
        break;
      }
    }
    if (tent == null) return;
    final box = context.findRenderObject() as RenderBox?;
    if (box == null || !box.hasSize) return;
    final p = _iso(tent.gx + 1, tent.gy + 1);
    final size = box.size;
    const scale = .52; // V16.37.5.11: start zoomed out to show most of the camp
    _camera.value = Matrix4.identity()
      ..translate(size.width / 2 - p.dx * scale, size.height / 2 - p.dy * scale)
      ..scale(scale);
    _cameraInitialized = true;
  }

  Future<void> _save() {
    widget.onWoodChanged(wood);
    return _CampStorage.save(_objects, wood, expansion, pathTiles: Map<String, String>.from(_pathTiles), inventory: _inventory);
  }

  int get unlockedMin => 1;
  int get unlockedMax => gridSize - 2;
  int get expansionCost => [40, 85, 150, 240][expansion.clamp(0, 3)];

  bool _unlockedCell(int x, int y) => x >= unlockedMin && x <= unlockedMax && y >= unlockedMin && y <= unlockedMax;

  Offset _iso(int x, int y) => Offset(origin.dx + (x - y) * tileW / 2, origin.dy + (x + y) * tileH / 2);

  math.Point<int> _gridFromLocal(Offset p) {
    final dx = p.dx - origin.dx;
    final dy = p.dy - origin.dy;
    final x = (dx / tileW + dy / tileH).round();
    final y = (dy / tileH - dx / tileW).round();
    return math.Point(x.clamp(0, gridSize - 1), y.clamp(0, gridSize - 1));
  }

  CampObject? _objectAt(int x, int y) {
    for (final o in _objects.reversed) {
      if (x >= o.gx && x < o.gx + o.w && y >= o.gy && y < o.gy + o.h) return o;
    }
    return null;
  }

  Size _objectVisualSize(CampObject o) => switch (o.kind) {
        CampKind.cabin => const Size(156, 128),
        CampKind.tent => const Size(104, 86),
        CampKind.market => const Size(112, 94),
        CampKind.bench => o.rotation.isEven ? const Size(92, 58) : const Size(68, 82),
        CampKind.tree => const Size(68, 76),
        CampKind.rock => const Size(58, 52),
        CampKind.forest => const Size(190, 142),
        CampKind.rockField => const Size(174, 118),
        CampKind.stump => const Size(50, 44),
        CampKind.campfire => const Size(58, 58),
        CampKind.hut => const Size(104, 90),
        CampKind.lantern => const Size(48, 54),
        CampKind.basket => const Size(52, 48),
        CampKind.bucket => const Size(48, 50),
        CampKind.toolbox => const Size(54, 46),
        CampKind.ladder => const Size(48, 72),
        CampKind.wheel => const Size(52, 52),
        CampKind.canoe => const Size(100, 54),
        CampKind.mushroom => const Size(46, 48),
        CampKind.pottedPlant => const Size(50, 58),
        CampKind.cactus => const Size(48, 58),
        CampKind.bicycle => const Size(92, 58),
        CampKind.flower => const Size(42, 42),
      };

  Offset _objectVisualTopLeft(CampObject o, int gx, int gy) {
    final p = _iso(gx, gy);
    final size = _objectVisualSize(o);
    // V16.37.5.6: center the visual on the ACTUAL isometric footprint.
    // On an iso grid, increasing x moves down-right while increasing y moves
    // down-left. The previous code added both axes to screen X, pushing
    // square objects (especially 4x4 forest/rock fields) far to the right of
    // their highlighted cells.
    final footprintCenterX = ((o.w - 1) - (o.h - 1)) * tileW / 4;
    final footprintCenterY = ((o.w - 1) + (o.h - 1)) * tileH / 4;
    return Offset(
      p.dx - size.width / 2 + footprintCenterX,
      p.dy - size.height * .78 + footprintCenterY,
    );
  }

  Rect _objectHitRect(CampObject o) {
    final topLeft = _objectVisualTopLeft(o, o.gx, o.gy);
    final size = _objectVisualSize(o);
    final visual = Rect.fromLTWH(topLeft.dx, topLeft.dy, size.width, size.height);

    // V16.37.5.9: visual sizes include transparent/empty room around emoji.
    // Tighten the hit box per object so nearby ground remains tappable.
    return switch (o.kind) {
      CampKind.cabin => Rect.fromLTRB(
          visual.left + size.width * .13,
          visual.top + size.height * .06,
          visual.right - size.width * .13,
          visual.bottom - size.height * .03,
        ),
      CampKind.tent => Rect.fromLTRB(
          visual.left + size.width * .12,
          visual.top + size.height * .08,
          visual.right - size.width * .12,
          visual.bottom - size.height * .04,
        ),
      CampKind.market => Rect.fromLTRB(
          visual.left + size.width * .10,
          visual.top + size.height * .08,
          visual.right - size.width * .10,
          visual.bottom - size.height * .04,
        ),
      CampKind.bench => Rect.fromLTRB(
          visual.left + size.width * .12,
          visual.top + size.height * .12,
          visual.right - size.width * .12,
          visual.bottom - size.height * .08,
        ),
      CampKind.tree => Rect.fromLTRB(
          visual.left + size.width * .20,
          visual.top + size.height * .03,
          visual.right - size.width * .20,
          visual.bottom - size.height * .02,
        ),
      CampKind.rock => Rect.fromLTRB(
          visual.left + size.width * .12,
          visual.top + size.height * .10,
          visual.right - size.width * .12,
          visual.bottom - size.height * .06,
        ),
      CampKind.forest => Rect.fromLTRB(
          visual.left + size.width * .08,
          visual.top + size.height * .04,
          visual.right - size.width * .08,
          visual.bottom - size.height * .03,
        ),
      CampKind.rockField => Rect.fromLTRB(
          visual.left + size.width * .08,
          visual.top + size.height * .08,
          visual.right - size.width * .08,
          visual.bottom - size.height * .05,
        ),
      CampKind.stump => Rect.fromLTRB(
          visual.left + size.width * .14,
          visual.top + size.height * .10,
          visual.right - size.width * .14,
          visual.bottom - size.height * .08,
        ),
      CampKind.campfire => Rect.fromLTRB(
          visual.left + size.width * .14,
          visual.top + size.height * .05,
          visual.right - size.width * .14,
          visual.bottom - size.height * .03,
        ),
      CampKind.hut ||
      CampKind.lantern ||
      CampKind.basket ||
      CampKind.bucket ||
      CampKind.toolbox ||
      CampKind.ladder ||
      CampKind.wheel ||
      CampKind.canoe ||
      CampKind.mushroom ||
      CampKind.pottedPlant ||
      CampKind.cactus ||
      CampKind.bicycle => Rect.fromLTRB(
          visual.left + size.width * .12,
          visual.top + size.height * .08,
          visual.right - size.width * .12,
          visual.bottom - size.height * .05,
        ),
      CampKind.flower => Rect.fromLTRB(
          visual.left + size.width * .10,
          visual.top + size.height * .05,
          visual.right - size.width * .10,
          visual.bottom - size.height * .05,
        ),
    };
  }

  CampObject? _objectFromVisualPoint(Offset p) {
    // V16.37.5.9 VISUAL_HITBOX_FIX:
    // Keep only a very small, screen-space finger tolerance around the
    // visible sprite. The old 54-78 px halo and grid-footprint fallback made
    // surrounding ground behave as if it belonged to the object.
    final scale = _camera.value.getMaxScaleOnAxis().clamp(.10, 3.2).toDouble();
    final screenPadding = scale < .45 ? 14.0 : scale < .75 ? 11.0 : 8.0;
    final scenePadding = screenPadding / scale;

    CampObject? best;
    double bestScore = double.infinity;
    for (final o in _objects) {
      if (!o.movable) continue;
      final rect = _objectHitRect(o);
      final hitRect = rect.inflate(scenePadding);
      if (!hitRect.contains(p)) continue;

      final distance = (p - rect.center).distance * scale;
      final furnitureBonus = switch (o.kind) {
        CampKind.cabin || CampKind.tent || CampKind.market || CampKind.campfire || CampKind.bench || CampKind.flower => -8.0,
        _ => 0.0,
      };
      final depthBonus = -(o.gx + o.gy) * .01;
      final score = distance + furnitureBonus + depthBonus;
      if (score < bestScore) {
        bestScore = score;
        best = o;
      }
    }
    return best;
  }

  bool _canPlace(CampObject target, int gx, int gy, {CampObject? ignore}) {
    if (gx < unlockedMin || gy < unlockedMin || gx + target.w - 1 > unlockedMax || gy + target.h - 1 > unlockedMax) return false;
    for (var x = gx; x < gx + target.w; x++) {
      for (var y = gy; y < gy + target.h; y++) {
        final hit = _objectAt(x, y);
        if (hit != null && hit != ignore) return false;
      }
    }
    return true;
  }

  String _cellKey(int x, int y) => '$x,$y';

  int _inventoryCountForKind(CampKind kind) => _inventory[kind.name] ?? 0;
  int _inventoryCountForPath(GroundTileKind kind) => _inventory['path:${kind.name}'] ?? 0;

  void _changeInventory(String key, int delta) {
    _inventory[key] = math.max(0, (_inventory[key] ?? 0) + delta);
  }

  String _groundTileLabel(GroundTileKind kind) => switch (kind) {
        GroundTileKind.dirt => '土の道',
        GroundTileKind.stone => '石畳',
      };

  int _buildCost(CampKind k) => switch (k) {
        CampKind.campfire => 12,
        CampKind.tent => 24,
        CampKind.cabin => 55,
        CampKind.bench => 10,
        CampKind.market => 45,
        CampKind.flower => 4,
        _ => 0,
      };

  String _kindLabel(CampKind k) => switch (k) {
        CampKind.campfire => '焚き火',
        CampKind.tent => 'テント',
        CampKind.cabin => '小屋',
        CampKind.bench => 'ベンチ',
        CampKind.market => '屋台',
        CampKind.flower => '花',
        CampKind.tree => '木',
        CampKind.rock => '岩',
        CampKind.forest => '森林',
        CampKind.rockField => '岩場',
        CampKind.stump => '切り株',
        CampKind.hut => '小屋',
        CampKind.lantern => 'ランタン',
        CampKind.basket => 'バスケット',
        CampKind.bucket => 'バケツ',
        CampKind.toolbox => '道具箱',
        CampKind.ladder => 'はしご',
        CampKind.wheel => '車輪',
        CampKind.canoe => 'カヌー',
        CampKind.mushroom => 'キノコ',
        CampKind.pottedPlant => '鉢植え',
        CampKind.cactus => 'サボテン',
        CampKind.bicycle => '自転車',
      };

  String _kindIcon(CampKind k) => switch (k) {
        CampKind.campfire => '🔥',
        CampKind.tent => '⛺',
        CampKind.cabin => '🏠',
        CampKind.bench => '🪑',
        CampKind.market => '🏪',
        CampKind.flower => '🌼',
        CampKind.tree => '🌲',
        CampKind.rock => '🪨',
        CampKind.forest => '🌲',
        CampKind.rockField => '🪨',
        CampKind.stump => '🪵',
        CampKind.hut => '🛖',
        CampKind.lantern => '🏮',
        CampKind.basket => '🧺',
        CampKind.bucket => '🪣',
        CampKind.toolbox => '🧰',
        CampKind.ladder => '🪜',
        CampKind.wheel => '🛞',
        CampKind.canoe => '🛶',
        CampKind.mushroom => '🍄',
        CampKind.pottedPlant => '🪴',
        CampKind.cactus => '🌵',
        CampKind.bicycle => '🚲',
      };

  String _objectArt(CampKind k) => switch (k) {
        CampKind.forest => '  🌲🌲\n 🌲🌲🌲🌲\n 🌲🌲🌲🌲\n 🌲🌲🌲🌲\n  🌲🌲',
        CampKind.rockField => '  🪨🪨\n 🪨🪨🪨🪨\n 🪨🪨🪨🪨\n 🪨🪨🪨🪨\n  🪨🪨',
        _ => _kindIcon(k),
      };

  void _rememberEditOrigin(CampObject o) {
    if (_editObjectId == o.id) return;
    _editObjectId = o.id;
    _editOriginalGx = o.gx;
    _editOriginalGy = o.gy;
    _editOriginalRotation = o.rotation;
  }

  void _clearEditOrigin() {
    _editObjectId = null;
    _editOriginalGx = null;
    _editOriginalGy = null;
    _editOriginalRotation = null;
  }

  math.Point<int> _findPlacementPreviewCell(CampKind kind) {
    final ghost = CampObject(id: -9999, kind: kind, gx: 18, gy: 18);
    const center = 19;
    for (var radius = 0; radius <= 8; radius++) {
      for (var x = center - radius; x <= center + radius; x++) {
        for (final y in <int>[center - radius, center + radius]) {
          if (_canPlace(ghost, x, y)) return math.Point(x, y);
        }
      }
      for (var y = center - radius + 1; y < center + radius; y++) {
        for (final x in <int>[center - radius, center + radius]) {
          if (_canPlace(ghost, x, y)) return math.Point(x, y);
        }
      }
    }
    return const math.Point<int>(18, 18);
  }

  void _startPlacementPreview(CampKind kind) {
    if (_inventoryCountForKind(kind) <= 0) return;
    final cell = _findPlacementPreviewCell(kind);
    final ghost = CampObject(
      id: -9999,
      kind: kind,
      gx: cell.x,
      gy: cell.y,
    );
    setState(() {
      _buildKind = kind;
      _buildTab = BuildPanelTab.object;
      _buildPanelCollapsed = true;
      _placementGhost = ghost;
      _selected = ghost;
      _dragCell = cell;
      _toast = '${_kindLabel(kind)}を移動して場所を決めてください';
    });
    _dragCellNotifier.value = cell;
    _dragVisualAnchor.value = _iso(cell.x, cell.y);
  }

  Future<void> _confirmPlacementPreview() async {
    final ghost = _placementGhost;
    if (ghost == null) return;
    if (_inventoryCountForKind(ghost.kind) <= 0) {
      _showToast('${_kindLabel(ghost.kind)}の在庫がありません');
      return;
    }
    if (!_canPlace(ghost, ghost.gx, ghost.gy)) {
      _showToast('その場所には配置できません');
      return;
    }
    setState(() {
      _changeInventory(ghost.kind.name, -1);
      _objects.add(CampObject(
        id: _nextId++,
        kind: ghost.kind,
        gx: ghost.gx,
        gy: ghost.gy,
        rotation: ghost.rotation,
      ));
      _placementGhost = null;
      _selected = null;
      _dragCell = null;
      _buildPanelCollapsed = false;
      _toast = '${_kindLabel(ghost.kind)}を配置しました';
    });
    _dragCellNotifier.value = null;
    _dragVisualAnchor.value = null;
    await _save();
  }

  Future<void> _recoverSelectedObject() async {
    final selected = _selected;
    if (selected == null || selected.kind == CampKind.forest) return;
    setState(() {
      _objects.remove(selected);
      _changeInventory(selected.kind.name, 1);
      _selected = null;
      _dragCell = null;
      _draggingObject = false;
      _tool = CampTool.view;
      _toast = '${_kindLabel(selected.kind)}を戻しました';
    });
    _dragCellNotifier.value = null;
    _dragVisualAnchor.value = null;
    _activeDragObjectId.value = null;
    _clearEditOrigin();
    widget.onToolChanged(CampTool.view);
    await _save();
  }

  void _selectPathForEdit(math.Point<int> cell) {
    final key = _cellKey(cell.x, cell.y);
    final kind = _pathTiles[key];
    if (kind == null) return;
    setState(() {
      _tool = CampTool.move;
      _selected = null;
      _selectedPathKey = key;
      _selectedPathKind = kind;
      _dragCell = cell;
      _toast = '${_groundTileLabel(kind == GroundTileKind.stone.name ? GroundTileKind.stone : GroundTileKind.dirt)}を編集中  •  ドラッグで移動';
    });
    _dragCellNotifier.value = cell;
    widget.onToolChanged(CampTool.move);
    SfxManager.instance.tap();
  }

  Future<void> _recoverSelectedPath() async {
    final key = _selectedPathKey;
    final kind = _selectedPathKind;
    if (key == null || kind == null) return;
    setState(() {
      _pathTiles.remove(key);
      _changeInventory('path:$kind', 1);
      _selectedPathKey = null;
      _selectedPathKind = null;
      _dragCell = null;
      _draggingPath = false;
      _tool = CampTool.view;
      _toast = '道タイルを戻しました';
    });
    _dragCellNotifier.value = null;
    widget.onToolChanged(CampTool.view);
    await _save();
  }

  Future<void> _commitSelectedPathEdit() async {
    if (_selectedPathKey == null) return;
    setState(() {
      _selectedPathKey = null;
      _selectedPathKind = null;
      _dragCell = null;
      _draggingPath = false;
      _tool = CampTool.view;
      _toast = '設置しました';
    });
    _dragCellNotifier.value = null;
    widget.onToolChanged(CampTool.view);
    await _save();
  }

  Future<void> _finishPathDrag() async {
    final oldKey = _selectedPathKey;
    final kind = _selectedPathKind;
    final target = _dragCell;
    if (oldKey == null || kind == null || target == null) return;

    final newKey = _cellKey(target.x, target.y);
    final valid = _unlockedCell(target.x, target.y) &&
        (!_pathTiles.containsKey(newKey) || newKey == oldKey);

    setState(() {
      _draggingPath = false;
      _pathDragPointer = null;
      _pendingPathDragPointer = null;
      if (valid && newKey != oldKey) {
        _pathTiles.remove(oldKey);
        _pathTiles[newKey] = kind;
        _selectedPathKey = newKey;
        _toast = '道タイルを移動しました  •  戻すこともできます';
      } else if (!valid) {
        final parts = oldKey.split(',');
        if (parts.length == 2) {
          _dragCell = math.Point(
            int.tryParse(parts[0]) ?? target.x,
            int.tryParse(parts[1]) ?? target.y,
          );
        }
        _toast = 'そこには移動できません';
      }
    });
    _dragCellNotifier.value = _dragCell;
    await _save();
  }

  void _selectForEdit(CampObject hit) {
    _rememberEditOrigin(hit);
    setState(() {
      _selectedPathKey = null;
      _selectedPathKind = null;
      _tool = CampTool.move;
      _selected = hit;
      _dragCell = math.Point(hit.gx, hit.gy);
      _toast = '${_kindLabel(hit.kind)}を編集中  •  ドラッグで移動・タップで向き変更・他をタップで設置完了';
    });
    _dragCellNotifier.value = _dragCell;
    widget.onToolChanged(CampTool.move);
    SfxManager.instance.tap();
  }

  Future<void> _commitSelectedEdit() async {
    if (_selected == null) return;
    setState(() {
      _selected = null;
      _dragCell = null;
      _tool = CampTool.view;
      _toast = '設置しました  •  1本指で高速移動・2本指でピンチズーム';
    });
    _dragCellNotifier.value = null;
    _dragVisualAnchor.value = null;
    _activeDragObjectId.value = null;
    _clearEditOrigin();
    widget.onToolChanged(CampTool.view);
    await _save();
  }

  void _cancelSelectedEdit() {
    if (_selectedPathKey != null) {
      setState(() {
        _selectedPathKey = null;
        _selectedPathKind = null;
        _dragCell = null;
        _draggingPath = false;
        _tool = CampTool.view;
        _toast = '編集を終了しました';
      });
      _dragCellNotifier.value = null;
      widget.onToolChanged(CampTool.view);
      return;
    }
    if (_placementGhost != null) {
      setState(() {
        _placementGhost = null;
        _selected = null;
        _dragCell = null;
        _draggingObject = false;
        _tool = CampTool.view;
        _toast = '配置を終了しました';
      });
      _dragCellNotifier.value = null;
      _dragVisualAnchor.value = null;
      widget.onToolChanged(CampTool.view);
      return;
    }
    final selected = _selected;
    if (selected != null && _editObjectId == selected.id) {
      if (_editOriginalGx != null) selected.gx = _editOriginalGx!;
      if (_editOriginalGy != null) selected.gy = _editOriginalGy!;
      if (_editOriginalRotation != null) selected.rotation = _editOriginalRotation!;
    }
    setState(() {
      _draggingObject = false;
      _dragPointer = null;
      _dragGrabOffset = null;
      _selected = null;
      _dragCell = null;
      _tool = CampTool.view;
      _toast = '編集を取り消しました';
    });
    _dragCellNotifier.value = null;
    _dragVisualAnchor.value = null;
    _activeDragObjectId.value = null;
    _clearEditOrigin();
    widget.onToolChanged(CampTool.view);
  }

  Future<void> _tapViewport(TapUpDetails d) async {
    // GestureDetector sits outside the transformed world, so convert viewport
    // coordinates back into world/scene coordinates before hit-testing.
    final scene = _camera.toScene(d.localPosition);
    await _tapWorldAt(scene);
  }

  Future<void> _tapWorldAt(Offset localPosition) async {
    if (_suppressNextTap) {
      _suppressNextTap = false;
      return;
    }
    final g = _gridFromLocal(localPosition);
    final hit = _objectFromVisualPoint(localPosition);

    if (_tool == CampTool.view) {
      if (hit != null && hit.movable) {
        _selectForEdit(hit);
        return;
      }
      if (_pathTiles.containsKey(_cellKey(g.x, g.y))) {
        _selectPathForEdit(g);
        return;
      }
    }

    if (_tool == CampTool.clear) {
      // Forest deliberately ignores taps for now. Clearing will later require
      // consuming a dedicated item, one forest cluster per use.
      if (hit == null || !hit.clearable || !_unlockedCell(hit.gx, hit.gy)) {
        return;
      }
      setState(() {
        if (hit.kind == CampKind.forest) {
          _objects.remove(hit);
          wood += 40;
          _toast = '森林を開拓しました  •  木材 +40';
        } else if (hit.kind == CampKind.rockField) {
          _objects.remove(hit);
          wood += 18;
          _toast = '岩場を開拓しました  •  木材 +18';
        } else if (hit.kind == CampKind.tree) {
          hit.kind = CampKind.stump;
          wood += 5;
          _toast = '木材 +5  •  もう一度で切り株も除去';
        } else {
          _objects.remove(hit);
          wood += hit.kind == CampKind.stump ? 2 : 3;
          _toast = '空きマスになりました';
        }
      });
      SfxManager.instance.tap();
      await _save();
      return;
    }

    if (_tool == CampTool.move) {
      if (_selectedPathKey != null) {
        final tappedKey = _cellKey(g.x, g.y);
        if (tappedKey == _selectedPathKey) return;
        await _commitSelectedPathEdit();
        return;
      }

      if (_selected == null) {
        if (hit != null && hit.movable) {
          _selectForEdit(hit);
        } else if (_pathTiles.containsKey(_cellKey(g.x, g.y))) {
          _selectPathForEdit(g);
        }
        return;
      }

      // DIRECT_EDIT_GESTURE_FIX:
      // - tap the selected object: rotate it
      // - tap anything else (ground or another object): confirm and leave edit mode
      if (identical(hit, _selected)) {
        _rotateSelected();
      } else {
        await _commitSelectedEdit();
      }
      return;
    }

    if (_tool == CampTool.build) {
      if (_placementGhost != null) {
        return;
      }
      if (!_unlockedCell(g.x, g.y)) {
        _showToast('このマスはまだ使用できません');
        return;
      }

      if (_buildTab == BuildPanelTab.path) {
        final key = _cellKey(g.x, g.y);
        final stockKey = 'path:${_groundTileKind.name}';
        if (_pathTiles.containsKey(key)) {
          _showToast('このマスにはすでに道があります');
          return;
        }
        if ((_inventory[stockKey] ?? 0) <= 0) {
          _showToast('${_groundTileLabel(_groundTileKind)}の在庫がありません');
          return;
        }
        setState(() {
          _pathTiles[key] = _groundTileKind.name;
          _changeInventory(stockKey, -1);
          _toast = '${_groundTileLabel(_groundTileKind)}を敷きました';
        });
        await _save();
        return;
      }

      _showToast('一覧から配置するオブジェクトを選んでください');
      return;
    }
  }

  void _beginObjectDrag(CampObject hit, Offset scenePosition) {
    final anchor = _iso(hit.gx, hit.gy);
    _tool = CampTool.move;
    _selected = hit;
    _rememberEditOrigin(hit);
    _draggingObject = true;
    _dragGrabOffset = scenePosition - anchor;
    _dragCell = math.Point(hit.gx, hit.gy);
    _toast = '${_kindLabel(hit.kind)}を移動中  •  指を離しても編集を続けられます';

    // INPUT_LATENCY_FIX: switch only the grabbed object's lightweight
    // listeners first. Rebuilding the whole camp here made the first visible
    // response wait behind hundreds of object widgets on mobile Web.
    _activeDragObjectId.value = hit.id;
    _dragVisualAnchor.value = anchor;
    _dragCellNotifier.value = _dragCell;
  }

  // V16.37.5.3 DRAG_RENDER_PIPELINE_FIX: single drag overlay + paint-only movement.
  // V16.37.5.1 RAW_POINTER_GESTURE_FIX: compile fix + one controller owns drag, pan and pinch.
  void _rawPointerDown(PointerDownEvent e) {
    _activePointers.add(e.pointer);
    _pointerPositions[e.pointer] = e.localPosition;
    _pointerDownPositions[e.pointer] = e.localPosition;

    if (_activePointers.length >= 2) {
      _multiTouchGesture = true;
      _pendingDragObject = null;
      _pendingDragPointer = null;
      if (_draggingObject) _pinchingDuringDrag = true;
      return;
    }

    if (_tool == CampTool.build && _placementGhost != null) {
      final scene = _camera.toScene(e.localPosition);
      final ghost = _placementGhost!;
      final scale = _camera.value.getMaxScaleOnAxis().clamp(.10, 3.2).toDouble();
      if (_objectHitRect(ghost).inflate(14 / scale).contains(scene)) {
        _selected = ghost;
        _draggingObject = true;
        _dragPointer = e.pointer;
        _dragGrabOffset = scene - _iso(ghost.gx, ghost.gy);
        _dragCell = math.Point(ghost.gx, ghost.gy);
        _dragVisualAnchor.value = _iso(ghost.gx, ghost.gy);
        _dragCellNotifier.value = _dragCell;
        _suppressNextTap = true;
        return;
      }
    }

    if (_tool == CampTool.build || _tool == CampTool.clear) return;

    final scene = _camera.toScene(e.localPosition);

    if (_tool == CampTool.move && _selectedPathKey != null) {
      final g = _gridFromLocal(scene);
      if (_cellKey(g.x, g.y) == _selectedPathKey) {
        _pendingPathDragPointer = e.pointer;
      } else {
        _pendingPathDragPointer = null;
      }
      return;
    }

    final hit = _objectFromVisualPoint(scene);

    // A touch on the selected object starts as a tap candidate. We only
    // promote it to a drag after the finger has moved a few pixels, allowing
    // a clean single-tap gesture to rotate the object.
    if (_tool == CampTool.move && _selected != null && identical(hit, _selected)) {
      _pendingDragObject = hit;
      _pendingDragPointer = e.pointer;
    } else {
      _pendingDragObject = null;
      _pendingDragPointer = null;
    }
  }

  void _applyCameraGesture(Offset previousFocal, Offset currentFocal, {double scaleRatio = 1.0, double panSpeed = 1.0}) {
    final currentScale = _camera.value.getMaxScaleOnAxis().clamp(.10, 3.2).toDouble();
    final safeRatio = scaleRatio.isFinite && scaleRatio > 0 ? scaleRatio : 1.0;
    final nextScale = (currentScale * safeRatio).clamp(.10, 3.2).toDouble();
    final delta = currentFocal - previousFocal;
    final targetFocal = previousFocal + delta * panSpeed;
    final anchorScene = _camera.toScene(previousFocal);

    _camera.value = Matrix4.identity()
      ..translate(targetFocal.dx, targetFocal.dy)
      ..scale(nextScale)
      ..translate(-anchorScene.dx, -anchorScene.dy);
  }

  void _rawPointerMove(PointerMoveEvent e) {
    // INPUT_LATENCY_FIX: avoid allocating/copying the pointer map on every
    // move event. Keep only the previous position of the pointer that moved.
    final old = _pointerPositions[e.pointer];
    _pointerPositions[e.pointer] = e.localPosition;

    if (_activePointers.length >= 2) {
      final ids = _activePointers.take(2).toList(growable: false);
      if (ids.length < 2) return;
      final a = ids[0], b = ids[1];
      final pa1 = _pointerPositions[a], pb1 = _pointerPositions[b];
      if (pa1 == null || pb1 == null || old == null) return;
      final pa0 = a == e.pointer ? old : pa1;
      final pb0 = b == e.pointer ? old : pb1;

      final oldMid = (pa0 + pb0) / 2;
      final newMid = (pa1 + pb1) / 2;
      final oldDistance = (pa0 - pb0).distance;
      final newDistance = (pa1 - pb1).distance;
      final ratio = oldDistance > 1 ? newDistance / oldDistance : 1.0;
      _applyCameraGesture(oldMid, newMid, scaleRatio: ratio);
      return;
    }

    if (old == null) return;

    if (!_draggingPath &&
        _tool == CampTool.move &&
        _selectedPathKey != null &&
        _pendingPathDragPointer == e.pointer) {
      final down = _pointerDownPositions[e.pointer];
      if (down != null && (e.localPosition - down).distance >= 6.0) {
        _draggingPath = true;
        _pathDragPointer = e.pointer;
        _pendingPathDragPointer = null;
        _suppressNextTap = true;
      }
    }

    if (_draggingPath && _pathDragPointer == e.pointer) {
      final scene = _camera.toScene(e.localPosition);
      final g = _gridFromLocal(scene);
      if (_dragCell?.x != g.x || _dragCell?.y != g.y) {
        _dragCell = g;
        _dragCellNotifier.value = g;
      }
      return;
    }

    // Distinguish a tap-to-rotate from a drag-to-move. Starting the drag only
    // after a small movement threshold keeps taps responsive without causing
    // the object to jump.
    if (!_draggingObject &&
        _tool == CampTool.move &&
        _selected != null &&
        _pendingDragPointer == e.pointer &&
        identical(_pendingDragObject, _selected)) {
      final down = _pointerDownPositions[e.pointer];
      if (down != null && (e.localPosition - down).distance >= 6.0) {
        final startScene = _camera.toScene(down);
        final dragId = _selected!.id;
        _beginObjectDrag(_selected!, startScene);
        _dragPointer = e.pointer;
        _pendingDragObject = null;
        _pendingDragPointer = null;
        _suppressNextTap = true;
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (!mounted || !_draggingObject || _selected?.id != dragId) return;
          setState(() {});
        });
      }
    }

    if (_draggingObject && _selected != null && (_dragPointer == null || _dragPointer == e.pointer)) {
      _dragPointer = e.pointer;
      final scene = _camera.toScene(e.localPosition);
      if (_pinchingDuringDrag) {
        final anchor = _dragVisualAnchor.value ?? _iso(_selected!.gx, _selected!.gy);
        _dragGrabOffset = scene - anchor;
        _pinchingDuringDrag = false;
      }
      final anchorPoint = scene - (_dragGrabOffset ?? Offset.zero);
      _dragVisualAnchor.value = anchorPoint;
      final g = _gridFromLocal(anchorPoint);
      if (_dragCell?.x != g.x || _dragCell?.y != g.y) {
        _dragCell = g;
        _dragCellNotifier.value = g;
      }
      return;
    }

    _applyCameraGesture(old, e.localPosition, panSpeed: 1.90);
  }

  void _rawPointerUp(PointerEvent e) {
    final down = _pointerDownPositions[e.pointer];
    final last = _pointerPositions[e.pointer] ?? e.localPosition;
    final moved = down == null ? 999.0 : (last - down).distance;

    if (_pendingDragPointer == e.pointer) {
      _pendingDragObject = null;
      _pendingDragPointer = null;
    }

    _activePointers.remove(e.pointer);
    _pointerPositions.remove(e.pointer);
    _pointerDownPositions.remove(e.pointer);

    if (_draggingPath && _pathDragPointer == e.pointer) {
      _finishPathDrag();
      _pathDragPointer = null;
      _multiTouchGesture = false;
      return;
    }

    if (_pendingPathDragPointer == e.pointer) {
      _pendingPathDragPointer = null;
    }

    if (_draggingObject && _selected != null) {
      if (_activePointers.isEmpty) {
        _finishObjectDrag();
        _dragPointer = null;
        _multiTouchGesture = false;
        return;
      }

      if (_activePointers.length == 1) {
        final remaining = _activePointers.first;
        _dragPointer = remaining;
        final pos = _pointerPositions[remaining];
        if (pos != null) {
          final scene = _camera.toScene(pos);
          final anchor = _dragVisualAnchor.value ?? _iso(_selected!.gx, _selected!.gy);
          _dragGrabOffset = scene - anchor;
        }
        _pinchingDuringDrag = false;
      }
      return;
    }

    if (_activePointers.isEmpty) {
      final wasMulti = _multiTouchGesture;
      _multiTouchGesture = false;
      if (!wasMulti && moved < 10) {
        _tapWorldAt(_camera.toScene(e.localPosition));
      }
      Future<void>.delayed(const Duration(milliseconds: 60), () => _suppressNextTap = false);
    }
  }

  Future<void> _finishObjectDrag() async {
    if (!_draggingObject || _selected == null) return;
    final selected = _selected!;
    final target = _dragCell ?? math.Point(selected.gx, selected.gy);

    if (_placementGhost != null && identical(selected, _placementGhost)) {
      final canPlaceGhost = _canPlace(selected, target.x, target.y);
      setState(() {
        _draggingObject = false;
        _dragPointer = null;
        _dragGrabOffset = null;
        if (canPlaceGhost) {
          selected.gx = target.x;
          selected.gy = target.y;
          _dragCell = target;
          _toast = '半透明の位置でよければ「置く」を押してください';
        } else {
          _dragCell = math.Point(selected.gx, selected.gy);
          _toast = 'そこには置けません。別の場所へ移動してください';
        }
      });
      _dragVisualAnchor.value = _iso(selected.gx, selected.gy);
      _dragCellNotifier.value = _dragCell;
      Future<void>.delayed(const Duration(milliseconds: 80), () {
        _suppressNextTap = false;
      });
      return;
    }

    final canPlace = _canPlace(selected, target.x, target.y, ignore: selected);

    setState(() {
      _draggingObject = false;
      _dragPointer = null;
      _dragGrabOffset = null;
      _pinchingDuringDrag = false;

      if (canPlace) {
        // Move is only provisional here. The object stays selected until the
        // player taps empty ground, which is the actual placement confirm.
        selected.gx = target.x;
        selected.gy = target.y;
        _dragCell = math.Point(selected.gx, selected.gy);
        _tool = CampTool.move;
        _toast = '編集中  •  ドラッグで移動・タップで向き変更・他をタップで設置完了';
      } else {
        _dragCell = math.Point(selected.gx, selected.gy);
        _tool = CampTool.move;
        _toast = 'そこには置けません。別の場所へ移動してください';
      }
    });

    _dragVisualAnchor.value = null;
    _dragCellNotifier.value = _dragCell;
    _activeDragObjectId.value = null;

    Future<void>.delayed(const Duration(milliseconds: 120), () {
      _suppressNextTap = false;
    });
  }

  void _showToast(String text) {
    if (mounted) setState(() => _toast = text);
  }

  Future<void> _expand() async {
    if (expansion >= 3) {
      _showToast('現在の最大エリアまで開拓済みです');
      return;
    }
    final cost = expansionCost;
    if (wood < cost) {
      _showToast('開拓には木材 $cost が必要です');
      return;
    }
    setState(() {
      wood -= cost;
      expansion++;
      _toast = '新しいエリアを開拓しました！';
    });
    await _save();
  }

  void _rotateSelected() {
    if (_selected == null) return;
    final o = _selected!;
    _rememberEditOrigin(o);
    final old = o.rotation;
    o.rotation = o.rotation.isEven ? 1 : 0; // east <-> west only
    if (!_canPlace(o, o.gx, o.gy, ignore: o)) {
      o.rotation = old;
      _showToast('この向きでは周囲のオブジェクトと重なります');
      return;
    }
    setState(() {
      _dragCell = math.Point(o.gx, o.gy);
      _toast = '向きを変更しました  •  ドラッグで移動・他をタップで設置完了';
    });
    _dragCellNotifier.value = _dragCell;
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) return const ColoredBox(color: Color(0xFF173A2A));
    final sorted = [..._objects]..sort((a, b) => (a.gx + a.gy).compareTo(b.gx + b.gy));
    final editing = _tool != CampTool.view;
    return Stack(
      children: [
        Positioned.fill(
          child: Listener(
            behavior: HitTestBehavior.opaque,
            onPointerDown: _rawPointerDown,
            onPointerMove: _rawPointerMove,
            onPointerUp: _rawPointerUp,
            onPointerCancel: _rawPointerUp,
            child: InteractiveViewer(
                transformationController: _camera,
                minScale: .10,
                maxScale: 3.2,
                boundaryMargin: const EdgeInsets.all(900),
                constrained: false,
                panEnabled: false,
                scaleEnabled: false,
                child: SizedBox(
                width: worldW,
                height: worldH,
                child: Stack(
                  clipBehavior: Clip.none,
                  children: [
                    Positioned.fill(
                      child: CustomPaint(
                        painter: _CampGroundPainter(
                          gridSize: gridSize,
                          tileW: tileW,
                          tileH: tileH,
                          origin: origin,
                          unlockedMin: unlockedMin,
                          unlockedMax: unlockedMax,
                          showGrid: editing,
                          pathTiles: Map<String, String>.from(_pathTiles),
                          movingCell: null,
                        ),
                      ),
                    ),
                    ValueListenableBuilder<math.Point<int>?>(
                      valueListenable: _dragCellNotifier,
                      builder: (context, cell, _) {
                        if (cell == null) return const SizedBox.shrink();
                        final isPathEdit = _selectedPathKey != null;
                        if (_selected == null && !isPathEdit) {
                          return const SizedBox.shrink();
                        }
                        return Positioned.fill(
                          child: IgnorePointer(
                            child: CustomPaint(
                              painter: _CampMoveHighlightPainter(
                                tileW: tileW,
                                tileH: tileH,
                                origin: origin,
                                cell: cell,
                                movingW: isPathEdit ? 1 : _selected!.w,
                                movingH: isPathEdit ? 1 : _selected!.h,
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                    for (final o in sorted) _buildObject(o),
                    if (_placementGhost != null)
                      ValueListenableBuilder<Offset?>(
                        valueListenable: _dragVisualAnchor,
                        builder: (context, anchor, _) => _positionedObject(
                          _placementGhost!,
                          selected: true,
                          anchorOverride: _draggingObject ? anchor : null,
                          opacity: .48,
                        ),
                      ),
                    // V16.37.5.3: a single drag overlay listens for drag
                    // movement. The previous design attached the drag-owner
                    // notifier to every object, waking ~300 builders on grab.
                    ValueListenableBuilder<int?>(
                      valueListenable: _activeDragObjectId,
                      builder: (context, dragId, _) {
                        if (dragId == null) return const SizedBox.shrink();
                        CampObject? active;
                        for (final candidate in _objects) {
                          if (candidate.id == dragId) {
                            active = candidate;
                            break;
                          }
                        }
                        if (active == null) return const SizedBox.shrink();
                        final dragged = active;
                        return ValueListenableBuilder<Offset?>(
                          valueListenable: _dragVisualAnchor,
                          builder: (context, anchor, _) => _positionedObject(
                            dragged,
                            selected: true,
                            anchorOverride: anchor,
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
        if (editing && _tool != CampTool.move)
          Positioned(
            left: _tool == CampTool.build ? (_buildPanelCollapsed ? 44 : 12) : 54,
            right: _tool == CampTool.build ? (_buildPanelCollapsed ? 44 : 12) : 54,
            bottom: _tool == CampTool.build ? 86 : 100,
            child: _EditorBar(
              tool: _tool,
              wood: wood,
              buildKind: _buildKind,
              buildCost: _buildCost(_buildKind),
              selected: _selected,
              kindIcon: _kindIcon,
              kindLabel: _kindLabel,
              costFor: _buildCost,
              buildTab: _buildTab,
              groundTileKind: _groundTileKind,
              inventory: _inventory,
              collapsed: _buildPanelCollapsed,
              onExpand: () => setState(() => _buildPanelCollapsed = false),
              onConfirmPlacement: _confirmPlacementPreview,
              onChooseBuild: _startPlacementPreview,
              onChooseTab: (tab) => setState(() {
                _buildTab = tab;
                _buildPanelCollapsed = false;
                if (tab != BuildPanelTab.object) {
                  _placementGhost = null;
                  _selected = null;
                  _dragCell = null;
                  _dragCellNotifier.value = null;
                  _dragVisualAnchor.value = null;
                }
              }),
              onChoosePath: (kind) => setState(() {
                _groundTileKind = kind;
                _buildTab = BuildPanelTab.path;
                _buildPanelCollapsed = true;
              }),
              onRotate: _rotateSelected,
              onCancel: _cancelSelectedEdit,
            ),
          ),
        if (_tool == CampTool.move &&
            (_selected != null || _selectedPathKey != null) &&
            _placementGhost == null)
          Positioned(
            left: 0,
            right: 0,
            bottom: 92,
            child: Center(
              child: GestureDetector(
                onTap: () {
                  if (_selectedPathKey != null) {
                    _recoverSelectedPath();
                  } else {
                    _recoverSelectedObject();
                  }
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 9),
                  decoration: BoxDecoration(
                    color: const Color(0xEE26342F),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: const Color(0xFFFFD775), width: 2),
                    boxShadow: const [
                      BoxShadow(color: Colors.black38, blurRadius: 5, offset: Offset(0, 3)),
                    ],
                  ),
                  child: Text(
                    _selectedPathKey != null
                        ? '↩  道タイルを戻す'
                        : '↩  ${_kindLabel(_selected!.kind)}を戻す',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
              ),
            ),
          ),
        Positioned(
          left: 0,
          right: 0,
          bottom: _tool == CampTool.build
              ? (_buildPanelCollapsed ? 150 : 205)
              : ((editing && _tool != CampTool.move) ? 112 : 120),
          child: Center(
            child: Container(
              constraints: const BoxConstraints(maxWidth: 430),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(color: const Color(0xDC182721), borderRadius: BorderRadius.circular(15), border: Border.all(color: const Color(0xFFFFDB76), width: 1.5)),
              child: Text(_toast, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800)),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildObject(CampObject o) {
    // Once the deferred full rebuild happens, hide the resting copy of the
    // dragged object. Pointer-move updates are handled only by the single
    // overlay above and never rebuild the full object collection.
    if (_draggingObject && identical(_selected, o)) {
      return const SizedBox.shrink();
    }
    return _positionedObject(o, selected: identical(_selected, o));
  }

  Widget _positionedObject(CampObject o, {required bool selected, Offset? anchorOverride, double opacity = 1.0}) {
    final visualSize = _objectVisualSize(o);
    final normalAnchor = _iso(o.gx, o.gy);
    final anchor = anchorOverride ?? normalAnchor;
    final normalTopLeft = _objectVisualTopLeft(o, o.gx, o.gy);
    // V16.37.5.3 DRAG_PAINT_ONLY: keep Positioned coordinates fixed while
    // dragging. Changing Positioned.left/top on every pointer event can force
    // the huge world Stack (hundreds of children) through layout repeatedly.
    // Transform.translate is paint-only, so the dragged object can follow the
    // finger without relaying out the entire camp.
    final dragPaintOffset = anchor - normalAnchor;
    final fontSize = switch (o.kind) {
      CampKind.cabin => 92.0,
      CampKind.tent => 68.0,
      CampKind.market => 72.0,
      CampKind.tree => 54.0,
      CampKind.rock => 42.0,
      CampKind.forest => 30.0,
      CampKind.rockField => 27.0,
      CampKind.stump => 36.0,
      CampKind.campfire => 42.0,
      CampKind.bench => 44.0,
      CampKind.hut => 66.0,
      CampKind.lantern => 38.0,
      CampKind.basket => 38.0,
      CampKind.bucket => 38.0,
      CampKind.toolbox => 40.0,
      CampKind.ladder => 44.0,
      CampKind.wheel => 40.0,
      CampKind.canoe => 54.0,
      CampKind.mushroom => 36.0,
      CampKind.pottedPlant => 38.0,
      CampKind.cactus => 40.0,
      CampKind.bicycle => 50.0,
      CampKind.flower => 30.0,
    };

    return Positioned(
      left: normalTopLeft.dx,
      top: normalTopLeft.dy,
      child: IgnorePointer(
        ignoring: true,
        child: Opacity(
          opacity: opacity,
          child: Transform.translate(
            offset: dragPaintOffset,
            child: RepaintBoundary(
            child: Transform.scale(
            scale: selected ? 1.06 : 1,
            child: SizedBox(
              width: visualSize.width,
              height: visualSize.height,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: Transform(
                      alignment: Alignment.center,
                      transform: Matrix4.diagonal3Values(o.rotation.isOdd ? -1.0 : 1.0, 1.0, 1.0),
                      child: Text(
                        _objectArt(o.kind),
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: fontSize,
                          height: o.kind == CampKind.forest || o.kind == CampKind.rockField ? .86 : 1,
                          shadows: const [Shadow(color: Colors.black45, offset: Offset(0, 4), blurRadius: 4)],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            ),
          ),
        ),
      ),
      ),
    );
  }

}

class _CampMoveHighlightPainter extends CustomPainter {
  final double tileW, tileH;
  final Offset origin;
  final math.Point<int> cell;
  final int movingW, movingH;
  const _CampMoveHighlightPainter({required this.tileW, required this.tileH, required this.origin, required this.cell, required this.movingW, required this.movingH});

  Offset _iso(int x, int y) => Offset(origin.dx + (x - y) * tileW / 2, origin.dy + (x + y) * tileH / 2);

  @override
  void paint(Canvas canvas, Size size) {
    final fill = Paint()..color = const Color(0x88FFD84A);
    final stroke = Paint()
      ..color = const Color(0xFFFFF09A)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;
    for (var x = cell.x; x < cell.x + movingW; x++) {
      for (var y = cell.y; y < cell.y + movingH; y++) {
        final c = _iso(x, y);
        final path = Path()
          ..moveTo(c.dx, c.dy - tileH / 2)
          ..lineTo(c.dx + tileW / 2, c.dy)
          ..lineTo(c.dx, c.dy + tileH / 2)
          ..lineTo(c.dx - tileW / 2, c.dy)
          ..close();
        canvas.drawPath(path, fill);
        canvas.drawPath(path, stroke);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _CampMoveHighlightPainter oldDelegate) => oldDelegate.cell != cell || oldDelegate.movingW != movingW || oldDelegate.movingH != movingH;
}

class _CampGroundPainter extends CustomPainter {
  final int gridSize;
  final double tileW, tileH;
  final Offset origin;
  final int unlockedMin, unlockedMax;
  final bool showGrid;
  final Map<String, String> pathTiles;
  final math.Point<int>? movingCell;
  final int movingW, movingH;
  const _CampGroundPainter({
    required this.gridSize,
    required this.tileW,
    required this.tileH,
    required this.origin,
    required this.unlockedMin,
    required this.unlockedMax,
    required this.showGrid,
    required this.pathTiles,
    this.movingCell,
    this.movingW = 1,
    this.movingH = 1,
  });

  Offset _iso(int x, int y) => Offset(origin.dx + (x - y) * tileW / 2, origin.dy + (x + y) * tileH / 2);

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Offset.zero & size, Paint()..color = const Color(0xFF163C2B));

    final grassA = Paint()..color = const Color(0xFF4F9653);
    final grassB = Paint()..color = const Color(0xFF579F58);
    final locked = Paint()..color = const Color(0xC41A3329);
    final grid = Paint()
      ..color = const Color(0x7AFFF49A)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2;

    for (var x = 0; x < gridSize; x++) {
      for (var y = 0; y < gridSize; y++) {
        final c = _iso(x, y);
        final path = Path()
          ..moveTo(c.dx, c.dy - tileH / 2)
          ..lineTo(c.dx + tileW / 2, c.dy)
          ..lineTo(c.dx, c.dy + tileH / 2)
          ..lineTo(c.dx - tileW / 2, c.dy)
          ..close();
        canvas.drawPath(path, (x + y).isEven ? grassA : grassB);
        final unlocked = x >= unlockedMin && x <= unlockedMax && y >= unlockedMin && y <= unlockedMax;
        if (!unlocked) canvas.drawPath(path, locked);
        if (showGrid && unlocked) canvas.drawPath(path, grid);
      }
    }

    // V16.37.5.6: central clearing must be derived from the CURRENT grid.
    // The half-map test accidentally kept the old 76x76 coordinates (28..48
    // around 38), so the clearing was painted beyond the new 38x38 diamond.
    final clearingFill = Paint()..color = const Color(0xFF78AA5B);
    final clearingEdge = Paint()
      ..color = const Color(0x66543A22)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4;
    final center = (gridSize - 1) / 2;
    final radius = math.max(4.0, gridSize * .18);
    final minCell = math.max(0, (center - radius).floor());
    final maxCell = math.min(gridSize - 1, (center + radius).ceil());
    for (var x = minCell; x <= maxCell; x++) {
      for (var y = minCell; y <= maxCell; y++) {
        final dx = x - center;
        final dy = y - center;
        if (dx * dx + dy * dy > radius * radius) continue;
        final c = _iso(x, y);
        final path = Path()
          ..moveTo(c.dx, c.dy - tileH / 2)
          ..lineTo(c.dx + tileW / 2, c.dy)
          ..lineTo(c.dx, c.dy + tileH / 2)
          ..lineTo(c.dx - tileW / 2, c.dy)
          ..close();
        canvas.drawPath(path, clearingFill);
        if (showGrid) canvas.drawPath(path, clearingEdge);
      }
    }

    // BUILD_INVENTORY_PATH_SYSTEM: roads are a ground overlay, so objects can
    // be placed on top without consuming an object slot.
    for (final entry in pathTiles.entries) {
      final parts = entry.key.split(',');
      if (parts.length != 2) continue;
      final x = int.tryParse(parts[0]);
      final y = int.tryParse(parts[1]);
      if (x == null || y == null || x < 0 || y < 0 || x >= gridSize || y >= gridSize) continue;
      final c = _iso(x, y);
      final path = Path()
        ..moveTo(c.dx, c.dy - tileH / 2)
        ..lineTo(c.dx + tileW / 2, c.dy)
        ..lineTo(c.dx, c.dy + tileH / 2)
        ..lineTo(c.dx - tileW / 2, c.dy)
        ..close();
      final isStone = entry.value == GroundTileKind.stone.name;
      final fill = Paint()..color = isStone ? const Color(0xFF9C9C91) : const Color(0xFFB58A58);
      final edge = Paint()
        ..color = isStone ? const Color(0xAA67675F) : const Color(0xAA7B5736)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.3;
      canvas.drawPath(path, fill);
      canvas.drawPath(path, edge);
    }

    if (movingCell != null) {
      final movingFill = Paint()..color = const Color(0x88FFD84A);
      final movingStroke = Paint()
        ..color = const Color(0xFFFFF09A)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3;
      for (var x = movingCell!.x; x < movingCell!.x + movingW; x++) {
        for (var y = movingCell!.y; y < movingCell!.y + movingH; y++) {
          if (x < 0 || y < 0 || x >= gridSize || y >= gridSize) continue;
          final c = _iso(x, y);
          final path = Path()
            ..moveTo(c.dx, c.dy - tileH / 2)
            ..lineTo(c.dx + tileW / 2, c.dy)
            ..lineTo(c.dx, c.dy + tileH / 2)
            ..lineTo(c.dx - tileW / 2, c.dy)
            ..close();
          canvas.drawPath(path, movingFill);
          canvas.drawPath(path, movingStroke);
        }
      }
    }


  }

  @override
  bool shouldRepaint(covariant _CampGroundPainter oldDelegate) => oldDelegate.showGrid != showGrid || oldDelegate.unlockedMin != unlockedMin || oldDelegate.unlockedMax != unlockedMax || oldDelegate.pathTiles != pathTiles || oldDelegate.movingCell != movingCell || oldDelegate.movingW != movingW || oldDelegate.movingH != movingH;
}

class _EditorBar extends StatelessWidget {
  final CampTool tool;
  final int wood;
  final CampKind buildKind;
  final int buildCost;
  final CampObject? selected;
  final String Function(CampKind) kindIcon;
  final String Function(CampKind) kindLabel;
  final int Function(CampKind) costFor;
  final BuildPanelTab buildTab;
  final GroundTileKind groundTileKind;
  final Map<String, int> inventory;
  final bool collapsed;
  final VoidCallback onExpand;
  final VoidCallback onConfirmPlacement;
  final ValueChanged<CampKind> onChooseBuild;
  final ValueChanged<BuildPanelTab> onChooseTab;
  final ValueChanged<GroundTileKind> onChoosePath;
  final VoidCallback onRotate;
  final VoidCallback onCancel;

  const _EditorBar({
    required this.tool,
    required this.wood,
    required this.buildKind,
    required this.buildCost,
    required this.selected,
    required this.kindIcon,
    required this.kindLabel,
    required this.costFor,
    required this.buildTab,
    required this.groundTileKind,
    required this.inventory,
    required this.collapsed,
    required this.onExpand,
    required this.onConfirmPlacement,
    required this.onChooseBuild,
    required this.onChooseTab,
    required this.onChoosePath,
    required this.onRotate,
    required this.onCancel,
  });

  @override
  Widget build(BuildContext context) {
    final builds = const [
      CampKind.campfire,
      CampKind.tent,
      CampKind.bench,
      CampKind.hut,
      CampKind.lantern,
      CampKind.basket,
      CampKind.bucket,
      CampKind.toolbox,
      CampKind.ladder,
      CampKind.wheel,
      CampKind.canoe,
      CampKind.mushroom,
      CampKind.pottedPlant,
      CampKind.cactus,
      CampKind.bicycle,
      CampKind.stump,
    ];
    final availableBuilds = builds
        .where((kind) => (inventory[kind.name] ?? 0) > 0)
        .toList(growable: false);

    if (tool != CampTool.build) {
      return Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: const Color(0xF1222926),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: const Color(0xFFFFD775), width: 2),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              tool == CampTool.clear
                  ? '🪓 森林をタップして開拓  🪵$wood'
                  : selected == null
                      ? '✥ 編集する施設をタップ'
                      : '${kindIcon(selected!.kind)} ${kindLabel(selected!.kind)}を編集中',
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900),
            ),
            const SizedBox(width: 12),
            _EditorButton(icon: '✕', label: '閉じる', onTap: onCancel),
          ],
        ),
      );
    }

    Widget tabButton(String icon, String label, BuildPanelTab tab) {
      final active = buildTab == tab;
      return Expanded(
        child: GestureDetector(
          onTap: () => onChooseTab(tab),
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 4),
            decoration: BoxDecoration(
              color: active ? const Color(0xFFFFD45E) : const Color(0xFF34413D),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: active ? Colors.white : Colors.white24),
            ),
            child: Text(
              '$icon $label',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: active ? const Color(0xFF352613) : Colors.white,
                fontSize: 10,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ),
      );
    }

    if (collapsed) {
      final String icon;
      final String title;
      final int count;
      if (buildTab == BuildPanelTab.path) {
        icon = groundTileKind == GroundTileKind.dirt ? '🟫' : '⬜';
        title = groundTileKind == GroundTileKind.dirt ? '土の道を配置中' : '石畳を配置中';
        count = inventory['path:${groundTileKind.name}'] ?? 0;
      } else {
        icon = kindIcon(buildKind);
        title = '${kindLabel(buildKind)}を配置中';
        count = inventory[buildKind.name] ?? 0;
      }
      return Container(
        height: 54,
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
        decoration: BoxDecoration(
          color: const Color(0xF1222926),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFFFFD775), width: 2),
        ),
        child: Row(
          children: [
            Text(icon, style: const TextStyle(fontSize: 23)),
            const SizedBox(width: 7),
            Expanded(
              child: Text(
                buildTab == BuildPanelTab.recover ? title : '$title  ×$count',
                style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w900),
              ),
            ),
            if (buildTab == BuildPanelTab.object) ...[
              _EditorButton(icon: '✓', label: '置く', onTap: onConfirmPlacement),
              const SizedBox(width: 4),
            ],
            _EditorButton(icon: '☰', label: '一覧', onTap: onExpand),
            const SizedBox(width: 4),
            _EditorButton(icon: '✕', label: '終了', onTap: onCancel),
          ],
        ),
      );
    }

    return Container(
      height: 108,
      padding: const EdgeInsets.fromLTRB(7, 6, 7, 5),
      decoration: BoxDecoration(
        color: const Color(0xF1222926),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFFFD775), width: 2),
        boxShadow: const [BoxShadow(color: Colors.black45, blurRadius: 10, offset: Offset(0, 5))],
      ),
      child: Column(
        children: [
          Row(
            children: [
              tabButton('🛤️', '道', BuildPanelTab.path),
              const SizedBox(width: 6),
              tabButton('⛺', 'オブジェクト', BuildPanelTab.object),

              const SizedBox(width: 6),
              SizedBox(width: 52, child: _EditorButton(icon: '✕', label: '閉じる', onTap: onCancel)),
            ],
          ),
          const SizedBox(height: 4),
          Expanded(
            child: buildTab == BuildPanelTab.path
                ? ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      _EditorButton(
                        icon: '🟫',
                        label: '土の道\n×${inventory['path:dirt'] ?? 0}',
                        active: groundTileKind == GroundTileKind.dirt,
                        onTap: () => onChoosePath(GroundTileKind.dirt),
                      ),
                      const SizedBox(width: 7),
                      _EditorButton(
                        icon: '⬜',
                        label: '石畳\n×${inventory['path:stone'] ?? 0}',
                        active: groundTileKind == GroundTileKind.stone,
                        onTap: () => onChoosePath(GroundTileKind.stone),
                      ),
                    ],
                  )
                : availableBuilds.isEmpty
                    ? const Center(
                        child: Text(
                          '配置できるオブジェクトはありません',
                          style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w800),
                        ),
                      )
                    : ListView.separated(
                        scrollDirection: Axis.horizontal,
                        itemCount: availableBuilds.length,
                        separatorBuilder: (_, __) => const SizedBox(width: 6),
                        itemBuilder: (context, i) {
                          final k = availableBuilds[i];
                          return _EditorButton(
                            icon: kindIcon(k),
                            label: '${kindLabel(k)}\n×${inventory[k.name] ?? 0}',
                            active: k == buildKind,
                            onTap: () => onChooseBuild(k),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}

class _EditorButton extends StatelessWidget {
  final String icon, label;
  final bool active;
  final VoidCallback onTap;
  const _EditorButton({required this.icon, required this.label, required this.onTap, this.active = false});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          constraints: const BoxConstraints(minWidth: 58),
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
          decoration: BoxDecoration(color: active ? const Color(0xFF5C9D38) : const Color(0xFF35423D), borderRadius: BorderRadius.circular(11), border: Border.all(color: active ? const Color(0xFFFFE46F) : Colors.white54, width: 1.5)),
          child: Column(mainAxisSize: MainAxisSize.min, mainAxisAlignment: MainAxisAlignment.center, children: [Text(icon, style: const TextStyle(fontSize: 21)), Text(label, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 9, height: 1.05, fontWeight: FontWeight.w800))]),
        ),
      );
}

class _WoodLogo extends StatelessWidget {
  const _WoodLogo();
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.fromLTRB(10, 6, 10, 7),
        decoration: BoxDecoration(color: const Color(0xFF6D431E), borderRadius: BorderRadius.circular(15), border: Border.all(color: const Color(0xFFDFA957), width: 2.5), boxShadow: const [BoxShadow(color: Colors.black38, offset: Offset(0, 3), blurRadius: 3)]),
        child: const Column(mainAxisSize: MainAxisSize.min, children: [Text('SURUSURU', style: TextStyle(color: Color(0xFFFFC83E), fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: .4)), Text('CAMP', style: TextStyle(color: Color(0xFFFFE1A1), fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 2))]),
      );
}

class _ResourceChip extends StatelessWidget {
  final String icon;
  final String? text;
  final String Function()? textBuilder;
  const _ResourceChip({required this.icon, this.text, this.textBuilder});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 7),
        decoration: BoxDecoration(color: const Color(0xE8232D32), borderRadius: BorderRadius.circular(13), border: Border.all(color: const Color(0xFFFFE099), width: 1.8), boxShadow: const [BoxShadow(color: Colors.black38, offset: Offset(0, 3), blurRadius: 2)]),
        child: Row(children: [Text(icon), const SizedBox(width: 3), Text(text ?? textBuilder?.call() ?? '', style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w900))]),
      );
}

class _SquareGameButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _SquareGameButton({required this.icon, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(width: 42, height: 42, decoration: BoxDecoration(color: const Color(0xE8273A44), borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFFFFE099), width: 2), boxShadow: const [BoxShadow(color: Colors.black45, offset: Offset(0, 3), blurRadius: 2)]), child: Icon(icon, color: Colors.white)),
      );
}

class _BottomGameNav extends StatelessWidget {
  final bool placementActive;
  final VoidCallback onAdventure;
  final VoidCallback onShop;
  final VoidCallback onPlacement;
  final VoidCallback onSurusuru;
  final VoidCallback onMap;

  const _BottomGameNav({
    required this.placementActive,
    required this.onAdventure,
    required this.onShop,
    required this.onPlacement,
    required this.onSurusuru,
    required this.onMap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 70,
      padding: const EdgeInsets.fromLTRB(5, 5, 5, 4),
      decoration: BoxDecoration(
        color: const Color(0xF122292F),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFFFD775), width: 2),
        boxShadow: const [
          BoxShadow(color: Colors.black45, blurRadius: 8, offset: Offset(0, 4)),
        ],
      ),
      child: Row(
        children: [
          Expanded(child: _BottomNavItem(icon: '⚔️', label: '冒険', onTap: onAdventure)),
          Expanded(child: _BottomNavItem(icon: '🛒', label: 'SHOP', onTap: onShop)),
          Expanded(
            child: _BottomNavItem(
              icon: '✨',
              label: '配置',
              active: placementActive,
              emphasized: true,
              onTap: onPlacement,
            ),
          ),
          Expanded(child: _BottomNavItem(icon: '✦', label: 'スルスル', onTap: onSurusuru)),
          Expanded(child: _BottomNavItem(icon: '🗺️', label: 'マップ', active: !placementActive, onTap: onMap)),
        ],
      ),
    );
  }
}

class _BottomNavItem extends StatelessWidget {
  final String icon;
  final String label;
  final bool active;
  final bool emphasized;
  final VoidCallback onTap;

  const _BottomNavItem({
    required this.icon,
    required this.label,
    required this.onTap,
    this.active = false,
    this.emphasized = false,
  });

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.opaque,
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 2),
          padding: EdgeInsets.symmetric(vertical: emphasized ? 5 : 7),
          decoration: BoxDecoration(
            color: active
                ? const Color(0xFFE9B93E)
                : emphasized
                    ? const Color(0xFF43504C)
                    : const Color(0xFF303D43),
            borderRadius: BorderRadius.circular(emphasized ? 15 : 12),
            border: Border.all(
              color: emphasized ? const Color(0xFFFFE49A) : Colors.white24,
              width: emphasized ? 2 : 1,
            ),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(icon, style: TextStyle(fontSize: emphasized ? 23 : 20)),
              const SizedBox(height: 1),
              Text(
                label,
                maxLines: 1,
                style: TextStyle(
                  color: active ? const Color(0xFF3D2B14) : Colors.white,
                  fontSize: 9,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ),
      );
}

class _SideButton extends StatelessWidget {
  final String icon, label;
  final String? badge;
  final bool active, glow;
  final VoidCallback onTap;
  const _SideButton({required this.icon, required this.label, required this.onTap, this.badge, this.active = false, this.glow = false});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          width: 58,
          padding: const EdgeInsets.symmetric(vertical: 7),
          decoration: BoxDecoration(color: active ? const Color(0xE85D9837) : const Color(0xE9213037), borderRadius: BorderRadius.circular(14), border: Border.all(color: glow ? const Color(0xFFFFD132) : const Color(0xFFFFE29B), width: 2), boxShadow: [BoxShadow(color: glow ? const Color(0x88FFD132) : Colors.black38, blurRadius: glow ? 12 : 3, offset: const Offset(0, 3))]),
          child: Column(mainAxisSize: MainAxisSize.min, children: [Text(icon, style: const TextStyle(fontSize: 24)), Text(label, style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w900)), if (badge != null) Text(badge!, style: const TextStyle(color: Color(0xFFFFD95D), fontSize: 8, fontWeight: FontWeight.w900))]),
        ),
      );
}

class _AdventureButton extends StatelessWidget {
  final VoidCallback onTap;
  const _AdventureButton({required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          height: 58,
          decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFFFFD541), Color(0xFFF4A521)]), borderRadius: BorderRadius.circular(19), border: Border.all(color: const Color(0xFFFFF1B1), width: 3), boxShadow: const [BoxShadow(color: Color(0x99000000), offset: Offset(0, 5), blurRadius: 5)]),
          child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [Text('🧭', style: TextStyle(fontSize: 25)), SizedBox(width: 8), Text('冒険に出発！', style: TextStyle(color: Color(0xFF4A2C13), fontSize: 19, fontWeight: FontWeight.w900))]),
        ),
      );
}
