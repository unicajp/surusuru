import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../game/game_controller.dart';

class ConnectBattleScreen extends StatefulWidget {
  final GameController controller;
  final int stageId;

  const ConnectBattleScreen({
    super.key,
    required this.controller,
    required this.stageId,
  });

  @override
  State<ConnectBattleScreen> createState() => _ConnectBattleScreenState();
}

class _DummyEnemy {
  _DummyEnemy(this.pos, this.phase);
  Offset pos;
  final double phase;
}

class _ConnectBattleScreenState extends State<ConnectBattleScreen> {
  Timer? _timer;
  DateTime _last = DateTime.now();
  Size _field = Size.zero;

  Offset _hero = const Offset(190, 360);
  Offset _velocity = Offset.zero;
  Offset _target = const Offset(190, 360);
  bool _holding = false;
  double _time = 0;
  double _tilt = 0;
  final List<Offset> _trail = <Offset>[];
  final List<_DummyEnemy> _enemies = <_DummyEnemy>[];

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(milliseconds: 16), (_) => _tick());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _seed(Size size) {
    if (_field != Size.zero) return;
    _field = size;
    _hero = Offset(size.width * .5, size.height * .72);
    _target = _hero;
    _enemies.addAll(<_DummyEnemy>[
      _DummyEnemy(Offset(size.width * .22, size.height * .28), .2),
      _DummyEnemy(Offset(size.width * .50, size.height * .20), 1.5),
      _DummyEnemy(Offset(size.width * .78, size.height * .31), 2.8),
    ]);
  }

  void _tick() {
    if (!mounted || _field == Size.zero) return;
    final now = DateTime.now();
    double dt = now.difference(_last).inMicroseconds / 1000000;
    _last = now;
    dt = dt.clamp(0.0, .035);
    _time += dt;

    // Spring-like follow: the finger is a target, not the character position.
    final Offset delta = _target - _hero;
    final double spring = _holding ? 28.0 : 12.0;
    final double damping = _holding ? 8.2 : 6.8;
    _velocity += delta * spring * dt;
    _velocity *= math.exp(-damping * dt);

    // Keep enough inertia to overshoot on sudden stops, but cap extreme speed.
    final double speed = _velocity.distance;
    if (speed > 1050) _velocity = _velocity / speed * 1050;
    _hero += _velocity * dt;
    _hero = Offset(
      _hero.dx.clamp(38.0, _field.width - 38.0),
      _hero.dy.clamp(54.0, _field.height - 48.0),
    );

    final double wantedTilt = (_velocity.dx / 520).clamp(-.34, .34);
    _tilt += (wantedTilt - _tilt) * math.min(1, dt * 10);

    if (_velocity.distance > 90) {
      _trail.insert(0, _hero);
      if (_trail.length > 8) _trail.removeLast();
    } else if (_trail.isNotEmpty && (_time * 30).floor().isEven) {
      _trail.removeLast();
    }
    setState(() {});
  }

  void _down(Offset p) {
    setState(() {
      _holding = true;
      _target = p;
    });
  }

  void _move(Offset p) {
    _holding = true;
    _target = p;
  }

  void _up() {
    // On release, stop pulling. The target becomes the current position so
    // residual velocity produces a tiny natural overshoot before settling.
    _holding = false;
    _target = _hero;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF122433),
      body: SafeArea(
        child: Column(
          children: <Widget>[
            SizedBox(
              height: 64,
              child: Row(
                children: <Widget>[
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    '冒険  STAGE ${widget.stageId}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const Spacer(),
                  const Padding(
                    padding: EdgeInsets.only(right: 18),
                    child: Text(
                      '操作テスト',
                      style: TextStyle(
                        color: Color(0xFFFFD978),
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: LayoutBuilder(
                builder: (context, c) {
                  final size = Size(c.maxWidth, c.maxHeight);
                  _seed(size);
                  return Listener(
                    behavior: HitTestBehavior.opaque,
                    onPointerDown: (e) => _down(e.localPosition),
                    onPointerMove: (e) => _move(e.localPosition),
                    onPointerUp: (_) => _up(),
                    onPointerCancel: (_) => _up(),
                    child: CustomPaint(
                      size: Size.infinite,
                      painter: _BattlePrototypePainter(
                        hero: _hero,
                        velocity: _velocity,
                        tilt: _tilt,
                        time: _time,
                        holding: _holding,
                        target: _target,
                        trail: _trail,
                        enemies: _enemies,
                      ),
                    ),
                  );
                },
              ),
            ),
            Container(
              height: 58,
              alignment: Alignment.center,
              color: const Color(0xFF0D1C28),
              child: const Text(
                '指で動かして、剣士の重さと追従感を確認',
                style: TextStyle(
                  color: Colors.white70,
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BattlePrototypePainter extends CustomPainter {
  const _BattlePrototypePainter({
    required this.hero,
    required this.velocity,
    required this.tilt,
    required this.time,
    required this.holding,
    required this.target,
    required this.trail,
    required this.enemies,
  });

  final Offset hero;
  final Offset velocity;
  final double tilt;
  final double time;
  final bool holding;
  final Offset target;
  final List<Offset> trail;
  final List<_DummyEnemy> enemies;

  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()..color = const Color(0xFF173B3B);
    canvas.drawRect(Offset.zero & size, bg);

    // Subtle battlefield rings keep depth without looking like a puzzle board.
    final ring = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..color = Colors.white.withValues(alpha: .045);
    for (double r = 90; r < size.width * .85; r += 82) {
      canvas.drawCircle(Offset(size.width / 2, size.height * .48), r, ring);
    }

    for (final e in enemies) {
      _drawMonster(canvas, e.pos + Offset(0, math.sin(time * 2 + e.phase) * 3));
    }

    final speed = velocity.distance;
    if (speed > 220) {
      for (var i = trail.length - 1; i >= 0; i--) {
        final alpha = (1 - i / math.max(1, trail.length)) * .10;
        _drawHero(canvas, trail[i], tilt, time, alpha: alpha, ghost: true);
      }
    }

    if (holding) {
      canvas.drawCircle(
        target,
        16,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..color = Colors.white.withValues(alpha: .16),
      );
    }

    _drawHero(canvas, hero, tilt, time, alpha: 1);
  }

  void _drawHero(
    Canvas canvas,
    Offset p,
    double lean,
    double t, {
    required double alpha,
    bool ghost = false,
  }) {
    canvas.save();
    final speed = velocity.distance;
    final bob = ghost ? 0.0 : math.sin(t * 9) * math.min(2.4, speed / 220);
    final double facing = (velocity.dx / 320).clamp(-1.0, 1.0).toDouble();
    final stride = ghost ? 0.0 : math.sin(t * (7.5 + math.min(5.0, speed / 120))) * math.min(3.2, speed / 150);

    canvas.translate(p.dx, p.dy + bob);
    canvas.rotate(lean);

    Color c(Color color) => color.withValues(alpha: alpha);
    final shadow = Paint()..color = Colors.black.withValues(alpha: alpha * .20);
    canvas.drawOval(const Rect.fromLTWH(-23, 29, 46, 13), shadow);

    // Scarf trails behind the movement. Keeping it on the back helps the
    // character read as a rear-view fighter instead of facing the player.
    final scarf = Path()
      ..moveTo(-7 - facing * 2, -14)
      ..quadraticBezierTo(
        -25 - velocity.dx * .010,
        -8 - velocity.dy * .004,
        -31 - velocity.dx * .017,
        5 - velocity.dy * .006,
      )
      ..quadraticBezierTo(-18, 3, -6, 0)
      ..close();
    canvas.drawPath(scarf, Paint()..color = c(const Color(0xFFD84B55)));

    // Legs. A tiny alternating stride makes low-speed motion feel alive.
    final dark = Paint()..color = c(const Color(0xFF273344));
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(-13, 17 + stride, 10, 19), const Radius.circular(4)),
      dark,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(3, 17 - stride, 10, 19), const Radius.circular(4)),
      dark,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(-17, 30 + stride, 15, 8), const Radius.circular(4)),
      Paint()..color = c(const Color(0xFF5A3C31)),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(2, 30 - stride, 15, 8), const Radius.circular(4)),
      Paint()..color = c(const Color(0xFF5A3C31)),
    );

    // Back of the torso. The center plate and shoulder offset make left/right
    // movement read as a slight turn while the default remains a rear view.
    canvas.save();
    canvas.translate(facing * 2.2, 0);
    canvas.drawRRect(
      RRect.fromRectAndRadius(const Rect.fromLTWH(-18, -7, 36, 31), const Radius.circular(9)),
      Paint()..color = c(const Color(0xFF3E6FA7)),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(const Rect.fromLTWH(-14, -3, 28, 13), const Radius.circular(5)),
      Paint()..color = c(const Color(0xFF9EB3C6)),
    );
    // Back seam / small armor plate. No face-side chest details.
    canvas.drawRRect(
      RRect.fromRectAndRadius(const Rect.fromLTWH(-5, -1, 10, 15), const Radius.circular(3)),
      Paint()..color = c(const Color(0xFF8099B0)),
    );
    canvas.drawRect(const Rect.fromLTWH(-18, 10, 36, 6), Paint()..color = c(const Color(0xFF6C432B)));
    canvas.restore();

    // Arms: the arm on the direction of travel comes a little forward, giving
    // a subtle three-quarter rear view without turning the character around.
    final nearArmX = facing >= 0 ? 14.0 : -24.0;
    final farArmX = facing >= 0 ? -24.0 : 14.0;
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(farArmX, -1, 10, 22), const Radius.circular(5)),
      Paint()..color = c(const Color(0xFF315F91)),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(nearArmX, -3, 10, 24), const Radius.circular(5)),
      Paint()..color = c(const Color(0xFF4A7DB2)),
    );

    // Sword stays generally pointed to the upper-right. It reacts to speed and
    // travel direction, but is deliberately clamped so it never flips around.
    final swingWave = ghost ? 0.0 : math.sin(t * 10.5) * math.min(.12, speed / 6000);
    final motionSwing = (velocity.dy / 1500).clamp(-.12, .12) - facing * .06;
    final double swordAngle = (-.55 + swingWave + motionSwing).clamp(-.82, -.30).toDouble();
    canvas.save();
    canvas.translate(20 + facing * 2.5, 7);
    canvas.rotate(swordAngle);
    final blade = Path()
      ..moveTo(-3, 3)
      ..lineTo(3, 3)
      ..lineTo(4, -43)
      ..lineTo(0, -53)
      ..lineTo(-4, -43)
      ..close();
    canvas.drawPath(blade, Paint()..color = c(const Color(0xFFE9F2F7)));
    canvas.drawPath(
      blade,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5
        ..color = c(const Color(0xFF7895A8)),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(const Rect.fromLTWH(-11, 1, 22, 5), const Radius.circular(2)),
      Paint()..color = c(const Color(0xFFFFC64B)),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(const Rect.fromLTWH(-3, 5, 6, 14), const Radius.circular(2)),
      Paint()..color = c(const Color(0xFF70442F)),
    );
    canvas.restore();

    // Rear-view head. Hair covers the face. When moving sideways, a tiny ear /
    // cheek edge appears on that side to suggest the fighter looking that way.
    canvas.save();
    canvas.translate(facing * 2.8, 0);
    canvas.drawCircle(const Offset(0, -25), 18, Paint()..color = c(const Color(0xFFFFD2A5)));
    final hairBack = Path()
      ..moveTo(-18, -27)
      ..quadraticBezierTo(-16, -46, 1, -47)
      ..quadraticBezierTo(18, -45, 19, -25)
      ..quadraticBezierTo(17, -13, 10, -10)
      ..lineTo(6, -18)
      ..lineTo(1, -12)
      ..lineTo(-4, -18)
      ..lineTo(-10, -11)
      ..quadraticBezierTo(-18, -16, -18, -27)
      ..close();
    canvas.drawPath(hairBack, Paint()..color = c(const Color(0xFF4A342D)));

    if (facing.abs() > .18) {
      final side = facing.sign;
      canvas.drawOval(
        Rect.fromCenter(center: Offset(side * 16.2, -24), width: 4.5, height: 7.0),
        Paint()..color = c(const Color(0xFFF2B98D)),
      );
      canvas.drawLine(
        Offset(side * 13.5, -21),
        Offset(side * 16.5, -20),
        Paint()
          ..strokeWidth = 1.2
          ..strokeCap = StrokeCap.round
          ..color = c(const Color(0xFF9A5D52)),
      );
    }
    canvas.restore();

    canvas.restore();
  }

  void _drawMonster(Canvas canvas, Offset p) {
    canvas.save();
    canvas.translate(p.dx, p.dy);
    canvas.drawOval(const Rect.fromLTWH(-22, 19, 44, 10), Paint()..color = Colors.black.withValues(alpha: .18));

    // Horned slime/beast hybrid: still simple, but no round puzzle-face sprite.
    final body = Path()
      ..moveTo(-24, 20)
      ..quadraticBezierTo(-27, -8, -13, -18)
      ..lineTo(-18, -31)
      ..lineTo(-4, -22)
      ..quadraticBezierTo(0, -25, 4, -22)
      ..lineTo(18, -31)
      ..lineTo(13, -17)
      ..quadraticBezierTo(28, -6, 24, 20)
      ..quadraticBezierTo(0, 31, -24, 20)
      ..close();
    canvas.drawPath(body, Paint()..color = const Color(0xFF7650A4));
    canvas.drawPath(body, Paint()..style = PaintingStyle.stroke..strokeWidth = 2..color = const Color(0xFF4C3473));
    canvas.drawCircle(const Offset(-8, -5), 3, Paint()..color = const Color(0xFFFFE65C));
    canvas.drawCircle(const Offset(8, -5), 3, Paint()..color = const Color(0xFFFFE65C));
    canvas.drawCircle(const Offset(-8, -5), 1.4, Paint()..color = const Color(0xFF241B31));
    canvas.drawCircle(const Offset(8, -5), 1.4, Paint()..color = const Color(0xFF241B31));
    canvas.drawLine(const Offset(-7, 8), const Offset(7, 8), Paint()..strokeWidth = 2..color = const Color(0xFF3A274E));
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _BattlePrototypePainter oldDelegate) => true;
}
