
import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../game/game_controller.dart';
import '../sfx_manager.dart';

/// V16.37.5.45 TRUE_HOLE_FINAL_STAGE
///
/// New visual/physics prototype:
/// - 3000 Surusuru for test play.
/// - Manual connect from the upper hub.
/// - Auto connect up to 30 in one hold.
/// - Smaller, staggered pachinko-style pin field.
/// - Three small branch bumpers near the top.
/// - Central special star bumper.
/// - Five bottom pockets with real separator collisions.
/// - Strong pocket/branch/star flashes and trails.
class SurusuruPlayScreen extends StatefulWidget {
  final GameController controller;

  const SurusuruPlayScreen({
    super.key,
    required this.controller,
  });

  @override
  State<SurusuruPlayScreen> createState() => _SurusuruPlayScreenState();
}

class _DropPiece {
  _DropPiece({
    required this.id,
    required this.type,
    required this.x,
    required this.y,
    required this.vx,
    required this.vy,
  });

  final int id;
  final int type;
  double x;
  double y;
  double vx;
  double vy;
  double angle = 0;
  double spin = 0;
  bool scored = false;
  bool branchTriggered = false;
  int branchCooldown = 0;
  bool starTriggered = false;
  int slowCenterFrames = 0;
  final Set<int> hitUPockets = <int>{};
  final List<Offset> trail = <Offset>[];
}

class _RewardToken {
  _RewardToken({
    required this.amount,
    required this.origin,
    required this.startedAt,
  });

  final int amount;
  final Offset origin;
  final DateTime startedAt;
  bool arrived = false;
}

class _ConnectionFlash {
  _ConnectionFlash(this.port, this.startedAt);
  final int port;
  final DateTime startedAt;
}

class _PocketBurst {
  _PocketBurst({
    required this.center,
    required this.text,
    required this.startedAt,
    required this.kind,
  });

  final Offset center;
  final String text;
  final DateTime startedAt;
  final int kind;
}

class _SurusuruPlayScreenState extends State<SurusuruPlayScreen> {
  final math.Random _random = math.Random();

  final List<_DropPiece> _pieces = <_DropPiece>[];
  final List<_ConnectionFlash> _flashes = <_ConnectionFlash>[];
  final List<_PocketBurst> _bursts = <_PocketBurst>[];
  final List<_RewardToken> _rewardTokens = <_RewardToken>[];

  int _rewardCounter = 0;
  DateTime? _lastCounterAddAt;
  DateTime? _expBeamStartedAt;
  int _expBeamAmount = 0;
  int _expTransferApplied = 0;
  int _expTransferDurationMs = 0;
  DateTime? _lastExpTickSfxAt;

  Timer? _physicsTimer;
  Timer? _autoTimer;

  Size _boardSize = Size.zero;
  int _nextPieceId = 1;

  int _surusuru = 3000;
  int _monsterExp = 0;
  int _monsterLevel = 1;

  int _autoUsed = 0;
  bool _autoRunning = false;

  bool _manualDragging = false;
  Offset? _manualFinger;
  int? _manualHoverPort;

  bool _miniGameOpen = false;
  bool _batchActive = false;
  bool _batchSettlementStarted = false;
  bool _holdCounterForBatch = false;
  int _centerPocketHits = 0;

  DateTime? _lastPegSfxAt;
  DateTime? _lastWallSfxAt;
  DateTime? _lastPieceSfxAt;

  bool get _dropBusy =>
      _autoRunning ||
      _pieces.isNotEmpty ||
      _miniGameOpen ||
      _batchSettlementStarted ||
      _rewardTokens.isNotEmpty ||
      _rewardCounter > 0 ||
      _expBeamStartedAt != null;

  static const int _portCount = 5;
  static const int _autoMax = 30;

  @override
  void initState() {
    super.initState();
    _physicsTimer = Timer.periodic(
      const Duration(milliseconds: 16),
      (_) => _tick(),
    );
  }

  @override
  void dispose() {
    _physicsTimer?.cancel();
    _autoTimer?.cancel();
    super.dispose();
  }

  double _pieceRadius(Size size) =>
      (size.width / 68).clamp(4.5, 6.0).toDouble();

  double _pegRadius(Size size) =>
      (size.width / 104).clamp(3.0, 4.2).toDouble();

  Rect _playRect(Size size) {
    // Restore the original vertical height, while narrowing the board width.
    final top = math.max(112.0, size.height * .205);
    final bottom = size.height - 122.0;
    final side = math.max(42.0, size.width * .16);
    return Rect.fromLTRB(side, top, size.width - side, bottom);
  }

  Offset _hub(Size size) =>
      Offset(size.width / 2, math.max(52.0, size.height * .085));

  List<Offset> _ports(Size size) {
    final y = math.max(88.0, size.height * .145);
    final side = math.max(48.0, size.width * .18);
    final left = side;
    final right = size.width - side;
    return List<Offset>.generate(
      _portCount,
      (i) => Offset(
        left + (right - left) * i / (_portCount - 1),
        y,
      ),
    );
  }

  List<({String label, Offset center})> _letterBumpers(Size size) {
    final r = _playRect(size);
    final topY = r.top + r.height * .31;
    final bottomY = r.top + r.height * .62;

    // Upper row:  S   U   R   U
    // Lower row:  S   U   ★   R   U
    return <({String label, Offset center})>[
      (label: 'S', center: Offset(r.left + r.width * .14, topY + 6)),
      (label: 'U', center: Offset(r.left + r.width * .38, topY - 8)),
      (label: 'R', center: Offset(r.left + r.width * .62, topY + 5)),
      (label: 'U', center: Offset(r.left + r.width * .86, topY - 4)),

      (label: 'S', center: Offset(r.left + r.width * .10, bottomY - 6)),
      (label: 'U', center: Offset(r.left + r.width * .31, bottomY + 10)),
      (label: 'R', center: Offset(r.left + r.width * .69, bottomY + 10)),
      (label: 'U', center: Offset(r.left + r.width * .90, bottomY - 6)),
    ];
  }

  Offset _starBumper(Size size) {
    final r = _playRect(size);
    // Move the ★ slightly upward so it is visually distinct from the
    // mini-game entrance mechanism below.
    return Offset(r.center.dx, r.top + r.height * .665);
  }

  List<Offset> _pegs(Size size) {
    final r = _playRect(size);
    if (r.height < 250) return const <Offset>[];
    return <Offset>[
      Offset(r.left + r.width * .23, r.top + r.height * .47),
      Offset(r.left + r.width * .50, r.top + r.height * .43),
      Offset(r.left + r.width * .77, r.top + r.height * .47),
      Offset(r.left + r.width * .20, r.top + r.height * .78),
      Offset(r.left + r.width * .40, r.top + r.height * .75),
      Offset(r.left + r.width * .60, r.top + r.height * .75),
      Offset(r.left + r.width * .80, r.top + r.height * .78),
    ];
  }

  List<Offset> _bottomPockets(Size size) {
    final r = _playRect(size);
    final y = r.bottom - 25;
    return List<Offset>.generate(
      5,
      (i) => Offset(r.left + r.width * (i + .5) / 5, y),
    );
  }

  List<double> _separatorXs(Size size) {
    final r = _playRect(size);
    return List<double>.generate(
      4,
      (i) => r.left + r.width * (i + 1) / 5,
    );
  }

  List<({Offset a, Offset b})> _miniGameGuards(Size size) {
    final r = _playRect(size);
    final cx = r.center.dx;

    // Final stage is deliberately simple and readable:
    // one straight-drop blocker and two side rails. The visible purple hole
    // itself is the only scoring trigger; there are no hidden qualifications.
    return <({Offset a, Offset b})>[
      (
        a: Offset(cx - 58, r.bottom - 108),
        b: Offset(cx - 27, r.bottom - 88),
      ),
      (
        a: Offset(cx + 58, r.bottom - 108),
        b: Offset(cx + 27, r.bottom - 88),
      ),
    ];
  }

  Offset _miniGameBlocker(Size size) {
    final r = _playRect(size);
    return Offset(r.center.dx, r.bottom - 112);
  }

  bool _allowSfx(DateTime? last, int milliseconds) {
    if (last == null) return true;
    return DateTime.now().difference(last).inMilliseconds >= milliseconds;
  }

  void _pegSfx() {
    if (!_allowSfx(_lastPegSfxAt, 55)) return;
    _lastPegSfxAt = DateTime.now();
    SfxManager.instance.traceStep(1 + _random.nextInt(3));
  }

  void _wallSfx() {
    if (!_allowSfx(_lastWallSfxAt, 90)) return;
    _lastWallSfxAt = DateTime.now();
    SfxManager.instance.tap();
  }

  void _pieceSfx() {
    if (!_allowSfx(_lastPieceSfxAt, 70)) return;
    _lastPieceSfxAt = DateTime.now();
    SfxManager.instance.spawn();
  }

  void _tick() {
    if (!mounted || _boardSize == Size.zero) return;

    _tickRewardFlow();
    if (_miniGameOpen) {
      if (_rewardTokens.isNotEmpty ||
          _rewardCounter > 0 ||
          _expBeamStartedAt != null) {
        setState(() {});
      }
      return;
    }

    final size = _boardSize;
    final rect = _playRect(size);
    final radius = _pieceRadius(size);
    final pegR = _pegRadius(size);
    final pegs = _pegs(size);
    final letterBumpers = _letterBumpers(size);
    final star = _starBumper(size);
    final pockets = _bottomPockets(size);
    final separators = _separatorXs(size);

    for (var index = 0; index < _pieces.length; index++) {
      final p = _pieces[index];
      if (p.scored) continue;
      if (p.branchCooldown > 0) p.branchCooldown--;

      final previousPosition = Offset(p.x, p.y);

      p.vy = math.min(p.vy + .17, 7.8);
      p.vx += (_random.nextDouble() - .5) * .025;
      p.vx *= .998;
      p.x += p.vx;
      p.y += p.vy;
      p.angle += p.spin;

      p.trail.add(Offset(p.x, p.y));
      if (p.trail.length > 8) p.trail.removeAt(0);

      // Swept side walls: even if a fast piece crosses beyond the wall
      // between frames, force it back inside and reflect the velocity.
      final leftLimit = rect.left + radius;
      final rightLimit = rect.right - radius;
      if (p.x < leftLimit ||
          (previousPosition.dx >= leftLimit && p.x < leftLimit)) {
        p.x = leftLimit + .35;
        p.vx = math.max(.9, p.vx.abs() * (.86 + _random.nextDouble() * .10));
        p.spin += .025;
        _wallSfx();
      } else if (p.x > rightLimit ||
          (previousPosition.dx <= rightLimit && p.x > rightLimit)) {
        p.x = rightLimit - .35;
        p.vx = -math.max(.9, p.vx.abs() * (.86 + _random.nextDouble() * .10));
        p.spin -= .025;
        _wallSfx();
      }

      // Small metallic pins.
      for (final peg in pegs) {
        final pegHit = _bounceCircle(
          p,
          peg,
          pegR,
          radius,
          restitution: .82 + _random.nextDouble() * .13,
          randomKick: .7,
        );
        if (pegHit) _pegSfx();
      }

      // Round SURUSURU letter bumpers.
      // Swept collision prevents tunnelling. Every valid hit gives EXP.
      for (var bumperIndex = 0;
          bumperIndex < letterBumpers.length;
          bumperIndex++) {
        final bumper = letterBumpers[bumperIndex];
        final hit = _bounceCircleSwept(
          p,
          previousPosition,
          bumper.center,
          13,
          radius,
          restitution: .88,
          randomKick: .72,
        );

        if (hit) {
          final gain = bumper.label == 'U' ? 1 : 2;
          if (bumper.label == 'U') {
            SfxManager.instance.traceStep(4);
          } else {
            SfxManager.instance.reaction();
          }
          _queueReward(gain, bumper.center);
          _bursts.add(
            _PocketBurst(
              center: bumper.center,
              text: '$gain',
              startedAt: DateTime.now(),
              kind: bumper.label == 'U' ? 0 : 1,
            ),
          );
        }
      }

      // Central star. Physical collision and EXP reward are active every hit.


      final starHit = _bounceCircleSwept(
        p,
        previousPosition,
        star,
        24,
        radius,
        restitution: .96,
        randomKick: 1.15,
      );
      if (starHit) {
        SfxManager.instance.lightning();
        _queueReward(5, star);
        _bursts.add(
          _PocketBurst(
            center: star,
            text: '5',
            startedAt: DateTime.now(),
            kind: 2,
          ),
        );
      }

      // Tiny character-to-character bounce.
      for (final q in _pieces) {
        if (identical(p, q) || q.id <= p.id || q.scored) continue;
        var dx = q.x - p.x;
        var dy = q.y - p.y;
        final minD = radius * 2;
        final d2 = dx * dx + dy * dy;
        if (d2 <= .0001 || d2 >= minD * minD) continue;
        final d = math.sqrt(d2);
        final nx = dx / d;
        final ny = dy / d;
        final overlap = minD - d;
        p.x -= nx * overlap * .5;
        p.y -= ny * overlap * .5;
        q.x += nx * overlap * .5;
        q.y += ny * overlap * .5;

        final rv = (q.vx - p.vx) * nx + (q.vy - p.vy) * ny;
        if (rv < 0) {
          _pieceSfx();
          final impulse = -rv * .60;
          p.vx -= nx * impulse;
          p.vy -= ny * impulse;
          q.vx += nx * impulse;
          q.vy += ny * impulse;
        }
      }

      // Real collision on the four vertical pocket separators.
      final separatorTop = rect.bottom - 86;
      final separatorBottom = rect.bottom + 6;
      if (p.y + radius >= separatorTop &&
          p.y - radius <= separatorBottom) {
        for (final sx in separators) {
          final dx = p.x - sx;
          final halfThickness = 4.5;
          if (dx.abs() <= radius + halfThickness) {
            p.x = sx +
                (dx >= 0 ? 1 : -1) * (radius + halfThickness + .2);
            p.vx = (dx >= 0 ? 1 : -1) *
                math.max(.85, p.vx.abs() * .78);
            p.spin += (dx >= 0 ? 1 : -1) * .03;
            _wallSfx();
          }
        }
      }

      // Pocket entry. The ball must actually descend below the lip.
      if (!p.scored && p.y >= rect.bottom - 40) {
        final pocketWidth = rect.width / 5;
        var pocketIndex =
            ((p.x - rect.left) / pocketWidth).floor().clamp(0, 4).toInt();

        final left = rect.left + pocketWidth * pocketIndex;
        final right = left + pocketWidth;
        if (p.x > left + radius + 4 &&
            p.x < right - radius - 4 &&
            p.y >= rect.bottom - 20) {
          p.scored = true;

          {
            const rewards = <int>[100, 200, 0, 200, 100];
            const labels = <String>[
              '100',
              '200',
              '',
              '200',
              '100',
            ];
            if (pocketIndex == 2) {
              // The center RED pocket is the mini-game pocket. It only counts
              // hits now; the mini-game opens later, after the whole batch has
              // finished, exactly like the existing settlement flow.
              _centerPocketHits++;
              SfxManager.instance.reward();
              _bursts.add(
                _PocketBurst(
                  center: pockets[pocketIndex] - const Offset(0, 18),
                  text: '×$_centerPocketHits',
                  startedAt: DateTime.now(),
                  kind: 5,
                ),
              );
            } else {
              SfxManager.instance.clear();
              _queueReward(rewards[pocketIndex], pockets[pocketIndex]);
              _bursts.add(
                _PocketBurst(
                  center: pockets[pocketIndex] - const Offset(0, 18),
                  text: labels[pocketIndex],
                  startedAt: DateTime.now(),
                  kind: 0,
                ),
              );
            }

            p.y = rect.bottom + 100;
            p.vx = 0;
            p.vy = 0;
          }
        }
      }
    }

    final hadPieces = _pieces.isNotEmpty;
    _pieces.removeWhere(
      (p) =>
          p.scored ||
          p.y > rect.bottom + 90 ||
          p.x < -100 ||
          p.x > size.width + 100,
    );
    if (hadPieces && _pieces.isEmpty && !_autoRunning) {
      SfxManager.instance.unlock();
      if (_batchActive && !_batchSettlementStarted) {
        _batchSettlementStarted = true;
        Future<void>.delayed(
          const Duration(milliseconds: 700),
          _settleBatch,
        );
      }
    }

    final now = DateTime.now();
    _flashes.removeWhere(
      (f) => now.difference(f.startedAt).inMilliseconds > 450,
    );
    _bursts.removeWhere(
      (b) =>
          now.difference(b.startedAt).inMilliseconds >
          (b.kind == 4 ? 1400 : b.kind == 5 ? 950 : 720),
    );

    if (mounted &&
        (_pieces.isNotEmpty ||
            _flashes.isNotEmpty ||
            _bursts.isNotEmpty ||
            _rewardTokens.isNotEmpty ||
            _rewardCounter > 0 ||
            _expBeamStartedAt != null)) {
      setState(() {});
    }
  }

  bool _bounceSegment(
    _DropPiece p,
    Offset a,
    Offset b,
    double obstacleRadius,
    double pieceRadius, {
    required double restitution,
    required double randomKick,
  }) {
    final ab = b - a;
    final len2 = ab.dx * ab.dx + ab.dy * ab.dy;
    if (len2 <= .0001) return false;

    final ap = Offset(p.x, p.y) - a;
    final t = ((ap.dx * ab.dx + ap.dy * ab.dy) / len2)
        .clamp(0.0, 1.0)
        .toDouble();
    final closest = a + ab * t;

    var dx = p.x - closest.dx;
    var dy = p.y - closest.dy;
    final minD = obstacleRadius + pieceRadius;
    final d2 = dx * dx + dy * dy;
    if (d2 >= minD * minD) return false;

    var d = math.sqrt(math.max(.0001, d2));
    if (d < .01) {
      dx = -ab.dy;
      dy = ab.dx;
      d = math.sqrt(dx * dx + dy * dy);
    }

    final nx = dx / d;
    final ny = dy / d;
    final overlap = minD - d;
    p.x += nx * (overlap + .25);
    p.y += ny * (overlap + .25);

    final dot = p.vx * nx + p.vy * ny;
    if (dot < 0) {
      p.vx -= (1 + restitution) * dot * nx;
      p.vy -= (1 + restitution) * dot * ny;
    }

    final kick = (_random.nextDouble() - .5) * randomKick;
    p.vx += -ny * kick;
    p.vy += nx * kick * .25;
    p.spin += kick * .018;
    return true;
  }

  Future<void> _settleBatch() async {
    if (!mounted) return;

    // Wait until all normal reward stars from this 30-ball batch have reached
    // the big counter. The counter is intentionally held and cannot beam yet.
    while (mounted && _rewardTokens.any((t) => !t.arrived)) {
      await Future<void>.delayed(const Duration(milliseconds: 80));
    }
    if (!mounted) return;

    final hits = _centerPocketHits;
    if (hits > 0) {
      setState(() {
        _miniGameOpen = true;
      });

      final miniReward = await Navigator.of(context).push<int>(
        MaterialPageRoute<int>(
          builder: (_) => _ConnectMiniGameScreen(multiplier: hits),
          fullscreenDialog: true,
        ),
      );

      if (!mounted) return;

      if (miniReward != null && miniReward > 0) {
        final bonus = miniReward * hits;
        setState(() {
          _miniGameOpen = false;
          _queueReward(
            bonus,
            _bottomPockets(_boardSize)[2],
          );
          _bursts.add(
            _PocketBurst(
              center: _playRect(_boardSize).center,
              text: hits > 1 ? '$miniReward ×$hits = $bonus' : '$bonus',
              startedAt: DateTime.now(),
              kind: 4,
            ),
          );
        });
        SfxManager.instance.unlock();
        SfxManager.instance.reward();

        // Wait for the mini-game bonus star to enter the big counter too.
        while (mounted && _rewardTokens.any((t) => !t.arrived)) {
          await Future<void>.delayed(const Duration(milliseconds: 80));
        }
      } else {
        setState(() {
          _miniGameOpen = false;
        });
      }
    }

    if (!mounted) return;
    setState(() {
      _centerPocketHits = 0;
      _batchActive = false;
      _batchSettlementStarted = false;
      _holdCounterForBatch = false;
      _lastCounterAddAt = DateTime.now();
    });
  }


  bool _bounceCircleSwept(
    _DropPiece p,
    Offset previous,
    Offset center,
    double obstacleRadius,
    double pieceRadius, {
    required double restitution,
    required double randomKick,
  }) {
    final current = Offset(p.x, p.y);
    final segment = current - previous;
    final segmentLen2 =
        segment.dx * segment.dx + segment.dy * segment.dy;
    final minD = obstacleRadius + pieceRadius;

    double t = 0.0;
    if (segmentLen2 > .000001) {
      final toCenter = center - previous;
      t = ((toCenter.dx * segment.dx + toCenter.dy * segment.dy) /
              segmentLen2)
          .clamp(0.0, 1.0)
          .toDouble();
    }

    final closest = previous + segment * t;
    var delta = closest - center;
    var distance = delta.distance;

    // Also catch ordinary overlap at the current position.
    final currentDelta = current - center;
    final currentDistance = currentDelta.distance;
    if (distance > minD && currentDistance > minD) return false;

    if (currentDistance <= minD) {
      delta = currentDelta;
      distance = currentDistance;
    }

    if (distance < .001) {
      final speed = Offset(p.vx, p.vy);
      if (speed.distance > .001) {
        delta = -speed / speed.distance;
      } else {
        delta = const Offset(0, -1);
      }
      distance = 1;
    }

    final normal = delta / distance;

    // Force the character back to the outside edge. This is the key part
    // that prevents tunnelling straight through on later contacts.
    p.x = center.dx + normal.dx * (minD + .35);
    p.y = center.dy + normal.dy * (minD + .35);

    final dot = p.vx * normal.dx + p.vy * normal.dy;
    if (dot < 0) {
      p.vx -= (1 + restitution) * dot * normal.dx;
      p.vy -= (1 + restitution) * dot * normal.dy;
    } else {
      // A swept crossing can finish on the far side with dot >= 0.
      // Give it a guaranteed outward push instead of allowing a pass-through.
      final outward = math.max(1.1, math.sqrt(p.vx * p.vx + p.vy * p.vy) * .72);
      p.vx = normal.dx * outward;
      p.vy = normal.dy * outward;
    }

    final tangentKick =
        (_random.nextDouble() - .5) * randomKick;
    p.vx += -normal.dy * tangentKick;
    p.vy += normal.dx * tangentKick * .22;
    p.spin += tangentKick * .02;
    return true;
  }

  bool _bounceCircle(
    _DropPiece p,
    Offset center,
    double obstacleRadius,
    double pieceRadius, {
    required double restitution,
    required double randomKick,
  }) {
    var dx = p.x - center.dx;
    var dy = p.y - center.dy;
    final minD = obstacleRadius + pieceRadius;
    var d2 = dx * dx + dy * dy;
    if (d2 >= minD * minD) return false;

    var d = math.sqrt(math.max(.0001, d2));
    if (d < .01) {
      dx = (_random.nextDouble() - .5) * .2;
      dy = -1;
      d = math.sqrt(dx * dx + dy * dy);
    }

    final nx = dx / d;
    final ny = dy / d;
    final overlap = minD - d;
    p.x += nx * overlap;
    p.y += ny * overlap;

    final dot = p.vx * nx + p.vy * ny;
    if (dot < 0) {
      p.vx -= (1 + restitution) * dot * nx;
      p.vy -= (1 + restitution) * dot * ny;
    }

    final tangentKick = (_random.nextDouble() - .5) * randomKick;
    p.vx += -ny * tangentKick;
    p.vy += nx * tangentKick * .22;
    p.spin += tangentKick * .02;
    return true;
  }

  Offset _rewardCounterCenter(Size size) {
    final r = _playRect(size);
    return Offset(r.center.dx, r.top + 34);
  }

  void _queueReward(int amount, Offset origin) {
    if (amount <= 0 || _boardSize == Size.zero) return;
    _rewardTokens.add(
      _RewardToken(
        amount: amount,
        origin: origin,
        startedAt: DateTime.now(),
      ),
    );
  }

  void _applyExp(int amount) {
    _monsterExp += amount;
    var leveledUp = false;
    while (true) {
      final need = _expNeed(_monsterLevel);
      if (_monsterExp < need) break;
      _monsterExp -= need;
      _monsterLevel++;
      leveledUp = true;
    }
    if (leveledUp) SfxManager.instance.unlock();
  }

  void _tickRewardFlow() {
    if (_boardSize == Size.zero) return;
    final now = DateTime.now();
    var addedToCounter = false;

    for (final token in _rewardTokens) {
      if (token.arrived) continue;
      if (now.difference(token.startedAt).inMilliseconds >= 430) {
        token.arrived = true;
        _rewardCounter += token.amount;
        _lastCounterAddAt = now;
        addedToCounter = true;
      }
    }

    _rewardTokens.removeWhere(
      (t) =>
          t.arrived &&
          now.difference(t.startedAt).inMilliseconds > 560,
    );

    if (addedToCounter) {
      SfxManager.instance.traceStep(
        (_rewardCounter ~/ 100 + 3).clamp(3, 8).toInt(),
      );
    }

    final waitingToken = _rewardTokens.any((t) => !t.arrived);

    // Start the counter -> EXP transfer automatically when settlement ends.
    if (!_holdCounterForBatch &&
        _expBeamStartedAt == null &&
        _rewardCounter > 0 &&
        !waitingToken &&
        _lastCounterAddAt != null &&
        now.difference(_lastCounterAddAt!).inMilliseconds >= 320) {
      _expBeamAmount = _rewardCounter;
      _rewardCounter = 0;
      _expTransferApplied = 0;

      // Bigger totals deliberately take longer to count up.
      // 100 ~= 0.9s, 1000 ~= 1.5s, 8000 ~= 3.0s.
      _expTransferDurationMs =
          (700 + math.sqrt(_expBeamAmount.toDouble()) * 25)
              .round()
              .clamp(850, 3600)
              .toInt();
      _expBeamStartedAt = now;
      _lastExpTickSfxAt = null;
      SfxManager.instance.core();

      if (mounted) setState(() {});
    }

    if (_expBeamStartedAt != null && _expBeamAmount > 0) {
      final elapsed =
          now.difference(_expBeamStartedAt!).inMilliseconds;
      final duration = math.max(1, _expTransferDurationMs);
      final progress =
          (elapsed / duration).clamp(0.0, 1.0).toDouble();

      // Smooth "pururururu" number count-up instead of one instant jump.
      final eased = Curves.easeOutCubic.transform(progress);
      final targetApplied =
          (_expBeamAmount * eased).round().clamp(0, _expBeamAmount);
      final delta = targetApplied - _expTransferApplied;

      if (delta > 0) {
        _applyExp(delta);
        _expTransferApplied += delta;

        if (_lastExpTickSfxAt == null ||
            now.difference(_lastExpTickSfxAt!).inMilliseconds >= 55) {
          _lastExpTickSfxAt = now;
          final step =
              1 + (progress * 7).floor().clamp(0, 7).toInt();
          SfxManager.instance.traceStep(step);
        }

        if (mounted) setState(() {});
      }

      if (progress >= 1.0) {
        final remaining = _expBeamAmount - _expTransferApplied;
        if (remaining > 0) {
          _applyExp(remaining);
          _expTransferApplied += remaining;
        }

        _expBeamAmount = 0;
        _expTransferApplied = 0;
        _expTransferDurationMs = 0;
        _expBeamStartedAt = null;
        _lastExpTickSfxAt = null;
        SfxManager.instance.reward();

        // Important: force the final frame now. Previously the last EXP
        // update could stay invisible until the next ball was launched.
        if (mounted) setState(() {});
      }
    }
  }

  int _expNeed(int level) {
    final n = level - 1;
    // Numeric rewards from the five bottom pockets are now large, so leveling needs
    // a much larger curve. Lv1=8,000, Lv2=13,000, Lv3=20,000, Lv4=29,000...
    return 8000 + n * 4000 + n * n * 1000;
  }

  bool _consumeOneAndConnect(int port, {bool automatic = false}) {
    if (_surusuru <= 0 || _boardSize == Size.zero) return false;

    final ports = _ports(_boardSize);
    if (port < 0 || port >= ports.length) return false;

    setState(() {
      _surusuru--;
      SfxManager.instance.spawn();
      _flashes.add(_ConnectionFlash(port, DateTime.now()));

      final start = ports[port];
      final r = _pieceRadius(_boardSize);
      _pieces.add(
        _DropPiece(
          id: _nextPieceId++,
          type: _random.nextInt(5),
          x: start.dx + (_random.nextDouble() - .5) * r * 1.2,
          y: math.min(start.dy + r * 1.25, _playRect(_boardSize).top - r - 2),
          vx: (_random.nextDouble() - .5) * (automatic ? 2.0 : 1.2),
          vy: .45 + _random.nextDouble() * .75,
        ),
      );
    });
    return true;
  }

  void _startAuto() {
    if (_dropBusy || _surusuru <= 0) {
      SfxManager.instance.error();
      return;
    }
    _autoUsed = 0;
    _autoRunning = true;
    _batchActive = true;
    _batchSettlementStarted = false;
    _holdCounterForBatch = true;
    _centerPocketHits = 0;
    SfxManager.instance.surusuru();

    void fire() {
      if (!_autoRunning ||
          _autoUsed >= _autoMax ||
          _surusuru <= 0 ||
          !mounted) {
        _stopAuto();
        return;
      }

      if (_consumeOneAndConnect(
        _random.nextInt(_portCount),
        automatic: true,
      )) {
        _autoUsed++;
      }
    }

    fire();
    _autoTimer?.cancel();
    _autoTimer = Timer.periodic(
      const Duration(milliseconds: 118),
      (_) => fire(),
    );
    setState(() {});
  }

  void _stopAuto() {
    _autoTimer?.cancel();
    _autoTimer = null;
    if (!_autoRunning) return;
    _autoRunning = false;
    if (mounted) setState(() {});
  }

  void _manualStart(DragStartDetails details) {
    if (_autoRunning || _surusuru <= 0) return;
    final hub = _hub(_boardSize);
    if ((details.localPosition - hub).distance > 42) return;

    SfxManager.instance.tap();
    setState(() {
      _manualDragging = true;
      _manualFinger = details.localPosition;
      _manualHoverPort = null;
    });
  }

  void _manualUpdate(DragUpdateDetails details) {
    if (!_manualDragging) return;
    final finger = details.localPosition;
    final ports = _ports(_boardSize);

    int? hover;
    var best = 38.0;
    for (var i = 0; i < ports.length; i++) {
      final d = (finger - ports[i]).distance;
      if (d < best) {
        best = d;
        hover = i;
      }
    }

    setState(() {
      _manualFinger = finger;
      _manualHoverPort = hover;
    });
  }

  void _manualEnd(DragEndDetails details) {
    if (!_manualDragging) return;
    final port = _manualHoverPort;

    setState(() {
      _manualDragging = false;
      _manualFinger = null;
      _manualHoverPort = null;
    });

    if (port != null) {
      if (!_batchActive) {
        _batchActive = true;
        _batchSettlementStarted = false;
        _holdCounterForBatch = true;
        _centerPocketHits = 0;
      }
      _consumeOneAndConnect(port);
    }
  }

  void _manualCancel() {
    if (!_manualDragging) return;
    setState(() {
      _manualDragging = false;
      _manualFinger = null;
      _manualHoverPort = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final expNeed = _expNeed(_monsterLevel);

    return Scaffold(
      backgroundColor: const Color(0xFF0B1025),
      body: SafeArea(
        child: Column(
          children: [
            _TopBar(
              level: _monsterLevel,
              exp: _monsterExp,
              expNeed: expNeed,
              onBack: () => Navigator.pop(context),
            ),
            Expanded(
              child: LayoutBuilder(
                builder: (context, constraints) {
                  _boardSize =
                      Size(constraints.maxWidth, constraints.maxHeight);

                  return GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onPanStart: _manualStart,
                    onPanUpdate: _manualUpdate,
                    onPanEnd: _manualEnd,
                    onPanCancel: _manualCancel,
                    child: Stack(
                      children: [
                        Positioned.fill(
                          child: CustomPaint(
                            painter: _SuruBoardPainter(
                              pieces: _pieces,
                              flashes: _flashes,
                              bursts: _bursts,
                              hub: _hub(_boardSize),
                              ports: _ports(_boardSize),
                              pegs: _pegs(_boardSize),
                              letterBumpers: _letterBumpers(_boardSize),
                              starBumper: _starBumper(_boardSize),
                              pockets: _bottomPockets(_boardSize),
                              separators: _separatorXs(_boardSize),
                              playRect: _playRect(_boardSize),
                              pieceRadius: _pieceRadius(_boardSize),
                              pegRadius: _pegRadius(_boardSize),
                              manualFinger: _manualFinger,
                              manualHoverPort: _manualHoverPort,
                              rewardTokens: _rewardTokens,
                              rewardCounter: _rewardCounter,
                              expBeamStartedAt: _expBeamStartedAt,
                              expBeamAmount: _expBeamAmount,
                              expTransferApplied: _expTransferApplied,
                              expTransferDurationMs: _expTransferDurationMs,
                              centerPocketHits: _centerPocketHits,
                            ),
                          ),
                        ),
                        Positioned(
                          top: 6,
                          left: 0,
                          right: 0,
                          child: IgnorePointer(
                            child: Center(
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 12,
                                  vertical: 4,
                                ),
                                decoration: BoxDecoration(
                                  color: const Color(0xCC11182D),
                                  borderRadius: BorderRadius.circular(15),
                                  border: Border.all(
                                    color: const Color(0x99A9C7FF),
                                  ),
                                ),
                                child: Text(
                                  _manualDragging
                                      ? '好きな入口へつないで離す'
                                      : '手動つなぎ  •  1スルスル',
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 10,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          left: 0,
                          right: 0,
                          bottom: 2,
                          child: Center(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                GestureDetector(
                                  onTap: () {
                                    if (_dropBusy || _surusuru <= 0) {
                                      SfxManager.instance.error();
                                      return;
                                    }
                                    SfxManager.instance.tap();
                                    _consumeOneAndConnect(
                                      _random.nextInt(_portCount),
                                      automatic: true,
                                    );
                                  },
                                  onLongPressStart: (_) => _startAuto(),
                                  // Once a 30-ball batch starts, releasing the
                                  // finger does not cancel it.
                                  onLongPressEnd: (_) {}, 
                                  child: AnimatedScale(
                                    duration: const Duration(milliseconds: 90),
                                    scale: _autoRunning ? .93 : 1,
                                    child: Container(
                                      width: 116,
                                      height: 116,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        gradient: const RadialGradient(
                                          colors: [
                                            Color(0xFFFFF39B),
                                            Color(0xFFFFB62F),
                                            Color(0xFFE36B16),
                                          ],
                                        ),
                                        border: Border.all(
                                          color: Colors.white,
                                          width: 4,
                                        ),
                                        boxShadow: const [
                                          BoxShadow(
                                            color: Color(0x99FF8A28),
                                            blurRadius: 26,
                                            spreadRadius: 3,
                                          ),
                                          BoxShadow(
                                            color: Color(0x77000000),
                                            blurRadius: 10,
                                            offset: Offset(0, 6),
                                          ),
                                        ],
                                      ),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          const Text(
                                            'スルスル',
                                            style: TextStyle(
                                              color: Color(0xFF432416),
                                              fontSize: 18,
                                              fontWeight: FontWeight.w900,
                                            ),
                                          ),
                                          Text(
                                            _autoRunning
                                                ? '$_autoUsed / $_autoMax'
                                                : _pieces.isNotEmpty
                                                    ? '落下中 ${_pieces.length}'
                                                    : 'MAX $_autoMax',
                                            style: const TextStyle(
                                              color: Color(0xFF432416),
                                              fontSize: 15,
                                              fontWeight: FontWeight.w900,
                                            ),
                                          ),
                                          const Text(
                                            '長押し',
                                            style: TextStyle(
                                              color: Color(0xAA432416),
                                              fontSize: 9,
                                              fontWeight: FontWeight.w900,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 5),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 13,
                                    vertical: 4,
                                  ),
                                  decoration: BoxDecoration(
                                    color: const Color(0xDD0E1120),
                                    borderRadius: BorderRadius.circular(13),
                                    border: Border.all(
                                      color: const Color(0x99FFD76A),
                                    ),
                                  ),
                                  child: Text(
                                    '所持スルスル  $_surusuru',
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 11,
                                      fontWeight: FontWeight.w900,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TopBar extends StatelessWidget {
  const _TopBar({
    required this.level,
    required this.exp,
    required this.expNeed,
    required this.onBack,
  });

  final int level;
  final int exp;
  final int expNeed;
  final VoidCallback onBack;

  @override
  Widget build(BuildContext context) {
    final ratio =
        expNeed <= 0 ? 0.0 : (exp / expNeed).clamp(0.0, 1.0);

    return Container(
      height: 74,
      padding: const EdgeInsets.fromLTRB(7, 6, 9, 7),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Color(0xFF15182D),
            Color(0xFF242047),
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: Color(0x66000000),
            blurRadius: 8,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          IconButton(
            onPressed: onBack,
            icon: const Icon(Icons.arrow_back, color: Colors.white),
          ),
          Expanded(
            child: Container(
              padding: const EdgeInsets.fromLTRB(10, 6, 10, 7),
              decoration: BoxDecoration(
                color: const Color(0xFF101526),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFF675A98)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      const Text(
                        '育成モンスター',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                          fontSize: 12,
                        ),
                      ),
                      const Spacer(),
                      Text(
                        'Lv.$level',
                        style: const TextStyle(
                          color: Color(0xFFFFE386),
                          fontWeight: FontWeight.w900,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 5),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(7),
                    child: Stack(
                      children: [
                        Container(
                          height: 14,
                          color: const Color(0xFF080B12),
                        ),
                        FractionallySizedBox(
                          widthFactor: ratio,
                          child: Container(
                            height: 14,
                            decoration: const BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Color(0xFF54E273),
                                  Color(0xFFA7F06F),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Positioned.fill(
                          child: Center(
                            child: Text(
                              '$exp / $expNeed',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 9,
                                fontWeight: FontWeight.w900,
                                shadows: [
                                  Shadow(
                                    color: Colors.black,
                                    blurRadius: 2,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}


enum _MiniGameType { route, target, memory, timing, rescue }

String _miniTitle(_MiniGameType type) {
  switch (type) {
    case _MiniGameType.route:
      return 'ルート CONNECT';
    case _MiniGameType.target:
      return 'ターゲット CONNECT';
    case _MiniGameType.memory:
      return 'メモリー CONNECT';
    case _MiniGameType.timing:
      return 'タイミング CONNECT';
    case _MiniGameType.rescue:
      return 'レスキュー CONNECT';
  }
}

IconData _miniIcon(_MiniGameType type) {
  switch (type) {
    case _MiniGameType.route:
      return Icons.alt_route_rounded;
    case _MiniGameType.target:
      return Icons.gps_fixed_rounded;
    case _MiniGameType.memory:
      return Icons.psychology_alt_rounded;
    case _MiniGameType.timing:
      return Icons.speed_rounded;
    case _MiniGameType.rescue:
      return Icons.volunteer_activism_rounded;
  }
}

String _miniDescription(_MiniGameType type) {
  switch (type) {
    case _MiniGameType.route:
      return '光るルートを見つけてつなぐ';
    case _MiniGameType.target:
      return '動く光を狙ってつなぐ';
    case _MiniGameType.memory:
      return '光った順番を覚えてつなぐ';
    case _MiniGameType.timing:
      return '光が重なった瞬間につなぐ';
    case _MiniGameType.rescue:
      return '同じマーク同士をつないで救出';
  }
}

class _ConnectMiniGameScreen extends StatefulWidget {
  const _ConnectMiniGameScreen({required this.multiplier});

  final int multiplier;

  @override
  State<_ConnectMiniGameScreen> createState() => _ConnectMiniGameScreenState();
}

class _ConnectMiniGameScreenState extends State<_ConnectMiniGameScreen> {
  final math.Random _rng = math.Random();
  late final List<_MiniGameType> _cards;
  bool _revealed = false;
  bool _opening = false;

  @override
  void initState() {
    super.initState();
    final all = _MiniGameType.values.toList()..shuffle(_rng);
    final count = widget.multiplier.clamp(1, 3).toInt();
    _cards = all.take(count).toList(growable: false);
    Future<void>.delayed(const Duration(milliseconds: 420), () {
      if (mounted) setState(() => _revealed = true);
    });
  }

  Future<void> _open(_MiniGameType type) async {
    if (_opening || !_revealed) return;
    setState(() => _opening = true);
    SfxManager.instance.reward();
    final reward = await Navigator.of(context).push<int>(
      MaterialPageRoute<int>(
        builder: (_) => _MiniGamePlayScreen(type: type),
        fullscreenDialog: true,
      ),
    );
    if (!mounted) return;
    Navigator.of(context).pop(reward ?? 1000);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0B1025),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 4),
              child: Row(
                children: [
                  IconButton(
                    onPressed: _opening ? null : () => Navigator.of(context).pop(1000),
                    icon: const Icon(Icons.close, color: Colors.white),
                  ),
                  const Expanded(
                    child: Text(
                      'MINI GAME CARD',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 21,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.2,
                      ),
                    ),
                  ),
                  const SizedBox(width: 48),
                ],
              ),
            ),
            Text(
              widget.multiplier <= 1
                  ? '今回のミニゲーム'
                  : '${_cards.length}枚から1枚選ぼう！　×${widget.multiplier}',
              style: const TextStyle(
                color: Color(0xFFFFE66D),
                fontSize: 16,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
                  child: Wrap(
                    alignment: WrapAlignment.center,
                    spacing: 14,
                    runSpacing: 14,
                    children: [
                      for (var i = 0; i < _cards.length; i++)
                        AnimatedScale(
                          duration: Duration(milliseconds: 360 + i * 110),
                          curve: Curves.easeOutBack,
                          scale: _revealed ? 1 : .12,
                          child: AnimatedRotation(
                            duration: Duration(milliseconds: 520 + i * 100),
                            turns: _revealed ? 0 : .5,
                            child: GestureDetector(
                              onTap: () => _open(_cards[i]),
                              child: Container(
                                width: _cards.length == 1 ? 220 : 155,
                                height: 220,
                                padding: const EdgeInsets.all(14),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(22),
                                  gradient: const LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                    colors: [Color(0xFF6745D9), Color(0xFF24144C)],
                                  ),
                                  border: Border.all(color: const Color(0xFFFFDE6D), width: 3),
                                  boxShadow: const [
                                    BoxShadow(color: Color(0x667B5CFF), blurRadius: 20, spreadRadius: 3),
                                  ],
                                ),
                                child: _revealed
                                    ? Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Icon(_miniIcon(_cards[i]), color: Colors.white, size: 58),
                                          const SizedBox(height: 16),
                                          Text(
                                            _miniTitle(_cards[i]),
                                            textAlign: TextAlign.center,
                                            style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900),
                                          ),
                                          const SizedBox(height: 10),
                                          Text(
                                            _miniDescription(_cards[i]),
                                            textAlign: TextAlign.center,
                                            style: const TextStyle(color: Color(0xFFC8C8E8), fontSize: 12, fontWeight: FontWeight.w700),
                                          ),
                                        ],
                                      )
                                    : const Center(
                                        child: Text('?', style: TextStyle(color: Colors.white, fontSize: 72, fontWeight: FontWeight.w900)),
                                      ),
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
            const Padding(
              padding: EdgeInsets.only(bottom: 18),
              child: Text(
                '1000保証　→　最大4000',
                style: TextStyle(color: Color(0xFFA9E8FF), fontWeight: FontWeight.w900),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MiniGamePlayScreen extends StatefulWidget {
  const _MiniGamePlayScreen({required this.type});

  final _MiniGameType type;

  @override
  State<_MiniGamePlayScreen> createState() => _MiniGamePlayScreenState();
}

class _MiniGamePlayScreenState extends State<_MiniGamePlayScreen>
    with SingleTickerProviderStateMixin {
  final math.Random _rng = math.Random();
  late final AnimationController _controller;
  int _reward = 1000;
  int _round = 0;
  int _correct = 0;
  bool _locked = false;
  String _message = 'つないでみよう！';

  // Route
  int _routeGood = 0;

  // Memory
  late List<int> _memorySequence;
  bool _memoryPreview = true;

  // Rescue
  int? _rescueFrom;
  Offset? _dragPoint;
  final Set<int> _rescued = <int>{};

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1900),
    )..repeat(reverse: true);
    _routeGood = _rng.nextInt(3);
    _memorySequence = List<int>.generate(3, (_) => _rng.nextInt(4));
    if (widget.type == _MiniGameType.memory) {
      _message = '3つの順番を覚えて！';
      Future<void>.delayed(const Duration(milliseconds: 1900), () {
        if (mounted) setState(() {
          _memoryPreview = false;
          _message = '同じ順番でつなごう！';
        });
      });
    } else if (widget.type == _MiniGameType.route) {
      _message = '光が強いルートを選ぼう！';
    } else if (widget.type == _MiniGameType.target) {
      _message = '動く光を3回つかまえよう！';
    } else if (widget.type == _MiniGameType.timing) {
      _message = '中央の黄色ゾーンでタップ！';
    } else {
      _message = '同じマーク同士をつなごう！';
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _success() {
    if (_locked) return;
    _correct++;
    _reward = math.min(4000, _reward + 1000);
    SfxManager.instance.reward();
    setState(() {
      _message = _reward >= 4000 ? 'PERFECT！ 4000 GET！' : 'SUCCESS！ $_reward';
    });
    if (_correct >= 3) {
      _finishSoon();
    }
  }

  void _fail([String text = 'MISS…']) {
    if (_locked) return;
    SfxManager.instance.error();
    setState(() => _message = '$text　$_reward GET');
    _finishSoon();
  }

  void _finishSoon() {
    _locked = true;
    Future<void>.delayed(const Duration(milliseconds: 850), () {
      if (mounted) Navigator.of(context).pop(_reward);
    });
  }

  void _routeTap(int index) {
    if (_locked) return;
    if (index == _routeGood) {
      _success();
      if (_correct < 3) {
        setState(() {
          _round++;
          _routeGood = _rng.nextInt(3);
          _message = '次の分岐！ 光をたどろう';
        });
      }
    } else {
      _fail('ルートが切れた！');
    }
  }

  void _targetTap(TapDownDetails d, Size size) {
    if (_locked) return;
    final x = 38 + _controller.value * (size.width - 76);
    final y = size.height * (.38 + .12 * math.sin(_controller.value * math.pi * 2));
    if ((d.localPosition - Offset(x, y)).distance <= 52) {
      _success();
      if (_correct < 3) setState(() => _message = 'HIT！ 次の光を狙おう');
    } else {
      _fail('届かなかった！');
    }
  }

  void _memoryTap(int index) {
    if (_locked || _memoryPreview) return;
    if (index == _memorySequence[_correct]) {
      _success();
      if (_correct < 3) setState(() => _message = 'OK！ あと${3 - _correct}つ');
    } else {
      _fail('順番が違う！');
    }
  }

  void _timingTap() {
    if (_locked) return;
    final distance = (_controller.value - .5).abs();
    final limit = _correct == 0 ? .22 : (_correct == 1 ? .16 : .11);
    if (distance <= limit) {
      _success();
      if (_correct < 3) setState(() => _message = 'GOOD！ 次は少し狭くなるよ');
    } else {
      _fail('タイミングが外れた！');
    }
  }

  List<Offset> _rescueLeft(Size size) => <Offset>[
    Offset(size.width * .18, size.height * .26),
    Offset(size.width * .18, size.height * .50),
    Offset(size.width * .18, size.height * .74),
  ];

  List<Offset> _rescueRight(Size size) => <Offset>[
    Offset(size.width * .82, size.height * .74),
    Offset(size.width * .82, size.height * .26),
    Offset(size.width * .82, size.height * .50),
  ];

  void _rescueStart(DragStartDetails d, Size size) {
    if (_locked) return;
    final left = _rescueLeft(size);
    for (var i = 0; i < left.length; i++) {
      if (_rescued.contains(i)) continue;
      if ((d.localPosition - left[i]).distance <= 40) {
        setState(() {
          _rescueFrom = i;
          _dragPoint = d.localPosition;
        });
        return;
      }
    }
  }

  void _rescueUpdate(DragUpdateDetails d) {
    if (_rescueFrom == null) return;
    setState(() => _dragPoint = d.localPosition);
  }

  void _rescueEnd(DragEndDetails d, Size size) {
    if (_rescueFrom == null) return;
    final from = _rescueFrom!;
    final right = _rescueRight(size);
    final target = <int>[1, 2, 0][from];
    final hit = _dragPoint != null && (_dragPoint! - right[target]).distance <= 48;
    setState(() {
      _rescueFrom = null;
      _dragPoint = null;
    });
    if (hit) {
      _rescued.add(from);
      _success();
      if (_correct < 3) setState(() => _message = '救出成功！ 次もつなごう');
    } else {
      _fail('違う相手につないだ！');
    }
  }

  Widget _buildRoute(Size size) {
    final ys = <double>[.28, .50, .72];
    return Stack(
      children: [
        Positioned(
          left: size.width * .08,
          top: size.height * .43,
          child: _node('S', const Color(0xFFFFD85C), 54),
        ),
        for (var i = 0; i < 3; i++)
          Positioned(
            right: size.width * .08,
            top: size.height * ys[i] - 30,
            child: GestureDetector(
              onTap: () => _routeTap(i),
              child: AnimatedBuilder(
                animation: _controller,
                builder: (_, child) => Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: i == _routeGood
                        ? [BoxShadow(color: const Color(0xFF58E8FF).withValues(alpha: .20 + .35 * _controller.value), blurRadius: 22, spreadRadius: 4)]
                        : null,
                  ),
                  child: child,
                ),
                child: _node('?', i == _routeGood ? const Color(0xFF58E8FF) : const Color(0xFF877FAE), 60),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildTarget(Size size) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: (d) => _targetTap(d, size),
      child: AnimatedBuilder(
        animation: _controller,
        builder: (_, __) {
          final x = 38 + _controller.value * (size.width - 76);
          final y = size.height * (.38 + .12 * math.sin(_controller.value * math.pi * 2));
          return Stack(
            children: [
              const Center(child: Icon(Icons.touch_app_rounded, color: Color(0x4458E8FF), size: 86)),
              Positioned(left: x - 30, top: y - 30, child: _node('✦', const Color(0xFF5CFFB5), 60)),
            ],
          );
        },
      ),
    );
  }

  Widget _buildMemory(Size size) {
    final pts = <Offset>[
      Offset(size.width * .28, size.height * .30),
      Offset(size.width * .72, size.height * .30),
      Offset(size.width * .28, size.height * .68),
      Offset(size.width * .72, size.height * .68),
    ];
    return Stack(
      children: [
        for (var i = 0; i < pts.length; i++)
          Positioned(
            left: pts[i].dx - 31,
            top: pts[i].dy - 31,
            child: GestureDetector(
              onTap: () => _memoryTap(i),
              child: _node(
                _memoryPreview
                    ? () {
                        final indexes = <int>[];
                        for (var j = 0; j < _memorySequence.length; j++) {
                          if (_memorySequence[j] == i) indexes.add(j + 1);
                        }
                        return indexes.isEmpty ? '•' : indexes.join('');
                      }()
                    : '${i + 1}',
                _memoryPreview && _memorySequence.contains(i) ? const Color(0xFFFFDF63) : const Color(0xFF6EDFFF),
                62,
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildTiming(Size size) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: _timingTap,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (_, __) {
          final x = size.width * (.10 + .80 * _controller.value);
          final zone = _correct == 0 ? .22 : (_correct == 1 ? .16 : .11);
          return Stack(
            children: [
              Positioned(
                left: size.width * (.5 - zone),
                top: size.height * .43,
                width: size.width * zone * 2,
                height: 42,
                child: Container(
                  decoration: BoxDecoration(
                    color: const Color(0x44FFD85C),
                    border: Border.all(color: const Color(0xFFFFD85C), width: 3),
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
              ),
              Positioned(left: x - 18, top: size.height * .415, child: _node('●', const Color(0xFF58E8FF), 38)),
              Positioned(
                left: size.width * .23,
                right: size.width * .23,
                bottom: size.height * .18,
                child: const Text('画面をタップして CONNECT！', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildRescue(Size size) {
    final left = _rescueLeft(size);
    final right = _rescueRight(size);
    const labels = <String>['★', '●', '▲'];
    const targetLabels = <String>['▲', '★', '●'];
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onPanStart: (d) => _rescueStart(d, size),
      onPanUpdate: _rescueUpdate,
      onPanEnd: (d) => _rescueEnd(d, size),
      onPanCancel: () => setState(() { _rescueFrom = null; _dragPoint = null; }),
      child: Stack(
        children: [
          Positioned.fill(
            child: CustomPaint(
              painter: _MiniGameLinePainter(
                start: _rescueFrom == null ? null : left[_rescueFrom!],
                end: _dragPoint,
                completed: [
                  for (final i in _rescued) (left[i], right[<int>[1, 2, 0][i]])
                ],
              ),
            ),
          ),
          for (var i = 0; i < left.length; i++)
            Positioned(left: left[i].dx - 30, top: left[i].dy - 30, child: Opacity(opacity: _rescued.contains(i) ? .35 : 1, child: _node(labels[i], const Color(0xFF5CFFB5), 60))),
          for (var i = 0; i < right.length; i++)
            Positioned(left: right[i].dx - 30, top: right[i].dy - 30, child: _node(targetLabels[i], const Color(0xFFFFC55E), 60)),
        ],
      ),
    );
  }

  Widget _node(String text, Color color, double size) {
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: const Color(0xFF20194A),
        border: Border.all(color: color, width: 3),
        boxShadow: [BoxShadow(color: color.withValues(alpha: .25), blurRadius: 12)],
      ),
      child: Text(text, style: TextStyle(color: color, fontSize: size * .38, fontWeight: FontWeight.w900)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0B1025),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
              child: Row(
                children: [
                  IconButton(onPressed: _locked ? null : () => Navigator.of(context).pop(_reward), icon: const Icon(Icons.close, color: Colors.white)),
                  Expanded(child: Text(_miniTitle(widget.type), textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900))),
                  const SizedBox(width: 48),
                ],
              ),
            ),
            Text(_message, textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFFFFE66D), fontSize: 17, fontWeight: FontWeight.w900)),
            const SizedBox(height: 5),
            Text('$_reward / 4000', style: const TextStyle(color: Color(0xFFA9E8FF), fontSize: 15, fontWeight: FontWeight.w900)),
            const SizedBox(height: 10),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 18),
                child: LayoutBuilder(
                  builder: (context, c) {
                    final size = Size(c.maxWidth, c.maxHeight);
                    Widget game;
                    switch (widget.type) {
                      case _MiniGameType.route:
                        game = _buildRoute(size);
                        break;
                      case _MiniGameType.target:
                        game = _buildTarget(size);
                        break;
                      case _MiniGameType.memory:
                        game = _buildMemory(size);
                        break;
                      case _MiniGameType.timing:
                        game = _buildTiming(size);
                        break;
                      case _MiniGameType.rescue:
                        game = _buildRescue(size);
                        break;
                    }
                    return Container(
                      clipBehavior: Clip.antiAlias,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(26),
                        gradient: const LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [Color(0xFF24175A), Color(0xFF120D35)],
                        ),
                        border: Border.all(color: const Color(0xFF6257A8), width: 3),
                      ),
                      child: game,
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MiniGameLinePainter extends CustomPainter {
  const _MiniGameLinePainter({required this.start, required this.end, required this.completed});
  final Offset? start;
  final Offset? end;
  final List<(Offset, Offset)> completed;

  @override
  void paint(Canvas canvas, Size size) {
    final donePaint = Paint()..color = const Color(0xFF5CFFB5)..strokeWidth = 5..strokeCap = StrokeCap.round;
    for (final pair in completed) {
      canvas.drawLine(pair.$1, pair.$2, donePaint);
    }
    if (start != null && end != null) {
      canvas.drawLine(start!, end!, Paint()..color = const Color(0xFFFFE66D)..strokeWidth = 6..strokeCap = StrokeCap.round);
    }
  }

  @override
  bool shouldRepaint(covariant _MiniGameLinePainter oldDelegate) =>
      oldDelegate.start != start || oldDelegate.end != end || oldDelegate.completed.length != completed.length;
}

class _SuruBoardPainter extends CustomPainter {
  const _SuruBoardPainter({
    required this.pieces,
    required this.flashes,
    required this.bursts,
    required this.hub,
    required this.ports,
    required this.pegs,
    required this.letterBumpers,
    required this.starBumper,
    required this.pockets,
    required this.separators,
    required this.playRect,
    required this.pieceRadius,
    required this.pegRadius,
    required this.manualFinger,
    required this.manualHoverPort,
    required this.rewardTokens,
    required this.rewardCounter,
    required this.expBeamStartedAt,
    required this.expBeamAmount,
    required this.expTransferApplied,
    required this.expTransferDurationMs,
    required this.centerPocketHits,
  });

  final List<_DropPiece> pieces;
  final List<_ConnectionFlash> flashes;
  final List<_PocketBurst> bursts;
  final Offset hub;
  final List<Offset> ports;
  final List<Offset> pegs;
  final List<({String label, Offset center})> letterBumpers;
  final Offset starBumper;
  final List<Offset> pockets;
  final List<double> separators;
  final Rect playRect;
  final double pieceRadius;
  final double pegRadius;
  final Offset? manualFinger;
  final int? manualHoverPort;
  final List<_RewardToken> rewardTokens;
  final int rewardCounter;
  final DateTime? expBeamStartedAt;
  final int expBeamAmount;
  final int expTransferApplied;
  final int expTransferDurationMs;
  final int centerPocketHits;

  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          Color(0xFF172145),
          Color(0xFF25164B),
          Color(0xFF371654),
          Color(0xFF14152D),
        ],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, bg);

    // Decorative stars / light speckles.
    final sparkle = Paint()..color = const Color(0x447EC8FF);
    for (var i = 0; i < 34; i++) {
      final x = (i * 71.0) % size.width;
      final y =
          (28 + ((i * 137.0) % math.max(50.0, size.height - 80))).toDouble();
      canvas.drawCircle(Offset(x, y), i % 5 == 0 ? 1.8 : .8, sparkle);
    }

    final machineRect = Rect.fromLTRB(
      playRect.left,
      math.max(8.0, hub.dy - 34),
      playRect.right,
      math.min(size.height - 4, playRect.bottom + 155),
    );
    final arena = RRect.fromRectAndRadius(
      machineRect,
      const Radius.circular(28),
    );
    canvas.drawRRect(
      arena,
      Paint()..color = const Color(0x99200F4A),
    );
    canvas.drawRRect(
      arena,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 5
        ..color = const Color(0xFFFFA52D),
    );
    canvas.drawRRect(
      arena.deflate(6),
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = const Color(0xFFFFE072),
    );

    _drawRewardCounter(canvas);
    _drawConnectionArea(canvas);
    _drawPegs(canvas);
    _drawLetterBumpers(canvas);
    _drawStar(canvas);
    _drawPocketArea(canvas);
    _drawCenterPocketCount(canvas);
    _drawTrails(canvas);
    _drawPieces(canvas);
    _drawBursts(canvas);
    _drawRewardTransfers(canvas, size);
  }

  Offset get _counterCenter =>
      Offset(playRect.center.dx, playRect.top + 34);

  void _drawRewardCounter(Canvas canvas) {
    final center = _counterCenter;
    final rect = RRect.fromRectAndRadius(
      Rect.fromCenter(
        center: center,
        width: math.min(220.0, playRect.width * .72),
        height: 54,
      ),
      const Radius.circular(16),
    );

    canvas.drawRRect(
      rect.inflate(7),
      Paint()
        ..color = const Color(0x44FFBF32)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12),
    );
    canvas.drawRRect(
      rect,
      Paint()
        ..shader = const LinearGradient(
          colors: [
            Color(0xFF5B210B),
            Color(0xFF1B101C),
            Color(0xFF5B210B),
          ],
        ).createShader(rect.outerRect),
    );
    canvas.drawRRect(
      rect,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 4
        ..color = const Color(0xFFFFB733),
    );

    // LED dots.
    final dotPaint = Paint()..color = const Color(0x44FFB432);
    for (var row = 0; row < 4; row++) {
      for (var col = 0; col < 21; col++) {
        canvas.drawCircle(
          Offset(
            rect.left + 10 + col * (rect.width - 20) / 20,
            rect.top + 9 + row * 12,
          ),
          1.1,
          dotPaint,
        );
      }
    }

    final shown = rewardCounter + math.max(0, expBeamAmount - expTransferApplied);
    final tp = TextPainter(
      text: TextSpan(
        text: '$shown',
        style: const TextStyle(
          color: Color(0xFFFFF4BA),
          fontSize: 29,
          fontWeight: FontWeight.w900,
          shadows: [
            Shadow(color: Color(0xFFFF8B1F), blurRadius: 9),
            Shadow(color: Colors.black, blurRadius: 3),
          ],
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(
      canvas,
      center - Offset(tp.width / 2, tp.height / 2),
    );
  }

  void _drawRewardTransfers(Canvas canvas, Size size) {
    final now = DateTime.now();
    final counter = _counterCenter;

    // Reward stars fly from the hit/pocket location into the counter.
    for (final token in rewardTokens) {
      if (token.arrived) continue;
      final elapsed = now.difference(token.startedAt).inMilliseconds;
      final t = (elapsed / 430).clamp(0.0, 1.0);
      final eased = Curves.easeOutCubic.transform(t);
      final control = Offset(
        (token.origin.dx + counter.dx) / 2,
        math.min(token.origin.dy, counter.dy) - 55,
      );
      final oneMinus = 1 - eased;
      final pos =
          token.origin * (oneMinus * oneMinus) +
          control * (2 * oneMinus * eased) +
          counter * (eased * eased);

      canvas.drawCircle(
        pos,
        18,
        Paint()
          ..color = const Color(0x55FFE15A)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10),
      );

      final star = TextPainter(
        text: const TextSpan(
          text: '★',
          style: TextStyle(
            color: Color(0xFFFFE55C),
            fontSize: 19,
            fontWeight: FontWeight.w900,
            shadows: [
              Shadow(color: Color(0xFFFF8E1A), blurRadius: 6),
            ],
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      star.paint(canvas, pos - Offset(star.width / 2, star.height / 2));

      final number = TextPainter(
        text: TextSpan(
          text: '${token.amount}',
          style: const TextStyle(
            color: Colors.white,
            fontSize: 9,
            fontWeight: FontWeight.w900,
            shadows: [
              Shadow(color: Colors.black, blurRadius: 3),
            ],
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      number.paint(
        canvas,
        pos + Offset(10, -number.height / 2),
      );
    }

    // The counter converts into a light beam that flies toward the EXP gauge.
    if (expBeamStartedAt != null && expBeamAmount > 0) {
      final elapsed = now.difference(expBeamStartedAt!).inMilliseconds;
      final duration = math.max(1, expTransferDurationMs);
      final t = (elapsed / duration).clamp(0.0, 1.0);
      final eased = Curves.easeInOutCubic.transform(t);
      final target = Offset(size.width * .58, -18);
      final pos = Offset.lerp(counter, target, eased)!;

      canvas.drawLine(
        counter,
        pos,
        Paint()
          ..color = const Color(0x55FFF29A)
          ..strokeWidth = 13 * (1 - t) + 3
          ..strokeCap = StrokeCap.round
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10),
      );
      canvas.drawLine(
        counter,
        pos,
        Paint()
          ..color = const Color(0xFFFFF8CB)
          ..strokeWidth = 3.5
          ..strokeCap = StrokeCap.round,
      );
      canvas.drawCircle(
        pos,
        9,
        Paint()
          ..color = const Color(0xFFFFFFD6)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5),
      );
    }
  }

  void _drawConnectionArea(Canvas canvas) {
    canvas.drawCircle(
      hub,
      22,
      Paint()
        ..color = const Color(0x5546B5FF)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 14),
    );
    canvas.drawCircle(
      hub,
      17,
      Paint()..color = const Color(0xFF2C1C65),
    );
    canvas.drawCircle(
      hub,
      17,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.4
        ..color = const Color(0xFFA3E7FF),
    );

    final hubText = TextPainter(
      text: const TextSpan(
        text: '手動',
        style: TextStyle(
          color: Colors.white,
          fontSize: 7,
          fontWeight: FontWeight.w900,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    hubText.paint(
      canvas,
      hub - Offset(hubText.width / 2, hubText.height / 2),
    );

    final guide = Paint()
      ..color = const Color(0x3358BFFF)
      ..strokeWidth = 1.2;
    for (final port in ports) {
      canvas.drawLine(hub, port, guide);
    }

    final now = DateTime.now();
    for (final flash in flashes) {
      if (flash.port < 0 || flash.port >= ports.length) continue;
      final elapsed = now.difference(flash.startedAt).inMilliseconds;
      final t = (elapsed / 450).clamp(0.0, 1.0);
      final a = ((1 - t) * 255).round().clamp(0, 255);

      canvas.drawLine(
        hub,
        ports[flash.port],
        Paint()
          ..color = Color.fromARGB(a ~/ 2, 81, 206, 255)
          ..strokeWidth = 12
          ..strokeCap = StrokeCap.round
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8),
      );
      canvas.drawLine(
        hub,
        ports[flash.port],
        Paint()
          ..color = Color.fromARGB(a, 214, 250, 255)
          ..strokeWidth = 3.2
          ..strokeCap = StrokeCap.round,
      );
    }

    if (manualFinger != null) {
      final to = manualHoverPort == null
          ? manualFinger!
          : ports[manualHoverPort!];
      canvas.drawLine(
        hub,
        to,
        Paint()
          ..color = const Color(0xFFFFE25C)
          ..strokeWidth = 5
          ..strokeCap = StrokeCap.round,
      );
    }

    for (var i = 0; i < ports.length; i++) {
      final selected = i == manualHoverPort;
      final p = ports[i];

      canvas.drawCircle(
        p,
        selected ? 5.5 : 3.2,
        Paint()
          ..color = const Color(0x5526AFFF)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
      );
      canvas.drawCircle(
        p,
        selected ? 4.5 : 2.5,
        Paint()..color = const Color(0xFF0E1021),
      );
      canvas.drawCircle(
        p,
        selected ? 4.5 : 2.5,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = selected ? 2.0 : 1.2
          ..color = selected
              ? const Color(0xFFFFE86A)
              : const Color(0xFF8FDAFF),
      );
    }
  }

  void _drawPegs(Canvas canvas) {
    for (final p in pegs) {
      canvas.drawCircle(
        p + const Offset(0, 1.2),
        pegRadius + 1.2,
        Paint()..color = const Color(0x55000000),
      );
      canvas.drawCircle(
        p,
        pegRadius + 1.4,
        Paint()
          ..shader = const RadialGradient(
            center: Alignment(-.35, -.35),
            colors: [
              Color(0xFFFFF2C2),
              Color(0xFFFFC247),
              Color(0xFF9A5A12),
            ],
          ).createShader(
            Rect.fromCircle(center: p, radius: pegRadius + 1.4),
          ),
      );
      canvas.drawCircle(
        p,
        pegRadius + 1.4,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = .8
          ..color = const Color(0xFFFFE89A),
      );
    }
  }

  void _drawLetterBumpers(Canvas canvas) {
    for (final bumper in letterBumpers) {
      final p = bumper.center;
      final isU = bumper.label == 'U';
      final ringColor =
          isU ? const Color(0xFF64DFFF) : const Color(0xFFFF63C8);

      canvas.drawCircle(
        p,
        16,
        Paint()
          ..color = ringColor.withOpacity(.18)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5),
      );
      canvas.drawCircle(
        p,
        13,
        Paint()
          ..shader = const RadialGradient(
            colors: [
              Color(0xFF432A79),
              Color(0xFF171226),
            ],
          ).createShader(
            Rect.fromCircle(center: p, radius: 13),
          ),
      );
      canvas.drawCircle(
        p,
        13,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.6
          ..color = ringColor,
      );

      final tp = TextPainter(
        text: TextSpan(
          text: bumper.label,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 14,
            fontWeight: FontWeight.w900,
            shadows: [
              Shadow(color: Colors.black, blurRadius: 3),
            ],
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();

      tp.paint(
        canvas,
        p - Offset(tp.width / 2, tp.height / 2),
      );
    }
  }

  void _drawStar(Canvas canvas) {
    canvas.drawCircle(
      starBumper,
      35,
      Paint()
        ..color = const Color(0x55FF4CE3)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12),
    );
    canvas.drawCircle(
      starBumper,
      25,
      Paint()
        ..shader = const RadialGradient(
          colors: [
            Color(0xFFFF89ED),
            Color(0xFF8F42D9),
            Color(0xFF46247C),
          ],
        ).createShader(
          Rect.fromCircle(center: starBumper, radius: 25),
        ),
    );
    canvas.drawCircle(
      starBumper,
      25,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 4
        ..color = const Color(0xFFFFDF63),
    );

    final tp = TextPainter(
      text: const TextSpan(
        text: '★',
        style: TextStyle(
          color: Colors.white,
          fontSize: 27,
          fontWeight: FontWeight.w900,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(
      canvas,
      starBumper - Offset(tp.width / 2, tp.height / 2),
    );
  }

  void _drawMiniGameGuards(Canvas canvas) {
    final cx = playRect.center.dx;
    final hole = Offset(cx, playRect.bottom - 82);

    // Exact scoring marker: the BRIGHT INNER OVAL is the suction hit area.
    // Outside glow is intentionally faint so the player reads the inner ring
    // as the only target.
    final hitRect = Rect.fromCenter(center: hole, width: 22, height: 12);
    canvas.drawOval(
      Rect.fromCenter(center: hole, width: 27, height: 17),
      Paint()
        ..color = const Color(0x335C27D9)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 7),
    );
    canvas.drawOval(
      hitRect,
      Paint()
        ..shader = const RadialGradient(
          colors: [
            Color(0xFF47107E),
            Color(0xFF160329),
            Color(0xFF020106),
          ],
        ).createShader(hitRect),
    );
    canvas.drawOval(
      hitRect,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.6
        ..color = const Color(0xFFF0D6FF),
    );

    // Straight-drop blocker. Clearly separate from the hole.
    final blockerY = playRect.bottom - 112;
    final blockerA = Offset(cx - 20, blockerY);
    final blockerB = Offset(cx + 20, blockerY);
    canvas.drawLine(
      blockerA,
      blockerB,
      Paint()
        ..color = const Color(0x5546C8FF)
        ..strokeWidth = 11
        ..strokeCap = StrokeCap.round
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5),
    );
    canvas.drawLine(
      blockerA,
      blockerB,
      Paint()
        ..color = const Color(0xFFFFE7B0)
        ..strokeWidth = 6
        ..strokeCap = StrokeCap.round,
    );
    canvas.drawLine(
      blockerA,
      blockerB,
      Paint()
        ..color = const Color(0xFF7A5260)
        ..strokeWidth = 3
        ..strokeCap = StrokeCap.round,
    );

    // Only two side rails. No lower rails overlapping the hole.
    final guards = <({Offset a, Offset b})>[
      (
        a: Offset(cx - 58, playRect.bottom - 108),
        b: Offset(cx - 27, playRect.bottom - 88),
      ),
      (
        a: Offset(cx + 58, playRect.bottom - 108),
        b: Offset(cx + 27, playRect.bottom - 88),
      ),
    ];
    for (final g in guards) {
      canvas.drawLine(
        g.a,
        g.b,
        Paint()
          ..color = const Color(0x5546C8FF)
          ..strokeWidth = 11
          ..strokeCap = StrokeCap.round
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5),
      );
      canvas.drawLine(
        g.a,
        g.b,
        Paint()
          ..color = const Color(0xFFFFE7B0)
          ..strokeWidth = 6
          ..strokeCap = StrokeCap.round,
      );
      canvas.drawLine(
        g.a,
        g.b,
        Paint()
          ..color = const Color(0xFF7A5260)
          ..strokeWidth = 3
          ..strokeCap = StrokeCap.round,
      );
    }

  }

  void _drawPocketArea(Canvas canvas) {
    final pocketWidth = playRect.width / 5;
    final top = playRect.bottom - 76;
    final bottom = playRect.bottom + 2;

    // Separator walls.
    for (final x in separators) {
      final wall = RRect.fromRectAndRadius(
        Rect.fromLTWH(x - 4, top, 8, bottom - top),
        const Radius.circular(4),
      );
      canvas.drawRRect(
        wall,
        Paint()..color = const Color(0xFFFFC14D),
      );
      canvas.drawRRect(
        wall,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5
          ..color = Colors.white,
      );
    }

    const labels = <String>[
      '100',
      '200',
      '',
      '200',
      '100',
    ];
    const baseColors = <Color>[
      Color(0xFF1D7DDF),
      Color(0xFF3AAA57),
      Color(0xFFD63C72),
      Color(0xFF3AAA57),
      Color(0xFF1D7DDF),
    ];

    for (var i = 0; i < 5; i++) {
      final left = playRect.left + i * pocketWidth + 4;
      final rect = RRect.fromRectAndRadius(
        Rect.fromLTWH(
          left,
          playRect.bottom - 64,
          pocketWidth - 8,
          58,
        ),
        const Radius.circular(10),
      );

      canvas.drawRRect(rect, Paint()..color = baseColors[i]);
      canvas.drawRRect(
        rect,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.5
          ..color = const Color(0xFFFFE06E),
      );

      final tp = TextPainter(
        text: TextSpan(
          text: labels[i],
          style: const TextStyle(
            color: Colors.white,
            fontSize: 10,
            height: 1.0,
            fontWeight: FontWeight.w900,
            shadows: [
              Shadow(
                color: Colors.black,
                blurRadius: 3,
              ),
            ],
          ),
        ),
        textAlign: TextAlign.center,
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(
        canvas,
        Offset(
          left + (pocketWidth - 8 - tp.width) / 2,
          playRect.bottom - 52,
        ),
      );
    }
  }

  void _drawCenterPocketCount(Canvas canvas) {
    final pocketWidth = playRect.width / 5;
    final center = Offset(
      playRect.left + pocketWidth * 2.5,
      playRect.bottom - 35,
    );

    final tp = TextPainter(
      text: TextSpan(
        text: centerPocketHits > 0 ? '×$centerPocketHits' : '×0',
        style: TextStyle(
          color: centerPocketHits > 0
              ? const Color(0xFFFFF06B)
              : const Color(0x99FFFFFF),
          fontSize: centerPocketHits > 0 ? 18 : 16,
          fontWeight: FontWeight.w900,
          shadows: const [
            Shadow(color: Colors.black, blurRadius: 5),
          ],
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();

    tp.paint(
      canvas,
      center - Offset(tp.width / 2, tp.height / 2),
    );
  }

  void _drawTrails(Canvas canvas) {
    for (final p in pieces) {
      if (p.trail.length < 2) continue;

      for (var i = 1; i < p.trail.length; i++) {
        final t = i / p.trail.length;
        canvas.drawLine(
          p.trail[i - 1],
          p.trail[i],
          Paint()
            ..color = Color.fromARGB(
              (38 + 90 * t).round(),
              103,
              214,
              255,
            )
            ..strokeWidth = 1.2 + t * 2
            ..strokeCap = StrokeCap.round,
        );
      }
    }
  }

  void _drawPieces(Canvas canvas) {
    for (final p in pieces) {
      canvas.save();
      canvas.translate(p.x, p.y);
      canvas.rotate(p.angle);

      canvas.drawCircle(
        Offset.zero,
        pieceRadius * 1.75,
        Paint()
          ..color = const Color(0x4468D8FF)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5),
      );

      final s = pieceRadius * 2;
      canvas.translate(-pieceRadius, -pieceRadius);
      _MiniCharacterPainter(type: p.type).paint(
        canvas,
        Size(s, s),
      );
      canvas.restore();
    }
  }

  void _drawBursts(Canvas canvas) {
    final now = DateTime.now();

    for (final b in bursts) {
      final elapsed = now.difference(b.startedAt).inMilliseconds;
      final duration = b.kind == 4 ? 1400.0 : b.kind == 5 ? 950.0 : 720.0;
      final t = (elapsed / duration).clamp(0.0, 1.0);
      final alpha = ((1 - t) * 255).round().clamp(0, 255);
      final radius = b.kind == 4 ? 24 + 72 * t : b.kind == 5 ? 18 + 50 * t : 12 + 34 * t;

      canvas.drawCircle(
        b.center,
        radius,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 4 * (1 - t) + 1
          ..color = Color.fromARGB(
            alpha,
            b.kind == 5 ? 255 : b.kind == 3 ? 255 : 118,
            b.kind == 5 ? 225 : b.kind == 3 ? 108 : 221,
            b.kind == 5 ? 75 : 255,
          ),
      );

      for (var i = 0; i < 8; i++) {
        final a = i * math.pi / 4 + t * .8;
        final p = b.center +
            Offset(math.cos(a), math.sin(a)) * (10 + 38 * t);
        canvas.drawCircle(
          p,
          2.5 * (1 - t) + .8,
          Paint()
            ..color = Color.fromARGB(
              alpha,
              255,
              b.kind == 2 ? 226 : 185,
              82,
            ),
        );
      }

      final tp = TextPainter(
        text: TextSpan(
          text: b.text,
          style: TextStyle(
            color: Color.fromARGB(alpha, 255, 255, 255),
            fontSize: b.kind == 4
                ? 18 + 7 * (1 - t)
                : b.kind == 5
                    ? 20 + 8 * (1 - t)
                    : 11 + 5 * (1 - t),
            fontWeight: FontWeight.w900,
            shadows: [
              Shadow(
                color: Color.fromARGB(
                  (alpha * .78).round().clamp(0, 255),
                  0,
                  0,
                  0,
                ),
                blurRadius: 4,
              ),
            ],
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();

      tp.paint(
        canvas,
        b.center +
            Offset(
              -tp.width / 2,
              b.kind == 4 ? -48 - t * 30 : -34 - t * 24,
            ),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _SuruBoardPainter oldDelegate) => true;
}

class _MiniCharacterPainter extends CustomPainter {
  const _MiniCharacterPainter({required this.type});

  final int type;

  Paint _gloss(
    Color light,
    Color base,
    Color dark,
    Offset c,
    double r,
  ) {
    return Paint()
      ..shader = RadialGradient(
        center: const Alignment(-.34, -.42),
        radius: 1.05,
        colors: [light, base, dark],
        stops: const [0, .55, 1],
      ).createShader(Rect.fromCircle(center: c, radius: r));
  }

  void _eyes(Canvas canvas, Offset c, double r) {
    final p = Paint()..color = const Color(0xFF202020);
    canvas.drawCircle(c + Offset(-r * .25, -r * .08), r * .085, p);
    canvas.drawCircle(c + Offset(r * .25, -r * .08), r * .085, p);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = math.min(size.width, size.height) / 2;

    switch (type % 5) {
      case 0:
        canvas.drawCircle(
          c,
          r * .82,
          _gloss(
            const Color(0xFFFFF08A),
            const Color(0xFFFFC928),
            const Color(0xFFE79A00),
            c,
            r,
          ),
        );
        _eyes(canvas, c, r);
        break;
      case 1:
        final body = _gloss(
          const Color(0xFFA6F3A9),
          const Color(0xFF63D46B),
          const Color(0xFF2C9A42),
          c,
          r,
        );
        canvas.drawCircle(c, r * .82, body);
        canvas.drawCircle(
          c + Offset(-r * .42, -r * .54),
          r * .22,
          body,
        );
        canvas.drawCircle(
          c + Offset(r * .42, -r * .54),
          r * .22,
          body,
        );
        _eyes(canvas, c, r);
        break;
      case 2:
        canvas.drawCircle(
          c,
          r * .82,
          _gloss(
            const Color(0xFF9DE1FF),
            const Color(0xFF4F9ED8),
            const Color(0xFF2464A8),
            c,
            r,
          ),
        );
        canvas.drawOval(
          Rect.fromCenter(
            center: c + Offset(0, r * .18),
            width: r * .98,
            height: r * 1.05,
          ),
          Paint()..color = const Color(0xFFEAF6FF),
        );
        _eyes(canvas, c, r);
        break;
      case 3:
        final ear = Paint()..color = const Color(0xFF7453B7);
        canvas.drawOval(
          Rect.fromCenter(
            center: c + Offset(-r * .63, -r * .12),
            width: r * .36,
            height: r * .65,
          ),
          ear,
        );
        canvas.drawOval(
          Rect.fromCenter(
            center: c + Offset(r * .63, -r * .12),
            width: r * .36,
            height: r * .65,
          ),
          ear,
        );
        canvas.drawCircle(
          c,
          r * .82,
          _gloss(
            const Color(0xFFE4D7FF),
            const Color(0xFFBFA8F2),
            const Color(0xFF8060C7),
            c,
            r,
          ),
        );
        _eyes(canvas, c, r);
        break;
      default:
        final body = _gloss(
          const Color(0xFFFFE2EE),
          const Color(0xFFFFA7C7),
          const Color(0xFFE66B9B),
          c,
          r,
        );
        canvas.drawOval(
          Rect.fromCenter(
            center: c + Offset(-r * .27, -r * .72),
            width: r * .28,
            height: r * .72,
          ),
          body,
        );
        canvas.drawOval(
          Rect.fromCenter(
            center: c + Offset(r * .27, -r * .72),
            width: r * .28,
            height: r * .72,
          ),
          body,
        );
        canvas.drawCircle(
          c + Offset(0, r * .06),
          r * .76,
          body,
        );
        _eyes(canvas, c + Offset(0, r * .04), r);
        break;
    }
  }

  @override
  bool shouldRepaint(covariant _MiniCharacterPainter oldDelegate) =>
      oldDelegate.type != type;
}
