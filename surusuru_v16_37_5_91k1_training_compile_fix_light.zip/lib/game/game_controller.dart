import 'dart:convert';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'game_state.dart';

class GameController extends ChangeNotifier {
  static const String _saveKey = 'yuru_merge_world_v1_save';
  static const String _collectionKey = 'yuru_merge_world_v1_collection';
  static const String _dailyClaimKey = 'yuru_merge_world_v1_daily_claim';
  static const String _dailyStreakKey = 'yuru_merge_world_v1_daily_streak';
  static const String _missionDateKey = 'yuru_merge_world_v1_mission_date';
  static const String _missionSpawnKey = 'yuru_merge_world_v1_mission_spawn';
  static const String _missionMergeKey = 'yuru_merge_world_v1_mission_merge';
  static const String _missionClaimKey = 'yuru_merge_world_v1_mission_claim';
  static const String _missionFeaturedSpawnKey = 'suru_merge_world_v1_mission_featured_spawn';
  static const String _missionOrderKey = 'suru_merge_world_v1_mission_orders';
  static const String _missionFeaturedGeneratorKey = 'suru_merge_world_v1_mission_featured_generator';
  static const String _tutorialKey = 'suru_merge_world_v1_tutorial_v2';
  static const String _orderLevelKey = 'suru_merge_world_v1_order_level_v2';
  static const String _orderPlanVersionKey = 'suru_merge_world_v1_order_plan_version';
  static const String _claimedLevelRewardsKey = 'suru_merge_world_v1_claimed_level_rewards_v12';
  static const String _unlockedBoardCellsKey = 'suru_merge_world_v1_unlocked_board_cells_v12';
  static const String _clearedStagesKey = 'suru_merge_world_v1_cleared_stages_v16';
  static const String _unlockedPlacesKey = 'suru_merge_world_v1_unlocked_places_v16';
  static const String _stageRequestStepsKey = 'suru_merge_world_v1_stage_request_steps_v16_12';
  static const String _stageSecretsKey = 'suru_merge_world_v1_stage_secrets_v16_15';
  static const String _secretRewardStagesKey = 'suru_merge_world_v1_secret_reward_stages_v16_15';
  static const String _ownedHomeItemsKey = 'surusuru_owned_home_items_v1';
  static const String _placedHomeItemsKey = 'surusuru_placed_home_items_v1';
  static const String _ownedClothesKey = 'surusuru_owned_clothes_v1';
  static const String _equippedClothesKey = 'surusuru_equipped_clothes_v1';
  static const String _puzzleBestChainKey = 'surusuru_puzzle_best_chain_v1';
  static const String _puzzleTotalClearedKey = 'surusuru_puzzle_total_cleared_v1';
  static const String _suruStickerKey = 'surusuru_stickers_v1';
  static const String _suruDailyDateKey = 'surusuru_daily_date_v1';
  static const String _suruDailyStageCountKey = 'surusuru_daily_stage_count_v1';
  static const String _suruDailyChestClaimedKey = 'surusuru_daily_chest_claimed_v1';
  static const String _suruAreaBoostsKey = 'surusuru_area_boosts_v1';
  static const String _suruAreaIdKey = 'surusuru_area_id_v1';
  static const String _suruBuildCreditsKey = 'surusuru_build_credits_v1';
  static const String _surusuruBalanceKey = 'surusuru_play_balance_v1';
  static const String _skillMaterialsKey = 'surusuru_skill_materials_v1';
  static const String _skillLevelsKey = 'surusuru_skill_levels_v1';

  static const int generatorCell = 24; // starter farm basket
  static const Map<String, int> generatorCells = <String, int>{
    'farm': 24,
    'drink': 30,
    'sweet': 18,
    'flower': 39,
    'kitchen': 9,
  };
  static const Map<String, int> generatorUnlockLevels = <String, int>{
    'farm': 1,
    'drink': 3,
    'sweet': 5,
    'flower': 7,
    'kitchen': 9,
  };
  static const Map<int, int> blockedUnlockLevels = <int, int>{
    3: 2,
    8: 4,
    12: 6,
    36: 8,
    40: 9,
    45: 10,
  };
  static Set<int> get blockedCells => blockedUnlockLevels.keys.toSet();
  static const Set<int> worldRewardLevels = <int>{2, 3, 5, 6, 7, 9, 10};

  final Set<int> claimedLevelRewards = <int>{1};
  final Set<int> unlockedBoardCells = <int>{};
  final Set<int> clearedStages = <int>{};
  final Set<String> unlockedPlaces = <String>{'home'};
  final Map<int, int> stageRequestSteps = <int, int>{};
  final Map<int, Set<int>> stageSecrets = <int, Set<int>>{};
  final Set<int> secretRewardStages = <int>{};

  int stageSecretCount(int stageId) => stageSecrets[stageId]?.length ?? 0;
  bool stageSecretFound(int stageId, int secretId) =>
      stageSecrets[stageId]?.contains(secretId) ?? false;
  bool stageSecretsComplete(int stageId) => stageSecretCount(stageId) >= 5;
  bool secretTownRewardUnlocked(int stageId) =>
      secretRewardStages.contains(stageId);


  int stageRequestStep(int stageId) => stageRequestSteps[stageId] ?? 0;
  static const int stageRequestCount = 3;
  static int stageRequestCountForStage(int stageId) => stageId == 1 ? 20 : stageRequestCount;

  bool stageCleared(int stageId) => clearedStages.contains(stageId);
  bool stageAvailable(int stageId) => stageId == 1 || clearedStages.contains(stageId - 1) || clearedStages.contains(stageId);

  bool placeUnlocked(String id) => id == 'home' || unlockedPlaces.contains(id);
  static const Map<String, int> placeUnlockMilestones = {'cafe':5, 'bakery':10, 'sweets':15, 'flower':20, 'goods':25};
  bool canUnlockPlace(String id) {
    final milestone = placeUnlockMilestones[id];
    return milestone != null && clearedStages.contains(milestone) && !placeUnlocked(id);
  }
  String? get nextPlaceReady {
    for (final id in const ['cafe','bakery','sweets','flower','goods']) {
      if (canUnlockPlace(id)) return id;
    }
    return null;
  }
  String placeTitle(String id) => switch (id) {
    'cafe' => '☕ ミミのカフェ',
    'bakery' => '🥐 ふわふわベーカリー',
    'sweets' => '🍰 おやつ工房',
    'flower' => '🌷 はなまる花店',
    'goods' => '🎁 ひみつ雑貨店',
    _ => '🏠 わたしのおうち',
  };

  Future<bool> unlockPlace(String id) async {
    if (!canUnlockPlace(id)) return false;
    unlockedPlaces.add(id);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_unlockedPlacesKey, unlockedPlaces.toList());
    notifyListeners();
    return true;
  }

  bool levelRewardClaimed(int level) => level == 1 || claimedLevelRewards.contains(level);

  bool generatorUnlocked(String id) {
    if (id == 'farm') return true;
    final level = generatorUnlockLevels[id] ?? 99;
    return claimedLevelRewards.contains(level);
  }

  bool canClaimWorldReward(int level) =>
      worldRewardLevels.contains(level) && state.level >= level && !levelRewardClaimed(level);

  int? get nextWorldRewardReady {
    final ready = worldRewardLevels.where(canClaimWorldReward).toList()..sort();
    return ready.isEmpty ? null : ready.first;
  }

  bool canUnlockBoardCell(int index) {
    final level = blockedUnlockLevels[index];
    return level != null && state.level >= level && !unlockedBoardCells.contains(index);
  }

  bool boardCellUnlocked(int index) => unlockedBoardCells.contains(index);

  bool allBoardCellsForLevelUnlocked(int level) {
    final cells = blockedUnlockLevels.entries.where((e) => e.value == level).map((e) => e.key).toList();
    if (cells.isEmpty) return true;
    return cells.every(unlockedBoardCells.contains);
  }

  bool isReservedCell(int index) {
    // V16.16: generator and locked-board cells are abolished.
    // Every board cell is now a normal puzzle cell.
    return false;
  }

  final Random _random = Random();

  GameState state = GameState.initial();

  // V16.18 slide-chain prototype state.
  static const List<int> slidePuzzleItemTypes = <int>[1, 2, 3, 4, 5];
  final List<int> nextItemsByColumn =
      List<int>.filled(GameState.boardColumns, 1);
  int activePuzzleStageId = -1;
  int lastChainCount = 0;
  final Set<int> chainFlashCells = <int>{};
  int activeChainStep = 0;

  bool loaded = false;

  final Set<String> ownedHomeItems = <String>{'rug_basic'};
  final Set<String> placedHomeItems = <String>{'rug_basic'};
  final Set<String> ownedClothes = <String>{'casual'};
  String equippedClothes = 'casual';
  int puzzleBestChain = 0;
  int puzzleTotalCleared = 0;

  // V16.28 prototype meta loop: stickers / daily chest / area-limited build.
  final Set<String> suruStickers = <String>{};
  String suruDailyDate = '';
  int suruDailyStageClears = 0;
  bool suruDailyChestClaimed = false;
  final Set<String> suruAreaBoosts = <String>{};
  int suruAreaId = 1;
  int suruBuildCredits = 0;
  String lastTreasureRewardText = '';

  static const List<String> suruStickerIds = <String>[
    'cake','bear','coffee','moon','ribbon','berry','crown','flower',
    'star','cloud','key','chest','frog','chick','penguin','pup',
    'bomb','line','lightning','rainbow','gem','coin','map','sparkle',
  ];
  static const Map<String, String> suruStickerEmoji = <String, String>{
    'cake':'🍰','bear':'🧸','coffee':'☕','moon':'🌙','ribbon':'🎀','berry':'🍓','crown':'👑','flower':'🌸',
    'star':'⭐','cloud':'☁️','key':'🔑','chest':'🧰','frog':'🐸','chick':'🐥','penguin':'🐧','pup':'🐶',
    'bomb':'💣','line':'➖','lightning':'⚡','rainbow':'🌈','gem':'💎','coin':'🪙','map':'🗺️','sparkle':'✨',
    'daily_star':'🌟',
  };
  static const Map<String, String> suruStickerName = <String, String>{
    'cake':'ごほうびケーキ','bear':'ちいさなくま','coffee':'ほっとコーヒー','moon':'おやすみムーン','ribbon':'ピンクリボン','berry':'いちご','crown':'きらきらクラウン','flower':'はなびら',
    'star':'ひかる星','cloud':'ふわふわ雲','key':'冒険のカギ','chest':'宝箱','frog':'カエル','chick':'ひよこ','penguin':'ペンギン','pup':'むらさきっこ',
    'bomb':'ボム','line':'ライン','lightning':'雷','rainbow':'虹','gem':'ジェム','coin':'コイン','map':'冒険マップ','sparkle':'SURUSURU','daily_star':'デイリースター',
  };

  static const Map<String, String> suruBoostName = <String, String>{
    'extra_moves':'じっくり設計',
    'special_seed':'特殊のタネ',
    'double_seed':'キラキラ準備',
    'treasure_bonus':'宝探し名人',
    'sticker_luck':'シール運UP',
    'balanced':'いい流れ',
  };
  static const Map<String, String> suruBoostDescription = <String, String>{
    'extra_moves':'各ステージの手数 +3',
    'special_seed':'開始時の特殊アイテム +1',
    'double_seed':'開始時の特殊アイテム +2',
    'treasure_bonus':'宝箱のコイン +75',
    'sticker_luck':'重複シール時に未所持を優先',
    'balanced':'手数 +1 / 開始特殊 +1',
  };
  static const List<String> suruBoostIds = <String>[
    'extra_moves','special_seed','double_seed','treasure_bonus','sticker_luck','balanced'
  ];

  int get suruExtraMoves => (suruAreaBoosts.contains('extra_moves') ? 3 : 0) + (suruAreaBoosts.contains('balanced') ? 1 : 0);
  int get suruStartingSpecialBonus => (suruAreaBoosts.contains('special_seed') ? 1 : 0) + (suruAreaBoosts.contains('double_seed') ? 2 : 0) + (suruAreaBoosts.contains('balanced') ? 1 : 0);
  int get suruTreasureCoinBonus => suruAreaBoosts.contains('treasure_bonus') ? 75 : 0;
  int get suruDailyProgress => suruDailyStageClears.clamp(0, 3).toInt();
  bool get canClaimSuruDailyChest => suruDailyProgress >= 3 && !suruDailyChestClaimed;

  Future<void> _saveSuruMetaLoop() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_suruStickerKey, suruStickers.toList());
    await prefs.setString(_suruDailyDateKey, suruDailyDate);
    await prefs.setInt(_suruDailyStageCountKey, suruDailyStageClears);
    await prefs.setBool(_suruDailyChestClaimedKey, suruDailyChestClaimed);
    await prefs.setStringList(_suruAreaBoostsKey, suruAreaBoosts.toList());
    await prefs.setInt(_suruAreaIdKey, suruAreaId);
    await prefs.setInt(_suruBuildCreditsKey, suruBuildCredits);
  }

  Future<void> _syncSuruDaily() async {
    final today = _dayKey(DateTime.now());
    if (suruDailyDate == today) return;
    suruDailyDate = today;
    suruDailyStageClears = 0;
    suruDailyChestClaimed = false;
    await _saveSuruMetaLoop();
  }

  Future<bool> chooseSuruAreaBoost(String id) async {
    if (!suruBoostIds.contains(id) || suruAreaBoosts.contains(id) || suruBuildCredits <= 0 || suruAreaBoosts.length >= 3) return false;
    suruAreaBoosts.add(id);
    suruBuildCredits--;
    await _saveSuruMetaLoop();
    notifyListeners();
    return true;
  }

  Future<bool> claimSuruDailyChest() async {
    await _syncSuruDaily();
    if (!canClaimSuruDailyChest) return false;
    suruDailyChestClaimed = true;
    state.coins += 250;
    suruStickers.add('daily_star');
    await _saveSuruMetaLoop();
    await save();
    notifyListeners();
    return true;
  }

  String _pickStageSticker(int stageId) {
    var index = (stageId * 7 + suruAreaId * 3) % suruStickerIds.length;
    var id = suruStickerIds[index];
    if (suruAreaBoosts.contains('sticker_luck') && suruStickers.contains(id)) {
      final missing = suruStickerIds.where((e) => !suruStickers.contains(e)).toList();
      if (missing.isNotEmpty) id = missing[(stageId + suruDailyStageClears) % missing.length];
    }
    return id;
  }

  static const Map<String, int> homeItemPrices = <String, int>{
    'rug_basic': 0, 'sofa_cream': 180, 'table_round': 120, 'plant_leaf': 90,
    'lamp_moon': 220, 'shelf_wood': 160, 'bed_cloud': 360, 'poster_chain': 0,
  };
  static const Map<String, int> clothesPrices = <String, int>{
    'casual': 0, 'pink_dress': 160, 'blue_knit': 190, 'star_pajama': 240,
  };

  Future<bool> buyHomeItem(String id) async {
    if (ownedHomeItems.contains(id)) return true;
    final price = homeItemPrices[id] ?? 999999;
    if (state.coins < price) return false;
    state.coins -= price;
    ownedHomeItems.add(id);
    placedHomeItems.add(id);
    await _saveSurusuruMeta(); await save(); notifyListeners(); return true;
  }
  Future<bool> buyClothes(String id) async {
    if (ownedClothes.contains(id)) return true;
    final price = clothesPrices[id] ?? 999999;
    if (state.coins < price) return false;
    state.coins -= price; ownedClothes.add(id); equippedClothes = id;
    await _saveSurusuruMeta(); await save(); notifyListeners(); return true;
  }
  Future<void> equipClothes(String id) async { if (!ownedClothes.contains(id)) return; equippedClothes=id; await _saveSurusuruMeta(); notifyListeners(); }
  Future<void> togglePlacedHomeItem(String id) async { if (!ownedHomeItems.contains(id)) return; placedHomeItems.contains(id)?placedHomeItems.remove(id):placedHomeItems.add(id); await _saveSurusuruMeta(); notifyListeners(); }
  Future<int> rewardPuzzleClear(int chain) async {
    final reward = chain + (chain >= 5 ? chain : 0) + (chain >= 8 ? 10 : 0);
    state.coins += reward; puzzleTotalCleared += chain; puzzleBestChain = max(puzzleBestChain, chain);
    if (puzzleBestChain >= 12) { ownedHomeItems.add('poster_chain'); placedHomeItems.add('poster_chain'); }
    await _saveSurusuruMeta(); await save(); notifyListeners(); return reward;
  }
  Future<void> _saveSurusuruMeta() async {
    final prefs=await SharedPreferences.getInstance();
    await prefs.setStringList(_ownedHomeItemsKey, ownedHomeItems.toList());
    await prefs.setStringList(_placedHomeItemsKey, placedHomeItems.toList());
    await prefs.setStringList(_ownedClothesKey, ownedClothes.toList());
    await prefs.setString(_equippedClothesKey, equippedClothes);
    await prefs.setInt(_puzzleBestChainKey, puzzleBestChain);
    await prefs.setInt(_puzzleTotalClearedKey, puzzleTotalCleared);
  }

  final Set<int> discoveredLevels = <int>{};

  String lastDailyClaimDate = '';
  int loginStreak = 0;

  String missionDate = '';
  int missionSpawnCount = 0;
  int missionMergeCount = 0;
  int missionFeaturedSpawnCount = 0;
  int missionOrderCount = 0;
  String missionFeaturedGenerator = 'farm';
  final Set<int> claimedMissions = <int>{};

  int? lastSpawnIndex;
  int? lastMergeIndex;
  int? lastMovedIndex;
  int? lastNewDiscoveryLevel;

  bool tutorialCompleted = false;
  int orderTargetLevel = 2;

  int surusuruBalance = 30;
  final Map<String, int> skillMaterials = <String, int>{'flash': 0, 'breaker': 0, 'spin': 0, 'extract': 0};
  final Map<String, int> skillLevels = <String, int>{'flash': 1, 'breaker': 1, 'spin': 1, 'extract': 1};

  Future<void> load() async {
    try {
      final prefs = await SharedPreferences.getInstance();

      final storedCollection =
          prefs.getStringList(_collectionKey) ?? const <String>[];

      discoveredLevels
        ..clear()
        ..addAll(
          storedCollection
              .map(int.tryParse)
              .whereType<int>()
              .where((level) => level > 0),
        );

      final raw = prefs.getString(_saveKey);

      if (raw != null) {
        final decoded = jsonDecode(raw);

        if (decoded is Map<String, dynamic>) {
          state = GameState.fromJson(decoded);
        } else if (decoded is Map) {
          state = GameState.fromJson(Map<String, dynamic>.from(decoded));
        }
      }
    } catch (_) {
      state = GameState.initial();
    }

    for (final item in state.board) {
      if (item != null && item > 0) {
        discoveredLevels.add(item);
      }
    }

    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
      _collectionKey,
      discoveredLevels.map((e) => e.toString()).toList(),
    );

    claimedLevelRewards
      ..clear()
      ..add(1)
      ..addAll((prefs.getStringList(_claimedLevelRewardsKey) ?? const <String>[])
          .map(int.tryParse).whereType<int>());
    unlockedBoardCells
      ..clear()
      ..addAll((prefs.getStringList(_unlockedBoardCellsKey) ?? const <String>[])
          .map(int.tryParse).whereType<int>());
    clearedStages
      ..clear()
      ..addAll((prefs.getStringList(_clearedStagesKey) ?? const <String>[])
          .map(int.tryParse).whereType<int>());
    unlockedPlaces
      ..clear()
      ..add('home')
      ..addAll(prefs.getStringList(_unlockedPlacesKey) ?? const <String>[]);

    surusuruBalance = prefs.getInt(_surusuruBalanceKey) ?? 30;
    try {
      final raw = prefs.getString(_skillMaterialsKey);
      if (raw != null) { final m = jsonDecode(raw) as Map<String, dynamic>; for (final k in skillMaterials.keys) skillMaterials[k] = (m[k] as num?)?.toInt() ?? 0; }
      final rawLv = prefs.getString(_skillLevelsKey);
      if (rawLv != null) { final m = jsonDecode(rawLv) as Map<String, dynamic>; for (final k in skillLevels.keys) skillLevels[k] = max(1, (m[k] as num?)?.toInt() ?? 1); }
    } catch (_) {}

    stageSecrets.clear();
    for (final raw in prefs.getStringList(_stageSecretsKey) ?? const <String>[]) {
      final parts = raw.split(':');
      if (parts.length != 2) continue;
      final stageId = int.tryParse(parts[0]);
      final secretId = int.tryParse(parts[1]);
      if (stageId != null && secretId != null) {
        stageSecrets.putIfAbsent(stageId, () => <int>{}).add(secretId);
      }
    }
    secretRewardStages
      ..clear()
      ..addAll(
        (prefs.getStringList(_secretRewardStagesKey) ?? const <String>[])
            .map(int.tryParse)
            .whereType<int>(),
      );

    stageRequestSteps.clear();
    for (final rawStep in prefs.getStringList(_stageRequestStepsKey) ?? const <String>[]) {
      final parts = rawStep.split(':');
      if (parts.length != 2) continue;
      final stageId = int.tryParse(parts[0]);
      final step = int.tryParse(parts[1]);
      if (stageId != null && step != null && step >= 0) {
        stageRequestSteps[stageId] = step;
      }
    }

    await _loadDailyData();
    await _loadMissionData();

    tutorialCompleted = prefs.getBool(_tutorialKey) ?? false;
    orderTargetLevel = prefs.getInt(_orderLevelKey) ?? 2;
    final orderPlanVersion = prefs.getInt(_orderPlanVersionKey) ?? 0;
    if (orderPlanVersion < 3) {
      orderTargetLevel = _recommendedFirstOrderTarget;
      await prefs.setInt(_orderLevelKey, orderTargetLevel);
      await prefs.setInt(_orderPlanVersionKey, 3);
    } else if (!_availableOrderTargets.contains(orderTargetLevel)) {
      orderTargetLevel = _availableOrderTargets.first;
    }

    ownedHomeItems.addAll(prefs.getStringList(_ownedHomeItemsKey) ?? const <String>[]);
    placedHomeItems.addAll(prefs.getStringList(_placedHomeItemsKey) ?? const <String>[]);
    ownedClothes.addAll(prefs.getStringList(_ownedClothesKey) ?? const <String>[]);
    equippedClothes = prefs.getString(_equippedClothesKey) ?? equippedClothes;
    puzzleBestChain = prefs.getInt(_puzzleBestChainKey) ?? 0;
    puzzleTotalCleared = prefs.getInt(_puzzleTotalClearedKey) ?? 0;
    suruStickers
      ..clear()
      ..addAll(prefs.getStringList(_suruStickerKey) ?? const <String>[]);
    suruDailyDate = prefs.getString(_suruDailyDateKey) ?? '';
    suruDailyStageClears = prefs.getInt(_suruDailyStageCountKey) ?? 0;
    suruDailyChestClaimed = prefs.getBool(_suruDailyChestClaimedKey) ?? false;
    suruAreaBoosts
      ..clear()
      ..addAll(prefs.getStringList(_suruAreaBoostsKey) ?? const <String>[]);
    suruAreaId = prefs.getInt(_suruAreaIdKey) ?? 1;
    suruBuildCredits = prefs.getInt(_suruBuildCreditsKey) ?? 0;
    await _syncSuruDaily();
    loaded = true;
    notifyListeners();
  }

  Future<void> save() async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.setString(_saveKey, jsonEncode(state.toJson()));
    await prefs.setStringList(
      _collectionKey,
      discoveredLevels.map((e) => e.toString()).toList(),
    );
  }

  String _dayKey(DateTime date) {
    final y = date.year.toString().padLeft(4, '0');
    final m = date.month.toString().padLeft(2, '0');
    final d = date.day.toString().padLeft(2, '0');
    return '$y-$m-$d';
  }

  int get nextDailyStreak {
    final now = DateTime.now();
    final today = _dayKey(now);

    if (lastDailyClaimDate == today) {
      return loginStreak;
    }

    final yesterday = _dayKey(now.subtract(const Duration(days: 1)));

    if (lastDailyClaimDate == yesterday) {
      return loginStreak + 1;
    }

    return 1;
  }

  bool get dailyRewardReady {
    return lastDailyClaimDate != _dayKey(DateTime.now());
  }

  int get nextDailyCoinReward {
    final day = nextDailyStreak.clamp(1, 7);
    return 20 + ((day - 1) * 5);
  }

  int get nextDailyEnergyReward {
    return nextDailyStreak >= 7 ? 20 : 10;
  }

  Future<void> _loadDailyData() async {
    final prefs = await SharedPreferences.getInstance();

    lastDailyClaimDate = prefs.getString(_dailyClaimKey) ?? '';

    loginStreak = prefs.getInt(_dailyStreakKey) ?? 0;
  }

  Future<bool> claimDailyReward() async {
    final now = DateTime.now();
    final today = _dayKey(now);

    if (lastDailyClaimDate == today) {
      return false;
    }

    final yesterday = _dayKey(now.subtract(const Duration(days: 1)));

    if (lastDailyClaimDate == yesterday) {
      loginStreak++;
    } else {
      loginStreak = 1;
    }

    final rewardDay = loginStreak.clamp(1, 7);
    final coins = 20 + ((rewardDay - 1) * 5);
    final energyReward = loginStreak >= 7 ? 20 : 10;

    state.coins += coins;
    state.energy = min(state.maxEnergy, state.energy + energyReward);

    if (loginStreak > 0 && loginStreak % 7 == 0) {
      state.gems += 1;
    }

    lastDailyClaimDate = today;

    final prefs = await SharedPreferences.getInstance();

    await prefs.setString(_dailyClaimKey, lastDailyClaimDate);

    await prefs.setInt(_dailyStreakKey, loginStreak);

    await save();

    notifyListeners();
    return true;
  }

  String levelRewardTitle(int level) {
    switch (level) {
      case 2: return '🐰 最初の住人を迎える';
      case 3: return '🥤 ドリンク屋さんをオープン';
      case 5: return '🍰 スイーツ屋さんをオープン';
      case 6: return '🎀 街の飾りと新しい住人';
      case 7: return '🌸 お花屋さんをオープン';
      case 9: return '🍳 キッチンをオープン';
      case 10: return '✨ 特別な仲間と広場';
      default: return '街の新しい発展';
    }
  }

  Future<bool> claimWorldReward(int level) async {
    if (!canClaimWorldReward(level)) return false;
    claimedLevelRewards.add(level);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_claimedLevelRewardsKey,
        claimedLevelRewards.map((e) => e.toString()).toList());
    notifyListeners();
    return true;
  }

  Future<bool> unlockBoardCell(int index) async {
    if (!canUnlockBoardCell(index)) return false;
    unlockedBoardCells.add(index);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_unlockedBoardCellsKey,
        unlockedBoardCells.map((e) => e.toString()).toList());
    notifyListeners();
    await save();
    return true;
  }

  String get orderGeneratorId {
    final value = orderTargetLevel;
    if (value >= 41) return 'kitchen';
    if (value >= 31) return 'flower';
    if (value >= 21) return 'sweet';
    if (value >= 11) return 'drink';
    return 'farm';
  }

  String get featuredMissionGeneratorId {
    if (generatorUnlocked('kitchen')) return 'kitchen';
    if (generatorUnlocked('flower')) return 'flower';
    if (generatorUnlocked('sweet')) return 'sweet';
    if (generatorUnlocked('drink')) return 'drink';
    return 'farm';
  }

  String get featuredMissionTitle =>
      '${generatorEmoji(featuredMissionGeneratorId)} ${generatorName(featuredMissionGeneratorId)}を4回使う';

  int missionProgress(int id) {
    switch (id) {
      case 1:
        return missionFeaturedSpawnCount;
      case 2:
        return missionMergeCount;
      case 3:
        return missionOrderCount;
      default:
        return 0;
    }
  }

  int missionTarget(int id) {
    switch (id) {
      case 1:
        return 4;
      case 2:
        return 3;
      case 3:
        return 2;
      default:
        return 1;
    }
  }

  int missionReward(int id) {
    switch (id) {
      case 1:
        return 15;
      case 2:
        return 20;
      case 3:
        return 40;
      default:
        return 0;
    }
  }

  bool missionCompleted(int id) {
    return missionProgress(id) >= missionTarget(id);
  }

  bool missionClaimed(int id) {
    return claimedMissions.contains(id);
  }

  bool get hasClaimableMission {
    for (var id = 1; id <= 3; id++) {
      if (missionCompleted(id) && !missionClaimed(id)) {
        return true;
      }
    }
    return false;
  }

  Future<void> _loadMissionData() async {
    final prefs = await SharedPreferences.getInstance();
    final today = _dayKey(DateTime.now());

    missionDate = prefs.getString(_missionDateKey) ?? '';

    if (missionDate != today) {
      missionDate = today;
      missionSpawnCount = 0;
      missionMergeCount = 0;
      missionFeaturedSpawnCount = 0;
      missionOrderCount = 0;
      missionFeaturedGenerator = featuredMissionGeneratorId;
      claimedMissions.clear();

      await _saveMissionData();
      return;
    }

    missionSpawnCount = prefs.getInt(_missionSpawnKey) ?? 0;

    missionMergeCount = prefs.getInt(_missionMergeKey) ?? 0;
    missionFeaturedGenerator = prefs.getString(_missionFeaturedGeneratorKey) ?? featuredMissionGeneratorId;
    if (missionFeaturedGenerator != featuredMissionGeneratorId) {
      missionFeaturedGenerator = featuredMissionGeneratorId;
      missionFeaturedSpawnCount = 0;
    }
    if (missionFeaturedGenerator == featuredMissionGeneratorId) {
      missionFeaturedSpawnCount = prefs.getInt(_missionFeaturedSpawnKey) ?? 0;
    }
    missionOrderCount = prefs.getInt(_missionOrderKey) ?? 0;

    claimedMissions
      ..clear()
      ..addAll(
        (prefs.getStringList(_missionClaimKey) ?? const <String>[])
            .map(int.tryParse)
            .whereType<int>(),
      );
  }

  Future<void> _saveMissionData() async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.setString(_missionDateKey, missionDate);

    await prefs.setInt(_missionSpawnKey, missionSpawnCount);

    await prefs.setInt(_missionMergeKey, missionMergeCount);
    await prefs.setInt(_missionFeaturedSpawnKey, missionFeaturedSpawnCount);
    await prefs.setInt(_missionOrderKey, missionOrderCount);
    await prefs.setString(_missionFeaturedGeneratorKey, featuredMissionGeneratorId);

    await prefs.setStringList(
      _missionClaimKey,
      claimedMissions.map((e) => e.toString()).toList(),
    );
  }

  Future<bool> claimMission(int id) async {
    if (id < 1 || id > 3) {
      return false;
    }

    if (!missionCompleted(id) || missionClaimed(id)) {
      return false;
    }

    claimedMissions.add(id);
    state.coins += missionReward(id);

    await _saveMissionData();
    await save();

    notifyListeners();
    return true;
  }

  Future<void> _recordMissionSpawn(String generatorId) async {
    final today = _dayKey(DateTime.now());

    if (missionDate != today) {
      await _loadMissionData();
    }

    missionSpawnCount++;
    if (missionFeaturedGenerator != featuredMissionGeneratorId) {
      missionFeaturedGenerator = featuredMissionGeneratorId;
      missionFeaturedSpawnCount = 0;
    }
    if (generatorId == featuredMissionGeneratorId) missionFeaturedSpawnCount++;
    await _saveMissionData();
  }

  Future<void> _recordMissionMerge() async {
    final today = _dayKey(DateTime.now());

    if (missionDate != today) {
      await _loadMissionData();
    }

    missionMergeCount++;
    await _saveMissionData();
  }

  bool canBuyWithCoins(int price) {
    return price > 0 && state.coins >= price;
  }

  Future<bool> buyEnergy({required int price, required int amount}) async {
    if (price <= 0 || amount <= 0) {
      return false;
    }

    if (state.coins < price) {
      return false;
    }

    if (state.energy >= state.maxEnergy) {
      return false;
    }

    state.coins -= price;
    state.energy = min(state.maxEnergy, state.energy + amount);

    await save();
    notifyListeners();
    return true;
  }

  Future<bool> buyEnergySmall() {
    return buyEnergy(price: 30, amount: 20);
  }

  Future<bool> buyEnergyLarge() {
    return buyEnergy(price: 70, amount: 50);
  }

  Future<bool> buySurusuru({required int price, required int amount}) async {
    if (price <= 0 || amount <= 0 || state.coins < price) return false;
    state.coins -= price;
    surusuruBalance += amount;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_surusuruBalanceKey, surusuruBalance);
    await save();
    notifyListeners();
    return true;
  }


  int skillLevel(String id) => skillLevels[id] ?? 1;
  int skillMaterial(String id) => skillMaterials[id] ?? 0;
  int skillNeed(String id) => 3 + (skillLevel(id) - 1) * 2;

  Future<void> _saveSkillGrowth() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_skillMaterialsKey, jsonEncode(skillMaterials));
    await prefs.setString(_skillLevelsKey, jsonEncode(skillLevels));
  }

  Future<bool> buySkillMaterial({required String id, required int price, int amount = 1}) async {
    if (!skillMaterials.containsKey(id) || price <= 0 || amount <= 0 || state.coins < price) return false;
    state.coins -= price;
    skillMaterials[id] = (skillMaterials[id] ?? 0) + amount;
    await _saveSkillGrowth(); await save(); notifyListeners(); return true;
  }

  Future<bool> upgradeSkill(String id) async {
    if (!skillLevels.containsKey(id)) return false;
    final need = skillNeed(id);
    if ((skillMaterials[id] ?? 0) < need) return false;
    skillMaterials[id] = (skillMaterials[id] ?? 0) - need;
    skillLevels[id] = (skillLevels[id] ?? 1) + 1;
    await _saveSkillGrowth(); notifyListeners(); return true;
  }

  Future<void> awardSurusuruPlayCoins(int rewardValue) async {
    if (rewardValue <= 0) return;
    final earned = max(1, rewardValue ~/ 25);
    state.coins += earned; await save(); notifyListeners();
  }

  bool consumeSurusuru() {
    if (surusuruBalance <= 0) return false;
    surusuruBalance--;
    SharedPreferences.getInstance().then(
      (prefs) => prefs.setInt(_surusuruBalanceKey, surusuruBalance),
    );
    notifyListeners();
    return true;
  }

  bool isDiscovered(int level) {
    return discoveredLevels.contains(level);
  }

  bool _discover(int level) {
    if (level <= 0) return false;

    final isNew = discoveredLevels.add(level);

    if (isNew) {
      lastNewDiscoveryLevel = level;
    }

    return isNew;
  }

  void clearNewDiscovery() {
    lastNewDiscoveryLevel = null;
  }

  int countLevel(int level) {
    return state.board.where((item) => item == level).length;
  }

  int xpNeeded(int level) {
    return 30 + ((level - 1) * 20);
  }

  void _addXp(int amount) {
    state.xp += amount;

    while (state.xp >= xpNeeded(state.level)) {
      state.xp -= xpNeeded(state.level);
      state.level++;
      state.coins += 30;
      state.energy = min(state.maxEnergy, state.energy + 10);
    }
  }

  int _generatorBaseLevel(String id) {
    switch (id) {
      case 'drink': return 11;
      case 'sweet': return 21;
      case 'flower': return 31;
      case 'kitchen': return 41;
      default: return 1;
    }
  }

  String generatorEmoji(String id) {
    switch (id) {
      case 'drink': return '🥤';
      case 'sweet': return '🍰';
      case 'flower': return '🌸';
      case 'kitchen': return '🍳';
      default: return '🧺';
    }
  }

  String generatorName(String id) {
    switch (id) {
      case 'drink': return 'ドリンク';
      case 'sweet': return 'スイーツ';
      case 'flower': return 'フラワー';
      case 'kitchen': return 'キッチン';
      default: return 'ファーム';
    }
  }

  Future<int?> spawnFromGenerator([String generatorId = 'farm']) async {
    if (!generatorUnlocked(generatorId) || state.energy <= 0) return null;

    final emptyCells = <int>[];
    for (var i = 0; i < state.board.length; i++) {
      if (state.board[i] == null && !isReservedCell(i)) emptyCells.add(i);
    }
    if (emptyCells.isEmpty) return null;

    final origin = generatorCells[generatorId] ?? generatorCell;
    emptyCells.sort((a, b) {
      final ar = (a ~/ GameState.boardColumns) - (origin ~/ GameState.boardColumns);
      final ac = (a % GameState.boardColumns) - (origin % GameState.boardColumns);
      final br = (b ~/ GameState.boardColumns) - (origin ~/ GameState.boardColumns);
      final bc = (b % GameState.boardColumns) - (origin % GameState.boardColumns);
      return (ar.abs() + ac.abs()).compareTo(br.abs() + bc.abs());
    });
    final near = emptyCells.take(min(8, emptyCells.length)).toList();
    final target = near[_random.nextInt(near.length)];

    final base = _generatorBaseLevel(generatorId);
    final roll = _random.nextInt(100);
    final value = (!tutorialCompleted && generatorId == 'farm')
        ? 1
        : roll < 88 ? base : base + 1;

    state.board[target] = value;
    _discover(value);
    state.energy--;
    await _recordMissionSpawn(generatorId);
    lastSpawnIndex = target;
    lastMergeIndex = null;
    lastMovedIndex = null;
    notifyListeners();
    await save();
    return target;
  }

  int _chainMax(int item) {
    if (item >= 31 && item <= 36) return 36;
    if (item >= 21 && item <= 26) return 26;
    if (item >= 11 && item <= 16) return 16;
    return 6;
  }

  static const List<int> fourSeriesBaseLevels = <int>[1, 2, 3, 4, 5];
  static const int fourSeriesTargetFill = GameState.boardSize;

  int _prototypeSeedForStage(int stageId) => stageId * 7919 + 1618;

  int _randomPuzzleItem(Random random, {int? avoid}) {
    final candidates = slidePuzzleItemTypes
        .where((value) => value != avoid)
        .toList(growable: false);
    return candidates[random.nextInt(candidates.length)];
  }

  bool _hasHorizontalPair() {
    for (var row = 0; row < GameState.boardRows; row++) {
      for (var col = 0; col < GameState.boardColumns - 1; col++) {
        final a = row * GameState.boardColumns + col;
        final b = a + 1;
        if (state.board[a] != null && state.board[a] == state.board[b]) {
          return true;
        }
      }
    }
    return false;
  }

  bool canSlideMove(int from, int to) {
    if (from < 0 || to < 0 ||
        from >= state.board.length || to >= state.board.length) {
      return false;
    }
    final fromRow = from ~/ GameState.boardColumns;
    final toRow = to ~/ GameState.boardColumns;
    final fromCol = from % GameState.boardColumns;
    final toCol = to % GameState.boardColumns;
    final adjacent = (fromRow - toRow).abs() + (fromCol - toCol).abs() == 1;
    return adjacent && state.board[from] != null && state.board[to] != null;
  }

  bool canSlideClear(int from, int to) {
    if (!canSlideMove(from, to)) return false;
    return state.board[from] == state.board[to];
  }

  bool get hasHorizontalMove => _hasHorizontalPair();

  Future<void> prepareSlidePuzzle(int stageId, {bool force = false}) async {
    if (!force &&
        activePuzzleStageId == stageId &&
        state.board.length == GameState.boardSize &&
        state.board.every((value) => value != null)) {
      return;
    }

    final random = Random(_prototypeSeedForStage(stageId));
    state.board
      ..clear()
      ..addAll(List<int?>.filled(GameState.boardSize, null));

    // Generate a dense board with five types. Counts are intentionally not
    // balanced; the only generation rule is to avoid an automatic vertical
    // collision before the player makes the first move.
    for (var row = 0; row < GameState.boardRows; row++) {
      for (var col = 0; col < GameState.boardColumns; col++) {
        final index = row * GameState.boardColumns + col;
        final above = row == 0
            ? null
            : state.board[(row - 1) * GameState.boardColumns + col];
        state.board[index] = _randomPuzzleItem(random, avoid: above);
      }
    }

    // Every stage starts playable while keeping its stage-specific layout.
    if (!_hasHorizontalPair()) {
      final row = GameState.boardRows - 1;
      final left = row * GameState.boardColumns;
      final aboveLeft = state.board[left - GameState.boardColumns];
      final aboveRight = state.board[left + 1 - GameState.boardColumns];
      final choices = slidePuzzleItemTypes
          .where((v) => v != aboveLeft && v != aboveRight)
          .toList();
      final forced = choices[random.nextInt(choices.length)];
      state.board[left] = forced;
      state.board[left + 1] = forced;
    }

    for (var col = 0; col < GameState.boardColumns; col++) {
      nextItemsByColumn[col] = _randomPuzzleItem(random);
    }

    activePuzzleStageId = stageId;
    lastChainCount = 0;
    activeChainStep = 0;
    chainFlashCells.clear();
    lastSpawnIndex = null;
    lastMergeIndex = null;
    lastMovedIndex = null;
    notifyListeners();
    await save();
  }

  // Kept as a compatibility entry point for older screens/routes.
  Future<void> ensureFourSeriesBoard() async {
    await prepareSlidePuzzle(activePuzzleStageId < 1 ? 1 : activePuzzleStageId);
  }

  Future<void> refillFourSeriesBoard({int targetFill = fourSeriesTargetFill}) async {
    // V16.18 refills are column-based and happen only after a horizontal clear.
    if (state.board.any((value) => value == null)) {
      await _settleAllColumns(Random());
      notifyListeners();
      await save();
    }
  }

  int _takeNext(int column, Random random) {
    final value = nextItemsByColumn[column];
    nextItemsByColumn[column] = _randomPuzzleItem(random);
    return value;
  }

  Future<int> _settleAllColumns(Random random, {Set<int>? columns}) async {
    // V16.18.3 gravity rules:
    // 1) After the manual pair disappears, every affected column collapses
    //    downward in ONE step (not one cell at a time).
    // 2) Existing board pieces NEVER chain merely because the collapse made
    //    two equal pieces touch.
    // 3) The empty cells at the top are then filled from NEXT.
    // 4) A vertical CHAIN occurs only when a newly supplied piece touches an
    //    existing board piece of the same type. New-vs-new is not a chain.
    var autoClears = 0;
    final targetColumns = columns ??
        <int>{for (var col = 0; col < GameState.boardColumns; col++) col};

    // Track which cells currently contain pieces that entered from NEXT during
    // this settle sequence. This lets us distinguish "new piece vs board" from
    // "two board pieces happened to meet after gravity".
    final fresh = List<bool>.filled(GameState.boardSize, false);

    void collapseColumns() {
      for (final col in targetColumns) {
        final values = <int>[];
        final flags = <bool>[];
        for (var row = GameState.boardRows - 1; row >= 0; row--) {
          final index = row * GameState.boardColumns + col;
          final value = state.board[index];
          if (value != null) {
            values.add(value);
            flags.add(fresh[index]);
          }
        }

        for (var row = 0; row < GameState.boardRows; row++) {
          final index = row * GameState.boardColumns + col;
          state.board[index] = null;
          fresh[index] = false;
        }

        for (var i = 0; i < values.length; i++) {
          final row = GameState.boardRows - 1 - i;
          final index = row * GameState.boardColumns + col;
          state.board[index] = values[i];
          fresh[index] = flags[i];
        }
      }
    }

    void fillFromNext() {
      for (final col in targetColumns) {
        for (var row = GameState.boardRows - 1; row >= 0; row--) {
          final index = row * GameState.boardColumns + col;
          if (state.board[index] != null) continue;
          state.board[index] = _takeNext(col, random);
          fresh[index] = true;
        }
      }
    }

    // First make the board visibly close the holes as one gravity movement.
    collapseColumns();
    notifyListeners();
    await Future<void>.delayed(const Duration(milliseconds: 155));

    // Then bring the replacement pieces in from the top together, keeping the
    // pace quick instead of dropping them one-by-one.
    fillFromNext();
    notifyListeners();
    await Future<void>.delayed(const Duration(milliseconds: 165));

    var safety = 0;
    while (safety < 40) {
      safety++;

      // Only a NEW-vs-EXISTING equal vertical pair may chain. Equal pairs made
      // of two old pieces or two freshly supplied pieces intentionally stay.
      int? upperMatch;
      int? lowerMatch;
      for (final col in targetColumns) {
        for (var row = 0; row < GameState.boardRows - 1; row++) {
          final upper = row * GameState.boardColumns + col;
          final lower = (row + 1) * GameState.boardColumns + col;
          final a = state.board[upper];
          final b = state.board[lower];
          if (a == null || b == null || a != b) continue;
          if (fresh[upper] == fresh[lower]) continue;
          upperMatch = upper;
          lowerMatch = lower;
          break;
        }
        if (upperMatch != null) break;
      }

      if (upperMatch == null || lowerMatch == null) break;

      autoClears++;
      activeChainStep = 1 + autoClears;
      lastChainCount = activeChainStep;
      chainFlashCells
        ..clear()
        ..addAll(<int>{upperMatch, lowerMatch});
      notifyListeners();
      await Future<void>.delayed(const Duration(milliseconds: 175));

      state.board[upperMatch] = null;
      state.board[lowerMatch] = null;
      fresh[upperMatch] = false;
      fresh[lowerMatch] = false;
      chainFlashCells.clear();
      notifyListeners();
      await Future<void>.delayed(const Duration(milliseconds: 90));

      // Close the new holes at once, then refill at once. The fresh flags move
      // with their pieces so another NEW-vs-board collision can continue the
      // chain naturally.
      collapseColumns();
      notifyListeners();
      await Future<void>.delayed(const Duration(milliseconds: 130));

      fillFromNext();
      notifyListeners();
      await Future<void>.delayed(const Duration(milliseconds: 145));
    }

    chainFlashCells.clear();
    activeChainStep = 0;
    return autoClears;
  }

  Future<bool> moveOrMerge({required int from, required int to}) async {
    if (!canSlideMove(from, to)) return false;

    // Different pieces simply swap. This is the free one-cell movement rule:
    // up/down/left/right are all valid and do not trigger gravity or CHAIN.
    if (state.board[from] != state.board[to]) {
      final temp = state.board[from];
      state.board[from] = state.board[to];
      state.board[to] = temp;
      lastChainCount = 0;
      activeChainStep = 0;
      chainFlashCells.clear();
      lastMovedIndex = to;
      notifyListeners();
      await save();
      return true;
    }

    final fromCol = from % GameState.boardColumns;
    final toCol = to % GameState.boardColumns;
    chainFlashCells
      ..clear()
      ..addAll(<int>{from, to});
    activeChainStep = 1;
    notifyListeners();
    await Future<void>.delayed(const Duration(milliseconds: 190));
    state.board[from] = null;
    state.board[to] = null;
    chainFlashCells.clear();
    notifyListeners();
    await Future<void>.delayed(const Duration(milliseconds: 170));

    final random = Random();
    final autoClears = await _settleAllColumns(
      random,
      columns: <int>{fromCol, toCol},
    );

    // Keep the prototype from dead-ending with no horizontal move. This only
    // runs when the random refill would otherwise leave the board unplayable.
    if (!_hasHorizontalPair()) {
      final row = GameState.boardRows - 1;
      final col = random.nextInt(GameState.boardColumns - 1);
      final left = row * GameState.boardColumns + col;
      final right = left + 1;
      state.board[right] = state.board[left];
      notifyListeners();
      await Future<void>.delayed(const Duration(milliseconds: 80));
    }

    // The manual horizontal clear is the first link. Only gravity-created
    // vertical collisions extend the visible CHAIN count.
    lastChainCount = autoClears == 0 ? 0 : 1 + autoClears;
    activeChainStep = 0;
    chainFlashCells.clear();
    lastMergeIndex = null;
    lastSpawnIndex = null;
    lastMovedIndex = null;

    await _recordMissionMerge();
    notifyListeners();
    await save();
    return true;
  }

  int get _recommendedFirstOrderTarget {
    switch (featuredMissionGeneratorId) {
      case 'kitchen': return 42;
      case 'flower': return 32;
      case 'sweet': return 22;
      case 'drink': return 12;
      default: return 2;
    }
  }

  List<int> get _availableOrderTargets {
    final chains = <int>[2];
    if (generatorUnlocked('drink')) chains.insert(0, 12);
    if (generatorUnlocked('sweet')) chains.insert(0, 22);
    if (generatorUnlocked('flower')) chains.insert(0, 32);
    if (generatorUnlocked('kitchen')) chains.insert(0, 42);

    final result = <int>[];
    for (var tier = 0; tier < 3; tier++) {
      for (final baseTarget in chains) {
        final value = baseTarget + tier;
        final chainMax = baseTarget < 10 ? 6 : (baseTarget ~/ 10) * 10 + 5;
        if (value <= chainMax) result.add(value);
      }
    }
    return result;
  }

  int get orderSourceLevel => orderTargetLevel - 1;
  bool get orderReady => countLevel(orderTargetLevel) >= 1;
  bool get starterOrderReady => orderReady;
  int get orderRewardCoins => 24 + ((orderTargetLevel % 10) * 9) + state.level * 2;
  int get orderRewardXp => 12 + ((orderTargetLevel % 10) * 5);


  Future<bool> discoverStageSecret(int stageId, int secretId) async {
    final secrets = stageSecrets.putIfAbsent(stageId, () => <int>{});
    if (!secrets.add(secretId)) return false;

    if (secrets.length >= 5 && secretRewardStages.add(stageId)) {
      state.coins += 50;
    }

    final prefs = await SharedPreferences.getInstance();
    final encoded = <String>[];
    for (final entry in stageSecrets.entries) {
      for (final id in entry.value) {
        encoded.add('${entry.key}:$id');
      }
    }
    await prefs.setStringList(_stageSecretsKey, encoded);
    await prefs.setStringList(
      _secretRewardStagesKey,
      secretRewardStages.map((e) => e.toString()).toList(),
    );
    notifyListeners();
    await save();
    return true;
  }

  bool boardHasRequirements(Map<int, int> requirements) {
    for (final entry in requirements.entries) {
      if (countLevel(entry.key) < entry.value) return false;
    }
    return true;
  }

  Future<bool> claimStageRequirement({
    required int stageId,
    required Map<int, int> requirements,
  }) async {
    if (!boardHasRequirements(requirements)) return false;

    for (final entry in requirements.entries) {
      var remaining = entry.value;
      for (var i = 0; i < state.board.length && remaining > 0; i++) {
        if (state.board[i] == entry.key) {
          state.board[i] = null;
          remaining--;
        }
      }
    }

    state.coins += 16 + stageId * 2;
    _addXp(10 + (stageId ~/ 2));
    missionOrderCount++;

    final currentStep = stageRequestStep(stageId);
    final nextStep = currentStep + 1;
    final stageComplete = nextStep >= stageRequestCountForStage(stageId);

    if (stageComplete) {
      stageRequestSteps.remove(stageId);
      clearedStages.add(stageId);
    } else {
      stageRequestSteps[stageId] = nextStep;
    }

    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
      _stageRequestStepsKey,
      stageRequestSteps.entries.map((e) => '${e.key}:${e.value}').toList(),
    );
    if (stageComplete) {
      await prefs.setStringList(
        _clearedStagesKey,
        clearedStages.map((e) => e.toString()).toList(),
      );
    }

    await _saveMissionData();
    lastMergeIndex = null;
    lastSpawnIndex = null;
    lastMovedIndex = null;
    notifyListeners();
    await save();
    await refillFourSeriesBoard();
    return true;
  }

  Future<void> completeRpgStage(int stageId) async {
    await _syncSuruDaily();
    final firstClear = !clearedStages.contains(stageId);
    clearedStages.add(stageId);
    final baseCoins = 100 + stageId * 10;
    state.coins += baseCoins + suruTreasureCoinBonus;
    // Adventure is the renewable source of SURUSURU. First clear pays more.
    surusuruBalance += firstClear ? 12 : 3;
    _addXp(20 + stageId * 2);

    final stickerId = _pickStageSticker(stageId);
    final isNewSticker = suruStickers.add(stickerId);
    if (!isNewSticker) state.coins += 25;
    lastTreasureRewardText = isNewSticker
        ? '${suruStickerEmoji[stickerId] ?? '✨'} ${suruStickerName[stickerId] ?? stickerId} シールGET!'
        : '${suruStickerEmoji[stickerId] ?? '✨'} シール重複 → 🪙 +25';

    suruDailyStageClears++;
    if (firstClear && suruAreaBoosts.length < 3) suruBuildCredits = min(3, suruBuildCredits + 1);

    // 10 stages form one adventure area. Builds reset at the area's exit.
    if (firstClear && stageId % 10 == 0) {
      suruAreaBoosts.clear();
      suruBuildCredits = 0;
      suruAreaId = stageId ~/ 10 + 1;
      lastTreasureRewardText += '\nAREA CLEAR! 次エリアではビルドがリセット';
    }

    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_clearedStagesKey, clearedStages.map((e) => e.toString()).toList());
    await prefs.setInt(_surusuruBalanceKey, surusuruBalance);
    await _saveSuruMetaLoop();
    await save();
    notifyListeners();
  }

  Future<bool> claimStageOrder({required int stageId, required int targetLevel, required int targetCount}) async {
    if (countLevel(targetLevel) < targetCount) return false;
    var remaining = targetCount;
    for (var i = 0; i < state.board.length && remaining > 0; i++) {
      if (state.board[i] == targetLevel) {
        state.board[i] = null;
        remaining--;
      }
    }
    state.coins += 35 + stageId * 3;
    _addXp(18 + stageId);
    missionOrderCount++;
    clearedStages.add(stageId);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_clearedStagesKey, clearedStages.map((e) => e.toString()).toList());
    await prefs.setInt(_surusuruBalanceKey, surusuruBalance);
    await _saveMissionData();
    lastMergeIndex = null;
    lastSpawnIndex = null;
    lastMovedIndex = null;
    notifyListeners();
    await save();
    return true;
  }

  Future<bool> claimCurrentOrder() async {
    if (!orderReady) return false;
    for (var i = 0; i < state.board.length; i++) {
      if (state.board[i] == orderTargetLevel) {
        state.board[i] = null;
        break;
      }
    }
    state.coins += orderRewardCoins;
    _addXp(orderRewardXp);
    missionOrderCount++;
    await _saveMissionData();

    final choices = _availableOrderTargets;
    final current = choices.indexOf(orderTargetLevel);
    orderTargetLevel = choices[(current + 1) % choices.length];
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_orderLevelKey, orderTargetLevel);
    lastMergeIndex = null;
    lastSpawnIndex = null;
    lastMovedIndex = null;
    notifyListeners();
    await save();
    return true;
  }

  Future<bool> claimStarterOrder() => claimCurrentOrder();

  Future<void> completeTutorial() async {
    tutorialCompleted = true;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_tutorialKey, true);
    notifyListeners();
  }

  Future<void> reset() async {
    await resetAllProgress();
  }

  Future<void> resetAllProgress() async {
    final prefs = await SharedPreferences.getInstance();
    for (final key in <String>[
      _saveKey, _collectionKey, _dailyClaimKey, _dailyStreakKey,
      _missionDateKey, _missionSpawnKey, _missionMergeKey, _missionFeaturedSpawnKey, _missionOrderKey, _missionFeaturedGeneratorKey, _missionClaimKey,
      _tutorialKey, _orderLevelKey, _orderPlanVersionKey, _claimedLevelRewardsKey, _unlockedBoardCellsKey, _clearedStagesKey, _unlockedPlacesKey, _stageRequestStepsKey, _stageSecretsKey, _secretRewardStagesKey,
      _ownedHomeItemsKey, _placedHomeItemsKey, _ownedClothesKey, _equippedClothesKey, _puzzleBestChainKey, _puzzleTotalClearedKey,
      _suruStickerKey, _suruDailyDateKey, _suruDailyStageCountKey, _suruDailyChestClaimedKey, _suruAreaBoostsKey, _suruAreaIdKey, _suruBuildCreditsKey,
      'surusuru_camp_world_v2', 'surusuru_camp_wood_v2', 'surusuru_camp_expansion_v2',
    ]) {
      await prefs.remove(key);
    }
    state = GameState.initial();
    discoveredLevels.clear();
    lastDailyClaimDate = '';
    loginStreak = 0;
    missionDate = '';
    missionSpawnCount = 0;
    missionMergeCount = 0;
    missionFeaturedSpawnCount = 0;
    missionOrderCount = 0;
    missionFeaturedGenerator = 'farm';
    claimedMissions.clear();
    claimedLevelRewards
      ..clear()
      ..add(1);
    unlockedBoardCells.clear();
    clearedStages.clear();
    unlockedPlaces
      ..clear()
      ..add('home');
    stageRequestSteps.clear();
    stageSecrets.clear();
    secretRewardStages.clear();
    ownedHomeItems
      ..clear()
      ..add('rug_basic');
    placedHomeItems
      ..clear()
      ..add('rug_basic');
    ownedClothes
      ..clear()
      ..add('casual');
    equippedClothes = 'casual';
    puzzleBestChain = 0;
    puzzleTotalCleared = 0;
    suruStickers.clear();
    suruDailyDate = '';
    suruDailyStageClears = 0;
    suruDailyChestClaimed = false;
    suruAreaBoosts.clear();
    suruAreaId = 1;
    suruBuildCredits = 0;
    lastTreasureRewardText = '';
    tutorialCompleted = false;
    orderTargetLevel = 2;
    lastSpawnIndex = null;
    lastMergeIndex = null;
    lastMovedIndex = null;
    lastNewDiscoveryLevel = null;
    loaded = true;
    notifyListeners();
    await save();
    activePuzzleStageId = -1;
    lastChainCount = 0;
    for (var col = 0; col < nextItemsByColumn.length; col++) {
      nextItemsByColumn[col] = 1;
    }
  }
}
