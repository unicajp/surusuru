import 'package:flutter/material.dart';
import '../game/game_controller.dart';
import '../sfx_manager.dart';
import '../widgets/game_bottom_nav.dart';
import 'rpg_home_screen.dart';
import 'shop_screen.dart';
import 'stage_map_screen.dart';
import 'surusuru_play_screen.dart';

class TrainingScreen extends StatelessWidget {
  final GameController controller;
  const TrainingScreen({super.key, required this.controller});
  void _replace(BuildContext c, Widget w){SfxManager.instance.tap();Navigator.of(c).pushReplacement(MaterialPageRoute(builder:(_)=>w));}
  static const skills = [
    ('flash','一閃','横へ鋭く払う','⚡','群れ・小型に強い'),
    ('breaker','兜割り','上から下へ叩く','🔨','殻・木箱に強い'),
    ('spin','回転斬り','円を描く','🌀','密集した敵に強い'),
    ('extract','引き抜き斬り','食い込み→逆方向へ引く','⚔️','重量・BOSSに強い'),
  ];
  @override Widget build(BuildContext context)=>Scaffold(
    backgroundColor:const Color(0xFFF7F1E8),
    appBar:AppBar(title:const Text('技の育成',style:TextStyle(fontWeight:FontWeight.w900)),backgroundColor:const Color(0xFFF7F1E8),foregroundColor:const Color(0xFF3E3229),elevation:0),
    body:AnimatedBuilder(animation:controller,builder:(context,_){return ListView(padding:const EdgeInsets.all(14),children:[
      Container(padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(18)),child:const Text('基本操作の速さは育成で変わりません。\n技の威力と相性を育てて、敵ギミックを攻略します。',style:TextStyle(fontWeight:FontWeight.w800,height:1.5))),
      const SizedBox(height:12),
      ...skills.map((s){final lv=controller.skillLevel(s.$1), have=controller.skillMaterial(s.$1), need=controller.skillNeed(s.$1);return Card(margin:const EdgeInsets.only(bottom:10),child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Row(children:[Text(s.$4,style:const TextStyle(fontSize:30)),const SizedBox(width:10),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(s.$2,style:const TextStyle(fontSize:19,fontWeight:FontWeight.w900)),Text('${s.$3}　・　${s.$5}',style:const TextStyle(fontSize:12,fontWeight:FontWeight.w700,color:Color(0xFF7C6E63)))])),Text('Lv.$lv',style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900))]),
        const SizedBox(height:10),Text('威力 ${(100+(lv-1)*12)}%　　素材 $have / $need',style:const TextStyle(fontWeight:FontWeight.w800)),const SizedBox(height:7),LinearProgressIndicator(value:(have/need).clamp(0,1),minHeight:8,borderRadius:BorderRadius.circular(99)),const SizedBox(height:10),
        SizedBox(
          width: double.infinity,
          child: FilledButton(
            onPressed: have >= need
                ? () async {
                    final ok = await controller.upgradeSkill(s.$1);
                    if (!context.mounted) return;
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          ok
                              ? '${s.$2} が Lv.${controller.skillLevel(s.$1)} になりました！'
                              : '素材が足りません',
                        ),
                      ),
                    );
                  }
                : null,
            child: Text('素材 $need で強化'),
          ),
        )
      ])));}),
      const SizedBox(height:8),const Text('Lv.5 / 10 などの節目では、今後「衝撃波」「巻き込み」などの派生効果を解放できる設計です。',style:TextStyle(fontSize:12,color:Color(0xFF7C6E63),fontWeight:FontWeight.w700))
    ]);}),
    bottomNavigationBar:GameBottomNav(active:'training',onAdventure:()=>_replace(context,StageMapScreen(controller:controller)),onShop:()=>_replace(context,ShopScreen(controller:controller)),onSurusuru:()=>_replace(context,SurusuruPlayScreen(controller:controller)),onTraining:(){},onMap:()=>_replace(context,RpgHomeScreen(controller:controller)))
  );
}
