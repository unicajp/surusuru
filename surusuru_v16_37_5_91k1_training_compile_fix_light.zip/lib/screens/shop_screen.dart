import 'package:flutter/material.dart';
import '../game/game_controller.dart';
import '../sfx_manager.dart';
import '../widgets/game_bottom_nav.dart';
import 'rpg_home_screen.dart';import 'stage_map_screen.dart';import 'surusuru_play_screen.dart';import 'training_screen.dart';
class ShopScreen extends StatelessWidget{
 final GameController controller; const ShopScreen({super.key,required this.controller});
 void _replace(BuildContext c,Widget w)=>Navigator.of(c).pushReplacement(MaterialPageRoute(builder:(_)=>w));
 Future<void> _buy(BuildContext c,String id,String name,int price)async{SfxManager.instance.tap();final ok=await controller.buySkillMaterial(id:id,price:price);if(!c.mounted)return;ScaffoldMessenger.of(c).showSnackBar(SnackBar(content:Text(ok?'$name を購入しました！':'コインが足りません')));}
 @override Widget build(BuildContext context)=>Scaffold(backgroundColor:const Color(0xFFFFF9F5),appBar:AppBar(title:const Text('ショップ',style:TextStyle(fontWeight:FontWeight.w900)),backgroundColor:const Color(0xFFFFF9F5),foregroundColor:const Color(0xFF674F49),elevation:0),body:AnimatedBuilder(animation:controller,builder:(c,_){final coins=controller.state.coins;return ListView(padding:const EdgeInsets.all(14),children:[
  Row(children:[_pill('🪙 $coins'),const SizedBox(width:8),_pill('✦ スルスル ${controller.surusuruBalance}')]),const SizedBox(height:14),
  const Text('強化素材',style:TextStyle(fontSize:21,fontWeight:FontWeight.w900)),const Text('スルスルを遊んで稼いだコインで、育てたい技の素材を選びます。',style:TextStyle(fontWeight:FontWeight.w700,color:Color(0xFF806B63))),const SizedBox(height:10),
  _item(c,'flash','⚡','一閃のかけら',25),_item(c,'breaker','🔨','破砕のかけら',25),_item(c,'spin','🌀','回転のかけら',25),_item(c,'extract','⚔️','引抜のかけら',30),
  const SizedBox(height:18),Container(padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:const Color(0xFFFFF2C9),borderRadius:BorderRadius.circular(18),border:Border.all(color:const Color(0xFFE9C85B))),child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('✦ スルスル',style:TextStyle(fontSize:19,fontWeight:FontWeight.w900)),SizedBox(height:5),Text('冒険クリアで入手。将来はストア課金でも追加購入できる通貨にします。\n※この試作では実際の決済処理はまだ接続していません。',style:TextStyle(fontWeight:FontWeight.w700,height:1.45))]))
 ]);}),bottomNavigationBar:GameBottomNav(active:'shop',onAdventure:()=>_replace(context,StageMapScreen(controller:controller)),onShop:(){},onSurusuru:()=>_replace(context,SurusuruPlayScreen(controller:controller)),onTraining:()=>_replace(context,TrainingScreen(controller:controller)),onMap:()=>_replace(context,RpgHomeScreen(controller:controller))));
 Widget _pill(String t)=>Container(padding:const EdgeInsets.symmetric(horizontal:12,vertical:8),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(99)),child:Text(t,style:const TextStyle(fontWeight:FontWeight.w900)));
 Widget _item(BuildContext c,String id,String icon,String name,int price)=>Card(child:ListTile(leading:Text(icon,style:const TextStyle(fontSize:28)),title:Text(name,style:const TextStyle(fontWeight:FontWeight.w900)),subtitle:Text('所持 ${controller.skillMaterial(id)}'),trailing:FilledButton(onPressed:controller.state.coins>=price?()=>_buy(c,id,name,price):null,child:Text('🪙 $price'))));
}
